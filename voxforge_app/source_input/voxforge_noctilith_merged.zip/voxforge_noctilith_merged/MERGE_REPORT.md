# VoxForge + Noctilith Merge Report

This package uses **VoxForge** as the main platform branch and imports the stronger Noctilith simulation systems into it.

## Added / migrated from Noctilith

### Advanced simulation pipeline
- `engine/sim/entropy.py`
- `engine/sim/reactions.py`
- `engine/sim/material_degradation.py`
- `engine/sim/fracture.py`
- `engine/sim/thermal_coupler.py`
- `engine/sim/entropy_coupler.py`
- `engine/sim/world_reaction.py`
- `engine/sim/debris_execution.py`
- `engine/sim/debris_world_coupling.py`
- `engine/sim/local_material_map.py`
- `engine/sim/quantized_field_ops.py`
- patched `engine/sim/material_profiles.py`

### Debris/entities
- `engine/entities/debris_dynamics.py`

### World helpers
- `engine/world/meshing.py`
- `engine/world/save_load.py`
- `engine/world/persistence_damage.py`
- `engine/world/noctilith_chunk.py`
- `engine/world/noctilith_gen.py`

### Tools
- `engine/tools/benchmark.py`
- `engine/tools/golden_replay.py`
- `engine/tools/damage_overlay.py`

### Field/simulation support
- `engine/space3d.py`
- `engine/multiscale.py`
- `engine/vision.py`
- `engine/io_utils.py`
- `engine/voxel_registry.py`

## Import changes

Original Noctilith imports like `from noctilith.sim.fracture import FractureBridge` were converted to platform imports like `from engine.sim.fracture import FractureBridge`.

## Compatibility note

The original Noctilith world chunk model does not overwrite VoxForge's newer chunk system. It is available as `NoctilithChunkData`, `NoctilithChunkManager`, and `NoctilithTerrainGen`.

## Test command

```bash
cd voxforge
python -m pytest -q
```
