# VoxForge Platform — Milestone A

> *"Noctilith / VoxForge je modulární voxelová platforma pro tvorbu 3D světů,
> her, fyzikálních sandboxů a simulačních scén."*
> — Blueprint §20

## Co je Milestone A

Kompletní implementace **Blueprint §19 — Vox Engine Platform Skeleton**.
Všechny soubory, všechny scénáře, fungující demo.

## Struktura

```
voxforge/
├── engine/
│   ├── core/
│   │   ├── events.py        ← EventBus, EventType (Noctilith v2.2)
│   │   ├── ecs.py           ← World, Entity (Noctilith v2.2)
│   │   └── scheduler.py     ← Scheduler, SimModule (NOVÝ)
│   ├── world/
│   │   ├── voxel.py         ← Material, MaterialRegistry, VoxelData (NOVÝ)
│   │   ├── chunk.py         ← Chunk, ChunkStorage (NOVÝ)
│   │   └── world.py         ← World manager (NOVÝ)
│   ├── sim/
│   │   ├── thermal.py       ← ThermalGrid (Noctilith v2.2)
│   │   └── fluid.py         ← FluidGrid, FluidSimulation Level 1+2 (NOVÝ)
│   └── builder/
│       ├── parts.py         ← PartDef, BuilderObject, CATALOG (NOVÝ)
│       └── builder_core.py  ← Builder base (Noctilith v2.2)
├── apps/
│   ├── studio_stub.py       ← CLI editor (NOVÝ)
│   └── player_stub.py       ← Headless player (NOVÝ)
├── demos/
│   └── milestone_a_demo.py  ← Kompletní §19 scénář (NOVÝ)
└── content/
    └── materials/           ← (ready pro asset soubory)
```

## Spuštění demo

```bash
cd voxforge
pip install numpy
python demos/milestone_a_demo.py
```

**Výstup** (25.6ms total):
```
✓ 1. Svět vytvořen       World(name='MilestoneA', seed=1337)
✓ 2. Voxely položeny     676 voxelů (stone, concrete, wood)
✓ 3. Voda přidána        volume=32.40
✓ 4. Voda proteče dolů   50 ticků, 5 fluid events
✓ 5. Teplo → materiál    lava@(8,2,8) → thermal diffusion
✓ 6. Damage → fraktura   damage field coupling, fracture events
✓ 7. Builder save/load   8-part pump system
```

## Klíčové nové moduly

### `engine/world/voxel.py` — Materiálový systém
12 výchozích materiálů s plnými fyzikálními vlastnostmi (blueprint §9):
```python
from engine.world.voxel import MATERIALS
stone = MATERIALS.get_by_name("stone")
print(stone.fracture_threshold())  # 0.575
print(stone.thermal_conductivity)  # 0.30
```

### `engine/world/chunk.py` — Chunk systém
```python
chunk = Chunk(cx=0, cy=0, cz=0)
chunk.fill(stone_id)
chunk.save(Path("world/chunks/c0_0_0.vox"))
loaded = Chunk.load(Path("world/chunks/c0_0_0.vox"))
```

### `engine/world/world.py` — World manager
```python
world = World.create("MyWorld", Path("/save"), seed=42)
world.set_voxel(10, 5, 10, stone_id)
world.fill_box(0, 0, 0, 32, 1, 32, stone_id)
world.save()
```

### `engine/core/scheduler.py` — Runtime scheduler (blueprint §5)
```python
scheduler = Scheduler(bus)
scheduler.register(SimModule("thermal", thermal.step, every_n_ticks=1,  priority=0))
scheduler.register(SimModule("fluid",   fluid.step,   every_n_ticks=1,  priority=1))
scheduler.register(SimModule("debris",  debris.step,  every_n_ticks=3,  priority=5))

for tick in range(1000):
    scheduler.tick()

print(scheduler.profile_report())
```

### `engine/sim/fluid.py` — Hydrodynamika Level 1 + 2 (blueprint §4.4, §15)
"Chybějící hlavní modul" — implementován přesně podle blueprintu:

```python
fluid = FluidSimulation(32, 16, 32, bus=bus)
fluid.grid.add_fluid(15, 12, 15, 0.9)  # přidej vodu
events = fluid.grid.step(tick)          # jeden krok simulace
# → FLUID_CELL_FILLED, FLUID_CELL_DRAINED, FLUID_PRESSURE_HIGH, ...
```

Algoritmus (§15):
1. gravitace (tok dolů)
2. horizontální šíření
3. pressure equalization (Level 2 — communicating vessels)
4. materiálové interakce
5. event emise

### `engine/builder/parts.py` — Builder katalog (blueprint §3)
```python
from engine.builder.parts import CATALOG, BuilderObject

obj = BuilderObject("vehicle_001", "Moje vozidlo")
obj.add_part("engine_v4", (0,0,0), "engine")
obj.add_part("wheel_medium", (2,0,1), "wheel_r")
obj.connect("engine", "wheel_r")

errors = obj.validate(CATALOG)  # blueprint §3.3
obj.save(Path("builder_objects/vehicle.voxobj"))
```

## CLI Studio

```bash
python apps/studio_stub.py
> fill          # vytvoř demo scénu
> fluid         # přidej vodu
> tick 100      # spusť 100 ticků
> fluid-view 3  # ASCII fluid řez @ y=3
> builder       # demo builder objektu
> save          # ulož svět
```

## Propojení s CogCore + GenomeForge

Viz `platform/` složka (z předchozí integrace):
- `cogvox_bridge.py` — CogCore AI agent vnímá Noctilith svět
- `genome_bridge.py` — GenomeForge evolvuje chování agentů
- `orchestrator.py`  — kompletní smyčka platformy

## Next milestones

| MVP | Popis | Stav |
|-----|-------|------|
| MVP 0 | Engine Skeleton    | ✅ |
| MVP 1 | Basic Voxel World  | ✅ |
| MVP 4 | Simulation Core    | ✅ (Noctilith) |
| MVP 5 | Hydrodynamics L1+2 | ✅ |
| MVP 2 | Editor Prototype   | ○ 3D viewport (pyglet/moderngl) |
| MVP 3 | Builder Prototype  | ○ snap + UI |
| MVP 6 | Game Runtime       | ○ full player |
| MVP 7 | Scripting          | ○ event graph |
| MVP 8 | Publishable        | ○ project format |

## Rizika (blueprint §18)

> "Příliš velký scope."

Strategie: core je hotový a testovaný. UI přijde až potom.
Python prototyp definuje správnou architekturu — Rust/C++ rewrite bude jednodušší
díky jasným rozhraním.

---

## Noctilith advanced simulation merge

This build includes a Noctilith-to-VoxForge migration layer. VoxForge remains the main platform package, while the older Noctilith material/destruction pipeline is now available under `engine.sim`, `engine.entities`, `engine.world`, and `engine.tools`.

Examples:

```python
from engine.sim import MaterialDegradationModel, FractureBridge
from engine.entities import DebrisDynamicsSystem
from engine.world import greedy_mesh, NoctilithTerrainGen
```

See `MERGE_REPORT.md` for the exact list of migrated modules.
