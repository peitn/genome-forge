"""
apps/player_stub.py
===================
VoxForge Player — runtime/player stub.
Headless player pro testování herní logiky bez editoru.

Blueprint §6: "Game Runtime"
Blueprint §13 MVP 6: "player controller, interaction, spawn system, basic rules, play/test mode"
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from engine.core import EventBus, EventType, Scheduler, SimModule, World as ECSWorld, Entity
from engine.world.world import World
from engine.world.voxel import MATERIALS
from engine.sim.fluid import FluidSimulation


class PlayerController:
    """
    Jednoduchý player controller.
    Blueprint §6: "player controller, interaction, spawn system"
    """
    def __init__(self, world: World, bus: EventBus):
        self.world = world
        self.bus = bus
        self.ecs = ECSWorld()

        # Spawn player entity
        self.player = self.ecs.create()
        self.player.add("position", [16, 5, 16])
        self.player.add("health", 1.0)
        self.player.add("inventory", {})
        self.player.add("tag", "player")

        self._tick = 0

    @property
    def pos(self):
        return self.player.get("position")

    def move(self, dx: int, dy: int, dz: int) -> bool:
        """Pohyb hráče. Vrátí False pokud je blokován."""
        p = self.pos
        nx, ny, nz = p[0] + dx, p[1] + dy, p[2] + dz

        if not self.world.is_solid(nx, ny, nz):
            self.player.add("position", [nx, ny, nz])
            return True
        return False

    def interact(self, wx: int, wy: int, wz: int, action: str = "destroy") -> dict:
        """Interakce s voxelem."""
        vox = self.world.get_voxel(wx, wy, wz)
        result = {"action": action, "pos": (wx, wy, wz), "material": vox.material_id}

        if action == "destroy":
            old_mat = self.world.destroy_voxel(wx, wy, wz)
            mat = MATERIALS.get(old_mat)
            if mat:
                # Přidej do inventáře
                inv = self.player.get("inventory")
                inv[mat.name] = inv.get(mat.name, 0) + 1
                self.player.add("inventory", inv)
            result["destroyed_material"] = old_mat

        elif action == "place":
            # Zkus vzít z inventáře
            inv = self.player.get("inventory")
            if inv:
                mat_name = next(iter(inv), None)
                if mat_name:
                    mat = MATERIALS.get_by_name(mat_name)
                    if mat:
                        self.world.set_voxel(wx, wy, wz, mat.id)
                        inv[mat_name] -= 1
                        if inv[mat_name] <= 0:
                            del inv[mat_name]
                        self.player.add("inventory", inv)
                        result["placed_material"] = mat.id

        return result

    def tick(self) -> dict:
        self._tick += 1
        p = self.pos
        # Gravitace (jednoduchá)
        below = self.world.is_solid(p[0], p[1]-1, p[2])
        if not below and p[1] > 0:
            self.player.add("position", [p[0], p[1]-1, p[2]])

        return {
            "tick": self._tick,
            "pos": list(self.pos),
            "health": self.player.get("health"),
            "inventory": dict(self.player.get("inventory")),
        }


def run_player(world_path: str = None, headless_ticks: int = 100):
    """
    Spusť player v headless módu.
    Blueprint §2.3 Game Mode: "testování světa jako hry"
    """
    print("=== VoxForge Player v0.1 (headless) ===")

    bus = EventBus()
    bus.record_history = True

    if world_path and Path(world_path).exists():
        world = World.load(Path(world_path), bus=bus)
        print(f"  Načten svět: {world}")
    else:
        # Vytvoř demo svět
        save_dir = Path("/tmp/voxforge_player_demo")
        world = World.create("PlayerDemo", save_dir, bus=bus)
        stone_id = MATERIALS.get_by_name("stone").id
        wood_id  = MATERIALS.get_by_name("wood").id
        # Podlaha
        for x in range(32):
            for z in range(32):
                world.set_voxel(x, 0, z, stone_id)
        # Pár bloků
        for x in range(10, 15):
            world.set_voxel(x, 1, 10, wood_id)
        print(f"  Nový svět: {world}")

    fluid_sim = FluidSimulation(32, 8, 32, bus=bus)
    scheduler = Scheduler(bus)
    scheduler.register(SimModule("fluid", fluid_sim.step, every_n_ticks=1))

    player = PlayerController(world, bus)
    print(f"  Player spawn: {player.pos}")

    # Headless game loop
    t0 = time.perf_counter()
    for i in range(headless_ticks):
        state = player.tick()
        scheduler.tick()

        # Demo interakce
        if i == 10:
            r = player.interact(10, 1, 10, "destroy")
            print(f"  [t=10] Destroy: {r}")
        if i == 20:
            player.move(2, 0, 0)
            print(f"  [t=20] Move → {player.pos}")

    elapsed = time.perf_counter() - t0
    print(f"\n  {headless_ticks} ticků za {elapsed*1000:.1f}ms")
    print(f"  Finální stav: {player.tick()}")
    print(f"  Fluid: {fluid_sim.stats}")
    print(f"  Events: {len(bus.history)}")
    print(f"  Scheduler: {scheduler.avg_tick_ms:.2f}ms avg")


if __name__ == "__main__":
    world_arg = sys.argv[1] if len(sys.argv) > 1 else None
    ticks_arg = int(sys.argv[2]) if len(sys.argv) > 2 else 200
    run_player(world_arg, ticks_arg)
