"""
apps/studio_stub.py
===================
VoxForge Studio — stub CLI editoru.
Spustitelný prototyp bez GUI.

Blueprint §2.3: "Kompletní 3D editační studio."
Aktuální verze: CLI základ (MVP 2 frontend bude 3D viewport).
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

# Přidej root do PYTHONPATH
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from engine.core import EventBus, EventType, Scheduler, SimModule
from engine.world.world import World
from engine.world.voxel import MATERIALS
from engine.sim.fluid import FluidSimulation
from engine.builder.parts import CATALOG, BuilderObject


BANNER = """
╔══════════════════════════════════════════════════╗
║         VOXFORGE STUDIO  v0.1 (stub)            ║
║         Blueprint Milestone A — CLI mode        ║
╚══════════════════════════════════════════════════╝

Příkazy:
  info          — stav světa
  fill          — vyplň demo scénu
  fluid         — přidej vodu
  tick N        — spusť N ticků simulace
  fluid-view Y  — zobraz fluid řez na výšce Y
  save          — ulož svět
  load PATH     — načti svět
  builder       — demo builder objektu
  quit          — konec
"""


def run_studio():
    print(BANNER)

    bus = EventBus()
    save_dir = Path("/tmp/voxforge_world_studio")

    world = World.create("StudioDemo", save_dir, seed=42, bus=bus)

    # Fluid simulace 32×16×32
    fluid_sim = FluidSimulation(32, 16, 32, bus=bus)

    # Scheduler
    scheduler = Scheduler(bus)

    def fluid_step(tick: int):
        fluid_sim.step(tick)

    scheduler.register(SimModule("fluid", fluid_step, every_n_ticks=1, priority=1))

    stone_id = MATERIALS.get_by_name("stone").id
    water_id = MATERIALS.get_by_name("water").id

    # Základní mapa
    for wx in range(32):
        for wz in range(32):
            world.set_voxel(wx, 0, wz, stone_id)

    print("[Studio] Svět inicializován. Zadej příkaz:")

    while True:
        try:
            raw = input("> ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nBye.")
            break

        if not raw:
            continue

        parts = raw.split()
        cmd = parts[0]

        if cmd == "quit":
            break

        elif cmd == "info":
            print(f"  Svět:   {world}")
            print(f"  Fluid:  {fluid_sim.stats}")
            print(f"  Tick:   {scheduler.current_tick}")
            print(f"  Events: {len(bus.history)}")

        elif cmd == "fill":
            print("  Plním demo scénu (stone + díra + voda)...")
            for wx in range(0, 32):
                for wz in range(0, 32):
                    world.set_voxel(wx, 1, wz, stone_id)
            for wx in range(8, 24):
                for wz in range(8, 24):
                    world.set_voxel(wx, 1, wz, 0)
            print(f"  Hotovo. {world}")

        elif cmd == "fluid":
            print("  Přidávám vodu nad díru...")
            for fx in range(10, 22):
                for fz in range(10, 22):
                    fluid_sim.grid.add_fluid(fx, 8, fz, 0.9)
                    fluid_sim.grid.solid[fx, 1, fz] = False
            for fx in range(0, 32):
                for fz in range(0, 32):
                    mat = world.get_material(fx, 1, fz)
                    if mat != 0:
                        fluid_sim.grid.solid[fx, 1, fz] = True
            print(f"  Total volume: {fluid_sim.total_volume:.2f}")

        elif cmd == "tick":
            n = int(parts[1]) if len(parts) > 1 else 10
            t0 = time.perf_counter()
            scheduler.run(n)
            dt = (time.perf_counter() - t0) * 1000
            print(f"  {n} ticků za {dt:.1f}ms ({dt/max(n,1):.2f}ms/tick)")
            print(f"  {fluid_sim.stats}")

        elif cmd == "fluid-view":
            y = int(parts[1]) if len(parts) > 1 else 5
            print(f"\n--- Fluid XZ řez @ y={y} ---")
            print(fluid_sim.grid.cross_section_y(y))

        elif cmd == "save":
            n = world.save()
            print(f"  Uloženo {n} chunků.")

        elif cmd == "builder":
            _demo_builder()

        else:
            print(f"  Neznámý příkaz: '{cmd}'")


def _demo_builder():
    obj = BuilderObject(
        object_id="demo_vehicle_001",
        name="Demo vozidlo",
        description="Jednoduchý testovací vůz z builderových dílů."
    )
    chassis = obj.add_part("beam_4x1x1", (0, 0, 0), "chassis")
    engine  = obj.add_part("engine_v4",  (1, 1, 0), "engine")
    w_fl    = obj.add_part("wheel_medium", (-0.5, 0, -1), "wheel_fl")
    w_fr    = obj.add_part("wheel_medium", (-0.5, 0,  1), "wheel_fr")
    w_rl    = obj.add_part("wheel_medium", ( 4.5, 0, -1), "wheel_rl")
    w_rr    = obj.add_part("wheel_medium", ( 4.5, 0,  1), "wheel_rr")

    obj.connect("chassis", "engine")
    obj.connect("engine",  "wheel_fl")
    obj.connect("engine",  "wheel_fr")
    obj.connect("chassis", "wheel_rl")
    obj.connect("chassis", "wheel_rr")

    errors = obj.validate(CATALOG)
    print(f"\n  Builder objekt: {obj}")
    if errors:
        print(f"  ❌ Validační chyby:")
        for e in errors:
            print(f"     - {e}")
    else:
        print(f"  ✓ Validace OK — {len(obj.parts)} dílů, všechna propojení platná")

    out = Path("/tmp/demo_vehicle.voxobj")
    obj.save(out)
    loaded = BuilderObject.load(out)
    print(f"  ✓ Save/load OK: {loaded}")


if __name__ == "__main__":
    run_studio()
