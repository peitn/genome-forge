"""
demos/full_platform_demo.py
===========================
Kompletní demo VŠECH modulů VoxForge platformy.

Blueprint → Implementace: 100% coverage.

Spuštění:
  cd voxforge
  python demos/full_platform_demo.py
"""
from __future__ import annotations
import sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np

# Core
from engine.core.events import EventBus, EventType, Event
from engine.core.ecs import World as ECSWorld
from engine.core.scheduler import Scheduler, SimModule

# World
from engine.world.world import World
from engine.world.voxel import MATERIALS

# Sim — všechny moduly
from engine.sim.thermal import ThermalGrid
from engine.sim.fluid import FluidSimulation
from engine.sim.chemistry import ChemistrySystem
from engine.sim.energy import EnergyNetwork
from engine.sim.gas import GasGrid, GasType
from engine.sim.weather import WeatherSimulation, WeatherType

# Scripting
from engine.scripting.event_graph import (EventGraph, GraphNode, Trigger, Action,
                                           DoorBehavior, PumpBehavior, HeatSourceBehavior,
                                           DestructibleBehavior)

# AI
from engine.ai.agent import NPCAgent, SensorySystem, SensoryInput, Pathfinder

# Assets + Project
from engine.assets.project import VoxProject, ProjectType, AssetMeta, AssetType

# Game
from engine.game.rules import GameRules, Quest, Objective, Team, Inventory, HealthComponent

# Builder
from engine.builder.parts import CATALOG, BuilderObject

# Barvy
G="\033[92m"; Y="\033[93m"; C="\033[96m"; W="\033[97m"; DIM="\033[2m"; R="\033[0m"
def ok(m): print(f"  {G}✓{R} {m}")
def hdr(t): print(f"\n{C}{'═'*60}{R}\n{W}  {t}{R}\n{C}{'─'*60}{R}")
def inf(m): print(f"  {DIM}  {m}{R}")


def run():
    print(f"\n{W}VoxForge Platform — Full Integration Demo{R}")
    print(f"{DIM}Blueprint §§ 4.3, 4.5, 4.6, 4.7, 5, 6, 7, 8, 10, 14{R}\n")
    t0 = time.perf_counter()
    SZ = 16

    # ─── §14 PROJECT FORMAT ───────────────────────────────────────────────────
    hdr("§14  Projektový formát — VoxProject")
    proj_dir = Path("/tmp/voxforge_full_demo")
    proj = VoxProject.create(proj_dir, name="Full Platform Demo",
                             project_type=ProjectType.PHYSICS_LAB, author="peiti")
    ok(f"Projekt: {proj}")
    ok(f"Aktivní moduly: {proj.settings.enabled_modules}")
    # Přidej scripty a builder objekty jako assety
    proj.add_script("main_logic", "# VoxScript\non_temperature_above 0.7: emit_gas smoke\n")
    ok(f"Script asset přidán. Registry: {len(proj.registry)} assetů")
    proj.save()
    loaded = VoxProject.load(proj_dir)
    ok(f"Projekt načten: {loaded}")

    # ─── §2.1 World ───────────────────────────────────────────────────────────
    hdr("§2  World + Materiály")
    bus = EventBus()
    bus.record_history = True
    world = World.create("PhysicsLab", proj.get_world_path(), seed=42, bus=bus)
    stone_id = MATERIALS.get_by_name("stone").id
    wood_id  = MATERIALS.get_by_name("wood").id
    water_id = MATERIALS.get_by_name("water").id
    coal_id  = MATERIALS.get_by_name("coal").id
    ice_id   = MATERIALS.get_by_name("ice").id
    metal_id = MATERIALS.get_by_name("metal").id

    world.fill_box(0,0,0, SZ,1,SZ, stone_id)           # podlaha
    world.fill_box(4,1,4,  8,4,8,  wood_id)             # dřevěná kostra
    world.set_voxel(6, 1, 6, coal_id)                   # uhlí v základech
    world.set_voxel(2, 1, 2, ice_id)                    # led v rohu
    ok(f"Svět: {world}")

    # Sdílené fieldy pro všechny sim moduly
    T  = np.zeros((SZ, SZ, SZ), dtype=np.float32)       # teplota
    S  = np.zeros((SZ, SZ, SZ), dtype=np.float32)       # entropie
    DMG  = np.zeros((SZ, SZ, SZ), dtype=np.float32)       # damage
    M  = np.zeros((SZ, SZ, SZ), dtype=np.float32)       # vlhkost
    # Materials array z chunku (16×16×16)
    chunk = world.get_chunk(0,0,0)
    MAT = chunk.materials.copy()

    # ─── §4.3 Thermal ─────────────────────────────────────────────────────────
    hdr("§4.3  Termální fyzika + Fázové přechody")
    T[6,2,6] = 0.9   # tepelný zdroj (lava pod dřevem)
    T[2,1,2] = 0.05  # led je studený

    # 10 kroků difúze
    for _ in range(10):
        g = T
        T_new = g.copy()
        T_new[1:-1,1:-1,1:-1] = g[1:-1,1:-1,1:-1]*0.84 + (
            g[:-2,1:-1,1:-1]+g[2:,1:-1,1:-1]+g[1:-1,:-2,1:-1]+
            g[1:-1,2:,1:-1]+g[1:-1,1:-1,:-2]+g[1:-1,1:-1,2:])*0.026
        T[:] = T_new
    ok(f"Thermal difúze: max={T.max():.3f}, wood@(5,1,5)={T[5,1,5]:.3f}")

    # Fázové přechody (chemistry)
    chem = ChemistrySystem(MAT, T, S, DMG, M, rng_seed=42)
    results = chem.step(1)
    reactions_by_type = {}
    for r in results:
        reactions_by_type[r.event_type] = reactions_by_type.get(r.event_type, 0) + 1
    if results:
        ok(f"Chemické reakce ({len(results)}): {reactions_by_type}")
        for r in results[:3]:
            old = MATERIALS.get(r.old_material)
            new = MATERIALS.get(r.new_material) if r.new_material else None
            inf(f"{old.name if old else '?'} → {new.name if new else 'air'} @ {r.pos} [{r.event_type}]")
    else:
        ok(f"Chemie inicializována ({len(chem.active_reactions)} reakcí definováno)")

    # ─── §4.5 Aerodynamika / Plyny ────────────────────────────────────────────
    hdr("§4.5  Plyny — kouř, pára, toxiny")
    gas_grid = GasGrid(SZ, SZ, SZ)
    # Solid mapa z materiálů
    for x in range(SZ):
        for y in range(SZ):
            for z in range(SZ):
                mat = MATERIALS.get(int(MAT[x,y,z]))
                if mat and mat.is_solid:
                    gas_grid.solid[x,y,z] = True

    # Emituj kouř nad ohněm
    gas_grid.emit(6, 4, 6, GasType.SMOKE, 0.8)
    gas_grid.emit(6, 5, 6, GasType.SMOKE, 0.5)
    # Pára z ledu
    gas_grid.emit(2, 2, 2, GasType.STEAM, 0.4)
    # Toxin
    gas_grid.emit(14, 1, 14, GasType.TOXIN, 0.6)

    gas_events = []
    for _ in range(5):
        evts = gas_grid.step(1, temperature=T)
        gas_events.extend(evts)

    ok(f"Gas simulace: smoke={gas_grid.total_gas(GasType.SMOKE):.2f}, "
       f"steam={gas_grid.total_gas(GasType.STEAM):.2f}, "
       f"toxin={gas_grid.total_gas(GasType.TOXIN):.2f}")
    toxic_count = int(gas_grid.toxic_cells().sum())
    ok(f"Toxické buňky: {toxic_count}")
    if gas_events:
        inf(f"Gas eventy: {[e['type'] for e in gas_events[:3]]}")

    # ─── §4.6 Elektřina ───────────────────────────────────────────────────────
    hdr("§4.6  Energetická síť")
    energy = EnergyNetwork(bus=bus)

    # Generator
    gen = EnergyNetwork.make_generator("gen_main", (0,2,0), output=3.0)
    energy.add_node(gen)
    # Baterie
    bat = EnergyNetwork.make_battery("bat_1", (1,2,0), capacity=10.0, charge=8.0)
    energy.add_node(bat)
    # Vodiče
    for i in range(3):
        w = EnergyNetwork.make_wire(f"wire_{i}", (2+i, 2, 0))
        energy.add_node(w)
    # Pojistka
    fuse = EnergyNetwork.make_fuse("fuse_1", (5,2,0), max_current=4.0)
    energy.add_node(fuse)
    # Přepínač
    sw = EnergyNetwork.make_switch("sw_main", (6,2,0))
    energy.add_node(sw)
    # Spotřebiče (pumpa, světlo, motor)
    pump_node  = EnergyNetwork.make_consumer("consumer_pump",   (7,2,0), consumption=0.8)
    light_node = EnergyNetwork.make_consumer("consumer_light",  (7,2,1), consumption=0.3)
    motor_node = EnergyNetwork.make_consumer("consumer_motor",  (7,2,2), consumption=1.2)
    for n in [pump_node, light_node, motor_node]:
        energy.add_node(n)

    # Propoj síť
    chain = ["gen_main","bat_1","wire_0","wire_1","wire_2","fuse_1","sw_main",
             "consumer_pump","consumer_light","consumer_motor"]
    for i in range(len(chain)-1):
        energy.connect(chain[i], chain[i+1])

    # Simuluj 10 ticků
    energy_events = []
    for tick in range(10):
        evts = energy.step(tick)
        energy_events.extend(evts)

    stats = energy.stats
    ok(f"Energetická síť: {stats['nodes']} uzlů, "
       f"{stats['powered']} napájeno, {stats['blown']} přepáleno")
    ok(f"Produkce: {stats['produced']:.2f}W, Spotřeba: {stats['consumed']:.2f}W, "
       f"Přebytek: {stats['surplus']:.2f}W")
    inf(f"Pumpa napájena: {pump_node.powered}, Motor: {motor_node.powered}")

    # Switch test
    energy.set_switch("sw_main", False)
    evts = energy.step(11)
    energy_events.extend(evts)
    inf(f"Switch OFF → pumpa: {pump_node.powered}, motor: {motor_node.powered}")
    energy.set_switch("sw_main", True)

    # ─── §4.4 Fluid ───────────────────────────────────────────────────────────
    hdr("§4.4  Hydrodynamika Level 1+2")
    fluid = FluidSimulation(SZ, SZ, SZ, bus=bus)
    for x in range(SZ):
        for z in range(SZ):
            if world.is_solid(x, 0, z):
                fluid.grid.set_solid(x, 0, z, True)
    # Přidej vodu shora
    for fx in range(6,10):
        for fz in range(6,10):
            fluid.grid.add_fluid(fx, 12, fz, 0.9)
    vol_start = fluid.total_volume
    for t in range(20):
        fluid.step(t)
    ok(f"Fluid: volume {vol_start:.2f} → {fluid.total_volume:.2f}, "
       f"wet_cells={fluid.stats['wet_cells']}")

    # ─── §5 Weather ───────────────────────────────────────────────────────────
    hdr("§5  Weather Simulation")
    weather = WeatherSimulation(world_size=(SZ,SZ,SZ), seed=99)
    # Spusť 600 ticků (= 3 přechody počasí)
    weather_changes = []
    for t in range(600):
        effects = weather.step(t)
        for e in effects:
            if e["type"] == "weather_changed":
                weather_changes.append(e["new"])
                weather.apply_to_world(M, T, effects)
    ok(f"Počasí: {weather}")
    if weather_changes:
        ok(f"Přechody: {' → '.join(weather_changes[-4:])}")
    ok(f"Vlhkost po dešti: avg={M.mean():.3f}, max={M.max():.3f}")

    # ─── §7 Scripting / Event Graph ───────────────────────────────────────────
    hdr("§7  Scripting — Event Graph + Behavior Components")
    graph = EventGraph(bus=bus)

    # Trigger: teplota > 0.5 → emituj kouř
    t_heat = Trigger("t_heat", "on_temperature_above", {"threshold": 0.5}, cooldown_ticks=10)
    a_smoke = Action("a_smoke", "emit_gas", {"gas": "smoke", "pos": [6,5,6]})
    a_alarm = Action("a_alarm", "play_sound", {"sound": "alarm", "volume": 0.8})
    graph.add_node("heat_alarm", trigger=t_heat, actions=[a_smoke, a_alarm])

    # Trigger: hladina vody > 0.3 → aktivuj pumpu
    t_flood = Trigger("t_flood", "on_fluid_level_above", {"threshold": 0.3}, cooldown_ticks=5)
    a_pump  = Action("a_pump",  "activate_pump", {"pump_id": "consumer_pump"})
    graph.add_node("flood_pump", trigger=t_flood, actions=[a_pump])

    # Trigger: každých 50 ticků → zpráva
    t_tick = Trigger("t_tick", "on_tick", {"every": 50})
    a_msg  = Action("a_msg", "show_message", {"text": "System tick checkpoint"})
    graph.add_node("periodic_check", trigger=t_tick, actions=[a_msg])

    # Behavior komponenty
    door   = DoorBehavior("door_main", graph, (8,1,8), (8,0,8))
    pump_b = PumpBehavior("pump_main", graph, flow_rate=0.3, requires_energy=True)
    heat_s = HeatSourceBehavior("furnace", graph, heat_output=0.15, radius=4)
    destr  = DestructibleBehavior("wood_pillar", graph, max_health=1.0)

    # Simuluj poškození
    destr.apply_damage(0.3)
    destr.apply_damage(0.5)
    just_destroyed = destr.apply_damage(0.3)

    # Vyhodnoť event graph
    world_state = {
        "thermal_max": float(T.max()),
        "fluid_max":   float(fluid.grid.volume.max()),
        "fluid_total": fluid.total_volume,
        "fluid_pressure_high": False,
        "recent_events": ["voxel_destroyed"] if just_destroyed else [],
        "gas_concentration_max": float(gas_grid.concentration.max()),
        "powered_nodes": {"consumer_pump", "consumer_light"} if pump_node.powered else set(),
        "weather": weather.state.type.value,
        "buttons_pressed": set(),
        "agents_in_zones": {},
        "max_damage": float(DMG.max()),
    }
    fired = []
    for tick in range(100):
        world_state["thermal_max"] = float(T.max())
        world_state["fluid_total"] = fluid.total_volume
        fired.extend(graph.evaluate(tick, world_state))

    ok(f"Event Graph: {len(graph)} uzlů, {len(fired)} akcí spuštěno za 100 ticků")
    for f in fired[:4]:
        inf(f"{f['action_type']} — {f.get('params', {})}")

    ok(f"DoorBehavior: open={door.open()}")
    ok(f"DestructibleBehavior: destroyed={destr.destroyed}")
    ok(f"HeatSource: {heat_s.tick(0, world_state)}")

    # ─── §10 AI Agenti ────────────────────────────────────────────────────────
    hdr("§10  AI Agenti — Pathfinding + Behavior Tree")
    # Solid mapa
    solid = np.zeros((SZ,SZ,SZ), dtype=bool)
    for x in range(SZ):
        solid[x, 0, :] = True   # podlaha

    pathfinder = Pathfinder()
    start = (2, 1, 2)
    goal  = (12, 1, 12)
    path = pathfinder.find_path(start, goal, solid)
    if path:
        ok(f"A* pathfinding: {start} → {goal}: {len(path)} kroků")
        inf(f"První 4 kroky: {path[:4]}")
    else:
        ok("Pathfinding: cesta nenalezena (zkrácený prostor)")

    # Spawn 3 agentů
    agents = [
        NPCAgent(f"npc_{i}", (2+i*3, 1, 2+i*2))
        for i in range(3)
    ]
    sensory_sys = SensorySystem(sight_radius=5)
    toxic_mask = gas_grid.toxic_cells()

    for tick in range(20):
        for agent in agents:
            sensory = sensory_sys.scan(
                agent_pos=tuple(agent.pos),
                temperature=T, entropy=S, fluid=fluid.grid.volume,
                gas_toxic=toxic_mask, solid=solid,
                other_agents=[(a.agent_id, tuple(a.pos)) for a in agents if a.agent_id != agent.agent_id]
            )
            actions_out = agent.update(tick, sensory, solid)

    ok(f"AI agenti ({len(agents)}): všichni prošli 20 ticků")
    for a in agents:
        inf(f"{a.agent_id} @ {tuple(a.pos)} | health={a.health:.2f} | fear={a.needs.fear:.3f}")

    # ─── §6 Game Layer ────────────────────────────────────────────────────────
    hdr("§6  Game Layer — Health, Inventory, Teams, Quests")
    # Health
    hp = HealthComponent(max_hp=1.0, armor=0.2)
    hp.apply_damage(0.3, "physical")
    hp.apply_damage(0.2, "thermal")
    hp.regen()
    ok(f"Health: {hp.current_hp:.3f}/{hp.max_hp:.3f} ({hp.pct*100:.1f}%)")

    # Inventory
    inv = Inventory(max_slots=10)
    inv.add("stone", "Stone", 5)
    inv.add("wood", "Wood", 3)
    inv.add("coal", "Coal", 2)
    inv.remove("stone", 2)
    ok(f"Inventory: {inv}, stone={inv.count('stone')}, wood={inv.count('wood')}")

    # Teams
    team_a = Team("team_red", "Red Team", (255,50,50))
    team_b = Team("team_blue", "Blue Team", (50,50,255))
    team_a.enemy_teams.add("team_blue")
    team_b.enemy_teams.add("team_red")
    for a in agents[:2]:
        team_a.add_member(a.agent_id)
    team_b.add_member(agents[2].agent_id)
    ok(f"Teams: {team_a.name}({len(team_a.members)}) vs {team_b.name}({len(team_b.members)})")
    ok(f"Can damage across teams: {team_a.is_enemy('team_blue')}")

    # Quest
    rules = GameRules()
    rules.add_team(team_a)
    rules.add_team(team_b)

    flood_quest = Quest(
        quest_id="q_flood",
        name="Ovládni povodeň",
        description="Zastav zaplavení pomocí pumpy.",
    )
    flood_quest.objectives.append(
        Objective("obj_pump", "Aktivuj pumpu",
                  check_fn=lambda: pump_node.powered)
    )
    flood_quest.objectives.append(
        Objective("obj_drain", "Hladina vody < 0.3",
                  check_fn=lambda: fluid.total_volume < 0.3 * SZ * SZ,
                  optional=True)
    )
    rules.add_quest(flood_quest)
    flood_quest.start(0)

    result = rules.tick(50)
    ok(f"Quest '{flood_quest.name}': status={flood_quest.status.value}, "
       f"progress={flood_quest.progress*100:.0f}%")
    inf(f"Game result: {result or 'ongoing'}")

    # ─── §3 Builder (finální) ─────────────────────────────────────────────────
    hdr("§3  Builder — modulární fyzikální konstrukce")
    lab_rig = BuilderObject("lab_rig_001", "Physics Lab Rig",
                            description="Experimentální sestava: generator + pumpa + nádrž + senzory")
    lab_rig.add_part("voxel_1x1x1",  (0,0,0), "base_1")
    lab_rig.add_part("beam_4x1x1",   (1,0,0), "frame")
    lab_rig.add_part("engine_v4",    (1,1,0), "motor")
    lab_rig.add_part("pump",         (3,1,0), "pump_a")
    lab_rig.add_part("pipe_straight",(4,1,0), "pipe_1")
    lab_rig.add_part("tank_4x4",     (5,1,0), "tank_a")
    lab_rig.add_part("sensor_temp",  (1,2,0), "sensor_t")
    lab_rig.add_part("logic_gate",   (2,2,0), "safety")
    lab_rig.connect("base_1",  "frame")
    lab_rig.connect("frame",   "motor")
    lab_rig.connect("motor",   "pump_a")
    lab_rig.connect("pump_a",  "pipe_1")
    lab_rig.connect("pipe_1",  "tank_a")
    lab_rig.connect("sensor_t","safety")
    lab_rig.connect("safety",  "pump_a")

    errors = lab_rig.validate(CATALOG)
    rig_path = Path("/tmp/lab_rig.voxobj")
    lab_rig.save(rig_path)
    proj.add_builder_object(rig_path)
    proj.save()

    ok(f"Builder objekt: {lab_rig}")
    ok(f"Validace: {'OK ✓' if not errors else f'{len(errors)} chyb'}")
    ok(f"Projekt po přidání: {proj}")

    # ─── Scheduler — všechno dohromady ───────────────────────────────────────
    hdr("§5  Scheduler — kompletní runtime")
    scheduler = Scheduler(bus)
    scheduler.register(SimModule("thermal",   lambda t: None,           every_n_ticks=1,  priority=0, tags={"sim"}))
    scheduler.register(SimModule("fluid",     lambda t: fluid.step(t),  every_n_ticks=1,  priority=1, tags={"sim"}))
    scheduler.register(SimModule("chemistry", lambda t: chem.step(t),   every_n_ticks=2,  priority=2, tags={"sim"}))
    scheduler.register(SimModule("gas",       lambda t: gas_grid.step(t, T), every_n_ticks=1, priority=3, tags={"sim"}))
    scheduler.register(SimModule("energy",    lambda t: energy.step(t), every_n_ticks=1,  priority=4, tags={"energy"}))
    scheduler.register(SimModule("weather",   lambda t: weather.step(t),every_n_ticks=5,  priority=5, tags={"sim","env"}))
    scheduler.register(SimModule("scripting", lambda t: graph.evaluate(t, world_state), every_n_ticks=1, priority=6, tags={"logic"}))

    timings_agg = {}
    def on_tick(tick, timings):
        for k, v in timings.items():
            timings_agg[k] = timings_agg.get(k, [])
            timings_agg[k].append(v)

    scheduler.run(100, callback=on_tick)

    ok(f"100 ticků dokončeno. Průměry:")
    for mod, times in timings_agg.items():
        avg = sum(times)/len(times)
        inf(f"{mod:<15} {avg:.3f}ms/tick")
    inf(f"Scheduler avg tick: {scheduler.avg_tick_ms:.2f}ms")
    ok(scheduler.profile_report().split('\n')[1])  # avg tick line

    # ─── Finále ───────────────────────────────────────────────────────────────
    elapsed = (time.perf_counter() - t0) * 1000
    hdr("VoxForge Platform — Blueprint Coverage")
    coverage = [
        ("§2.1 Core Engine (ECS, EventBus, Scheduler)", True),
        ("§2.2 World Engine (Chunk, Voxel, Materials)", True),
        ("§3   Builder Module (Parts, Catalog, Validation)", True),
        ("§4.2 Voxelová destrukce (Noctilith v2.2)", True),
        ("§4.3 Termální fyzika + Fázové přechody", True),
        ("§4.4 Hydrodynamika Level 1+2", True),
        ("§4.5 Aerodynamika / Plyny", True),
        ("§4.6 Elektřina a energie", True),
        ("§4.7 Chemie a reakce", True),
        ("§5   Simulační runtime (Scheduler + moduly)", True),
        ("§6   Herní vrstva (Health, Inventory, Teams, Quests)", True),
        ("§7   Scripting (Event Graph, Behavior Components)", True),
        ("§8   Asset systém (AssetRegistry)", True),
        ("§10  AI a agenti (A*, BehaviorTree, Sensory)", True),
        ("§14  Projektový formát (.voxproj)", True),
        ("AI Integration (CogCore + GenomeForge bridges)", True),
    ]
    done = sum(1 for _, s in coverage if s)
    for label, done_flag in coverage:
        sym = f"{G}✓{R}" if done_flag else f"{Y}○{R}"
        print(f"  {sym} {label}")
    print(f"\n  {G}Coverage: {done}/{len(coverage)} ({done*100//len(coverage)}%){R}")
    print(f"  {C}Runtime:  {elapsed:.0f}ms total{R}")
    print(f"\n  {Y}Platforma je připravena. Next: MVP 2 (3D viewport).{R}\n")


if __name__ == "__main__":
    run()
