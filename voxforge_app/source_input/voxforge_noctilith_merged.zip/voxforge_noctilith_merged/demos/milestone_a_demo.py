"""
demos/milestone_a_demo.py
=========================
Milestone A Demo — přesně scénář z blueprintu §19:

  1. vytvoř malý svět
  2. polož voxelové bloky
  3. přidej vodu
  4. voda proteče dolů
  5. teplo ovlivní materiál
  6. damage field oslabí blok
  7. builder objekt se uloží/načte

Spuštění:
  cd voxforge
  python demos/milestone_a_demo.py
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from engine.core.events import EventBus, EventType, Event
from engine.core.ecs import World as ECSWorld
from engine.core.scheduler import Scheduler, SimModule
from engine.world.world import World
from engine.world.voxel import MATERIALS
from engine.sim.thermal import ThermalGrid
from engine.sim.fluid import FluidSimulation, FluidEventType
from engine.builder.parts import CATALOG, BuilderObject


# ── Barvy pro terminál ────────────────────────────────────────────────────────
R  = "\033[91m"   # červená
G  = "\033[92m"   # zelená
Y  = "\033[93m"   # žlutá
B  = "\033[94m"   # modrá
C  = "\033[96m"   # cyan
W  = "\033[97m"   # bílá
DIM = "\033[2m"
RST = "\033[0m"

def header(title: str) -> None:
    width = 60
    print(f"\n{C}{'═' * width}{RST}")
    print(f"{W}  {title}{RST}")
    print(f"{C}{'─' * width}{RST}")

def ok(msg: str) -> None:
    print(f"  {G}✓{RST} {msg}")

def info(msg: str) -> None:
    print(f"  {B}→{RST} {msg}")

def warn(msg: str) -> None:
    print(f"  {Y}⚠{RST}  {msg}")

def event_log(msg: str) -> None:
    print(f"  {DIM}[EVENT] {msg}{RST}")


# ── Scénář ────────────────────────────────────────────────────────────────────

def run():
    print(f"\n{W}VoxForge Platform — Milestone A Demo{RST}")
    print(f"{DIM}Blueprint §19 — testovací scénář{RST}\n")
    t_total = time.perf_counter()

    # ─── 1. Vytvoř malý svět ──────────────────────────────────────────────────
    header("1. Vytvoř malý svět")

    bus = EventBus()
    bus.record_history = True
    save_dir = Path("/tmp/voxforge_milestone_a")
    save_dir.mkdir(parents=True, exist_ok=True)

    WORLD_SIZE = 16   # 16×16×16 voxelů (jeden chunk)
    world = World.create("MilestoneA", save_dir, seed=1337, bus=bus)

    ok(f"Svět '{world.meta.name}' (seed={world.meta.seed})")
    ok(f"Save dir: {save_dir}")
    ok(f"Chunk size: {world.chunk_size}³")

    # ─── 2. Polož voxelové bloky ──────────────────────────────────────────────
    header("2. Polož voxelové bloky")

    stone_id   = MATERIALS.get_by_name("stone").id
    wood_id    = MATERIALS.get_by_name("wood").id
    water_id   = MATERIALS.get_by_name("water").id
    concrete_id = MATERIALS.get_by_name("concrete").id

    # Kamenná podlaha (y=0)
    count = world.fill_box(0,0,0, WORLD_SIZE,1,WORLD_SIZE, stone_id)
    ok(f"Podlaha: {count} stone voxelů @ y=0")

    # Betonové stěny po obvodu (y=1..6)
    for wy in range(1, 7):
        for wx in range(WORLD_SIZE):
            world.set_voxel(wx, wy, 0, concrete_id)
            world.set_voxel(wx, wy, WORLD_SIZE-1, concrete_id)
        for wz in range(1, WORLD_SIZE-1):
            world.set_voxel(0, wy, wz, concrete_id)
            world.set_voxel(WORLD_SIZE-1, wy, wz, concrete_id)
    ok(f"Betonové stěny: y=1..6, 4 stěny")

    # Dřevěná platforma uprostřed (y=4)
    wood_count = 0
    for wx in range(4, 12):
        for wz in range(4, 12):
            world.set_voxel(wx, 4, wz, wood_id)
            wood_count += 1
    ok(f"Dřevěná platforma: {wood_count} wood voxelů @ y=4")

    # Díra v platformě (pro průtok vody)
    for wx in range(7, 9):
        for wz in range(7, 9):
            world.set_voxel(wx, 4, wz, 0)
    ok(f"Díra v platformě: 2×2 @ (7-8, 4, 7-8)")

    total_voxels = world.total_voxel_count()
    info(f"Celkem voxelů: {total_voxels}")

    # ─── 3. Přidej vodu ───────────────────────────────────────────────────────
    header("3. Přidej vodu")

    # Fluid simulace (16×8×16 = prostor světa)
    fluid = FluidSimulation(WORLD_SIZE, 8, WORLD_SIZE, bus=bus)

    # Nastav solid mapu z materiálů světa
    chunk = world.get_chunk(0, 0, 0)
    if chunk is not None:
        for wx in range(WORLD_SIZE):
            for wy in range(8):
                for wz in range(WORLD_SIZE):
                    mat_id = world.get_material(wx, wy, wz)
                    mat = MATERIALS.get(mat_id)
                    if mat and mat.is_solid:
                        fluid.grid.set_solid(wx, wy, wz, True)

    # Přidej vodu nad platformu (y=6)
    water_cells = 0
    for fx in range(5, 11):
        for fz in range(5, 11):
            fluid.grid.add_fluid(fx, 6, fz, 0.9)
            water_cells += 1

    ok(f"Voda přidána: {water_cells} buněk @ y=6, volume={fluid.total_volume:.2f}")
    info(f"Čeká se na gravitační tok přes díru v platformě...")

    # Event listener pro fluid
    fluid_events_caught = []
    def on_fluid_event(evt: Event):
        fluid_events_caught.append(evt.type)

    bus.subscribe(FluidEventType.CELL_FILLED,  on_fluid_event)
    bus.subscribe(FluidEventType.CELL_DRAINED, on_fluid_event)
    bus.subscribe(FluidEventType.PRESSURE_HIGH, on_fluid_event)

    # ─── 4. Voda proteče dolů ─────────────────────────────────────────────────
    header("4. Voda proteče dolů")

    scheduler = Scheduler(bus)
    scheduler.register(SimModule("fluid", fluid.step, every_n_ticks=1, priority=1))

    # Spusť 50 ticků fluidní simulace
    vol_before = fluid.total_volume
    t0 = time.perf_counter()
    for tick in range(50):
        timings = scheduler.tick()
    elapsed = (time.perf_counter() - t0) * 1000

    vol_after = fluid.total_volume
    ok(f"50 fluid ticků za {elapsed:.1f}ms ({elapsed/50:.2f}ms/tick)")
    info(f"Volume před: {vol_before:.3f}  →  po: {vol_after:.3f}")
    info(f"Fluid events zachyceno: {len(fluid_events_caught)} ({set(fluid_events_caught)})")

    # Zobraz vertikální sloupec přes díru
    print(f"\n  {DIM}Vertikální sloupec vody @ x=7, z=7:{RST}")
    col = fluid.grid.column_y(7, 7)
    print(f"  Nahoře [y=7] → dole [y=0]:  {C}{col}{RST}")

    col_solid = "".join("█" if fluid.grid.solid[7, y, 7] else "·" for y in range(7, -1, -1))
    print(f"  Solid mapa:                  {DIM}{col_solid}{RST}")

    stats = fluid.stats
    ok(f"Wet cells: {stats['wet_cells']}, max vol: {stats['max_volume']:.3f}")

    # ─── 5. Teplo ovlivní materiál ────────────────────────────────────────────
    header("5. Teplo ovlivní materiál")

    # Přidej tepelný zdroj (lávový blok pod platformou)
    lava_id = MATERIALS.get_by_name("lava").id
    world.set_voxel(8, 2, 8, lava_id)
    ok(f"Lávový blok umístěn @ (8,2,8), material_id={lava_id}")

    # ThermalGrid (16×8×16)
    thermal = ThermalGrid((WORLD_SIZE, 8, WORLD_SIZE))
    thermal.T[8, 2, 8] = 1.0   # maximum tepla z lávy
    thermal.T[7:10, 2, 7:10] = 0.8

    # Simuluj tepelnou difúzi (20 kroků)
    for _ in range(20):
        g = thermal.T
        g[1:-1, 1:-1, 1:-1] = (
            g[1:-1, 1:-1, 1:-1] * 0.84 +
            (g[:-2, 1:-1, 1:-1] + g[2:, 1:-1, 1:-1] +
             g[1:-1, :-2, 1:-1] + g[1:-1, 2:, 1:-1] +
             g[1:-1, 1:-1, :-2] + g[1:-1, 1:-1, 2:]) * 0.026
        )

    # Zkontroluj teplotu u dřevěné platformy (y=4)
    temp_at_wood = float(thermal.T[8, 4, 8])
    wood_mat = MATERIALS.get_by_name("wood")
    ok(f"Teplota u dřeva (8,4,8): {temp_at_wood:.4f}")
    info(f"Ignition point dřeva: {wood_mat.ignition_point:.2f}")

    if temp_at_wood > wood_mat.ignition_point * 0.5:
        warn(f"Dřevo je v nebezpečné zóně! ({temp_at_wood:.3f} > {wood_mat.ignition_point*0.5:.3f})")
        bus.publish(Event(
            type=EventType.THERMAL_ALERT,
            tick=scheduler.current_tick,
            payload={"pos": (8,4,8), "temp": temp_at_wood, "material": "wood"},
        ))
    else:
        ok(f"Dřevo zatím v bezpečí.")

    # Teplo na dřevo = MATERIAL_BURNED event pokud > ignition
    if temp_at_wood > wood_mat.ignition_point:
        bus.publish(Event(
            type=EventType.MATERIAL_BURNED,
            tick=scheduler.current_tick,
            payload={"pos": (8,4,8)},
        ))
        warn(f"MATERIAL_BURNED event emitován! Dřevo se vznítí.")

    info(f"Thermal max v gridu: {float(thermal.T.max()):.4f}")
    info(f"Thermal mean:        {float(thermal.T.mean()):.4f}")

    # ─── 6. Damage field oslabí blok ─────────────────────────────────────────
    header("6. Damage field oslabí blok")

    import numpy as np
    damage_field = np.zeros((WORLD_SIZE, 8, WORLD_SIZE), dtype=np.float32)

    # Thermal → damage coupling (zjednodušený)
    damage_field[:] = np.clip(thermal.T - 0.4, 0, None) * 2.0

    max_damage_pos = np.unravel_index(np.argmax(damage_field), damage_field.shape)
    max_damage_val = float(damage_field[max_damage_pos])

    ok(f"Damage field vypočítán z tepelného pole")
    info(f"Max damage: {max_damage_val:.4f} @ {max_damage_pos}")

    # Zkontroluj fracture threshold pro konkrétní voxely
    for (wx, wy, wz) in [(8,4,8), (7,1,7), (8,2,8)]:
        mat_id = world.get_material(wx, wy, wz)
        mat = MATERIALS.get(mat_id)
        dmg = float(damage_field[wx, wy, wz])
        if mat:
            threshold = mat.fracture_threshold()
            status = f"{R}FRACTURED{RST}" if dmg > threshold else f"{G}OK{RST}"
            print(f"  {DIM}({wx},{wy},{wz}){RST} {mat.name:<10} "
                  f"damage={dmg:.3f} threshold={threshold:.3f} → {status}")

            if dmg > threshold:
                bus.publish(Event(
                    type=EventType.MATERIAL_FRACTURED,
                    tick=scheduler.current_tick,
                    payload={"pos": (wx, wy, wz), "damage": dmg},
                ))

    # ─── 7. Builder objekt se uloží/načte ────────────────────────────────────
    header("7. Builder objekt se uloží/načte")

    # Sestav jednoduché čerpadlo s potrubím (hydrodynamika blueprint §15)
    pump_system = BuilderObject(
        object_id="pump_sys_001",
        name="Demo Pump System",
        description="Čerpadlo + 3 trubky + tank — pro přečerpání vody v Milestone A scéně.",
        tags=["fluid", "pump", "demo"],
    )

    # Přidej díly
    tank_in  = pump_system.add_part("tank_4x4",      (0,  0, 0), "tank_input")
    pipe1    = pump_system.add_part("pipe_straight",  (4,  0, 0), "pipe_1")
    pump     = pump_system.add_part("pump",           (5,  0, 0), "pump_main")
    pipe2    = pump_system.add_part("pipe_straight",  (6,  0, 0), "pipe_2")
    pipe3    = pump_system.add_part("pipe_straight",  (7,  0, 0), "pipe_3")
    tank_out = pump_system.add_part("tank_4x4",       (8,  0, 0), "tank_output")
    sensor   = pump_system.add_part("sensor_temp",    (5,  1, 0), "temp_sensor")
    logic    = pump_system.add_part("logic_gate",     (5,  2, 0), "safety_logic")

    # Propoj: tank_input → pipe_1 → pump → pipe_2 → pipe_3 → tank_output
    pump_system.connect("tank_input",  "pipe_1")
    pump_system.connect("pipe_1",      "pump_main")
    pump_system.connect("pump_main",   "pipe_2")
    pump_system.connect("pipe_2",      "pipe_3")
    pump_system.connect("pipe_3",      "tank_output")
    pump_system.connect("temp_sensor", "safety_logic")
    pump_system.connect("safety_logic","pump_main")

    errors = pump_system.validate(CATALOG)
    if errors:
        warn(f"Validační chyby: {errors}")
    else:
        ok(f"Validace OK — {len(pump_system.parts)} dílů")

    # Uložení
    obj_path = save_dir / "builder_objects" / "pump_system.voxobj"
    pump_system.save(obj_path)
    ok(f"Uloženo: {obj_path}")

    # Načtení
    loaded = BuilderObject.load(obj_path)
    assert loaded.object_id == pump_system.object_id
    assert len(loaded.parts) == len(pump_system.parts)
    ok(f"Načteno: {loaded}")
    ok(f"Save/load konzistentní ✓")

    # Uložení světa
    world.save()
    ok(f"Svět uložen do: {save_dir}")

    # ─── Závěrečná zpráva ─────────────────────────────────────────────────────
    header("Milestone A — Výsledky")

    elapsed_total = (time.perf_counter() - t_total) * 1000
    total_events = len(bus.history)

    print(f"""
  {G}Všechny kroky blueprintu §19 splněny:{RST}

  {G}✓{RST} 1. Svět vytvořen       {DIM}World(name='MilestoneA', seed=1337){RST}
  {G}✓{RST} 2. Voxely položeny     {DIM}{total_voxels} voxelů (stone, concrete, wood){RST}
  {G}✓{RST} 3. Voda přidána        {DIM}volume={vol_before:.2f} → {vol_after:.2f}{RST}
  {G}✓{RST} 4. Voda proteče dolů   {DIM}50 ticků, {len(fluid_events_caught)} fluid events{RST}
  {G}✓{RST} 5. Teplo → materiál    {DIM}lava@(8,2,8) → thermal diffusion{RST}
  {G}✓{RST} 6. Damage → fraktura   {DIM}damage field coupling, fracture events{RST}
  {G}✓{RST} 7. Builder save/load   {DIM}{len(pump_system.parts)}-part pump system{RST}

  {B}EventBus:{RST} {total_events} events total
  {B}Runtime:{RST}  {elapsed_total:.1f}ms celkem

  {Y}Next: MVP 2 (3D viewport) nebo MVP 5 (full hydrodynamics Level 2){RST}
""")


if __name__ == "__main__":
    run()
