"""
engine/ai/agent.py
==================
AI agenti — NPC s pathfindingem, behavior trees, senzory a metabolismem.

Blueprint §10: "NPC agents, pathfinding, behavior trees, utility AI,
                swarm behavior, sensory system, needs/metabolism,
                memory/replay, learning agents (experimentální)"

Agent může vnímat:
  světlo, teplotu, zvuk, vodu, překážky, ostatní entity, nebezpečí, zdroje
"""
from __future__ import annotations

import heapq
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
import numpy as np


# ── Sensory System ────────────────────────────────────────────────────────────

@dataclass
class SensoryInput:
    """Co agent vidí/cítí v daném ticku."""
    temperature: float = 0.0
    danger_level: float = 0.0    # kombinace entropy + damage
    fluid_nearby: bool = False
    gas_toxic: bool = False
    light_level: float = 1.0
    entities_nearby: List[str] = field(default_factory=list)
    resource_nearby: Optional[Tuple[int,int,int]] = None   # poloha nejbližšího zdroje
    solid_neighbors: List[bool] = field(default_factory=lambda: [False]*6)  # N,S,E,W,U,D


class SensorySystem:
    """
    Senzorický systém pro agenta.
    Blueprint §10: "sensory system — světlo, teplotu, zvuk, vodu, překážky..."
    """

    def __init__(self, sight_radius: int = 8):
        self.sight_radius = sight_radius

    def scan(self,
             agent_pos: Tuple[int,int,int],
             temperature: np.ndarray,
             entropy: np.ndarray,
             fluid: np.ndarray,
             gas_toxic: np.ndarray,
             solid: np.ndarray,
             other_agents: List[Tuple[str, Tuple[int,int,int]]]) -> SensoryInput:
        """Vygeneruj SensoryInput pro agenta na pozici."""
        x, y, z = agent_pos
        sx, sy, sz = temperature.shape

        # Lokální hodnoty (v buňce agenta a okolí)
        lx0 = max(0, x - self.sight_radius)
        lx1 = min(sx, x + self.sight_radius + 1)
        ly0 = max(0, y - self.sight_radius)
        ly1 = min(sy, y + self.sight_radius + 1)
        lz0 = max(0, z - self.sight_radius)
        lz1 = min(sz, z + self.sight_radius + 1)

        local_temp = temperature[lx0:lx1, ly0:ly1, lz0:lz1]
        local_ent  = entropy[lx0:lx1, ly0:ly1, lz0:lz1]
        local_fluid = fluid[lx0:lx1, ly0:ly1, lz0:lz1]
        local_gas  = gas_toxic[lx0:lx1, ly0:ly1, lz0:lz1]

        agent_temp = float(temperature[x, y, z]) if 0 <= x < sx and 0 <= y < sy and 0 <= z < sz else 0.0
        agent_danger = float(entropy[x, y, z]) * 0.5 + float(local_temp.max()) * 0.3

        # Solid sousedé (N, S, E, W, U, D) = (-z, +z, +x, -x, +y, -y)
        dirs = [(0,0,-1),(0,0,1),(1,0,0),(-1,0,0),(0,1,0),(0,-1,0)]
        solid_neighbors = []
        for (dx, dy, dz) in dirs:
            nx, ny, nz = x+dx, y+dy, z+dz
            if 0 <= nx < sx and 0 <= ny < sy and 0 <= nz < sz:
                solid_neighbors.append(bool(solid[nx, ny, nz]))
            else:
                solid_neighbors.append(True)  # hranice = solid

        # Agenti v dohledu
        nearby_agents = [
            aid for aid, apos in other_agents
            if (abs(apos[0]-x) + abs(apos[1]-y) + abs(apos[2]-z)) < self.sight_radius
        ]

        return SensoryInput(
            temperature=agent_temp,
            danger_level=agent_danger,
            fluid_nearby=bool(local_fluid.max() > 0.2),
            gas_toxic=bool(local_gas.any()),
            light_level=1.0,   # TODO: light simulation
            entities_nearby=nearby_agents,
            solid_neighbors=solid_neighbors,
        )


# ── Pathfinding (A*) ──────────────────────────────────────────────────────────

class Pathfinder:
    """
    A* pathfinding na voxelovém gridu.
    Blueprint §10: "pathfinding"
    """

    def find_path(self,
                  start: Tuple[int,int,int],
                  goal: Tuple[int,int,int],
                  solid: np.ndarray,
                  max_dist: int = 64) -> Optional[List[Tuple[int,int,int]]]:
        """
        Najdi cestu ze start do goal přes ne-solid buňky.
        Vrátí seznam pozic (bez start, včetně goal), nebo None pokud cesta neexistuje.
        """
        if not self._walkable(goal, solid):
            return None

        def h(pos):
            return abs(pos[0]-goal[0]) + abs(pos[1]-goal[1]) + abs(pos[2]-goal[2])

        open_set: List[Tuple[float, Tuple[int,int,int]]] = []
        heapq.heappush(open_set, (h(start), start))

        came_from: Dict[Tuple[int,int,int], Tuple[int,int,int]] = {}
        g_score: Dict[Tuple[int,int,int], float] = {start: 0.0}

        iterations = 0
        while open_set and iterations < max_dist * 3:
            iterations += 1
            _, current = heapq.heappop(open_set)

            if current == goal:
                return self._reconstruct(came_from, current)

            for neighbor in self._neighbors(current, solid):
                tentative_g = g_score.get(current, float('inf')) + 1.0
                if tentative_g < g_score.get(neighbor, float('inf')):
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f = tentative_g + h(neighbor)
                    heapq.heappush(open_set, (f, neighbor))

        return None   # cesta nenalezena

    def _walkable(self, pos: Tuple[int,int,int], solid: np.ndarray) -> bool:
        x, y, z = pos
        sx, sy, sz = solid.shape
        if not (0 <= x < sx and 0 <= y < sy and 0 <= z < sz):
            return False
        return not bool(solid[x, y, z])

    def _neighbors(self, pos: Tuple[int,int,int],
                   solid: np.ndarray) -> List[Tuple[int,int,int]]:
        x, y, z = pos
        candidates = [
            (x+1,y,z),(x-1,y,z),(x,y+1,z),(x,y-1,z),(x,y,z+1),(x,y,z-1)
        ]
        return [c for c in candidates if self._walkable(c, solid)]

    def _reconstruct(self, came_from: dict,
                     current: Tuple[int,int,int]) -> List[Tuple[int,int,int]]:
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        path.reverse()
        return path[1:]   # bez start bodu


# ── Behavior Tree ─────────────────────────────────────────────────────────────

class BTStatus(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    RUNNING = "running"


class BTNode:
    """Základní uzel behavior tree."""
    def tick(self, agent: "NPCAgent") -> BTStatus:
        return BTStatus.SUCCESS


class Sequence(BTNode):
    """AND — všechny děti musí uspět."""
    def __init__(self, *children: BTNode):
        self.children = list(children)

    def tick(self, agent: "NPCAgent") -> BTStatus:
        for child in self.children:
            status = child.tick(agent)
            if status != BTStatus.SUCCESS:
                return status
        return BTStatus.SUCCESS


class Selector(BTNode):
    """OR — první úspěšný dítě."""
    def __init__(self, *children: BTNode):
        self.children = list(children)

    def tick(self, agent: "NPCAgent") -> BTStatus:
        for child in self.children:
            status = child.tick(agent)
            if status == BTStatus.SUCCESS:
                return BTStatus.SUCCESS
        return BTStatus.FAILURE


class Condition(BTNode):
    """Podmínka — success pokud fn(agent) je True."""
    def __init__(self, fn: Callable[["NPCAgent"], bool], name: str = ""):
        self.fn = fn
        self.name = name

    def tick(self, agent: "NPCAgent") -> BTStatus:
        return BTStatus.SUCCESS if self.fn(agent) else BTStatus.FAILURE


class Action(BTNode):
    """Akce — volá fn(agent), success pokud vrátí True nebo None."""
    def __init__(self, fn: Callable[["NPCAgent"], Optional[bool]], name: str = ""):
        self.fn = fn
        self.name = name

    def tick(self, agent: "NPCAgent") -> BTStatus:
        result = self.fn(agent)
        return BTStatus.SUCCESS if result is not False else BTStatus.FAILURE


# ── NPC Agent ─────────────────────────────────────────────────────────────────

@dataclass
class AgentNeeds:
    """
    Biologické potřeby agenta.
    Blueprint §10: "needs/metabolism"
    """
    hunger: float   = 0.0    # 0 = sytý, 1 = umírá hlady
    fear: float     = 0.0    # 0 = klidný, 1 = panika
    curiosity: float = 0.5   # 0 = pasivní, 1 = průzkumný
    social: float   = 0.5    # 0 = samotář, 1 = společenský
    energy: float   = 1.0    # 0 = vyčerpaný, 1 = plný


class NPCAgent:
    """
    Kompletní NPC agent pro VoxForge platformu.

    Blueprint §10:
    - pathfinding (A*)
    - behavior tree (Sequence, Selector, Condition, Action)
    - sensory system (teplota, nebezpečí, překážky)
    - needs/metabolism (hlad, strach, zvídavost)
    - memory/replay (pamatuji si kde jsem byl)
    """

    def __init__(self, agent_id: str, pos: Tuple[int,int,int],
                 behavior_tree: Optional[BTNode] = None):
        self.agent_id = agent_id
        self.pos = list(pos)
        self.health = 1.0
        self.alive = True
        self.needs = AgentNeeds()
        self.sensory: Optional[SensoryInput] = None
        self.path: List[Tuple[int,int,int]] = []
        self.target: Optional[Tuple[int,int,int]] = None
        self.behavior_tree = behavior_tree or self._default_bt()
        self.memory: deque = deque(maxlen=64)   # pamatuj si posledních 64 pozic
        self._pathfinder = Pathfinder()
        self._tick = 0
        self.tags: Set[str] = set()

    def update(self, tick: int, sensory: SensoryInput,
               solid: np.ndarray) -> List[dict]:
        """
        Hlavní update agenta — jeden tick.
        Vrátí seznam akcí/eventů.
        """
        self._tick = tick
        self.sensory = sensory
        actions: List[dict] = []

        if not self.alive:
            return actions

        # Metabolism
        self._update_needs(sensory)

        # Behavior tree
        status = self.behavior_tree.tick(self)

        # Pohyb po cestě
        if self.path:
            next_pos = self.path[0]
            if not solid[next_pos]:
                self.pos = list(next_pos)
                self.path.pop(0)
                self.memory.append(tuple(self.pos))
                actions.append({
                    "type": "agent_moved",
                    "agent_id": self.agent_id,
                    "pos": tuple(self.pos),
                })

        # Smrt
        if self.health <= 0:
            self.alive = False
            actions.append({"type": "agent_died", "agent_id": self.agent_id})

        return actions

    def navigate_to(self, goal: Tuple[int,int,int], solid: np.ndarray) -> bool:
        """Nastav novou cestu k cíli. Vrátí True pokud cesta existuje."""
        path = self._pathfinder.find_path(tuple(self.pos), goal, solid)
        if path:
            self.path = path
            self.target = goal
            return True
        return False

    def _update_needs(self, s: SensoryInput) -> None:
        """Aktualizuj potřeby na základě podmínek."""
        # Hlad roste
        self.needs.hunger = min(1.0, self.needs.hunger + 0.001)
        # Strach z nebezpečí
        if s.danger_level > 0.5:
            self.needs.fear = min(1.0, self.needs.fear + 0.05)
        else:
            self.needs.fear = max(0.0, self.needs.fear - 0.02)
        # Zvídavost klesat při strachu
        if self.needs.fear > 0.7:
            self.needs.curiosity = max(0.0, self.needs.curiosity - 0.03)
        # Poškození z tepla
        if s.temperature > 0.7:
            self.health = max(0.0, self.health - (s.temperature - 0.7) * 0.05)
        # Poškození z toxického plynu
        if s.gas_toxic:
            self.health = max(0.0, self.health - 0.02)

    def _default_bt(self) -> BTNode:
        """
        Výchozí behavior tree:
        SELECTOR:
          1. Flee (pokud velké nebezpečí)
          2. Seek safety (pokud střední nebezpečí)
          3. Find food (pokud hladový)
          4. Explore (zvídavost)
          5. Idle
        """
        flee = Sequence(
            Condition(lambda a: a.sensory and a.sensory.danger_level > 0.7, "is_danger_high"),
            Action(lambda a: self._flee(), "flee"),
        )
        seek_safety = Sequence(
            Condition(lambda a: a.sensory and a.sensory.danger_level > 0.4, "is_danger_medium"),
            Action(lambda a: self._move_random_safe(), "move_safe"),
        )
        find_food = Sequence(
            Condition(lambda a: a.needs.hunger > 0.6, "is_hungry"),
            Action(lambda a: self._seek_resource(), "seek_food"),
        )
        explore = Sequence(
            Condition(lambda a: a.needs.curiosity > 0.5, "is_curious"),
            Action(lambda a: self._wander(), "wander"),
        )
        idle = Action(lambda a: True, "idle")

        return Selector(flee, seek_safety, find_food, explore, idle)

    def _flee(self) -> bool:
        """Útěk od nebezpečí."""
        if self.sensory:
            # Pohyb v opačném směru od horké buňky
            pass  # implementace závisí na world reference
        return True

    def _move_random_safe(self) -> bool:
        return True

    def _seek_resource(self) -> bool:
        if self.sensory and self.sensory.resource_nearby:
            self.target = self.sensory.resource_nearby
        return True

    def _wander(self) -> bool:
        return True

    def __repr__(self) -> str:
        return (f"NPCAgent(id={self.agent_id}, "
                f"pos={tuple(self.pos)}, "
                f"health={self.health:.2f}, "
                f"fear={self.needs.fear:.2f})")
