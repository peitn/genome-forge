"""
engine/ai/swarm.py
==================
Swarm Behavior — rojová AI pro kolektivní chování entit.

Blueprint §10: "swarm behavior"

Implementuje:
  - Boids algoritmus (separation, alignment, cohesion)
  - Formace (V, čtverec, kruh, kolona)
  - Stigmergie (pheromone trails)
  - Skupinové pathfinding (flow fields)
  - Predator/Prey dynamika
  - Ant Colony Optimization pro hledání cest
  - Emergentní chování z jednoduchých pravidel
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np


# ─── Boid ──────────────────────────────────────────────────────────────────

@dataclass
class Boid:
    """Jeden agent v roji."""
    boid_id: str
    position: np.ndarray      # (3,) float32
    velocity: np.ndarray      # (3,) float32
    acceleration: np.ndarray  # (3,) float32
    max_speed: float = 3.0
    max_force: float = 0.15
    mass: float = 1.0
    # Role v roji
    is_leader: bool = False
    group_id: str = "default"
    # Pheromone (pro stigmergie)
    pheromone_strength: float = 1.0
    # Visual state
    color: Tuple[float,float,float] = (0.8, 0.8, 0.2)

    def __post_init__(self):
        if not isinstance(self.position, np.ndarray):
            self.position = np.array(self.position, dtype=np.float32)
        if not isinstance(self.velocity, np.ndarray):
            self.velocity = np.array(self.velocity, dtype=np.float32)
        if not isinstance(self.acceleration, np.ndarray):
            self.acceleration = np.zeros(3, dtype=np.float32)

    def apply_force(self, force: np.ndarray) -> None:
        self.acceleration += force / self.mass

    def update(self, dt: float) -> None:
        self.velocity += self.acceleration * dt
        speed = np.linalg.norm(self.velocity)
        if speed > self.max_speed:
            self.velocity = self.velocity / speed * self.max_speed
        self.position += self.velocity * dt
        self.acceleration[:] = 0

    def seek(self, target: np.ndarray) -> np.ndarray:
        """Steering force směrem k cíli."""
        desired = target - self.position
        d = np.linalg.norm(desired)
        if d < 1e-6:
            return np.zeros(3, dtype=np.float32)
        desired = desired / d * self.max_speed
        steer = desired - self.velocity
        return self._limit(steer, self.max_force)

    def flee(self, threat: np.ndarray) -> np.ndarray:
        """Steering force pryč od hrozby."""
        return -self.seek(threat)

    def arrive(self, target: np.ndarray, slow_radius: float = 5.0) -> np.ndarray:
        """Seek s zpomalením blízko cíle (arrival behavior)."""
        desired = target - self.position
        d = np.linalg.norm(desired)
        if d < 1e-6:
            return np.zeros(3, dtype=np.float32)
        speed = self.max_speed
        if d < slow_radius:
            speed = self.max_speed * (d / slow_radius)
        desired = desired / d * speed
        steer = desired - self.velocity
        return self._limit(steer, self.max_force)

    def _limit(self, v: np.ndarray, max_val: float) -> np.ndarray:
        mag = np.linalg.norm(v)
        if mag > max_val and mag > 1e-9:
            return v / mag * max_val
        return v


# ─── Pheromone Grid ───────────────────────────────────────────────────────────

class PheromoneGrid:
    """
    Stigmergie — chemické stopy v prostoru.
    Implementuje Ant Colony Optimization základ.
    """

    def __init__(self, sx: int, sz: int, decay: float = 0.005):
        self.sx = sx; self.sz = sz
        self.decay = decay
        self.grid = np.zeros((sx, sz), dtype=np.float32)   # intensity
        self.trail_types: Dict[str, np.ndarray] = {
            "food":   np.zeros((sx, sz), dtype=np.float32),
            "danger": np.zeros((sx, sz), dtype=np.float32),
            "home":   np.zeros((sx, sz), dtype=np.float32),
        }

    def deposit(self, x: int, z: int, amount: float,
                trail_type: str = "food") -> None:
        """Uloň feromon na pozici."""
        if 0 <= x < self.sx and 0 <= z < self.sz:
            if trail_type in self.trail_types:
                self.trail_types[trail_type][x, z] = min(1.0,
                    self.trail_types[trail_type][x, z] + amount)
            self.grid[x, z] = min(1.0, self.grid[x, z] + amount)

    def deposit_trail(self, positions: List[Tuple[int,int]],
                      amount: float, trail_type: str = "food") -> None:
        """Uloň feromon podél trasy."""
        for (x, z) in positions:
            self.deposit(x, z, amount, trail_type)

    def step(self) -> None:
        """Evaporace feromonů."""
        self.grid *= (1.0 - self.decay)
        for tg in self.trail_types.values():
            tg *= (1.0 - self.decay)

    def get_gradient(self, x: int, z: int,
                     trail_type: str = "food") -> Tuple[float, float]:
        """Vrátí gradient feromonů (dx, dz) — směr ke koncentraci."""
        grid = self.trail_types.get(trail_type, self.grid)
        dx = 0.0; dz = 0.0
        for ddx, ddz in [(1,0),(-1,0),(0,1),(0,-1)]:
            nx, nz = x+ddx, z+ddz
            if 0 <= nx < self.sx and 0 <= nz < self.sz:
                val = float(grid[nx, nz])
                dx += ddx * val
                dz += ddz * val
        mag = math.sqrt(dx*dx + dz*dz)
        if mag > 1e-9:
            dx /= mag; dz /= mag
        return dx, dz

    def get_at(self, x: int, z: int, trail_type: str = "food") -> float:
        grid = self.trail_types.get(trail_type, self.grid)
        if 0 <= x < self.sx and 0 <= z < self.sz:
            return float(grid[x, z])
        return 0.0


# ─── Flow Field ───────────────────────────────────────────────────────────────

class FlowField:
    """
    Flow field pro skupinové pathfinding.
    Každá buňka má steering vector směrem k cíli.
    Používá BFS od cíle pro optimální flow.
    """

    def __init__(self, sx: int, sz: int):
        self.sx = sx; self.sz = sz
        self.field = np.zeros((sx, sz, 2), dtype=np.float32)   # (dx, dz) per cell
        self._costs = np.full((sx, sz), float('inf'))

    def compute(self, goal_x: int, goal_z: int,
                solid: np.ndarray) -> None:
        """Přepočítej flow field pro daný cíl (BFS od goal)."""
        self._costs[:] = float('inf')
        self.field[:] = 0

        if not (0 <= goal_x < self.sx and 0 <= goal_z < self.sz):
            return

        from collections import deque
        queue = deque()
        self._costs[goal_x, goal_z] = 0
        queue.append((goal_x, goal_z))

        while queue:
            x, z = queue.popleft()
            cur_cost = self._costs[x, z]
            for dx, dz in [(1,0),(-1,0),(0,1),(0,-1)]:
                nx, nz = x+dx, z+dz
                if not (0 <= nx < self.sx and 0 <= nz < self.sz):
                    continue
                # Kontrola solid (2D průmět)
                is_blocked = bool(solid[nx, :, nz].any()) if solid.ndim == 3 else bool(solid[nx, nz])
                if is_blocked:
                    continue
                new_cost = cur_cost + 1
                if new_cost < self._costs[nx, nz]:
                    self._costs[nx, nz] = new_cost
                    queue.append((nx, nz))

        # Konvertuj costs na vektory (gradient sestupem)
        for x in range(self.sx):
            for z in range(self.sz):
                if self._costs[x, z] == float('inf'):
                    continue
                best_dx, best_dz = 0.0, 0.0
                best_cost = self._costs[x, z]
                for dx, dz in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
                    nx, nz = x+dx, z+dz
                    if 0 <= nx < self.sx and 0 <= nz < self.sz:
                        c = self._costs[nx, nz]
                        if c < best_cost:
                            best_cost = c
                            best_dx, best_dz = float(dx), float(dz)
                mag = math.sqrt(best_dx**2 + best_dz**2)
                if mag > 0:
                    self.field[x, z] = [best_dx/mag, best_dz/mag]

    def get_direction(self, x: int, z: int) -> np.ndarray:
        """Vrátí steering vector pro pozici."""
        ix, iz = int(x), int(z)
        if 0 <= ix < self.sx and 0 <= iz < self.sz:
            d = self.field[ix, iz]
            return np.array([d[0], 0.0, d[1]], dtype=np.float32)
        return np.zeros(3, dtype=np.float32)


# ─── Formace ──────────────────────────────────────────────────────────────────

class FormationType(str, Enum):
    V_SHAPE   = "v_shape"
    LINE      = "line"
    CIRCLE    = "circle"
    COLUMN    = "column"
    SQUARE    = "square"
    WEDGE     = "wedge"


def compute_formation_offsets(formation: FormationType,
                              count: int, spacing: float = 2.0
                              ) -> List[np.ndarray]:
    """Vrátí seznam 3D offset vektorů pro každého člena formace."""
    offsets = []
    if formation == FormationType.V_SHAPE:
        offsets.append(np.zeros(3, dtype=np.float32))   # leader vpředu
        for i in range(1, count):
            side = 1 if i % 2 == 1 else -1
            row = (i + 1) // 2
            offsets.append(np.array([-row * spacing,
                                      0,
                                      side * row * spacing * 0.7],
                                     dtype=np.float32))

    elif formation == FormationType.LINE:
        for i in range(count):
            offsets.append(np.array([-i * spacing, 0, 0], dtype=np.float32))

    elif formation == FormationType.CIRCLE:
        for i in range(count):
            angle = 2 * math.pi * i / count
            offsets.append(np.array([math.cos(angle) * spacing * 1.5,
                                      0,
                                      math.sin(angle) * spacing * 1.5],
                                     dtype=np.float32))

    elif formation == FormationType.COLUMN:
        cols = max(1, int(math.sqrt(count)))
        for i in range(count):
            row = i // cols
            col = i % cols
            offsets.append(np.array([-row * spacing,
                                      0,
                                      (col - cols//2) * spacing],
                                     dtype=np.float32))

    elif formation == FormationType.SQUARE:
        side = max(1, int(math.sqrt(count)))
        for i in range(count):
            r = i // side
            c = i % side
            offsets.append(np.array([-r * spacing, 0, c * spacing],
                                     dtype=np.float32))

    elif formation == FormationType.WEDGE:
        offsets.append(np.zeros(3, dtype=np.float32))
        for i in range(1, count):
            side = 1 if i % 2 == 1 else -1
            row = (i + 1) // 2
            offsets.append(np.array([-row * spacing * 0.8,
                                      0,
                                      side * row * spacing],
                                     dtype=np.float32))

    # Doplň chybějící (kdyby count > počet definovaných offsetů)
    while len(offsets) < count:
        offsets.append(np.zeros(3, dtype=np.float32))
    return offsets[:count]


# ─── Swarm ────────────────────────────────────────────────────────────────────

@dataclass
class SwarmConfig:
    """Konfigurace roje — váhy jednotlivých sil."""
    # Boids
    separation_weight:  float = 1.5
    alignment_weight:   float = 1.0
    cohesion_weight:    float = 1.0
    separation_radius:  float = 2.5
    perception_radius:  float = 8.0
    # Seek
    seek_weight:        float = 0.8
    # Obstacle avoidance
    avoid_weight:       float = 2.0
    avoid_radius:       float = 3.0
    # Formation
    formation_weight:   float = 1.2
    # Pheromone
    pheromone_weight:   float = 0.5
    # Noise (náhodnost)
    noise_weight:       float = 0.2
    # Limity
    max_speed:          float = 4.0
    max_force:          float = 0.3
    # Predator-prey
    predator_flee_radius: float = 12.0
    predator_flee_weight: float = 3.0


class Swarm:
    """
    Kompletní swarm systém.
    Implementuje Boids algoritmus + formace + stigmergie + flow fields.

    Blueprint §10: "swarm behavior"

    Použití:
        swarm = Swarm(config=SwarmConfig())
        for i in range(20):
            swarm.add_boid(f"b{i}", position=np.random.rand(3) * 20)
        swarm.set_goal(np.array([50, 0, 50]))
        for tick in range(1000):
            swarm.update(dt=0.016)
    """

    def __init__(self, config: SwarmConfig = None,
                 grid_size: Tuple[int,int] = (64, 64)):
        self.config = config or SwarmConfig()
        self.boids: Dict[str, Boid] = {}
        self.goal: Optional[np.ndarray] = None
        self.formation: Optional[FormationType] = None
        self._formation_offsets: List[np.ndarray] = []
        self.pheromones = PheromoneGrid(*grid_size, decay=0.003)
        self.flow_field = FlowField(*grid_size)
        self._rng = np.random.default_rng(42)
        self._predators: List[np.ndarray] = []   # pozice predátorů
        self._tick = 0
        # Statistiky
        self._avg_velocity = np.zeros(3, dtype=np.float32)
        self._centroid     = np.zeros(3, dtype=np.float32)

    # ── Management ────────────────────────────────────────────────────────────

    def add_boid(self, boid_id: str,
                 position: Optional[np.ndarray] = None,
                 velocity: Optional[np.ndarray] = None,
                 is_leader: bool = False,
                 group_id: str = "default") -> Boid:
        pos = position if position is not None else (
            self._rng.random(3).astype(np.float32) * 10)
        vel = velocity if velocity is not None else (
            (self._rng.random(3).astype(np.float32) - 0.5) * 2)
        boid = Boid(
            boid_id=boid_id,
            position=pos.astype(np.float32),
            velocity=vel.astype(np.float32),
            acceleration=np.zeros(3, dtype=np.float32),
            max_speed=self.config.max_speed,
            max_force=self.config.max_force,
            is_leader=is_leader,
            group_id=group_id,
        )
        self.boids[boid_id] = boid
        self._rebuild_formation()
        return boid

    def remove_boid(self, boid_id: str) -> None:
        self.boids.pop(boid_id, None)
        self._rebuild_formation()

    def set_goal(self, goal: np.ndarray) -> None:
        self.goal = goal.astype(np.float32)

    def set_formation(self, formation: Optional[FormationType]) -> None:
        self.formation = formation
        self._rebuild_formation()

    def add_predator(self, position: np.ndarray) -> None:
        self._predators.append(position.astype(np.float32))

    def clear_predators(self) -> None:
        self._predators.clear()

    # ── Simulace ──────────────────────────────────────────────────────────────

    def update(self, dt: float = 0.016) -> None:
        """Jeden tick swarm simulace."""
        self._tick += 1
        boid_list = list(self.boids.values())
        cfg = self.config

        if not boid_list:
            return

        # Přepočítej centroid a avg velocity
        positions = np.array([b.position for b in boid_list], dtype=np.float32)
        velocities = np.array([b.velocity for b in boid_list], dtype=np.float32)
        self._centroid = positions.mean(axis=0)
        self._avg_velocity = velocities.mean(axis=0)

        # Formace offsety (přiřaď k boidy)
        leader_boids = [b for b in boid_list if b.is_leader]
        leader_pos = leader_boids[0].position if leader_boids else self._centroid

        for idx, boid in enumerate(boid_list):
            force = np.zeros(3, dtype=np.float32)

            # 1. Separace — vyhni se přeplnění
            sep = self._separation(boid, boid_list)
            force += sep * cfg.separation_weight

            # 2. Alignace — letí stejným směrem jako sousedé
            aln = self._alignment(boid, boid_list)
            force += aln * cfg.alignment_weight

            # 3. Koheze — drž se blízko skupiny
            coh = self._cohesion(boid, boid_list)
            force += coh * cfg.cohesion_weight

            # 4. Seek goal nebo formace
            if self.formation and idx < len(self._formation_offsets):
                formation_target = leader_pos + self._formation_offsets[idx]
                seek_f = boid.arrive(formation_target, slow_radius=3.0)
                force += seek_f * cfg.formation_weight
            elif self.goal is not None:
                seek_f = boid.arrive(self.goal, slow_radius=8.0)
                force += seek_f * cfg.seek_weight

            # 5. Úniku před predátory
            for pred_pos in self._predators:
                d = np.linalg.norm(boid.position - pred_pos)
                if d < cfg.predator_flee_radius and d > 1e-6:
                    flee_f = boid.flee(pred_pos) * (1.0 - d/cfg.predator_flee_radius)
                    force += flee_f * cfg.predator_flee_weight

            # 6. Pheromone gradient
            if cfg.pheromone_weight > 0:
                bx, bz = int(boid.position[0]), int(boid.position[2])
                gx, gz = self.pheromones.get_gradient(bx, bz, "food")
                ph_force = np.array([gx, 0, gz], dtype=np.float32)
                force += ph_force * cfg.pheromone_weight

            # 7. Šum (náhodný drift)
            if cfg.noise_weight > 0:
                noise = (self._rng.random(3).astype(np.float32) - 0.5) * 2
                noise[1] = 0  # bez vertikálního šumu (2D pohyb)
                force += noise * cfg.noise_weight

            # Aplikuj sílu
            boid.apply_force(force)

        # Aktualizuj pozice
        for boid in boid_list:
            boid.update(dt)
            # Uloň feromon (leader)
            if boid.is_leader:
                bx, bz = int(boid.position[0]), int(boid.position[2])
                self.pheromones.deposit(bx, bz, 0.1 * boid.pheromone_strength)

        # Evaporace feromonů každých 10 ticků
        if self._tick % 10 == 0:
            self.pheromones.step()

    # ── Boids chování ────────────────────────────────────────────────────────

    def _separation(self, boid: Boid, neighbors: List[Boid]) -> np.ndarray:
        steer = np.zeros(3, dtype=np.float32)
        count = 0
        for other in neighbors:
            if other.boid_id == boid.boid_id:
                continue
            d = np.linalg.norm(boid.position - other.position)
            if 0 < d < self.config.separation_radius:
                diff = boid.position - other.position
                diff = diff / (d * d)   # váha vzdáleností
                steer += diff
                count += 1
        if count > 0:
            steer /= count
        mag = np.linalg.norm(steer)
        if mag > 1e-9:
            steer = steer / mag * boid.max_speed - boid.velocity
            steer = boid._limit(steer, boid.max_force)
        return steer

    def _alignment(self, boid: Boid, neighbors: List[Boid]) -> np.ndarray:
        avg_vel = np.zeros(3, dtype=np.float32)
        count = 0
        for other in neighbors:
            if other.boid_id == boid.boid_id:
                continue
            d = np.linalg.norm(boid.position - other.position)
            if d < self.config.perception_radius:
                avg_vel += other.velocity
                count += 1
        if count > 0:
            avg_vel /= count
            mag = np.linalg.norm(avg_vel)
            if mag > 1e-9:
                avg_vel = avg_vel / mag * boid.max_speed
            steer = avg_vel - boid.velocity
            return boid._limit(steer, boid.max_force)
        return np.zeros(3, dtype=np.float32)

    def _cohesion(self, boid: Boid, neighbors: List[Boid]) -> np.ndarray:
        center = np.zeros(3, dtype=np.float32)
        count = 0
        for other in neighbors:
            if other.boid_id == boid.boid_id:
                continue
            d = np.linalg.norm(boid.position - other.position)
            if d < self.config.perception_radius:
                center += other.position
                count += 1
        if count > 0:
            center /= count
            return boid.seek(center)
        return np.zeros(3, dtype=np.float32)

    # ── Formace ───────────────────────────────────────────────────────────────

    def _rebuild_formation(self) -> None:
        if self.formation is None:
            self._formation_offsets = []
            return
        self._formation_offsets = compute_formation_offsets(
            self.formation, len(self.boids), spacing=2.5)

    # ── Predator-Prey ─────────────────────────────────────────────────────────

    def hunt_nearest(self, predator_id: str, prey_swarm: "Swarm") -> None:
        """
        Predátor (jeden boid v tomto roji) loví kořist z jiného roje.
        Blueprint §10: predator/prey dynamika.
        """
        pred = self.boids.get(predator_id)
        if not pred or not prey_swarm.boids:
            return
        # Najdi nejbližší kořist
        nearest = None
        nearest_d = float('inf')
        for prey in prey_swarm.boids.values():
            d = float(np.linalg.norm(pred.position - prey.position))
            if d < nearest_d:
                nearest_d = d
                nearest = prey
        if nearest:
            seek_f = pred.seek(nearest.position)
            pred.apply_force(seek_f * 2.0)

    # ── Status ────────────────────────────────────────────────────────────────

    @property
    def stats(self) -> dict:
        if not self.boids:
            return {"count": 0}
        positions = np.array([b.position for b in self.boids.values()])
        speeds    = np.array([np.linalg.norm(b.velocity) for b in self.boids.values()])
        spread = float(np.std(positions, axis=0).mean()) if len(positions) > 1 else 0.0
        return {
            "count":     len(self.boids),
            "centroid":  [round(float(v), 2) for v in self._centroid],
            "avg_speed": round(float(speeds.mean()), 3),
            "spread":    round(spread, 3),
            "formation": self.formation.value if self.formation else None,
            "pheromone_total": round(float(self.pheromones.grid.sum()), 2),
            "tick":      self._tick,
        }

    def __repr__(self) -> str:
        return (f"Swarm(boids={len(self.boids)}, "
                f"formation={self.formation}, "
                f"tick={self._tick})")
