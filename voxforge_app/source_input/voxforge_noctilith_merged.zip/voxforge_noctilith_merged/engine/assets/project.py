"""
engine/assets/project.py
========================
Projektový formát (.voxproj) a Asset Registry.

Blueprint §14: "Projektový formát"
  my_project.voxproj/
    ├── project.json
    ├── world/
    ├── assets/
    ├── scripts/
    ├── builder_objects/
    ├── simulations/
    ├── game/
    └── settings.json

Blueprint §8: "Asset systém"
  Assety: voxel objects, materials, textures, procedural brushes,
          scripts, sounds, animations, particle effects,
          simulation presets, builder modules, game templates
"""
from __future__ import annotations

import json
import shutil
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional


# ── Typy projektů (blueprint §6 Game Layer) ───────────────────────────────────

class ProjectType(str, Enum):
    GAME        = "game"
    SIMULATION  = "simulation"
    BUILDER     = "builder"
    EDUCATIONAL = "educational"
    PHYSICS_LAB = "physics_lab"
    WORLD_MAP   = "world_map"
    ASSET_PACK  = "asset_pack"
    MODULE_PACK = "module_pack"


# ── Asset typy (blueprint §8) ─────────────────────────────────────────────────

class AssetType(str, Enum):
    VOXEL_OBJECT  = "voxel_object"
    MATERIAL      = "material"
    TEXTURE       = "texture"
    PROC_BRUSH    = "procedural_brush"
    SCRIPT        = "script"
    SOUND         = "sound"
    ANIMATION     = "animation"
    PARTICLE      = "particle_effect"
    SIM_PRESET    = "simulation_preset"
    BUILDER_MOD   = "builder_module"
    GAME_TEMPLATE = "game_template"
    WORLD_TEMPLATE = "world_template"
    EVENT_GRAPH   = "event_graph"
    GENOME        = "genome"


@dataclass
class AssetMeta:
    """
    Metadata assetu.
    Blueprint §8: "název, autor, verze, typ, závislosti, licence,
                   fyzikální vlastnosti, tagy, kompatibilita"
    """
    asset_id: str
    name: str
    asset_type: AssetType
    author: str = "unknown"
    version: str = "1.0.0"
    description: str = ""
    tags: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)   # asset_id
    license: str = "MIT"
    engine_version: str = "0.1.0"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    file_path: str = ""            # relativní cesta v projektu
    thumbnail: str = ""            # relativní cesta k náhledu
    # Fyzikální vlastnosti (pro materiálové assety)
    physical_props: Dict[str, Any] = field(default_factory=dict)
    # Kompatibilita
    compatible_with: List[str] = field(default_factory=list)


class AssetRegistry:
    """
    Registr všech assetů v projektu.
    Blueprint §8: "asset registry, import/export"
    """

    def __init__(self, project_dir: Path):
        self.project_dir = Path(project_dir)
        self._assets: Dict[str, AssetMeta] = {}
        self._registry_file = self.project_dir / "assets" / "registry.json"

    def register(self, meta: AssetMeta) -> AssetMeta:
        self._assets[meta.asset_id] = meta
        return meta

    def get(self, asset_id: str) -> Optional[AssetMeta]:
        return self._assets.get(asset_id)

    def find_by_type(self, atype: AssetType) -> List[AssetMeta]:
        return [a for a in self._assets.values() if a.asset_type == atype]

    def find_by_tag(self, tag: str) -> List[AssetMeta]:
        return [a for a in self._assets.values() if tag in a.tags]

    def search(self, query: str) -> List[AssetMeta]:
        q = query.lower()
        return [a for a in self._assets.values()
                if q in a.name.lower() or q in a.description.lower()
                or any(q in t for t in a.tags)]

    def save(self) -> None:
        self._registry_file.parent.mkdir(parents=True, exist_ok=True)
        data = {aid: asdict(a) for aid, a in self._assets.items()}
        self._registry_file.write_text(json.dumps(data, indent=2))

    def load(self) -> None:
        if not self._registry_file.exists():
            return
        data = json.loads(self._registry_file.read_text())
        for aid, d in data.items():
            d["asset_type"] = AssetType(d["asset_type"])
            self._assets[aid] = AssetMeta(**d)

    def __len__(self) -> int:
        return len(self._assets)


# ── Simulační preset ──────────────────────────────────────────────────────────

@dataclass
class SimulationPreset:
    """
    Uložená konfigurace simulace.
    Blueprint §8: "simulation presets"
    """
    preset_id: str
    name: str
    description: str = ""
    enabled_modules: List[str] = field(default_factory=list)
    module_configs: Dict[str, Any] = field(default_factory=dict)
    world_size: tuple = (32, 16, 32)
    ticks_per_evolution: int = 200
    tags: List[str] = field(default_factory=list)


# ── Projektová nastavení ──────────────────────────────────────────────────────

@dataclass
class ProjectSettings:
    """
    Globální nastavení projektu.
    Blueprint §14: "project.json obsahuje: název, typ, verzi enginu,
                    zapnuté moduly, závislosti, startovací scénu, autorství"
    """
    name: str
    project_type: ProjectType
    engine_version: str = "0.1.0"
    enabled_modules: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)   # asset pack IDs
    start_scene: str = "world"
    author: str = "unknown"
    description: str = ""
    version: str = "1.0.0"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    tags: List[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.enabled_modules:
            defaults = {
                ProjectType.GAME:        ["thermal", "fluid", "damage", "scripting", "ai"],
                ProjectType.SIMULATION:  ["thermal", "fluid", "damage", "chemistry", "gas", "energy"],
                ProjectType.PHYSICS_LAB: ["thermal", "fluid", "damage", "chemistry", "gas", "energy", "weather"],
                ProjectType.BUILDER:     ["scripting", "energy"],
                ProjectType.EDUCATIONAL: ["thermal", "fluid"],
                ProjectType.WORLD_MAP:   ["thermal", "fluid", "weather"],
            }
            self.enabled_modules = defaults.get(self.project_type, ["thermal", "fluid"])


# ── VoxProject ────────────────────────────────────────────────────────────────

class VoxProject:
    """
    Kompletní VoxForge projekt.

    Blueprint §14: Struktura my_project.voxproj/

    Typy projektů (blueprint §6):
      Game, Simulation, Builder, Educational, PhysicsLab, World, AssetPack

    Použití:
        # Vytvoř nový projekt
        proj = VoxProject.create(
            Path("/projects/my_game"),
            name="My Vox Game",
            project_type=ProjectType.GAME,
            author="peiti",
        )

        # Přidej asset
        proj.registry.register(AssetMeta(
            asset_id="mat_custom_stone",
            name="Custom Stone",
            asset_type=AssetType.MATERIAL,
            tags=["stone", "custom"],
        ))

        proj.save()

        # Načti existující
        proj = VoxProject.load(Path("/projects/my_game"))
    """

    STRUCTURE = [
        "world/regions",
        "world/metadata.json",
        "assets",
        "scripts",
        "builder_objects",
        "simulations",
        "game",
    ]

    def __init__(self, root: Path, settings: ProjectSettings):
        self.root = Path(root)
        self.settings = settings
        self.registry = AssetRegistry(self.root)
        self._settings_file = self.root / "project.json"
        self._game_settings  = self.root / "game" / "rules.json"

    # ── Factory ──────────────────────────────────────────────────────────────

    @classmethod
    def create(cls, root: Path,
               name: str,
               project_type: ProjectType = ProjectType.SIMULATION,
               author: str = "unknown",
               description: str = "") -> "VoxProject":
        """Vytvoř novou strukturu projektu na disku."""
        root = Path(root)
        root.mkdir(parents=True, exist_ok=True)

        settings = ProjectSettings(
            name=name,
            project_type=project_type,
            author=author,
            description=description,
        )
        proj = cls(root, settings)
        proj._create_structure()
        proj.save()
        return proj

    @classmethod
    def load(cls, root: Path) -> "VoxProject":
        """Načti existující projekt."""
        root = Path(root)
        settings_file = root / "project.json"
        if not settings_file.exists():
            raise FileNotFoundError(f"Projekt nenalezen: {root}")
        d = json.loads(settings_file.read_text())
        d["project_type"] = ProjectType(d["project_type"])
        settings = ProjectSettings(**d)
        proj = cls(root, settings)
        proj.registry.load()
        return proj

    def save(self) -> None:
        """Ulož projekt (settings + asset registry)."""
        data = asdict(self.settings)
        data["project_type"] = self.settings.project_type.value
        self._settings_file.write_text(json.dumps(data, indent=2))
        self.registry.save()

    def _create_structure(self) -> None:
        """Vytvoř adresářovou strukturu projektu."""
        for subdir in self.STRUCTURE:
            p = self.root / subdir
            if "." in subdir:   # soubor
                p.parent.mkdir(parents=True, exist_ok=True)
                if not p.exists():
                    p.write_text("{}")
            else:
                p.mkdir(parents=True, exist_ok=True)

        # Výchozí game rules
        rules = {
            "max_players": 1,
            "respawn": True,
            "pvp": False,
            "starting_inventory": [],
            "win_conditions": [],
            "lose_conditions": ["player_health_zero"],
        }
        game_dir = self.root / "game"
        game_dir.mkdir(exist_ok=True)
        (game_dir / "rules.json").write_text(json.dumps(rules, indent=2))

        # Výchozí simulation preset
        preset = SimulationPreset(
            preset_id="default",
            name="Default",
            enabled_modules=self.settings.enabled_modules,
        )
        sim_dir = self.root / "simulations"
        sim_dir.mkdir(exist_ok=True)
        (sim_dir / "default.json").write_text(json.dumps(asdict(preset), indent=2))

    def add_script(self, name: str, content: str) -> Path:
        """Přidej script soubor do projektu."""
        scripts_dir = self.root / "scripts"
        scripts_dir.mkdir(exist_ok=True)
        path = scripts_dir / f"{name}.voxscript"
        path.write_text(content)
        self.registry.register(AssetMeta(
            asset_id=f"script_{name}",
            name=name,
            asset_type=AssetType.SCRIPT,
            file_path=f"scripts/{name}.voxscript",
        ))
        return path

    def add_builder_object(self, obj_path: Path) -> None:
        """Přidej builder objekt do projektu."""
        dest = self.root / "builder_objects" / obj_path.name
        dest.parent.mkdir(exist_ok=True)
        shutil.copy2(obj_path, dest)
        name = obj_path.stem
        self.registry.register(AssetMeta(
            asset_id=f"bobj_{name}",
            name=name,
            asset_type=AssetType.BUILDER_MOD,
            file_path=f"builder_objects/{obj_path.name}",
        ))

    def get_world_path(self) -> Path:
        return self.root / "world"

    @property
    def module_summary(self) -> str:
        mods = self.settings.enabled_modules
        return f"{self.settings.name} [{self.settings.project_type.value}] — moduly: {', '.join(mods)}"

    def __repr__(self) -> str:
        return (f"VoxProject(name='{self.settings.name}', "
                f"type={self.settings.project_type.value}, "
                f"assets={len(self.registry)})")
