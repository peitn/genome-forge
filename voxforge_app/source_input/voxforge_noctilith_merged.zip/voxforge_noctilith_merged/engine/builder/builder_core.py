#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
noctilith/builder.py
====================

NOCTILITH UNIVERSAL BUILDER (full unified package revision)
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME = "noctilith.builder"
MODULE_VERSION = "1.0.0"


# ==============================================================================
# CONFIG
# ==============================================================================

@dataclass
class BuilderConfig:
    seed: int = 4242
    rng_stream: int = 0

    bounds_policy: str = "clip"
    clip_padding: float = 1.5
    min_bounds: float = 1e-9
    nan_guard: bool = True
    noise_scale: float = 1.0

    default_gravity_coupling: float = 1.0
    default_em_coupling: float = 1.0
    default_strong_coupling: float = 1.0
    default_weak_coupling: float = 0.35

    quark_mass: float = 0.001
    electron_mass: float = 0.0005
    proton_mass: float = 1.0
    neutron_mass: float = 1.0
    electron_speed: float = 3.0
    core_spread: float = 0.02
    nucleon_spread: float = 0.05

    atom_detail_policy: str = "auto"
    full_atom_max_z: int = 12
    full_nucleon_max_z: int = 36
    keep_electrons_in_degraded_atoms: bool = True

    max_particles: int = 2_000_000
    max_particles_policy: str = "raise"

    electron_subsample_mode: str = "cap"
    electron_subsample_max: int = 64
    electron_fraction_degraded: float = 0.10

    store_meta: bool = True
    store_symmetry: bool = True

    default_light_intensity: float = 12.0
    default_light_radius: float = 1.5
    default_light_temperature_k: float = 4200.0
    auto_add_scene_lights: bool = False
    auto_light_scale_with_bounds: bool = True

    material_marker_mass_scale: float = 5.0
    organism_marker_mass_scale: float = 8.0
    ecosystem_marker_mass_scale: float = 30.0
    city_marker_mass_scale: float = 200.0
    planet_marker_mass_scale: float = 1000.0
    star_marker_mass_scale: float = 2500.0

    ambient_temperature_k: float = 293.15
    ambient_humidity: float = 0.45
    ambient_salinity: float = 0.0
    ambient_radiation: float = 0.0
    ambient_ph: float = 7.0

    macro_scatter_sigma: float = 0.25


# ==============================================================================
# ELEMENT TABLE
# ==============================================================================

ELEMENT_TABLE: List[Tuple[int, str, str]] = [
    (1,"H","Hydrogen"),(2,"He","Helium"),(3,"Li","Lithium"),(4,"Be","Beryllium"),
    (5,"B","Boron"),(6,"C","Carbon"),(7,"N","Nitrogen"),(8,"O","Oxygen"),
    (9,"F","Fluorine"),(10,"Ne","Neon"),(11,"Na","Sodium"),(12,"Mg","Magnesium"),
    (13,"Al","Aluminium"),(14,"Si","Silicon"),(15,"P","Phosphorus"),(16,"S","Sulfur"),
    (17,"Cl","Chlorine"),(18,"Ar","Argon"),(19,"K","Potassium"),(20,"Ca","Calcium"),
    (21,"Sc","Scandium"),(22,"Ti","Titanium"),(23,"V","Vanadium"),(24,"Cr","Chromium"),
    (25,"Mn","Manganese"),(26,"Fe","Iron"),(27,"Co","Cobalt"),(28,"Ni","Nickel"),
    (29,"Cu","Copper"),(30,"Zn","Zinc"),(31,"Ga","Gallium"),(32,"Ge","Germanium"),
    (33,"As","Arsenic"),(34,"Se","Selenium"),(35,"Br","Bromine"),(36,"Kr","Krypton"),
    (37,"Rb","Rubidium"),(38,"Sr","Strontium"),(39,"Y","Yttrium"),(40,"Zr","Zirconium"),
    (41,"Nb","Niobium"),(42,"Mo","Molybdenum"),(43,"Tc","Technetium"),(44,"Ru","Ruthenium"),
    (45,"Rh","Rhodium"),(46,"Pd","Palladium"),(47,"Ag","Silver"),(48,"Cd","Cadmium"),
    (49,"In","Indium"),(50,"Sn","Tin"),(51,"Sb","Antimony"),(52,"Te","Tellurium"),
    (53,"I","Iodine"),(54,"Xe","Xenon"),(55,"Cs","Caesium"),(56,"Ba","Barium"),
    (57,"La","Lanthanum"),(58,"Ce","Cerium"),(59,"Pr","Praseodymium"),(60,"Nd","Neodymium"),
    (61,"Pm","Promethium"),(62,"Sm","Samarium"),(63,"Eu","Europium"),(64,"Gd","Gadolinium"),
    (65,"Tb","Terbium"),(66,"Dy","Dysprosium"),(67,"Ho","Holmium"),(68,"Er","Erbium"),
    (69,"Tm","Thulium"),(70,"Yb","Ytterbium"),(71,"Lu","Lutetium"),(72,"Hf","Hafnium"),
    (73,"Ta","Tantalum"),(74,"W","Tungsten"),(75,"Re","Rhenium"),(76,"Os","Osmium"),
    (77,"Ir","Iridium"),(78,"Pt","Platinum"),(79,"Au","Gold"),(80,"Hg","Mercury"),
    (81,"Tl","Thallium"),(82,"Pb","Lead"),(83,"Bi","Bismuth"),(84,"Po","Polonium"),
    (85,"At","Astatine"),(86,"Rn","Radon"),(87,"Fr","Francium"),(88,"Ra","Radium"),
    (89,"Ac","Actinium"),(90,"Th","Thorium"),(91,"Pa","Protactinium"),(92,"U","Uranium"),
    (93,"Np","Neptunium"),(94,"Pu","Plutonium"),(95,"Am","Americium"),(96,"Cm","Curium"),
    (97,"Bk","Berkelium"),(98,"Cf","Californium"),(99,"Es","Einsteinium"),(100,"Fm","Fermium"),
    (101,"Md","Mendelevium"),(102,"No","Nobelium"),(103,"Lr","Lawrencium"),(104,"Rf","Rutherfordium"),
    (105,"Db","Dubnium"),(106,"Sg","Seaborgium"),(107,"Bh","Bohrium"),(108,"Hs","Hassium"),
    (109,"Mt","Meitnerium"),(110,"Ds","Darmstadtium"),(111,"Rg","Roentgenium"),(112,"Cn","Copernicium"),
    (113,"Nh","Nihonium"),(114,"Fl","Flerovium"),(115,"Mc","Moscovium"),(116,"Lv","Livermorium"),
    (117,"Ts","Tennessine"),(118,"Og","Oganesson"),
]

ELEMENTS_BY_Z = {z: {"atomic_number": z, "symbol": sym, "name": name} for z, sym, name in ELEMENT_TABLE}
ELEMENTS_BY_SYMBOL = {sym: {"atomic_number": z, "symbol": sym, "name": name} for z, sym, name in ELEMENT_TABLE}

ALKALI_METALS = {3,11,19,37,55,87}
ALKALINE_EARTH = {4,12,20,38,56,88}
HALOGENS = {9,17,35,53,85,117}
NOBLE_GASES = {2,10,18,36,54,86,118}
METALLOIDS = {5,14,32,33,51,52,84}
OTHER_NONMETALS = {1,6,7,8,15,16,34}
POST_TRANSITION = {13,31,49,50,81,82,83,113,114,115,116}
LANTHANIDES = set(range(57,72))
ACTINIDES = set(range(89,104))
TRANSITION_METALS = set(range(21,31))|set(range(39,49))|set(range(72,81))|set(range(104,113))


def _element_category(z: int) -> str:
    if z in ALKALI_METALS: return "alkali_metal"
    if z in ALKALINE_EARTH: return "alkaline_earth_metal"
    if z in HALOGENS: return "halogen"
    if z in NOBLE_GASES: return "noble_gas"
    if z in METALLOIDS: return "metalloid"
    if z in OTHER_NONMETALS: return "nonmetal"
    if z in POST_TRANSITION: return "post_transition_metal"
    if z in LANTHANIDES: return "lanthanide"
    if z in ACTINIDES: return "actinide"
    if z in TRANSITION_METALS: return "transition_metal"
    return "unknown"


# ==============================================================================
# EFFECTIVE DATA MODELS
# ==============================================================================

@dataclass
class MaterialProfile:
    name: str
    category: str = "generic"
    density: float = 1.0
    hardness: float = 0.5
    toughness: float = 0.5
    ductility: float = 0.5
    elasticity: float = 0.5
    thermal_conductivity: float = 0.5
    thermal_expansion: float = 0.1
    oxidation_resistance: float = 0.5
    corrosion_resistance: float = 0.5
    fatigue_resistance: float = 0.5
    wear_resistance: float = 0.5
    creep_resistance: float = 0.5
    fracture_toughness: float = 0.5
    porosity: float = 0.0
    grain_scale: float = 1.0
    composite_layers: List[str] = field(default_factory=list)
    notes: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EnvironmentProfile:
    temperature_k: float = 293.15
    humidity: float = 0.45
    salinity: float = 0.0
    radiation: float = 0.0
    ph: float = 7.0
    oxygen_fraction: float = 0.21
    pressure_bar: float = 1.0
    wind_speed: float = 0.0
    abrasion_index: float = 0.0
    uv_index: float = 0.0
    biofouling_pressure: float = 0.0


@dataclass
class DegradationState:
    fatigue: float = 0.0
    wear: float = 0.0
    corrosion: float = 0.0
    oxidation: float = 0.0
    thermal_damage: float = 0.0
    creep: float = 0.0
    fracture: float = 0.0
    contamination: float = 0.0
    hydration: float = 0.0
    health: float = 1.0


@dataclass
class GenomeProfile:
    genome_id: str
    ploidy: int = 2
    genome_size_mb: float = 100.0
    gene_count: int = 1000
    mutation_rate: float = 1e-6
    recombination_rate: float = 1e-3
    regulatory_complexity: float = 0.5
    metabolic_bias: float = 0.5
    growth_bias: float = 0.5
    resilience_bias: float = 0.5
    locomotion_bias: float = 0.5
    cognition_bias: float = 0.5
    engineered: bool = False
    edits: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class BiomechProfile:
    morphology: str = "generic"
    body_mass: float = 1.0
    muscle_factor: float = 0.5
    tendon_factor: float = 0.5
    bone_factor: float = 0.5
    fluid_factor: float = 0.5
    gait_efficiency: float = 0.5
    thermal_regulation: float = 0.5
    damage_tolerance: float = 0.5
    healing_rate: float = 0.5


# ==============================================================================
# PARSERS / HELPERS
# ==============================================================================

_FORMULA_TOKEN = re.compile(r"([A-Z][a-z]?)(\d*)")


def parse_formula(formula: str) -> Dict[str, int]:
    s = str(formula).strip()
    if not s:
        raise ValueError("Formula is empty.")
    out: Dict[str, int] = {}
    pos = 0
    for m in _FORMULA_TOKEN.finditer(s):
        if m.start() != pos:
            raise ValueError(f"Unsupported formula syntax near: {s[pos:]}")
        sym = m.group(1)
        cnt = int(m.group(2)) if m.group(2) else 1
        if sym not in ELEMENTS_BY_SYMBOL:
            raise ValueError(f"Unknown element symbol in formula: {sym}")
        out[sym] = out.get(sym, 0) + cnt
        pos = m.end()
    if pos != len(s):
        raise ValueError(f"Unsupported formula syntax near: {s[pos:]}")
    return out


# ==============================================================================
# BUILDER
# ==============================================================================

class NoctilithUniversalBuilder:
    def __init__(self, bounds: Tuple[float, float, float], cfg: Optional[BuilderConfig] = None):
        self.cfg = cfg or BuilderConfig()

        b = np.asarray(bounds, dtype=np.float64).reshape(3)
        if self.cfg.nan_guard and not np.isfinite(b).all():
            raise ValueError(f"Bounds contain NaN/Inf: {b}")
        b = np.maximum(b, float(self.cfg.min_bounds))
        self.bounds = b
        self.center = self.bounds / 2.0

        self.seed_eff = self._mix_seed(self.cfg.seed, self.cfg.rng_stream)
        self.rng = np.random.default_rng(self.seed_eff)

        self._r: List[np.ndarray] = []
        self._v: List[np.ndarray] = []
        self._m: List[float] = []
        self._q: List[float] = []

        self._force_gravity: List[float] = []
        self._force_em: List[float] = []
        self._force_strong: List[float] = []
        self._force_weak: List[float] = []

        self._meta: List[Dict[str, Any]] = []
        self._symmetry: List[Dict[str, Any]] = []

        self._force_sources: List[Dict[str, Any]] = []
        self._light_sources: List[Dict[str, Any]] = []
        self._materials: List[Dict[str, Any]] = []
        self._organisms: List[Dict[str, Any]] = []
        self._ecosystems: List[Dict[str, Any]] = []
        self._cities: List[Dict[str, Any]] = []
        self._planets: List[Dict[str, Any]] = []
        self._stellar_systems: List[Dict[str, Any]] = []

        self._dropped_particles = 0

    @staticmethod
    def _splitmix64(x: int) -> int:
        x = (int(x) + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
        z = x
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
        z = (z ^ (z >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
        z ^= z >> 31
        return int(z) & 0xFFFFFFFFFFFFFFFF

    @classmethod
    def _mix_seed(cls, seed: int, stream: int) -> int:
        return int(cls._splitmix64((int(seed) & 0xFFFFFFFFFFFFFFFF) ^ ((int(stream) << 1) & 0xFFFFFFFFFFFFFFFF)))

    @staticmethod
    def _as_vec3(x: Any) -> np.ndarray:
        return np.asarray(x, dtype=np.float64).reshape(3)

    def _guard_vec3(self, v: np.ndarray) -> np.ndarray:
        if self.cfg.nan_guard and not np.isfinite(v).all():
            raise ValueError(f"Vector contains NaN/Inf: {v}")
        return v

    def _apply_bounds_policy(self, r: np.ndarray) -> np.ndarray:
        mode = str(self.cfg.bounds_policy).lower().strip()
        r = self._guard_vec3(np.asarray(r, dtype=np.float64).reshape(3))
        if mode == "none":
            return r
        if mode == "wrap":
            out = np.empty_like(r)
            for d in range(3):
                L = max(float(self.bounds[d]), float(self.cfg.min_bounds))
                out[d] = r[d] % L
            return out
        if mode == "clip":
            pad = max(float(self.cfg.clip_padding), 0.0)
            lo = np.array([pad, pad, pad], dtype=np.float64)
            hi = np.maximum(lo, self.bounds - pad)
            return np.clip(r, lo, hi)
        raise ValueError(f"Unknown bounds_policy: {self.cfg.bounds_policy!r}")

    @staticmethod
    def _euler_matrix_xyz(angles: Tuple[float, float, float]) -> np.ndarray:
        ax, ay, az = [float(a) for a in angles]
        cx, sx = math.cos(ax), math.sin(ax)
        cy, sy = math.cos(ay), math.sin(ay)
        cz, sz = math.cos(az), math.sin(az)
        rx = np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]], dtype=np.float64)
        ry = np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]], dtype=np.float64)
        rz = np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]], dtype=np.float64)
        return rz @ ry @ rx

    @staticmethod
    def _default_symmetry_record(kind: str, antimatter: bool = False, parity: int = 1, time_orientation: int = 1) -> Dict[str, Any]:
        c = -1 if antimatter else 1
        p = 1 if int(parity) >= 0 else -1
        t = 1 if int(time_orientation) >= 0 else -1
        return {"kind": str(kind), "C": c, "P": p, "T": t, "CP": c*p, "CPT": c*p*t, "antimatter": bool(antimatter)}

    def _can_add_particle(self) -> bool:
        cap = int(self.cfg.max_particles or 0)
        if cap <= 0: return True
        if len(self._r) < cap: return True
        if str(self.cfg.max_particles_policy).lower().strip() == "drop":
            self._dropped_particles += 1
            return False
        raise RuntimeError(f"max_particles exceeded: {cap}")

    def _append_particle_record(self, r, v, m, q, fg, fe, fs, fw, meta=None, symmetry=None):
        if not self._can_add_particle(): return
        self._r.append(r); self._v.append(v)
        self._m.append(float(m)); self._q.append(float(q))
        self._force_gravity.append(float(fg)); self._force_em.append(float(fe))
        self._force_strong.append(float(fs)); self._force_weak.append(float(fw))
        self._meta.append(dict(meta or {}) if self.cfg.store_meta else {})
        self._symmetry.append(dict(symmetry or {}) if self.cfg.store_symmetry else {})

    def get_element(self, *, atomic_number=None, symbol=None):
        if atomic_number is not None:
            z = int(atomic_number)
            if z not in ELEMENTS_BY_Z: raise ValueError(f"Unknown atomic number: {z}")
            elem = dict(ELEMENTS_BY_Z[z])
        elif symbol is not None:
            sym = str(symbol).strip()
            if sym not in ELEMENTS_BY_SYMBOL: raise ValueError(f"Unknown element symbol: {sym}")
            elem = dict(ELEMENTS_BY_SYMBOL[sym])
        else:
            raise ValueError("Provide atomic_number or symbol.")
        elem["category"] = _element_category(int(elem["atomic_number"]))
        return elem

    def add_particle(self, r, v, m, q, *, force_gravity=None, force_em=None,
                     force_strong=0.0, force_weak=0.0, meta=None, symmetry=None):
        rr = self._apply_bounds_policy(self._as_vec3(r))
        vv = self._guard_vec3(self._as_vec3(v))
        mm, qq = float(m), float(q)
        if self.cfg.nan_guard and not (np.isfinite(mm) and np.isfinite(qq)):
            raise ValueError(f"m/q contain NaN/Inf: m={m}, q={q}")
        fg = float(abs(mm) if force_gravity is None else force_gravity)
        fe = float(abs(qq) if force_em is None else force_em)
        self._append_particle_record(rr, vv, mm, qq, fg, fe, float(force_strong), float(force_weak), meta=meta, symmetry=symmetry)

    def add_quark(self, pos, flavor="up", v_sigma=0.5, antimatter=False):
        fl = str(flavor).lower().strip()
        q = 2.0/3.0 if fl in {"up","charm","top"} else -1.0/3.0
        if antimatter: q = -q
        v = self.rng.normal(0.0, float(v_sigma)*float(self.cfg.noise_scale), 3)
        color = ["red","green","blue"][int(self.rng.integers(0,3))]
        if antimatter: color = "anti_" + color
        self.add_particle(pos, v, m=self.cfg.quark_mass, q=q,
            force_strong=self.cfg.default_strong_coupling, force_weak=self.cfg.default_weak_coupling,
            meta={"particle_kind":"quark","flavor":fl,"color_charge":color},
            symmetry=self._default_symmetry_record("quark", antimatter=antimatter))

    def add_nucleon(self, pos, is_proton=True, spread=None, *, with_quarks=True):
        base = self._as_vec3(pos)
        if with_quarks:
            flavors = ["up","up","down"] if is_proton else ["up","down","down"]
            sig = float(self.cfg.nucleon_spread if spread is None else spread)*float(self.cfg.noise_scale)
            for f in flavors:
                self.add_quark(base + self.rng.normal(0.0, sig, 3), flavor=f)
        eff_q = 1.0 if is_proton else 0.0
        eff_m = float(self.cfg.proton_mass if is_proton else self.cfg.neutron_mass)
        self.add_particle(base, np.zeros(3), m=eff_m, q=eff_q,
            force_strong=self.cfg.default_strong_coupling, force_weak=self.cfg.default_weak_coupling,
            meta={"particle_kind":"nucleon_center","nucleon_type":"proton" if is_proton else "neutron"},
            symmetry=self._default_symmetry_record("nucleon_center"))

    def _resolve_atom_detail(self, z):
        pol = str(self.cfg.atom_detail_policy).lower().strip()
        if pol in {"full","nucleus_only","center_only"}: return pol
        if pol != "auto": raise ValueError(f"Unknown atom_detail_policy: {self.cfg.atom_detail_policy!r}")
        if z <= int(self.cfg.full_atom_max_z): return "full"
        if z <= int(self.cfg.full_nucleon_max_z): return "nucleus_only"
        return "center_only"

    def _resolve_electron_count(self, n_e, *, detail):
        n_e = int(max(0, n_e))
        if detail == "full": return n_e
        mode = str(self.cfg.electron_subsample_mode).lower().strip()
        if mode == "cap": return min(n_e, max(0, int(self.cfg.electron_subsample_max)))
        if mode == "sqrt": return min(n_e, max(1, int(round(math.sqrt(max(n_e,1))*4.0))))
        if mode == "fraction":
            frac = float(np.clip(self.cfg.electron_fraction_degraded, 0.0, 1.0))
            return min(n_e, max(1, int(round(n_e*frac))))
        raise ValueError(f"Unknown electron_subsample_mode: {self.cfg.electron_subsample_mode!r}")

    def _add_electron_cloud(self, pos, elem, z, ion_charge, scale, *, detail):
        n_e = self._resolve_electron_count(max(0, int(z)-int(ion_charge)), detail=detail)
        s = float(scale)
        for _ in range(int(n_e)):
            phi = self.rng.uniform(0.0, 2.0*np.pi)
            costheta = self.rng.uniform(-1.0, 1.0)
            theta = float(np.arccos(costheta))
            rr = s * float(self.rng.uniform(0.5, 1.5))
            offset = np.array([rr*math.sin(theta)*math.cos(phi),
                                rr*math.sin(theta)*math.sin(phi),
                                rr*math.cos(theta)], dtype=np.float64)
            v_dir = np.cross(offset, np.array([0.,0.,1.], dtype=np.float64))
            n = float(np.linalg.norm(v_dir))
            if n < 1e-8:
                v_dir = np.cross(offset, np.array([1.,0.,0.], dtype=np.float64))
                n = float(np.linalg.norm(v_dir))
            v_dir = v_dir / max(n, 1e-12)
            self.add_particle(pos+offset, v_dir*float(self.cfg.electron_speed),
                m=self.cfg.electron_mass, q=-1.0, force_weak=self.cfg.default_weak_coupling,
                meta={"particle_kind":"electron","element_symbol":elem["symbol"],
                      "atomic_number":int(z),"electron_cloud_detail":detail},
                symmetry=self._default_symmetry_record("electron"))

    def add_atom(self, pos, atomic_number, scale=0.2, ion_charge=0):
        pos = self._as_vec3(pos)
        z = max(1, int(atomic_number))
        ion_charge = int(ion_charge)
        elem = self.get_element(atomic_number=z)
        detail = self._resolve_atom_detail(z)
        if detail == "full":
            core_sig = float(self.cfg.core_spread)*float(self.cfg.noise_scale)
            for _ in range(z):
                self.add_nucleon(pos+self.rng.normal(0.,core_sig,3), is_proton=True, with_quarks=True)
                self.add_nucleon(pos+self.rng.normal(0.,core_sig,3), is_proton=False, with_quarks=True)
        elif detail == "nucleus_only":
            core_sig = float(self.cfg.core_spread)*float(self.cfg.noise_scale)
            for _ in range(z):
                self.add_nucleon(pos+self.rng.normal(0.,core_sig,3), is_proton=True, with_quarks=False)
                self.add_nucleon(pos+self.rng.normal(0.,core_sig,3), is_proton=False, with_quarks=False)
        elif detail != "center_only":
            raise RuntimeError(f"Unhandled atom detail mode: {detail}")
        if detail == "full" or bool(self.cfg.keep_electrons_in_degraded_atoms):
            self._add_electron_cloud(pos, elem, z, ion_charge, scale, detail=detail)
        self.add_particle(pos, np.zeros(3), m=float(2*z), q=float(ion_charge),
            force_strong=float(self.cfg.default_strong_coupling*(0.25 if detail!="center_only" else 0.10)),
            force_weak=self.cfg.default_weak_coupling,
            meta={"particle_kind":"atom_center","element_symbol":elem["symbol"],
                  "element_name":elem["name"],"atomic_number":z,
                  "element_category":elem["category"],"ion_charge":ion_charge,"atom_detail":detail},
            symmetry=self._default_symmetry_record("atom_center"))

    def add_element(self, pos, *, symbol=None, atomic_number=None, scale=0.2, ion_charge=0):
        elem = self.get_element(symbol=symbol, atomic_number=atomic_number)
        self.add_atom(pos, atomic_number=int(elem["atomic_number"]), scale=scale, ion_charge=ion_charge)

    def add_molecule_from_formula(self, pos, formula, scale=0.25, spacing=0.8, jitter=0.15):
        pos = self._as_vec3(pos)
        comp = parse_formula(formula)
        total_atoms = sum(comp.values())
        if total_atoms <= 0: raise ValueError("Formula produced zero atoms.")
        symbols = []
        for sym, cnt in comp.items(): symbols.extend([sym]*int(cnt))
        if len(symbols) == 1:
            self.add_element(pos, symbol=symbols[0], scale=scale)
        else:
            for i, sym in enumerate(symbols):
                ang = (2.0*np.pi*i)/max(len(symbols),1)
                radial = float(spacing)*(0.6+0.4*(i%3))
                offset = np.array([radial*math.cos(ang), radial*math.sin(ang),
                                    float(self.rng.normal(0.,float(jitter)))], dtype=np.float64)
                self.add_element(pos+offset, symbol=sym, scale=scale)
        self.add_particle(pos, np.zeros(3), m=float(total_atoms), q=0.0,
            force_strong=0.05, force_weak=0.05,
            meta={"particle_kind":"molecule_marker","formula":formula,"composition":dict(comp)},
            symmetry=self._default_symmetry_record("molecule_marker"))

    def add_material(self, pos, material, *, size=1.0, environment=None, degradation=None, tags=None):
        pos = self._apply_bounds_policy(self._as_vec3(pos))
        env = environment or EnvironmentProfile(temperature_k=self.cfg.ambient_temperature_k,
            humidity=self.cfg.ambient_humidity, salinity=self.cfg.ambient_salinity,
            radiation=self.cfg.ambient_radiation, ph=self.cfg.ambient_ph)
        degr = degradation or DegradationState()
        rec = {"kind":"material","position":pos.tolist(),"size":float(size),
               "material":asdict(material),"environment":asdict(env),
               "degradation":asdict(degr),"tags":list(tags or [])}
        self._materials.append(rec)
        material_health = float(np.clip(degr.health, 0.0, 1.0))
        mass = float(max(material.density,1e-6)*max(size,1e-6)*self.cfg.material_marker_mass_scale)
        charge = float((material.corrosion_resistance-material.oxidation_resistance)*0.05)
        self.add_particle(pos, np.zeros(3), m=mass*(0.75+0.25*material_health), q=charge,
            force_gravity=mass, force_em=abs(charge),
            force_strong=material.hardness*0.2, force_weak=material.toughness*0.05,
            meta={"particle_kind":"material_marker","material_name":material.name,
                  "material_category":material.category,"health":material_health},
            symmetry=self._default_symmetry_record("material_marker"))
        return rec

    def add_multicellular_organism(self, pos, species, *, body_scale=1.0, genome=None,
                                    biomech=None, environment=None, phenotype=None,
                                    selection_traits=None, engineering_notes=None):
        pos = self._apply_bounds_policy(self._as_vec3(pos))
        genome = genome or GenomeProfile(genome_id=f"{species}_genome")
        biomech = biomech or BiomechProfile(morphology="generic", body_mass=max(1.0,body_scale))
        environment = environment or EnvironmentProfile(temperature_k=self.cfg.ambient_temperature_k,
            humidity=self.cfg.ambient_humidity, salinity=self.cfg.ambient_salinity,
            radiation=self.cfg.ambient_radiation, ph=self.cfg.ambient_ph)
        rec = {"kind":"multicellular_organism","species":str(species),"position":pos.tolist(),
               "body_scale":float(body_scale),"genome":asdict(genome),"biomech":asdict(biomech),
               "environment":asdict(environment),"phenotype":dict(phenotype or {}),
               "selection_traits":dict(selection_traits or {}),"engineering_notes":list(engineering_notes or [])}
        self._organisms.append(rec)
        n_markers = max(4, int(round(6*body_scale)))
        sigma = max(0.12, body_scale*0.18)
        for i in range(n_markers):
            local = self.rng.normal(0.0, sigma, 3)
            q = 0.2 if i%2==0 else -0.15
            self.add_particle(pos+local, np.zeros(3),
                m=max(0.05,biomech.body_mass/max(n_markers,1)), q=q,
                force_gravity=max(0.05,biomech.body_mass/max(n_markers,1)), force_em=abs(q),
                force_strong=biomech.muscle_factor*0.15, force_weak=biomech.healing_rate*0.08,
                meta={"particle_kind":"organism_node","species":species,"node_index":i},
                symmetry=self._default_symmetry_record("organism_node"))
        self.add_particle(pos, np.zeros(3),
            m=max(0.5,biomech.body_mass*self.cfg.organism_marker_mass_scale), q=0.0,
            force_gravity=max(0.5,biomech.body_mass*self.cfg.organism_marker_mass_scale), force_em=0.0,
            force_strong=biomech.damage_tolerance*0.2, force_weak=genome.resilience_bias*0.1,
            meta={"particle_kind":"organism_marker","species":species},
            symmetry=self._default_symmetry_record("organism_marker"))
        return rec

    def add_ecosystem(self, center, biome_name, *, radius=6.0, population=12,
                      trophic_complexity=0.5, diversity=0.5, environment=None, species_pool=None):
        center = self._apply_bounds_policy(self._as_vec3(center))
        environment = environment or EnvironmentProfile(temperature_k=self.cfg.ambient_temperature_k,
            humidity=self.cfg.ambient_humidity, salinity=self.cfg.ambient_salinity,
            radiation=self.cfg.ambient_radiation, ph=self.cfg.ambient_ph)
        pool = list(species_pool or ["flora","grazer","predator","decomposer"])
        rec = {"kind":"ecosystem","biome_name":biome_name,"center":center.tolist(),
               "radius":float(radius),"population":int(population),
               "trophic_complexity":float(trophic_complexity),"diversity":float(diversity),
               "environment":asdict(environment),"species_pool":pool}
        self._ecosystems.append(rec)
        for i in range(max(1,int(population))):
            ang = self.rng.uniform(0.0, 2.0*np.pi)
            rr = radius*math.sqrt(float(self.rng.uniform(0.0,1.0)))
            pos = center + np.array([rr*math.cos(ang), rr*math.sin(ang),
                                      self.rng.normal(0.0,radius*0.05)], dtype=np.float64)
            species = pool[i%len(pool)]
            geno = GenomeProfile(genome_id=f"{biome_name}_{species}_{i}", engineered=False,
                                  resilience_bias=0.4+0.6*diversity)
            bio = BiomechProfile(morphology=species, body_mass=0.5+2.0*float(self.rng.uniform()),
                                  muscle_factor=0.3+trophic_complexity*0.5,
                                  healing_rate=0.2+diversity*0.5)
            self.add_multicellular_organism(pos, species=f"{biome_name}_{species}",
                body_scale=0.7+0.8*float(self.rng.uniform()),
                genome=geno, biomech=bio, environment=environment)
        self.add_particle(center, np.zeros(3),
            m=max(1.0,population*self.cfg.ecosystem_marker_mass_scale), q=0.0,
            force_gravity=max(1.0,population*self.cfg.ecosystem_marker_mass_scale), force_em=0.0,
            force_strong=trophic_complexity*0.15, force_weak=diversity*0.15,
            meta={"particle_kind":"ecosystem_marker","biome_name":biome_name},
            symmetry=self._default_symmetry_record("ecosystem_marker"))
        return rec

    def add_city(self, center, name, *, radius=8.0, population=100_000, density=0.7,
                 infrastructure=0.6, technology_index=0.5, resilience=0.5, materials=None):
        center = self._apply_bounds_policy(self._as_vec3(center))
        mats = materials or [
            MaterialProfile(name="concrete",category="civil",density=2.4,hardness=0.6,toughness=0.45,corrosion_resistance=0.7),
            MaterialProfile(name="steel",category="alloy",density=7.8,hardness=0.8,toughness=0.75,corrosion_resistance=0.6),
            MaterialProfile(name="glass",category="silicate",density=2.5,hardness=0.7,toughness=0.2,oxidation_resistance=0.95),
        ]
        rec = {"kind":"city","name":name,"center":center.tolist(),"radius":float(radius),
               "population":int(population),"density":float(density),
               "infrastructure":float(infrastructure),"technology_index":float(technology_index),
               "resilience":float(resilience),"materials":[asdict(m) for m in mats]}
        self._cities.append(rec)
        n_blocks = max(8, int(round(radius*density*3)))
        for i in range(n_blocks):
            ang = (2.0*np.pi*i)/max(1,n_blocks)
            rr = radius*(0.2+0.8*float(self.rng.uniform()))
            pos = center + np.array([rr*math.cos(ang), rr*math.sin(ang), 0.0], dtype=np.float64)
            q = (technology_index-0.5)*0.2
            mass = max(1.0,(population/max(1,n_blocks))*1e-3)
            self.add_particle(pos, np.zeros(3), m=mass, q=q,
                force_gravity=mass, force_em=abs(q),
                force_strong=infrastructure*0.1, force_weak=resilience*0.05,
                meta={"particle_kind":"city_block","city_name":name,"block_index":i},
                symmetry=self._default_symmetry_record("city_block"))
        self.add_particle(center, np.zeros(3),
            m=max(5.0,population*self.cfg.city_marker_mass_scale*1e-3),
            q=(technology_index-0.5)*0.4,
            force_gravity=max(5.0,population*self.cfg.city_marker_mass_scale*1e-3),
            force_em=abs((technology_index-0.5)*0.4),
            force_strong=infrastructure*0.2, force_weak=resilience*0.1,
            meta={"particle_kind":"city_marker","city_name":name},
            symmetry=self._default_symmetry_record("city_marker"))
        return rec

    def add_planet(self, pos, name, *, radius=3.0, mass_scale=1.0, orbital_velocity=None,
                   composition=None, atmosphere=None, environment=None,
                   has_biosphere=False, has_city=False):
        pos = self._apply_bounds_policy(self._as_vec3(pos))
        composition = dict(composition or {"silicate":0.5,"iron":0.3,"ice":0.0,"organics":0.2})
        atmosphere = dict(atmosphere or {"N2":0.7,"O2":0.2,"CO2":0.02})
        environment = environment or EnvironmentProfile(temperature_k=self.cfg.ambient_temperature_k,
            humidity=self.cfg.ambient_humidity, salinity=self.cfg.ambient_salinity,
            radiation=self.cfg.ambient_radiation, ph=self.cfg.ambient_ph)
        v = np.zeros(3,dtype=np.float64) if orbital_velocity is None else self._as_vec3(orbital_velocity)
        rec = {"kind":"planet","name":name,"position":pos.tolist(),"radius":float(radius),
               "mass_scale":float(mass_scale),"composition":composition,"atmosphere":atmosphere,
               "environment":asdict(environment),"has_biosphere":bool(has_biosphere),"has_city":bool(has_city)}
        self._planets.append(rec)
        planet_mass = max(5.0, radius*radius*radius*max(mass_scale,1e-6)*self.cfg.planet_marker_mass_scale)
        charge = (atmosphere.get("ionized",0.0)-0.5)*0.2 if "ionized" in atmosphere else 0.0
        self.add_particle(pos, v, m=planet_mass, q=charge,
            force_gravity=planet_mass, force_em=abs(charge), force_strong=0.0, force_weak=0.0,
            meta={"particle_kind":"planet_marker","planet_name":name},
            symmetry=self._default_symmetry_record("planet_marker"))
        if has_biosphere:
            self.add_ecosystem(pos+np.array([radius*0.35,0.,0.]),
                biome_name=f"{name}_biosphere", radius=max(2.0,radius*0.7), population=8)
        if has_city:
            self.add_city(pos+np.array([-radius*0.28,0.,0.]),
                name=f"{name}_city", radius=max(2.0,radius*0.45), population=500_000)
        if bool(self.cfg.auto_add_scene_lights):
            self.add_light_source(pos, intensity=4.0+radius, radius=max(0.5,radius*0.4),
                color_temperature_k=4300.0, field_coupling_em=0.4, kind="planet_probe",
                tags=["planet"], metadata={"label":f"{name}_light_probe"})
        return rec

    def add_solar_system(self, center, name="system", *, star_temperature_k=5800.0,
                          n_planets=5, system_radius=18.0, add_city_on_habitable=False):
        center = self._apply_bounds_policy(self._as_vec3(center))
        rec = {"kind":"solar_system","name":name,"center":center.tolist(),
               "star_temperature_k":float(star_temperature_k),"n_planets":int(n_planets),
               "system_radius":float(system_radius),"planet_names":[]}
        self._stellar_systems.append(rec)
        star_mass = max(100.0, self.cfg.star_marker_mass_scale*(1.0+0.2*n_planets))
        self.add_particle(center, np.zeros(3), m=star_mass, q=0.0,
            force_gravity=star_mass, force_em=0.0, force_strong=0.0, force_weak=0.0,
            meta={"particle_kind":"star_marker","system_name":name},
            symmetry=self._default_symmetry_record("star_marker"))
        self.add_light_source(center, intensity=28.0, radius=2.0,
            color_temperature_k=star_temperature_k, field_coupling_g=0.10, field_coupling_em=1.0,
            kind="area_sphere", tags=["star","system_core"], metadata={"label":f"{name}_star"})
        habitable_idx = max(0, min(n_planets-1, n_planets//2))
        for i in range(max(1,int(n_planets))):
            frac = (i+1)/(n_planets+1)
            rr = system_radius*frac
            ang = float(self.rng.uniform(0.0, 2.0*np.pi))
            pos = center + np.array([rr*math.cos(ang), rr*math.sin(ang),
                                      self.rng.normal(0.0,system_radius*0.03)], dtype=np.float64)
            tangential = np.array([-math.sin(ang), math.cos(ang), 0.0], dtype=np.float64)
            speed = 5.0/math.sqrt(rr+0.5)
            name_i = f"{name}_planet_{i+1}"
            self.add_planet(pos, name_i,
                radius=0.8+0.5*float(self.rng.uniform()),
                mass_scale=0.7+0.8*float(self.rng.uniform()),
                orbital_velocity=tangential*speed,
                has_biosphere=(i==habitable_idx),
                has_city=(i==habitable_idx and add_city_on_habitable))
            rec["planet_names"].append(name_i)
        return rec

    def add_dna_strand(self, start_pos, length, radius=0.5, pitch=0.4, orientation_angles=(0.,0.,0.)):
        start_pos = self._as_vec3(start_pos)
        rmat = self._euler_matrix_xyz(orientation_angles)
        length = max(1, int(length))
        for i in range(length):
            z_offset = i*pitch
            ang = i*(np.pi/4.0)
            pa = start_pos+(rmat@np.array([radius*math.cos(ang),radius*math.sin(ang),z_offset],dtype=np.float64))
            pb = start_pos+(rmat@np.array([radius*math.cos(ang+np.pi),radius*math.sin(ang+np.pi),z_offset],dtype=np.float64))
            self.add_particle(pa, np.zeros(3), m=0.5, q=0.5, force_weak=0.1,
                meta={"particle_kind":"dna_base","strand":"A"},
                symmetry=self._default_symmetry_record("dna_base"))
            self.add_particle(pb, np.zeros(3), m=0.5, q=-0.5, force_weak=0.1,
                meta={"particle_kind":"dna_base","strand":"B"},
                symmetry=self._default_symmetry_record("dna_base"))
            if i%2==0:
                self.add_particle(0.5*(pa+pb), np.zeros(3), m=0.2, q=0.1, force_weak=0.05,
                    meta={"particle_kind":"dna_bridge"},
                    symmetry=self._default_symmetry_record("dna_bridge"))

    def add_force_source(self, kind, position, strength, radius=1.0, falloff=2.0, metadata=None):
        k = str(kind).lower().strip()
        if k not in {"gravity","electromagnetic","strong","weak"}:
            raise ValueError(f"Unknown force source kind: {kind}")
        pos = self._apply_bounds_policy(self._as_vec3(position))
        self._force_sources.append({"kind":k,"position":pos.tolist(),"strength":float(strength),
            "radius":float(radius),"falloff":float(falloff),"metadata":dict(metadata or {})})

    def add_symmetry_region(self, position, radius, *, C=1, P=1, T=1, label="symmetry_region"):
        pos = self._apply_bounds_policy(self._as_vec3(position))
        c = 1 if C>=0 else -1; p = 1 if P>=0 else -1; t = 1 if T>=0 else -1
        self._force_sources.append({"kind":"symmetry_region","position":pos.tolist(),
            "radius":float(radius),"C":c,"P":p,"T":t,"CP":c*p,"CPT":c*p*t,"label":str(label)})

    def add_light_source(self, position, *, intensity=None, radius=None, color_temperature_k=None,
                          field_coupling_g=0.0, field_coupling_em=1.0, field_coupling_s=0.0,
                          field_coupling_w=0.0, kind="point", tags=None, metadata=None):
        pos = self._apply_bounds_policy(self._as_vec3(position))
        inten = float(self.cfg.default_light_intensity if intensity is None else intensity)
        rad = float(self.cfg.default_light_radius if radius is None else radius)
        temp = float(self.cfg.default_light_temperature_k if color_temperature_k is None else color_temperature_k)
        if bool(self.cfg.auto_light_scale_with_bounds):
            rad *= max(1e-9, float(min(self.bounds)))/48.0
        self._light_sources.append({"pos":pos.tolist(),"intensity":inten,"radius":rad,
            "color_temperature_k":temp,"field_coupling_g":float(field_coupling_g),
            "field_coupling_em":float(field_coupling_em),"field_coupling_s":float(field_coupling_s),
            "field_coupling_w":float(field_coupling_w),"kind":str(kind),
            "tags":list(tags or []),"metadata":dict(metadata or {})})

    def build_scene_galaxy(self, radius=25.0, num_stars=300, arms=3):
        center = self.center
        self.add_particle(center, np.zeros(3), m=500.0, q=0.0, force_gravity=500.0, force_em=0.0,
            meta={"particle_kind":"black_hole_seed"}, symmetry=self._default_symmetry_record("black_hole_seed"))
        for _ in range(max(0,int(num_stars))):
            arm_offset = int(self.rng.integers(0,max(1,int(arms))))*(2.0*np.pi/max(1,int(arms)))
            t = float(self.rng.uniform(0.1,1.0))
            ang = t*10.0+arm_offset+float(self.rng.normal(0.0,0.3*self.cfg.noise_scale))
            rr = float(radius)*t
            pos = center+np.array([rr*math.cos(ang),rr*math.sin(ang),
                                    self.rng.normal(0.0,radius*0.05*self.cfg.noise_scale)],dtype=np.float64)
            vel = np.array([-math.sin(ang),math.cos(ang),0.0],dtype=np.float64)*(10.0/math.sqrt(rr+0.1))
            qq = float(self.rng.normal(1.0,0.5*self.cfg.noise_scale))
            self.add_particle(pos, vel, m=2.0, q=qq, force_gravity=2.0, force_em=abs(qq),
                meta={"particle_kind":"star_seed"}, symmetry=self._default_symmetry_record("star_seed"))
        if self.cfg.auto_add_scene_lights:
            self.add_light_source(center, intensity=30.0, radius=2.0, color_temperature_k=6500.0,
                field_coupling_g=0.15, field_coupling_em=1.0, kind="area_sphere",
                tags=["star","plasma","core"], metadata={"label":"galaxy_core_light"})

    def build_scene_dna(self, length=80, radius=0.7, pitch=0.35):
        length = max(1, int(length))
        if str(self.cfg.bounds_policy).lower().strip() == "clip":
            pad = max(float(self.cfg.clip_padding), 0.0)
            usable_z = max(float(self.bounds[2])-2.0*pad, 1e-9)
            span = max((length-1)*pitch, 0.0)
            if span > usable_z: pitch = usable_z/max(length-1,1)
        start = self.center - np.array([0.,0.,((length-1)*pitch)*0.5],dtype=np.float64)
        self.add_dna_strand(start, length=length, radius=radius, pitch=pitch)
        if self.cfg.auto_add_scene_lights:
            self.add_light_source(self.center+np.array([0.,0.,float(min(self.bounds)*0.15)]),
                intensity=12.0, radius=2.0, color_temperature_k=5000.0, field_coupling_em=1.0,
                kind="area_sphere", tags=["ambient","lab"], metadata={"label":"dna_key_light"})

    def build_scene_water_cluster(self, n_molecules=30, spread=4.0):
        for _ in range(max(1,int(n_molecules))):
            p = self.center+self.rng.normal(0.0,float(spread)*float(self.cfg.noise_scale),3)
            self.add_molecule_from_formula(p, "H2O", scale=0.18)
        if self.cfg.auto_add_scene_lights:
            self.add_light_source(self.center+np.array([0.,0.,float(min(self.bounds)*0.15)]),
                intensity=10.0, radius=2.5, color_temperature_k=4500.0, field_coupling_em=1.0,
                kind="area_sphere", tags=["ambient"], metadata={"label":"water_ambient_light"})

    def build_scene_molecule_field(self, formula="C6H12O6", count=20, spread=5.0):
        for _ in range(max(1,int(count))):
            p = self.center+self.rng.normal(0.0,float(spread)*float(self.cfg.noise_scale),3)
            self.add_molecule_from_formula(p, formula=formula)
        if self.cfg.auto_add_scene_lights:
            self.add_light_source(self.center, intensity=14.0, radius=3.0,
                color_temperature_k=4300.0, field_coupling_em=1.0,
                kind="area_sphere", tags=["ambient"], metadata={"label":"molecule_field_ambient"})

    def build_scene_ecosystem(self, biome_name="temperate", radius=8.0, population=14):
        self.add_ecosystem(self.center, biome_name=biome_name, radius=radius, population=population,
            trophic_complexity=0.65, diversity=0.7)
        if self.cfg.auto_add_scene_lights:
            self.add_light_source(self.center+np.array([0.,0.,float(min(self.bounds)*0.2)]),
                intensity=13.0, radius=2.5, color_temperature_k=5400.0, field_coupling_em=1.0,
                kind="ecosystem_sun", tags=["ecosystem","ambient"], metadata={"label":"ecosystem_light"})

    def build_scene_city(self, name="Noctis", radius=10.0, population=250_000):
        self.add_city(self.center, name=name, radius=radius, population=population,
            density=0.8, infrastructure=0.75, technology_index=0.7, resilience=0.65)
        if self.cfg.auto_add_scene_lights:
            self.add_light_source(self.center, intensity=18.0, radius=3.0,
                color_temperature_k=3800.0, field_coupling_em=1.0,
                kind="urban_core", tags=["city","electrical"], metadata={"label":"city_core_light"})

    def build_scene_solar_system(self, n_planets=6, system_radius=18.0, name="Helion"):
        self.add_solar_system(self.center, name=name, n_planets=n_planets,
            system_radius=system_radius, add_city_on_habitable=True)

    def build_arrays(self):
        if not self._r: raise ValueError("No matter has been added.")
        return (
            np.ascontiguousarray(np.array(self._r, dtype=np.float64)),
            np.ascontiguousarray(np.array(self._v, dtype=np.float64)),
            np.ascontiguousarray(np.array(self._m, dtype=np.float64)),
            np.ascontiguousarray(np.array(self._q, dtype=np.float64)),
        )

    def build_force_arrays(self):
        return {
            "obj_force_gravity":       np.ascontiguousarray(np.array(self._force_gravity, dtype=np.float64)),
            "obj_force_electromagnetic": np.ascontiguousarray(np.array(self._force_em, dtype=np.float64)),
            "obj_force_strong":        np.ascontiguousarray(np.array(self._force_strong, dtype=np.float64)),
            "obj_force_weak":          np.ascontiguousarray(np.array(self._force_weak, dtype=np.float64)),
        }

    def build_metadata(self):
        return {"schema_version":SCHEMA_VERSION,"module_name":MODULE_NAME,"module_version":MODULE_VERSION,
                "seed_eff":int(self.seed_eff),"particle_meta":self._meta,"symmetry_records":self._symmetry,
                "force_sources":self._force_sources,"light_sources":self._light_sources,
                "materials":self._materials,"organisms":self._organisms,"ecosystems":self._ecosystems,
                "cities":self._cities,"planets":self._planets,"stellar_systems":self._stellar_systems,
                "dropped_particles":int(self._dropped_particles)}

    def inject_into_sim(self, sim: Any) -> Dict[str, Any]:
        obj_r, obj_v, obj_m, obj_q = self.build_arrays()
        force = self.build_force_arrays()
        if hasattr(sim, "set_objects_from_arrays"):
            sym_C   = np.array([float(s.get("C",   1.0)) for s in self._symmetry], dtype=np.float64)
            sym_P   = np.array([float(s.get("P",   1.0)) for s in self._symmetry], dtype=np.float64)
            sym_T   = np.array([float(s.get("T",   1.0)) for s in self._symmetry], dtype=np.float64)
            sym_CP  = np.array([float(s.get("CP",  1.0)) for s in self._symmetry], dtype=np.float64)
            sym_CPT = np.array([float(s.get("CPT", 1.0)) for s in self._symmetry], dtype=np.float64)
            sim.set_objects_from_arrays(obj_r=obj_r, obj_v=obj_v, obj_m=obj_m, obj_q=obj_q,
                force_gravity=force["obj_force_gravity"],
                force_electromagnetic=force["obj_force_electromagnetic"],
                force_strong=force["obj_force_strong"], force_weak=force["obj_force_weak"],
                sym_C=sym_C, sym_P=sym_P, sym_T=sym_T, sym_CP=sym_CP, sym_CPT=sym_CPT,
                obj_meta=list(self._meta))
        else:
            sim.obj_r = obj_r; sim.obj_v = obj_v; sim.obj_m = obj_m; sim.obj_q = obj_q
            for attr, key in [("obj_force_gravity","obj_force_gravity"),
                               ("obj_force_electromagnetic","obj_force_electromagnetic"),
                               ("obj_force_strong","obj_force_strong"),
                               ("obj_force_weak","obj_force_weak")]:
                if hasattr(sim, attr): setattr(sim, attr, force[key])
        if hasattr(sim, "obj_meta"):       sim.obj_meta = list(self._meta)
        if hasattr(sim, "obj_symmetry"):   sim.obj_symmetry = list(self._symmetry)
        if hasattr(sim, "force_sources"):  sim.force_sources = list(self._force_sources)
        if hasattr(sim, "light_sources"):  sim.light_sources = list(self._light_sources)
        if hasattr(sim, "set_force_sources"): sim.set_force_sources(list(self._force_sources))
        if hasattr(sim, "n_obj"):          sim.n_obj = int(len(obj_r))
        if hasattr(sim, "cfg") and hasattr(sim.cfg, "n_obj"): sim.cfg.n_obj = int(len(obj_r))
        return {"schema_version":SCHEMA_VERSION,"module_name":MODULE_NAME,"module_version":MODULE_VERSION,
                "injected_n":int(len(obj_r)),"seed_eff":int(self.seed_eff),
                "force_sources_n":int(len(self._force_sources)),
                "light_sources_n":int(len(self._light_sources)),
                "dropped_particles":int(self._dropped_particles)}

    def summary(self) -> Dict[str, Any]:
        n = int(len(self._r))
        v_arr = np.asarray(self._v, dtype=np.float64) if self._v else np.zeros((0,3))
        speeds = np.linalg.norm(v_arr, axis=1) if n else np.array([0.0])
        r_arr = np.asarray(self._r, dtype=np.float64) if self._r else np.zeros((0,3))
        return {"schema_version":SCHEMA_VERSION,"module_name":MODULE_NAME,"module_version":MODULE_VERSION,
                "n_particles":n,"dropped_particles":int(self._dropped_particles),
                "bounds":self.bounds.tolist(),"center":self.center.tolist(),
                "seed_eff":int(self.seed_eff),
                "total_mass":float(np.sum(np.asarray(self._m,dtype=np.float64))) if self._m else 0.0,
                "total_charge":float(np.sum(np.asarray(self._q,dtype=np.float64))) if self._q else 0.0,
                "mean_speed":float(np.mean(speeds)),"max_speed":float(np.max(speeds)),
                "pos_min":np.min(r_arr,axis=0).tolist() if n else [0.,0.,0.],
                "pos_max":np.max(r_arr,axis=0).tolist() if n else [0.,0.,0.],
                "force_sources_n":int(len(self._force_sources)),
                "light_sources_n":int(len(self._light_sources)),
                "materials_n":int(len(self._materials)),"organisms_n":int(len(self._organisms)),
                "ecosystems_n":int(len(self._ecosystems)),"cities_n":int(len(self._cities)),
                "planets_n":int(len(self._planets)),"stellar_systems_n":int(len(self._stellar_systems)),
                "periodic_table_size":int(len(ELEMENT_TABLE)),"cfg":asdict(self.cfg)}