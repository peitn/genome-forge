"""
engine/builder/parts.py
=======================
Builder Parts — katalog stavebních jednotek.

Blueprint §3.1: "voxel block, microblock, panel, beam/truss, joint,
                  hinge, actuator, pipe, wire, logic node, sensor,
                  fluid container, engine block, wheel, rotor,
                  thruster, decorative part, programmable module"

Blueprint §3.3: Konstrukční validace.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ── Part typy (blueprint §3.1) ────────────────────────────────────────────────

class PartType(str, Enum):
    VOXEL_BLOCK       = "voxel_block"
    MICROBLOCK        = "microblock"
    PANEL             = "panel"
    BEAM              = "beam"
    TRUSS             = "truss"
    JOINT             = "joint"
    HINGE             = "hinge"
    ACTUATOR          = "actuator"
    PIPE              = "pipe"
    WIRE              = "wire"
    LOGIC_NODE        = "logic_node"
    SENSOR            = "sensor"
    FLUID_CONTAINER   = "fluid_container"
    ENGINE_BLOCK      = "engine_block"
    WHEEL             = "wheel"
    ROTOR             = "rotor"
    THRUSTER          = "thruster"
    DECORATIVE        = "decorative"
    PROGRAMMABLE      = "programmable"


# ── Connector (blueprint §3.2 snap systém) ────────────────────────────────────

class ConnectorType(str, Enum):
    VOXEL_GRID   = "voxel_grid"
    SURFACE      = "surface"
    JOINT        = "joint"
    PIPE_END     = "pipe_end"
    WIRE_END     = "wire_end"
    HINGE_AXIS   = "hinge_axis"


@dataclass
class Connector:
    """Konektoru na builderovém dílu."""
    id: str
    type: ConnectorType
    local_pos: Tuple[float, float, float]    # pozice relativně k dílu
    local_dir: Tuple[float, float, float]    # směr (normála)
    compatible_with: List[str] = field(default_factory=list)   # seznam PartType


# ── Part definice ──────────────────────────────────────────────────────────────

@dataclass
class PartDef:
    """
    Definice jednoho builderového dílu.
    Uloženo v katalogu, sdílené přes asset systém.
    """
    id: str
    name: str
    type: PartType
    description: str = ""

    # Fyzikální vlastnosti
    mass: float = 1.0           # kg
    volume: float = 1.0         # m³ normalizovaný
    structural_strength: float = 1.0    # únosnost

    # Rozměry (v voxelech)
    size: Tuple[int, int, int] = (1, 1, 1)

    # Konektory (snap body)
    connectors: List[Connector] = field(default_factory=list)

    # Fyzikální flags
    is_structural: bool = True   # přispívá ke strukturální integritě
    is_rigid: bool = True
    can_rotate: bool = False
    needs_energy: bool = False
    needs_fluid: bool = False

    # Vizuální
    material_id: int = 6   # výchozí: metal
    color: Tuple[int, int, int] = (180, 185, 195)

    # Metadata
    tags: List[str] = field(default_factory=list)
    version: str = "1.0"
    author: str = "voxforge"


# ── Katalog dílů ──────────────────────────────────────────────────────────────

class PartCatalog:
    """
    Katalog všech dostupných builderových dílů.
    Blueprint §3: "Builder je klíčový modul propojený s editorem."
    """

    def __init__(self):
        self._parts: Dict[str, PartDef] = {}

    def register(self, part: PartDef) -> PartDef:
        self._parts[part.id] = part
        return part

    def get(self, part_id: str) -> Optional[PartDef]:
        return self._parts.get(part_id)

    def by_type(self, ptype: PartType) -> List[PartDef]:
        return [p for p in self._parts.values() if p.type == ptype]

    def search(self, query: str) -> List[PartDef]:
        q = query.lower()
        return [p for p in self._parts.values()
                if q in p.name.lower() or q in p.description.lower()
                or q in " ".join(p.tags)]

    def save(self, path: Path) -> None:
        data = {pid: asdict(p) for pid, p in self._parts.items()}
        Path(path).write_text(json.dumps(data, indent=2))

    def __len__(self) -> int:
        return len(self._parts)

    def __repr__(self) -> str:
        return f"PartCatalog({len(self._parts)} parts)"


# ── Builderový objekt ──────────────────────────────────────────────────────────

@dataclass
class PlacedPart:
    """Jeden díl umístěný v builderovém objektu."""
    instance_id: str
    part_id: str
    position: Tuple[float, float, float]
    rotation: Tuple[float, float, float] = (0.0, 0.0, 0.0)   # euler degrees
    connected_to: List[str] = field(default_factory=list)      # instance_id → instance_id


@dataclass
class BuilderObject:
    """
    Kompletní stavebnice — seznam dílů + jejich propojení.
    Může být exported/imported jako .voxobj soubor.

    Blueprint §3.3: Konstrukční validace při uložení.
    """
    object_id: str
    name: str
    description: str = ""
    parts: List[PlacedPart] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    version: str = "1.0"
    author: str = "unknown"

    def add_part(self, part_id: str, position: Tuple[float,float,float],
                 instance_id: Optional[str] = None) -> PlacedPart:
        if instance_id is None:
            instance_id = f"{part_id}_{len(self.parts)}"
        pp = PlacedPart(instance_id=instance_id, part_id=part_id, position=position)
        self.parts.append(pp)
        return pp

    def connect(self, inst_a: str, inst_b: str) -> None:
        for p in self.parts:
            if p.instance_id == inst_a and inst_b not in p.connected_to:
                p.connected_to.append(inst_b)
            if p.instance_id == inst_b and inst_a not in p.connected_to:
                p.connected_to.append(inst_a)

    def validate(self, catalog: PartCatalog) -> List[str]:
        """
        Blueprint §3.3: Konstrukční validace.
        Vrátí seznam chyb (prázdný = OK).
        """
        errors: List[str] = []
        part_ids = {p.instance_id for p in self.parts}

        if not self.parts:
            errors.append("Objekt neobsahuje žádné díly.")
            return errors

        # 1. Všechny reference existují v katalogu
        for p in self.parts:
            if catalog.get(p.part_id) is None:
                errors.append(f"Díl '{p.part_id}' (instance {p.instance_id}) neexistuje v katalogu.")

        # 2. Spojovací body odkazují na existující instance
        for p in self.parts:
            for conn_id in p.connected_to:
                if conn_id not in part_ids:
                    errors.append(f"Instance '{p.instance_id}' odkazuje na neexistující '{conn_id}'.")

        # 3. Kontrola trubek — každá pipe musí být spojena s alespoň 1 dalším dílem
        for p in self.parts:
            pd = catalog.get(p.part_id)
            if pd and pd.type == PartType.PIPE and not p.connected_to:
                errors.append(f"Pipe '{p.instance_id}' není připojena k ničemu.")

        # 4. Motor musí mít výstup
        for p in self.parts:
            pd = catalog.get(p.part_id)
            if pd and pd.type == PartType.ENGINE_BLOCK:
                has_output = any(
                    catalog.get(self._find(conn, self.parts).part_id)
                    and catalog.get(self._find(conn, self.parts).part_id).type
                    in {PartType.WHEEL, PartType.ROTOR, PartType.THRUSTER}
                    for conn in p.connected_to
                    if self._find(conn, self.parts)
                )
                if not has_output:
                    errors.append(f"Engine '{p.instance_id}' nemá propojený výstup (wheel/rotor/thruster).")

        return errors

    def _find(self, instance_id: str, parts: List[PlacedPart]) -> Optional[PlacedPart]:
        for p in parts:
            if p.instance_id == instance_id:
                return p
        return None

    def save(self, path: Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(asdict(self), indent=2))

    @classmethod
    def load(cls, path: Path) -> "BuilderObject":
        d = json.loads(Path(path).read_text())
        parts = [PlacedPart(**p) for p in d.pop("parts")]
        obj = cls(**d)
        obj.parts = parts
        return obj

    def __repr__(self) -> str:
        return f"BuilderObject('{self.name}', {len(self.parts)} parts)"


# ── Výchozí katalog ────────────────────────────────────────────────────────────

def build_default_catalog() -> PartCatalog:
    cat = PartCatalog()

    cat.register(PartDef(
        id="voxel_1x1x1", name="Voxel Block 1×1×1", type=PartType.VOXEL_BLOCK,
        description="Základní stavební jednotka. Pevný 1×1×1 voxel.",
        mass=1.0, size=(1,1,1), structural_strength=1.0, material_id=1,
        tags=["basic", "structural"],
    ))
    cat.register(PartDef(
        id="beam_4x1x1", name="Beam 4×1×1", type=PartType.BEAM,
        description="Nosník. Vysoká strukturální pevnost.",
        mass=2.0, size=(4,1,1), structural_strength=4.0, material_id=6,
        tags=["structural", "beam"],
        connectors=[
            Connector("end_a", ConnectorType.JOINT, (0,0,0), (-1,0,0)),
            Connector("end_b", ConnectorType.JOINT, (4,0,0), (1,0,0)),
        ],
    ))
    cat.register(PartDef(
        id="hinge_basic", name="Hinge (základní)", type=PartType.HINGE,
        description="Pant. Umožňuje rotaci na jedné ose.",
        mass=0.5, size=(1,1,1), can_rotate=True, material_id=6,
        tags=["joint", "rotation"],
        connectors=[
            Connector("side_a", ConnectorType.HINGE_AXIS, (0,0,0), (-1,0,0)),
            Connector("side_b", ConnectorType.HINGE_AXIS, (1,0,0), (1,0,0)),
        ],
    ))
    cat.register(PartDef(
        id="pipe_straight", name="Trubka (rovná)", type=PartType.PIPE,
        description="Rovná trubka pro přenos kapalin.",
        mass=0.8, size=(1,1,1), needs_fluid=True, material_id=6,
        tags=["fluid", "pipe"],
        connectors=[
            Connector("in",  ConnectorType.PIPE_END, (0,0,0), (-1,0,0)),
            Connector("out", ConnectorType.PIPE_END, (1,0,0), (1,0,0)),
        ],
    ))
    cat.register(PartDef(
        id="pump", name="Pumpa", type=PartType.ACTUATOR,
        description="Čerpadlo kapaliny. Potřebuje energii.",
        mass=2.0, size=(1,1,1), needs_energy=True, needs_fluid=True, material_id=6,
        tags=["fluid", "energy", "actuator"],
    ))
    cat.register(PartDef(
        id="tank_4x4", name="Tank 4×4×4", type=PartType.FLUID_CONTAINER,
        description="Zásobník kapaliny. Kapacita: 64 jednotek.",
        mass=5.0, size=(4,4,4), needs_fluid=True, material_id=6,
        tags=["fluid", "storage"],
    ))
    cat.register(PartDef(
        id="engine_v4", name="Motor V4", type=PartType.ENGINE_BLOCK,
        description="Základní motor. Potřebuje palivo, vydává rotaci.",
        mass=8.0, size=(2,2,2), needs_energy=True, material_id=6,
        tags=["engine", "power"],
    ))
    cat.register(PartDef(
        id="wheel_medium", name="Kolo (střední)", type=PartType.WHEEL,
        description="Pohonné kolo. Připojit k motoru.",
        mass=3.0, size=(1,1,1), can_rotate=True, material_id=4,
        tags=["wheel", "vehicle"],
        connectors=[
            Connector("axle", ConnectorType.JOINT, (0,0,0), (-1,0,0)),
        ],
    ))
    cat.register(PartDef(
        id="sensor_temp", name="Teplotní senzor", type=PartType.SENSOR,
        description="Snímá teplotu okolí. Emituje události.",
        mass=0.2, size=(1,1,1), material_id=6,
        tags=["sensor", "thermal", "logic"],
    ))
    cat.register(PartDef(
        id="logic_gate", name="Logic Node (AND)", type=PartType.LOGIC_NODE,
        description="Logický uzel. Vstup: 2 signály, výstup: AND.",
        mass=0.1, size=(1,1,1), needs_energy=False, material_id=6,
        tags=["logic", "scripting"],
        connectors=[
            Connector("in_a",  ConnectorType.WIRE_END, (0,0,0), (-1,0,0)),
            Connector("in_b",  ConnectorType.WIRE_END, (0,1,0), (-1,0,0)),
            Connector("out",   ConnectorType.WIRE_END, (1,0,0), (1,0,0)),
        ],
    ))
    cat.register(PartDef(
        id="thruster_small", name="Thruster (malý)", type=PartType.THRUSTER,
        description="Malý tryskový motor. Potřebuje palivo.",
        mass=2.0, size=(1,1,1), needs_energy=True, can_rotate=False, material_id=12,
        tags=["thruster", "vehicle", "flight"],
    ))

    return cat


# Globální singleton
CATALOG = build_default_catalog()
