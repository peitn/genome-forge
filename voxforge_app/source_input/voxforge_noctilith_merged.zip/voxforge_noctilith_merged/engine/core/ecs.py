"""noctilith/ecs.py — minimal ECS skeleton."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

SCHEMA_VERSION = "noctilith.schema.v1"

@dataclass
class Entity:
    entity_id: int
    components: Dict[str, Any] = field(default_factory=dict)
    active: bool = True

    def add(self, name: str, component: Any) -> None:
        self.components[name] = component

    def get(self, name: str) -> Optional[Any]:
        return self.components.get(name)

    def remove(self, name: str) -> None:
        self.components.pop(name, None)

    def has(self, name: str) -> bool:
        return name in self.components


class World:
    def __init__(self) -> None:
        self._entities: Dict[int, Entity] = {}
        self._next_id: int = 1

    def create(self) -> Entity:
        eid = self._next_id
        self._next_id += 1
        e = Entity(entity_id=eid)
        self._entities[eid] = e
        return e

    def destroy(self, entity_id: int) -> None:
        self._entities.pop(entity_id, None)

    def get(self, entity_id: int) -> Optional[Entity]:
        return self._entities.get(entity_id)

    def query(self, *component_names: str) -> List[Entity]:
        return [e for e in self._entities.values()
                if e.active and all(e.has(c) for c in component_names)]

    def __len__(self) -> int:
        return len(self._entities)
