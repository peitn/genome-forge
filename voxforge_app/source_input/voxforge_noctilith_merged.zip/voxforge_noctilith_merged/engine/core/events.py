#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
noctilith/events.py
===================
NOCTILITH EVENTS — core event helpers + factory methods.
Patch 3: additive, backward-compatible.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, DefaultDict, Dict, List, Optional

SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME    = "noctilith.events"
MODULE_VERSION = "1.1.0"


# ── Core types ────────────────────────────────────────────────────────────────

@dataclass
class Event:
    type: str
    payload: Dict[str, Any] = field(default_factory=dict)
    # backward-compat alias kept for old code that used Event.payload as Event.payload
    tick: int = 0              # preserved from original EventBus usage
    source_id: Optional[int] = None


# ── Well-known event type constants (unchanged from original) ─────────────────

class EventType:
    VOXEL_DESTROYED    = "voxel_destroyed"
    VOXEL_PLACED       = "voxel_placed"
    CHUNK_LOADED       = "chunk_loaded"
    CHUNK_UNLOADED     = "chunk_unloaded"
    MATERIAL_MELTED    = "material_melted"
    MATERIAL_BURNED    = "material_burned"
    MATERIAL_FRACTURED = "material_fractured"
    ENTROPY_STORM_START = "entropy_storm_start"
    ENTROPY_STORM_END   = "entropy_storm_end"
    THERMAL_ALERT       = "thermal_alert"
    ENTITY_SPAWNED     = "entity_spawned"
    ENTITY_DIED        = "entity_died"
    AGENT_REPRODUCED   = "agent_reproduced"
    AGENT_MUTATED      = "agent_mutated"
    BRAIN_UPDATED      = "brain_updated"
    MACHINE_FAILED     = "machine_failed"
    # new in patch 3
    ENTROPY_SPIKE      = "entropy_spike"
    ENTROPY_STORM      = "entropy_storm"
    THERMAL_HOTSPOT    = "thermal_hotspot"
    REGIME_TRANSITION  = "regime_transition"
    SIM_TICK_COMPLETED = "sim_tick_completed"


# ── EventBus ──────────────────────────────────────────────────────────────────

class EventBus:
    """
    Synchronous publish/subscribe event bus.

    Backward-compatible API:
        subscribe(event_type, handler)
        subscribe_all(handler)
        unsubscribe(event_type, handler)
        publish(event)  / emit(event) / push(event)  ← all equivalent
        publish_many(events)
        history / clear_history()
        record_history flag

    New in patch 3:
        Static factory methods for structured events.
        emit/publish/push accept both Event and dict payloads.
    """

    def __init__(self) -> None:
        self._subscribers: DefaultDict[str, List[Callable[[Event], None]]] = defaultdict(list)
        self._global: List[Callable[[Event], None]] = []
        self._history: List[Event] = []
        self.record_history: bool = False

    # ── subscription ─────────────────────────────────────────────────────────

    def subscribe(self, event_type: str, handler: Callable[[Event], None]) -> None:
        self._subscribers[event_type].append(handler)

    def subscribe_all(self, handler: Callable[[Event], None]) -> None:
        self._global.append(handler)

    def unsubscribe(self, event_type: str, handler: Callable[[Event], None]) -> None:
        handlers = self._subscribers.get(event_type, [])
        if handler in handlers:
            handlers.remove(handler)

    # ── publishing ────────────────────────────────────────────────────────────

    def emit(self, event: "Event | Dict[str, Any]") -> None:
        evt = self._coerce_event(event)
        if self.record_history:
            self._history.append(evt)
        for handler in self._subscribers.get(evt.type, []):
            handler(evt)
        for handler in self._global:
            handler(evt)

    def publish(self, event: "Event | Dict[str, Any]") -> None:
        self.emit(event)

    def push(self, event: "Event | Dict[str, Any]") -> None:
        self.emit(event)

    def publish_many(self, events: List["Event | Dict[str, Any]"]) -> None:
        for e in events:
            self.emit(e)

    # ── history ───────────────────────────────────────────────────────────────

    def get_history(self) -> List[Event]:
        return list(self._history)

    def clear_history(self) -> None:
        self._history.clear()

    @property
    def history(self) -> List[Event]:
        return list(self._history)

    # ── coercion ──────────────────────────────────────────────────────────────

    @staticmethod
    def _coerce_event(event: "Event | Dict[str, Any]") -> Event:
        if isinstance(event, Event):
            return event
        if isinstance(event, dict):
            etype = str(event.get("type", "unknown"))
            payload = dict(event)
            payload.pop("type", None)
            return Event(type=etype, payload=payload)
        raise TypeError(f"Unsupported event type: {type(event)}")

    # ── factory methods (patch 3) ─────────────────────────────────────────────

    @staticmethod
    def make_entropy_spike(
        *,
        step_index: int,
        phi_rms_total: float,
        regime: str,
        unstable: bool = True,
        severity: Optional[float] = None,
        source: str = "noctilith.sim.entropy_coupler",
    ) -> Event:
        sev = float(phi_rms_total if severity is None else severity)
        return Event(
            type="entropy_spike",
            payload={
                "schema_version": SCHEMA_VERSION,
                "module_name":    MODULE_NAME,
                "module_version": MODULE_VERSION,
                "source":         source,
                "step_index":     int(step_index),
                "phi_rms_total":  float(phi_rms_total),
                "regime":         str(regime),
                "unstable":       bool(unstable),
                "severity":       sev,
            },
        )

    @staticmethod
    def make_entropy_storm(
        *,
        step_index: int,
        phi_rms_total: float,
        regime: str,
        unstable: bool,
        severity: float,
        source: str = "noctilith.sim.entropy_coupler",
    ) -> Event:
        return Event(
            type="entropy_storm",
            payload={
                "schema_version": SCHEMA_VERSION,
                "module_name":    MODULE_NAME,
                "module_version": MODULE_VERSION,
                "source":         source,
                "step_index":     int(step_index),
                "phi_rms_total":  float(phi_rms_total),
                "regime":         str(regime),
                "unstable":       bool(unstable),
                "severity":       float(severity),
            },
        )

    @staticmethod
    def make_thermal_hotspot(
        *,
        step_index: int,
        total_added_heat: float,
        max_cell_heat: float,
        active_cells: int,
        source: str = "noctilith.sim.thermal_coupler",
    ) -> Event:
        return Event(
            type="thermal_hotspot",
            payload={
                "schema_version":  SCHEMA_VERSION,
                "module_name":     MODULE_NAME,
                "module_version":  MODULE_VERSION,
                "source":          source,
                "step_index":      int(step_index),
                "total_added_heat":float(total_added_heat),
                "max_cell_heat":   float(max_cell_heat),
                "active_cells":    int(active_cells),
            },
        )

    @staticmethod
    def make_regime_transition(
        *,
        step_index: int,
        old_regime: str,
        new_regime: str,
        phi_rms_total: float = 0.0,
        unstable: bool = False,
        source: str = "noctilith.terminal",
    ) -> Event:
        return Event(
            type="regime_transition",
            payload={
                "schema_version": SCHEMA_VERSION,
                "module_name":    MODULE_NAME,
                "module_version": MODULE_VERSION,
                "source":         source,
                "step_index":     int(step_index),
                "old_regime":     str(old_regime),
                "new_regime":     str(new_regime),
                "phi_rms_total":  float(phi_rms_total),
                "unstable":       bool(unstable),
            },
        )

    @staticmethod
    def make_sim_tick_completed(
        *,
        step_index: int,
        dt: float,
        thermal: Optional[Dict[str, Any]] = None,
        entropy: Optional[Dict[str, Any]] = None,
        source: str = "noctilith.terminal",
    ) -> Event:
        return Event(
            type="sim_tick_completed",
            payload={
                "schema_version": SCHEMA_VERSION,
                "module_name":    MODULE_NAME,
                "module_version": MODULE_VERSION,
                "source":         source,
                "step_index":     int(step_index),
                "dt":             float(dt),
                "thermal":        dict(thermal or {}),
                "entropy":        dict(entropy or {}),
            },
        )


    @staticmethod
    def make_world_damage_applied(*, step_index: int, index: tuple, risk: float,
                                   damage: float, source: str = "noctilith") -> "Event":
        return Event(type="world_damage_applied", payload={
            "schema_version": SCHEMA_VERSION, "source": source,
            "step_index": int(step_index), "index": tuple(int(x) for x in index),
            "risk": float(risk), "damage": float(damage),
        })

    @staticmethod
    def make_debris_spawn_requested(*, step_index: int, index: tuple, risk: float,
                                     strength: float, source: str = "noctilith") -> "Event":
        return Event(type="debris_spawn_requested", payload={
            "schema_version": SCHEMA_VERSION, "source": source,
            "step_index": int(step_index), "index": tuple(int(x) for x in index),
            "risk": float(risk), "strength": float(strength),
        })

    @staticmethod
    def make_fracture_zone_detected(*, step_index: int, candidate_count: int,
                                     risk_max: float, source: str = "noctilith") -> "Event":
        return Event(type="fracture_zone_detected", payload={
            "schema_version": SCHEMA_VERSION, "source": source,
            "step_index": int(step_index), "candidate_count": int(candidate_count),
            "risk_max": float(risk_max),
        })

    @staticmethod
    def make_material_failure_risk(*, step_index: int, risk_max: float,
                                    zone_fraction: float, source: str = "noctilith") -> "Event":
        return Event(type="material_failure_risk", payload={
            "schema_version": SCHEMA_VERSION, "source": source,
            "step_index": int(step_index), "risk_max": float(risk_max),
            "zone_fraction": float(zone_fraction),
        })

    @staticmethod
    def make_debris_entity_spawned(*, step_index: int, entity_id: int,
                                    strength: float, source: str = "noctilith") -> "Event":
        return Event(type="debris_entity_spawned", payload={
            "schema_version": SCHEMA_VERSION, "source": source,
            "step_index": int(step_index), "entity_id": int(entity_id),
            "strength": float(strength),
        })

    @staticmethod
    def make_debris_ground_hit(*, step_index: int, entity_id: int,
                                position: tuple, source: str = "noctilith") -> "Event":
        return Event(type="debris_ground_hit", payload={
            "schema_version": SCHEMA_VERSION, "source": source,
            "step_index": int(step_index), "entity_id": int(entity_id),
            "position": tuple(float(x) for x in position),
        })

    @staticmethod
    def make_debris_expired(*, step_index: int, entity_id: int,
                             source: str = "noctilith") -> "Event":
        return Event(type="debris_expired", payload={
            "schema_version": SCHEMA_VERSION, "source": source,
            "step_index": int(step_index), "entity_id": int(entity_id),
        })

    @staticmethod
    def make_debris_world_impact(
        *, step_index: int, index: tuple, strength: float, speed: float,
        source: str = "noctilith.sim.debris_world_coupling",
    ) -> "Event":
        """M12.3: debris impacted world — for secondary fragmentation events."""
        return Event(type="debris_world_impact", payload={
            "schema_version": SCHEMA_VERSION,
            "source":         source,
            "step_index":     int(step_index),
            "index":          tuple(int(x) for x in index),
            "strength":       float(strength),
            "speed":          float(speed),
        })


