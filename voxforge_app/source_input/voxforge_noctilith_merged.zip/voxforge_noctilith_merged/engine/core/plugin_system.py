"""
engine/core/plugin_system.py
=============================
Plugin / Module systém — rozšiřování platformy bez zásahu do core.

Blueprint §2.1: "plugin/module system"
Blueprint §2.3: "Publish Mode — balíčkování hry/simulace/modulu"

Architektura:
    Plugin = Python modul s definovaným interfacem
    ModuleRegistry = centrální registr všech pluginů
    PluginLoader = detekce a načtení pluginů z adresářů
    PluginContext = izolovaný kontext pro každý plugin

Plugin interface (plugin musí implementovat):
    class VoxPlugin:
        NAME = "my_plugin"
        VERSION = "1.0.0"
        DESCRIPTION = "..."
        DEPENDENCIES = []     # jména závislostí
        AUTHOR = "..."

        def on_load(self, ctx: PluginContext) -> None: ...
        def on_unload(self) -> None: ...
        def on_tick(self, tick: int) -> None: ...   # volitelné

Příklady pluginů:
    - HydrodynamicsPlugin v2 (pokročilá SPH hydrodynamika)
    - ElectronicsPlugin (komplexní elektrické obvody)
    - WeaponSystemPlugin (herní zbraně)
    - NPCPackPlugin (sada NPC behaviorů)
"""
from __future__ import annotations

import importlib
import importlib.util
import sys
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Type


# ─── Plugin status ────────────────────────────────────────────────────────────

class PluginStatus(str, Enum):
    DISCOVERED  = "discovered"
    LOADING     = "loading"
    LOADED      = "loaded"
    ACTIVE      = "active"
    DISABLED    = "disabled"
    ERROR       = "error"
    UNLOADED    = "unloaded"


# ─── Plugin Context ───────────────────────────────────────────────────────────

@dataclass
class PluginContext:
    """
    Izolovaný kontext pro každý plugin.
    Poskytuje přístup k platformě bez přímé závislosti.
    """
    plugin_name: str
    engine_ref: Any                          # reference na Engine (slabá)
    scheduler_ref: Any = None                # reference na Scheduler
    bus_ref: Any = None                      # reference na EventBus
    world_ref: Any = None                    # reference na World
    resource_manager_ref: Any = None
    _storage: Dict[str, Any] = field(default_factory=dict)

    # Plugin API
    def store(self, key: str, value: Any) -> None:
        """Ulož data pluginu."""
        self._storage[key] = value

    def retrieve(self, key: str, default: Any = None) -> Any:
        return self._storage.get(key, default)

    def register_sim_module(self, name: str, step_fn: Callable,
                             every_n_ticks: int = 1,
                             priority: int = 50) -> None:
        """Zaregistruj simulační modul přes Scheduler."""
        if self.scheduler_ref:
            from engine.core.scheduler import SimModule
            self.scheduler_ref.register(SimModule(
                name=f"{self.plugin_name}.{name}",
                step_fn=step_fn,
                every_n_ticks=every_n_ticks,
                priority=priority,
                tags={self.plugin_name},
            ))

    def subscribe_event(self, event_type: str, callback: Callable) -> None:
        """Přihlás se k odběru EventBus události."""
        if self.bus_ref:
            self.bus_ref.subscribe(event_type, callback)

    def emit_event(self, event_type: str, tick: int = 0, **payload) -> None:
        """Emituj událost přes EventBus."""
        if self.bus_ref:
            try:
                from engine.core.events import Event
                self.bus_ref.publish(Event(type=event_type, tick=tick, payload=payload))
            except Exception:
                pass

    def log(self, msg: str, level: str = "INFO") -> None:
        print(f"[Plugin:{self.plugin_name}] [{level}] {msg}")


# ─── Plugin Base ──────────────────────────────────────────────────────────────

class VoxPlugin:
    """
    Základní třída pro všechny VoxForge pluginy.
    Pluginy dědí z této třídy.
    """
    NAME:         str = "unnamed_plugin"
    VERSION:      str = "0.0.0"
    DESCRIPTION:  str = ""
    AUTHOR:       str = "unknown"
    DEPENDENCIES: List[str] = []    # jména závislých pluginů
    TAGS:         List[str] = []    # kategorické tagy

    def __init__(self):
        self.ctx: Optional[PluginContext] = None
        self._active = False

    def on_load(self, ctx: PluginContext) -> None:
        """Voláno při načtení pluginu. Inicializace."""
        self.ctx = ctx

    def on_enable(self) -> None:
        """Voláno při aktivaci pluginu."""
        self._active = True

    def on_disable(self) -> None:
        """Voláno při deaktivaci pluginu."""
        self._active = False

    def on_unload(self) -> None:
        """Voláno při odebírání pluginu. Úklid."""
        self.ctx = None
        self._active = False

    def on_tick(self, tick: int) -> None:
        """Volitelný tick callback (každý engine tick)."""
        pass

    def on_world_load(self, world) -> None:
        """Voláno při načtení/vytvoření světa."""
        pass

    def on_player_join(self, session) -> None:
        """Voláno při připojení hráče."""
        pass

    def on_player_leave(self, session) -> None:
        pass

    @property
    def is_active(self) -> bool:
        return self._active

    def __repr__(self) -> str:
        return f"VoxPlugin({self.NAME} v{self.VERSION})"


# ─── Plugin Record ────────────────────────────────────────────────────────────

@dataclass
class PluginRecord:
    """Záznám v registru o jednom pluginu."""
    name: str
    version: str
    description: str
    author: str
    status: PluginStatus = PluginStatus.DISCOVERED
    dependencies: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    plugin_instance: Optional[VoxPlugin] = None
    source_path: Optional[Path] = None
    load_error: str = ""
    loaded_at: float = 0.0
    tick_count: int = 0
    total_tick_ms: float = 0.0

    @property
    def avg_tick_ms(self) -> float:
        return self.total_tick_ms / max(1, self.tick_count)


# ─── Plugin Loader ────────────────────────────────────────────────────────────

class PluginLoader:
    """
    Detekuje a načítá pluginy z adresářů.
    Plugin = Python soubor s třídou dědící z VoxPlugin.
    """

    def discover(self, plugin_dir: Path) -> List[Path]:
        """Najdi všechny plugin soubory v adresáři."""
        plugin_dir = Path(plugin_dir)
        if not plugin_dir.exists():
            return []
        # Hledej plugin_{name}.py nebo plugins/{name}/plugin.py
        plugins = []
        for f in plugin_dir.glob("plugin_*.py"):
            plugins.append(f)
        for subdir in plugin_dir.iterdir():
            if subdir.is_dir():
                pfile = subdir / "plugin.py"
                if pfile.exists():
                    plugins.append(pfile)
        return plugins

    def load_from_file(self, path: Path) -> Optional[Type[VoxPlugin]]:
        """
        Načti plugin z Python souboru.
        Vrátí třídu pluginu nebo None pokud selže.
        """
        path = Path(path)
        if not path.exists():
            return None

        module_name = f"voxforge_plugin_{path.stem}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        if not spec:
            return None

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        try:
            spec.loader.exec_module(module)
        except Exception as e:
            return None

        # Najdi VoxPlugin subclass
        for attr_name in dir(module):
            obj = getattr(module, attr_name)
            if (isinstance(obj, type) and
                issubclass(obj, VoxPlugin) and
                obj is not VoxPlugin and
                hasattr(obj, 'NAME')):
                return obj

        return None

    def load_from_class(self, cls: Type[VoxPlugin]) -> Optional[VoxPlugin]:
        """Instanciuj plugin z třídy."""
        try:
            return cls()
        except Exception as e:
            return None


# ─── Module Registry ──────────────────────────────────────────────────────────

class ModuleRegistry:
    """
    Centrální registr všech pluginů a modulů platformy.
    Blueprint §2.1: "plugin/module system"

    Použití:
        registry = ModuleRegistry()
        registry.register_class(MyPlugin)
        registry.enable("my_plugin", ctx)
    """

    def __init__(self):
        self._records: Dict[str, PluginRecord] = {}
        self._loader  = PluginLoader()
        self._active_tick_plugins: List[PluginRecord] = []
        self._load_callbacks: List[Callable[[PluginRecord], None]] = []

    # ── Registrace ────────────────────────────────────────────────────────────

    def register_class(self, cls: Type[VoxPlugin]) -> PluginRecord:
        """Zaregistruj plugin třídu přímo."""
        instance = cls()
        record = PluginRecord(
            name=cls.NAME,
            version=cls.VERSION,
            description=cls.DESCRIPTION,
            author=cls.AUTHOR,
            dependencies=list(cls.DEPENDENCIES),
            tags=list(cls.TAGS),
            plugin_instance=instance,
            status=PluginStatus.DISCOVERED,
        )
        self._records[cls.NAME] = record
        return record

    def register_instance(self, plugin: VoxPlugin) -> PluginRecord:
        """Zaregistruj instanci pluginu."""
        cls = type(plugin)
        record = PluginRecord(
            name=cls.NAME, version=cls.VERSION,
            description=cls.DESCRIPTION, author=cls.AUTHOR,
            dependencies=list(cls.DEPENDENCIES),
            tags=list(cls.TAGS),
            plugin_instance=plugin,
            status=PluginStatus.DISCOVERED,
        )
        self._records[cls.NAME] = record
        return record

    def discover_and_register(self, plugin_dir: Path) -> int:
        """Najdi a zaregistruj všechny pluginy v adresáři. Vrátí počet."""
        paths = self._loader.discover(plugin_dir)
        loaded = 0
        for path in paths:
            cls = self._loader.load_from_file(path)
            if cls:
                record = self.register_class(cls)
                record.source_path = path
                loaded += 1
        return loaded

    # ── Enable / Disable ──────────────────────────────────────────────────────

    def enable(self, plugin_name: str, ctx: PluginContext) -> bool:
        """Aktivuj plugin. Vrátí True pokud úspěšné."""
        record = self._records.get(plugin_name)
        if not record:
            return False

        # Zkontroluj závislosti
        for dep in record.dependencies:
            dep_rec = self._records.get(dep)
            if not dep_rec or dep_rec.status != PluginStatus.ACTIVE:
                record.load_error = f"Závislost '{dep}' není aktivní."
                record.status = PluginStatus.ERROR
                return False

        # Načti
        record.status = PluginStatus.LOADING
        plugin = record.plugin_instance
        if not plugin:
            record.status = PluginStatus.ERROR
            return False

        try:
            plugin.on_load(ctx)
            plugin.on_enable()
            record.status = PluginStatus.ACTIVE
            record.loaded_at = time.time()
            # Zaregistruj do tick listu pokud override on_tick
            if type(plugin).on_tick is not VoxPlugin.on_tick:
                self._active_tick_plugins.append(record)
            for cb in self._load_callbacks:
                cb(record)
            return True
        except Exception as e:
            record.status = PluginStatus.ERROR
            record.load_error = str(e)
            return False

    def disable(self, plugin_name: str) -> bool:
        record = self._records.get(plugin_name)
        if not record or record.status != PluginStatus.ACTIVE:
            return False
        try:
            record.plugin_instance.on_disable()
            record.status = PluginStatus.DISABLED
            self._active_tick_plugins = [r for r in self._active_tick_plugins
                                         if r.name != plugin_name]
            return True
        except Exception:
            return False

    def unload(self, plugin_name: str) -> bool:
        record = self._records.get(plugin_name)
        if not record:
            return False
        if record.status == PluginStatus.ACTIVE:
            self.disable(plugin_name)
        try:
            if record.plugin_instance:
                record.plugin_instance.on_unload()
            record.status = PluginStatus.UNLOADED
            del self._records[plugin_name]
            return True
        except Exception:
            return False

    def reload(self, plugin_name: str, ctx: PluginContext) -> bool:
        """Hot reload pluginu."""
        record = self._records.get(plugin_name)
        if not record or not record.source_path:
            return False
        was_active = record.status == PluginStatus.ACTIVE
        if was_active:
            self.disable(plugin_name)

        cls = self._loader.load_from_file(record.source_path)
        if not cls:
            return False

        new_instance = cls()
        record.plugin_instance = new_instance
        record.version = cls.VERSION
        record.status = PluginStatus.DISCOVERED

        if was_active:
            return self.enable(plugin_name, ctx)
        return True

    # ── Tick dispatch ─────────────────────────────────────────────────────────

    def tick(self, tick: int) -> Dict[str, float]:
        """Zavolej on_tick na všech aktivních pluginech. Vrátí timing dict."""
        timings: Dict[str, float] = {}
        import time as _time
        for record in self._active_tick_plugins:
            if record.status != PluginStatus.ACTIVE:
                continue
            t0 = _time.perf_counter()
            try:
                record.plugin_instance.on_tick(tick)
            except Exception as e:
                record.load_error = str(e)
                record.status = PluginStatus.ERROR
            dt = (_time.perf_counter() - t0) * 1000
            record.tick_count += 1
            record.total_tick_ms += dt
            timings[record.name] = round(dt, 3)
        return timings

    # ── Queries ───────────────────────────────────────────────────────────────

    def get(self, name: str) -> Optional[PluginRecord]:
        return self._records.get(name)

    def get_plugin(self, name: str) -> Optional[VoxPlugin]:
        rec = self._records.get(name)
        return rec.plugin_instance if rec else None

    def active(self) -> List[PluginRecord]:
        return [r for r in self._records.values() if r.status == PluginStatus.ACTIVE]

    def by_tag(self, tag: str) -> List[PluginRecord]:
        return [r for r in self._records.values() if tag in r.tags]

    def on_plugin_load(self, fn: Callable[[PluginRecord], None]) -> None:
        self._load_callbacks.append(fn)

    @property
    def stats(self) -> dict:
        statuses = {}
        for r in self._records.values():
            statuses[r.status.value] = statuses.get(r.status.value, 0) + 1
        return {
            "total": len(self._records),
            "active": len(self.active()),
            "by_status": statuses,
        }

    def report(self) -> str:
        lines = [f"=== ModuleRegistry ({len(self._records)} plugins) ==="]
        for name, rec in sorted(self._records.items()):
            status_icon = {
                PluginStatus.ACTIVE:   "✓",
                PluginStatus.DISABLED: "○",
                PluginStatus.ERROR:    "✗",
                PluginStatus.LOADING:  "↻",
            }.get(rec.status, "?")
            err = f" ERR={rec.load_error[:30]}" if rec.load_error else ""
            lines.append(f"  [{status_icon}] {rec.name:<25} v{rec.version:<8} "
                         f"{rec.status.value:<12}{err}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"ModuleRegistry({len(self._records)} plugins, {len(self.active())} active)"


# ─── Built-in Plugins ─────────────────────────────────────────────────────────

class ThermalPhysicsPlugin(VoxPlugin):
    """Plugin pro rozšířenou termální fyziku."""
    NAME = "thermal_physics"; VERSION = "1.0.0"
    DESCRIPTION = "Rozšířená termální simulace s heat sources a insulation"
    AUTHOR = "voxforge_core"; TAGS = ["physics", "simulation", "thermal"]

    def on_load(self, ctx: PluginContext) -> None:
        super().on_load(ctx)
        ctx.log("Thermal Physics Plugin načten")
        ctx.register_sim_module("thermal_ext", self._thermal_step,
                                every_n_ticks=2, priority=5)

    def _thermal_step(self, tick: int) -> None:
        pass  # hook do thermal simulace

    def on_tick(self, tick: int) -> None:
        pass


class FluidPhysicsPlugin(VoxPlugin):
    """Plugin pro hydrodynamiku Level 3 (hybrid particle)."""
    NAME = "fluid_physics_l3"; VERSION = "1.0.0"
    DESCRIPTION = "Hybridní voxel+particle fluid (Level 3)"
    AUTHOR = "voxforge_core"; TAGS = ["physics", "simulation", "fluid"]
    DEPENDENCIES = []

    def on_load(self, ctx: PluginContext) -> None:
        super().on_load(ctx)
        ctx.log("Fluid Physics L3 Plugin načten")


class AIBehaviorPackPlugin(VoxPlugin):
    """Balíček AI behaviorů — více typů NPC."""
    NAME = "ai_behavior_pack"; VERSION = "1.0.0"
    DESCRIPTION = "Rozšířené AI chování: obchodníci, strážci, průzkumníci"
    AUTHOR = "voxforge_core"; TAGS = ["ai", "npc", "gameplay"]

    def on_load(self, ctx: PluginContext) -> None:
        super().on_load(ctx)
        ctx.log("AI Behavior Pack načten")
        self._npc_count = 0

    def on_player_join(self, session) -> None:
        if self.ctx:
            self.ctx.log(f"Hráč připojen, spawning welcome NPC")


class MultiplayerPlugin(VoxPlugin):
    """Plugin pro multiplayer infrastrukturu."""
    NAME = "multiplayer"; VERSION = "1.0.0"
    DESCRIPTION = "Multiplayer server a client synchronizace"
    AUTHOR = "voxforge_core"; TAGS = ["network", "multiplayer"]

    def on_load(self, ctx: PluginContext) -> None:
        super().on_load(ctx)
        ctx.log("Multiplayer Plugin načten")


# Registr built-in pluginů
BUILTIN_PLUGINS: List[Type[VoxPlugin]] = [
    ThermalPhysicsPlugin,
    FluidPhysicsPlugin,
    AIBehaviorPackPlugin,
    MultiplayerPlugin,
]
