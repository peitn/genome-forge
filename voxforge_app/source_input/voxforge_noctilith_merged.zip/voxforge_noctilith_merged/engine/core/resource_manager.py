"""
engine/core/resource_manager.py
================================
Resource Manager — správa herních zdrojů, asset loading, caching.

Blueprint §2.1: "resource manager, asset registry, plugin/module system"
"""
from __future__ import annotations

import hashlib
import json
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Type
import weakref


# ─── Resource ─────────────────────────────────────────────────────────────────

@dataclass
class ResourceHandle:
    """Handle na načtený resource."""
    resource_id: str
    resource_type: str
    path: Optional[Path]
    data: Any
    loaded_at: float = field(default_factory=time.time)
    size_bytes: int = 0
    ref_count: int = 0
    checksum: str = ""

    @property
    def age_seconds(self) -> float:
        return time.time() - self.loaded_at

    def addref(self) -> None:
        self.ref_count += 1

    def release(self) -> bool:
        """Vrátí True pokud má být resource uvolněn (ref_count = 0)."""
        self.ref_count = max(0, self.ref_count - 1)
        return self.ref_count == 0


class ResourceLoader:
    """Základní loader — přečte soubor jako bytes nebo text."""

    def can_load(self, path: Path) -> bool:
        return True

    def load(self, path: Path) -> Any:
        if path.suffix.lower() == '.json':
            return json.loads(path.read_text(encoding='utf-8'))
        return path.read_bytes()

    def get_size(self, data: Any) -> int:
        if isinstance(data, bytes):
            return len(data)
        if isinstance(data, str):
            return len(data.encode())
        return 0


class JsonLoader(ResourceLoader):
    def can_load(self, path: Path) -> bool:
        return path.suffix.lower() == '.json'
    def load(self, path: Path) -> Any:
        return json.loads(path.read_text(encoding='utf-8'))


class TextLoader(ResourceLoader):
    def can_load(self, path: Path) -> bool:
        return path.suffix.lower() in ('.txt', '.voxscript', '.md')
    def load(self, path: Path) -> str:
        return path.read_text(encoding='utf-8')


class ResourceManager:
    """
    Centrální správce zdrojů platformy.
    Blueprint §2.1: "resource manager"

    Funkce:
    - Lazy loading (načítá při prvním požadavku)
    - LRU cache s konfigurovatelným limitem paměti
    - Hot reload (sleduje změny souborů)
    - Thread-safe (pro asynchronní loading)
    - Reference counting (GC při uvolnění)
    """

    def __init__(self, max_cache_mb: float = 256.0):
        self._resources: Dict[str, ResourceHandle] = {}
        self._max_cache_bytes = int(max_cache_mb * 1024 * 1024)
        self._current_bytes = 0
        self._loaders: List[ResourceLoader] = [JsonLoader(), TextLoader(), ResourceLoader()]
        self._search_paths: List[Path] = []
        self._lock = threading.Lock()
        self._access_order: List[str] = []   # LRU tracking
        self._listeners: Dict[str, List[Callable]] = {}   # hot reload callbacks

    def add_search_path(self, path: Path) -> None:
        """Přidej adresář pro vyhledávání assetů."""
        p = Path(path)
        if p.exists() and p not in self._search_paths:
            self._search_paths.append(p)

    def register_loader(self, loader: ResourceLoader) -> None:
        self._loaders.insert(0, loader)

    # ── Loading ───────────────────────────────────────────────────────────────

    def load(self, resource_id: str,
             path: Optional[Path] = None) -> Optional[ResourceHandle]:
        """
        Načti resource podle ID nebo cesty.
        Pokud je v cache, vrátí cached verzi.
        """
        with self._lock:
            if resource_id in self._resources:
                handle = self._resources[resource_id]
                handle.addref()
                self._touch_lru(resource_id)
                return handle

        resolved_path = path or self._resolve_path(resource_id)
        if resolved_path is None or not resolved_path.exists():
            return None

        loader = self._find_loader(resolved_path)
        try:
            data = loader.load(resolved_path)
            checksum = self._checksum(resolved_path)
            handle = ResourceHandle(
                resource_id=resource_id,
                resource_type=resolved_path.suffix.lstrip('.').lower(),
                path=resolved_path,
                data=data,
                size_bytes=loader.get_size(data),
                checksum=checksum,
                ref_count=1,
            )
            with self._lock:
                self._resources[resource_id] = handle
                self._current_bytes += handle.size_bytes
                self._access_order.append(resource_id)
                self._evict_if_needed()
            return handle
        except Exception as e:
            return None

    def load_or_default(self, resource_id: str, default: Any,
                        path: Optional[Path] = None) -> Any:
        handle = self.load(resource_id, path)
        return handle.data if handle else default

    def release(self, resource_id: str) -> None:
        """Uvolni referenci na resource."""
        with self._lock:
            handle = self._resources.get(resource_id)
            if handle and handle.release():
                self._current_bytes -= handle.size_bytes
                del self._resources[resource_id]
                if resource_id in self._access_order:
                    self._access_order.remove(resource_id)

    def get(self, resource_id: str) -> Optional[Any]:
        """Vrátí data z cache nebo None."""
        handle = self._resources.get(resource_id)
        return handle.data if handle else None

    def preload(self, resource_ids: List[str],
                search_root: Optional[Path] = None) -> int:
        """Předem načti seznam zdrojů. Vrátí počet úspěšně načtených."""
        loaded = 0
        for rid in resource_ids:
            path = None
            if search_root:
                candidate = search_root / rid
                if candidate.exists():
                    path = candidate
            if self.load(rid, path):
                loaded += 1
        return loaded

    # ── Hot Reload ────────────────────────────────────────────────────────────

    def watch(self, resource_id: str, callback: Callable[[str, Any], None]) -> None:
        """Sleduj změny souboru a zavolej callback při reloadu."""
        if resource_id not in self._listeners:
            self._listeners[resource_id] = []
        self._listeners[resource_id].append(callback)

    def reload(self, resource_id: str) -> bool:
        """Přenačti resource (hot reload). Vrátí True pokud úspěšné."""
        handle = self._resources.get(resource_id)
        if not handle or not handle.path:
            return False
        new_checksum = self._checksum(handle.path)
        if new_checksum == handle.checksum:
            return False   # soubor se nezměnil
        # Přenačti
        loader = self._find_loader(handle.path)
        try:
            new_data = loader.load(handle.path)
            with self._lock:
                old_size = handle.size_bytes
                handle.data = new_data
                handle.checksum = new_checksum
                handle.size_bytes = loader.get_size(new_data)
                handle.loaded_at = time.time()
                self._current_bytes += handle.size_bytes - old_size
            # Notifikuj listenery
            for cb in self._listeners.get(resource_id, []):
                cb(resource_id, new_data)
            return True
        except Exception:
            return False

    def check_for_changes(self) -> List[str]:
        """Zkontroluj změny všech sledovaných souborů. Vrátí reloadnuté ID."""
        reloaded = []
        for rid in list(self._listeners.keys()):
            if self.reload(rid):
                reloaded.append(rid)
        return reloaded

    # ── Internals ─────────────────────────────────────────────────────────────

    def _resolve_path(self, resource_id: str) -> Optional[Path]:
        """Najdi soubor v search paths."""
        for base in self._search_paths:
            candidate = base / resource_id
            if candidate.exists():
                return candidate
        return None

    def _find_loader(self, path: Path) -> ResourceLoader:
        for loader in self._loaders:
            if loader.can_load(path):
                return loader
        return self._loaders[-1]  # fallback

    def _checksum(self, path: Path) -> str:
        try:
            return hashlib.md5(path.read_bytes()).hexdigest()[:12]
        except Exception:
            return ""

    def _touch_lru(self, resource_id: str) -> None:
        if resource_id in self._access_order:
            self._access_order.remove(resource_id)
        self._access_order.append(resource_id)

    def _evict_if_needed(self) -> None:
        """LRU eviction pokud překračujeme paměťový limit."""
        while self._current_bytes > self._max_cache_bytes and self._access_order:
            evict_id = self._access_order[0]
            handle = self._resources.get(evict_id)
            if handle and handle.ref_count <= 0:
                self._current_bytes -= handle.size_bytes
                del self._resources[evict_id]
                self._access_order.pop(0)
            else:
                break  # nejstarší má stále reference

    # ── Status ────────────────────────────────────────────────────────────────

    @property
    def stats(self) -> dict:
        return {
            "cached_resources": len(self._resources),
            "cache_mb":         round(self._current_bytes / 1024 / 1024, 2),
            "max_cache_mb":     round(self._max_cache_mb_limit, 2),
            "search_paths":     len(self._search_paths),
        }

    @property
    def _max_cache_mb_limit(self) -> float:
        return self._max_cache_bytes / 1024 / 1024

    def __repr__(self) -> str:
        return (f"ResourceManager("
                f"cached={len(self._resources)}, "
                f"mb={self._current_bytes/1024/1024:.1f})")
