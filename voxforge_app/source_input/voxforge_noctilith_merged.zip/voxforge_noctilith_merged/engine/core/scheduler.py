"""
engine/core/scheduler.py
========================
Runtime Scheduler — řídí co se počítá každý frame,
co jednou za N ticků, a co jen lokálně v zóně.

Blueprint §5: "Scheduler určuje, co se počítá každý frame,
               co jednou za několik ticků a co jen lokálně."
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set


# ── Simulační modul ────────────────────────────────────────────────────────────

@dataclass
class SimModule:
    """
    Jeden simulační modul v platformě.
    Každý modul má vlastní data fieldy, step funkci a konfiguraci.

    Blueprint §5 — příklady:
        ThermalSimulation, EntropySimulation, DamageSimulation,
        FractureSimulation, FluidSimulation, DebrisSimulation,
        ReactionSimulation, AgentSimulation, WeatherSimulation, EnergySimulation
    """
    name: str
    step_fn: Callable[[int], None]        # step_fn(tick) → None
    every_n_ticks: int = 1                # frekvence volání (1 = každý tick)
    enabled: bool = True
    priority: int = 0                     # nižší číslo = vyšší priorita (dřív)
    tags: Set[str] = field(default_factory=set)
    stats: Dict[str, float] = field(default_factory=dict)

    # Runtime metadata
    _last_tick: int = field(default=-1, init=False, repr=False)
    _call_count: int = field(default=0, init=False, repr=False)
    _total_ms: float = field(default=0.0, init=False, repr=False)

    def should_run(self, tick: int) -> bool:
        return self.enabled and (tick % self.every_n_ticks == 0)

    @property
    def avg_ms(self) -> float:
        if self._call_count == 0:
            return 0.0
        return self._total_ms / self._call_count


class Scheduler:
    """
    Hlavní plánovač simulačních modulů.

    Použití:

        scheduler = Scheduler(bus)
        scheduler.register(SimModule("thermal", thermal_sim.step, every_n_ticks=1, priority=0))
        scheduler.register(SimModule("fluid",   fluid_sim.step,   every_n_ticks=1, priority=1))
        scheduler.register(SimModule("debris",  debris_sim.step,  every_n_ticks=3, priority=5))

        for tick in range(1000):
            scheduler.tick()
    """

    def __init__(self, bus=None):
        self._modules: List[SimModule] = []
        self._tick: int = 0
        self._bus = bus
        self._paused: Set[str] = set()
        self._tick_start: float = 0.0
        self._tick_times: List[float] = []

    # ── Registration ──────────────────────────────────────────────────────────

    def register(self, module: SimModule) -> None:
        """Zaregistruj simulační modul. Automaticky seřadí podle priority."""
        self._modules.append(module)
        self._modules.sort(key=lambda m: m.priority)

    def unregister(self, name: str) -> None:
        self._modules = [m for m in self._modules if m.name != name]

    def get(self, name: str) -> Optional[SimModule]:
        for m in self._modules:
            if m.name == name:
                return m
        return None

    # ── Control ───────────────────────────────────────────────────────────────

    def pause(self, name: str) -> None:
        """Pozastav konkrétní modul."""
        mod = self.get(name)
        if mod:
            mod.enabled = False

    def resume(self, name: str) -> None:
        mod = self.get(name)
        if mod:
            mod.enabled = True

    def pause_tag(self, tag: str) -> None:
        """Pozastav všechny moduly s daným tagem."""
        for m in self._modules:
            if tag in m.tags:
                m.enabled = False

    def resume_tag(self, tag: str) -> None:
        for m in self._modules:
            if tag in m.tags:
                m.enabled = True

    # ── Tick ──────────────────────────────────────────────────────────────────

    def tick(self) -> Dict[str, float]:
        """
        Vykonej jeden globální tick.
        Vrátí slovník {module_name: ms} pro profiling.
        """
        self._tick += 1
        t = self._tick
        tick_start = time.perf_counter()
        timings: Dict[str, float] = {}

        for module in self._modules:
            if not module.should_run(t):
                continue
            t0 = time.perf_counter()
            try:
                module.step_fn(t)
            except Exception as e:
                # Chyba v modulu nezastaví ostatní
                print(f"[Scheduler] ERROR in '{module.name}' at tick {t}: {e}")
            dt = (time.perf_counter() - t0) * 1000
            module._call_count += 1
            module._total_ms += dt
            module._last_tick = t
            timings[module.name] = round(dt, 3)

        total = (time.perf_counter() - tick_start) * 1000
        self._tick_times.append(total)
        self._tick_times = self._tick_times[-200:]
        return timings

    def run(self, n_ticks: int, *, callback: Optional[Callable] = None) -> None:
        """Spusť N ticků. Volitelný callback(tick, timings) po každém."""
        for _ in range(n_ticks):
            timings = self.tick()
            if callback:
                callback(self._tick, timings)

    # ── Profiling ─────────────────────────────────────────────────────────────

    @property
    def current_tick(self) -> int:
        return self._tick

    @property
    def avg_tick_ms(self) -> float:
        if not self._tick_times:
            return 0.0
        return sum(self._tick_times[-50:]) / len(self._tick_times[-50:])

    def profile_report(self) -> str:
        lines = [f"=== Scheduler Report (tick={self._tick}) ==="]
        lines.append(f"  avg tick: {self.avg_tick_ms:.2f} ms")
        for m in self._modules:
            status = "ON " if m.enabled else "OFF"
            lines.append(
                f"  [{status}] {m.name:<22} "
                f"every={m.every_n_ticks}  "
                f"calls={m._call_count}  "
                f"avg={m.avg_ms:.2f}ms"
            )
        return "\n".join(lines)
