"""noctilith/entities/debris_dynamics.py — M12 DebrisDynamicsSystem."""
from __future__ import annotations
import math
import numpy as np
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from engine.sim.debris_world_coupling import DebrisWorldCoupling, DebrisWorldCouplingConfig
from engine.sim.quantized_field_ops import compute_overlap_eta, batch_scatter_deposit

SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME    = "noctilith.entities.debris_dynamics"


@dataclass
class DebrisEntity:
    entity_id: int
    position: Tuple[float, float, float]
    velocity: Tuple[float, float, float]
    mass: float = 1.0
    lifetime: float = 5.0
    strength: float = 1.0
    origin_index: Tuple[int, int, int] = (0, 0, 0)
    age: float = 0.0
    active: bool = True


@dataclass
class DebrisDynamicsConfig:
    enabled: bool = True
    gravity: float = 9.81
    linear_drag: float = 0.05
    ground_z: float = 0.0
    bounce_coefficient: float = 0.0
    max_spawn_per_step: int = 16
    max_entities: int = 512
    emit_events: bool = True


@dataclass
class DebrisDynamicsSystem:
    config: DebrisDynamicsConfig = field(default_factory=DebrisDynamicsConfig)
    world_coupling: DebrisWorldCoupling = field(
        default_factory=lambda: DebrisWorldCoupling(DebrisWorldCouplingConfig()))

    def _integrate(self, ent: DebrisEntity, dt: float) -> DebrisEntity:
        cfg = self.config
        vx, vy, vz = ent.velocity
        vz -= cfg.gravity * dt
        drag = max(0.0, 1.0 - cfg.linear_drag * dt)
        vx *= drag; vy *= drag; vz *= drag
        x, y, z = ent.position
        x += vx * dt; y += vy * dt; z += vz * dt
        return DebrisEntity(
            entity_id=ent.entity_id, position=(x, y, z), velocity=(vx, vy, vz),
            mass=ent.mass, lifetime=ent.lifetime, strength=ent.strength,
            origin_index=ent.origin_index, age=ent.age + dt, active=True)

    def _is_grounded(self, ent: DebrisEntity) -> bool:
        return ent.position[2] <= self.config.ground_z and ent.velocity[2] <= 0

    def step(self, *, target_obj: Any, world_obj: Any, thermal_grid: Any,
             entropy_field: Any, dt: float,
             telemetry: Optional[Dict[str, Any]] = None,
             event_bus: Optional[Any] = None) -> Dict[str, Any]:
        cfg = self.config

        class TelOut:
            step_index = 0; alive_entities = 0; expired = 0; ground_hits = 0
            spawned = 0; overlap_eta = 0.0; emitted_events = 0

        out = TelOut()
        if not cfg.enabled:
            return {"enabled": False, "alive_entities": 0, "ground_hits": 0,
                    "expired": 0, "spawned": 0, "overlap_eta": 0.0, "emitted_events": 0}

        telemetry = telemetry or {}
        out.step_index = int(telemetry.get("step_index", 0))

        store = _EntityStore(target_obj)

        # Ingest newly spawned entities
        spawned_list = getattr(world_obj, "_spawned_entities", []) \
                    if world_obj is not None else []
        ingest = [e for e in spawned_list if e.get("kind") == "debris"]
        del spawned_list[:len(ingest)]
        for item in ingest[:cfg.max_spawn_per_step]:
            p = item.get("payload", {})
            eid = getattr(target_obj, "_next_debris_entity_id", 1)
            if hasattr(target_obj, "_next_debris_entity_id"):
                target_obj._next_debris_entity_id = eid + 1
            pos = p.get("position", (0., 0., 1.))
            vel = p.get("velocity", (0., 0., 0.))
            store.add(DebrisEntity(
                entity_id=eid, position=tuple(pos), velocity=tuple(vel),
                mass=float(p.get("mass", 1.0)), lifetime=float(p.get("lifetime", 5.0)),
                strength=float(p.get("strength", 1.0)),
                origin_index=tuple(p.get("origin_index", (0,0,0))),
            ))
            out.spawned += 1

        # Update loop
        _ground_hits_batch: list = []
        updated: List[DebrisEntity] = []
        for ent in store.entities:
            if not ent.active or ent.age >= ent.lifetime:
                out.expired += 1
                continue
            ent = self._integrate(ent, dt)
            if self._is_grounded(ent):
                out.ground_hits += 1
                if world_obj is not None:
                    coupling_result = self.world_coupling.apply_ground_hit(
                        world_obj=world_obj, thermal_grid=None, entropy_field=None,
                        debris_entity=ent, step_index=out.step_index, event_bus=event_bus)
                    out.emitted_events += int(coupling_result.get("emitted_events", 0))
                    if coupling_result.get("processed_hits", 0) > 0:
                        speed = math.sqrt(sum(v*v for v in ent.velocity))
                        _ground_hits_batch.append((
                            (int(round(ent.position[0])), int(round(ent.position[1])),
                             int(round(ent.position[2]))),
                            float(ent.strength) * speed,
                        ))
                continue  # consumed on ground hit
            updated.append(ent)

        store.replace_all(updated)
        out.alive_entities = len(store.entities)

        # Batch field deposition (η-dedup)
        if _ground_hits_batch and (entropy_field is not None or thermal_grid is not None):
            cfg2   = self.world_coupling.config
            kernel = self.world_coupling._get_kernel()
            if entropy_field is not None and cfg2.apply_entropy:
                entropy_arr = entropy_field.S if hasattr(entropy_field, "S") \
                              else getattr(entropy_field, "values", entropy_field)
                e_hits = [(c, min(cfg2.max_entropy_delta, cfg2.entropy_gain * s))
                          for c, s in _ground_hits_batch]
                batch_scatter_deposit(entropy_arr, e_hits, kernel,
                                      clamp=cfg2.max_entropy_delta)
            if thermal_grid is not None and cfg2.apply_thermal:
                thermal_arr = thermal_grid.T if hasattr(thermal_grid, "T") \
                              else getattr(thermal_grid, "values", thermal_grid)
                t_hits = [(c, min(cfg2.max_thermal_delta, cfg2.thermal_gain * s))
                          for c, s in _ground_hits_batch]
                batch_scatter_deposit(thermal_arr, t_hits, kernel,
                                      clamp=cfg2.max_thermal_delta)

        # η(t)
        if store.entities:
            positions = np.array([list(e.position) for e in store.entities], dtype=np.float64)
            out.overlap_eta = compute_overlap_eta(positions)
        else:
            out.overlap_eta = 0.0

        return {
            "schema_version": SCHEMA_VERSION, "module_name": MODULE_NAME,
            "step_index":     out.step_index,
            "alive_entities": out.alive_entities,
            "ground_hits":    out.ground_hits,
            "expired":        out.expired,
            "spawned":        out.spawned,
            "overlap_eta":    float(out.overlap_eta),
            "emitted_events": out.emitted_events,
        }


class _EntityStore:
    def __init__(self, target_obj: Any):
        self._obj = target_obj

    @property
    def entities(self) -> List[DebrisEntity]:
        return getattr(self._obj, "_debris_entities", [])

    def add(self, ent: DebrisEntity) -> None:
        lst = getattr(self._obj, "_debris_entities", None)
        if lst is None:
            self._obj._debris_entities = []
            lst = self._obj._debris_entities
        lst.append(ent)

    def replace_all(self, updated: List[DebrisEntity]) -> None:
        lst = getattr(self._obj, "_debris_entities", None)
        if lst is None: return
        lst.clear()
        lst.extend(updated)
