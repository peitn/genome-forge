"""
engine/game/rules.py
====================
Game Layer — herní pravidla, zdraví, týmy, questy.

Blueprint §6: "player controller, camera system, input mapping,
               inventory, interaction system, health/damage,
               teams, quests/objectives, multiplayer hooks, UI/HUD"
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple


# ── Zdraví a poškození ────────────────────────────────────────────────────────

@dataclass
class HealthComponent:
    max_hp: float = 1.0
    current_hp: float = 1.0
    armor: float = 0.0          # 0-1, snižuje damage
    regen_rate: float = 0.001   # regenerace za tick
    invincible: bool = False

    def apply_damage(self, amount: float, damage_type: str = "physical") -> float:
        if self.invincible:
            return 0.0
        effective = amount * (1.0 - self.armor)
        self.current_hp = max(0.0, self.current_hp - effective)
        return effective

    def heal(self, amount: float) -> None:
        self.current_hp = min(self.max_hp, self.current_hp + amount)

    def regen(self) -> None:
        if self.current_hp > 0:
            self.heal(self.regen_rate)

    @property
    def is_dead(self) -> bool:
        return self.current_hp <= 0

    @property
    def pct(self) -> float:
        return self.current_hp / max(self.max_hp, 0.001)


# ── Inventář ─────────────────────────────────────────────────────────────────

@dataclass
class InventoryItem:
    item_id: str
    name: str
    count: int = 1
    data: Dict[str, Any] = field(default_factory=dict)


class Inventory:
    def __init__(self, max_slots: int = 32):
        self.max_slots = max_slots
        self._items: Dict[str, InventoryItem] = {}

    def add(self, item_id: str, name: str, count: int = 1, **data) -> bool:
        if item_id in self._items:
            self._items[item_id].count += count
        elif len(self._items) < self.max_slots:
            self._items[item_id] = InventoryItem(item_id, name, count, data)
        else:
            return False
        return True

    def remove(self, item_id: str, count: int = 1) -> bool:
        if item_id not in self._items:
            return False
        item = self._items[item_id]
        if item.count < count:
            return False
        item.count -= count
        if item.count <= 0:
            del self._items[item_id]
        return True

    def count(self, item_id: str) -> int:
        return self._items.get(item_id, InventoryItem("", "", 0)).count

    def has(self, item_id: str, count: int = 1) -> bool:
        return self.count(item_id) >= count

    def items(self) -> List[InventoryItem]:
        return list(self._items.values())

    def __repr__(self) -> str:
        return f"Inventory({sum(i.count for i in self._items.values())} items)"


# ── Týmy ──────────────────────────────────────────────────────────────────────

class Team:
    def __init__(self, team_id: str, name: str, color: Tuple[int,int,int] = (255,255,255)):
        self.team_id = team_id
        self.name = name
        self.color = color
        self.members: Set[str] = set()   # entity IDs
        self.score: float = 0.0
        self.enemy_teams: Set[str] = set()

    def add_member(self, entity_id: str) -> None:
        self.members.add(entity_id)

    def remove_member(self, entity_id: str) -> None:
        self.members.discard(entity_id)

    def is_enemy(self, other_team_id: str) -> bool:
        return other_team_id in self.enemy_teams


# ── Questy / Objectives ───────────────────────────────────────────────────────

class QuestStatus(str, Enum):
    INACTIVE   = "inactive"
    ACTIVE     = "active"
    COMPLETED  = "completed"
    FAILED     = "failed"


@dataclass
class Objective:
    objective_id: str
    description: str
    check_fn: Callable[[], bool] = field(default_factory=lambda: lambda: False)
    completed: bool = False
    optional: bool = False

    def check(self) -> bool:
        if not self.completed:
            self.completed = self.check_fn()
        return self.completed


@dataclass
class Quest:
    """Blueprint §6: "quests/objectives" """
    quest_id: str
    name: str
    description: str = ""
    status: QuestStatus = QuestStatus.INACTIVE
    objectives: List[Objective] = field(default_factory=list)
    rewards: Dict[str, Any] = field(default_factory=dict)
    time_limit: Optional[int] = None   # ticků, None = bez limitu
    _start_tick: int = field(default=0, init=False)

    def start(self, tick: int) -> None:
        self.status = QuestStatus.ACTIVE
        self._start_tick = tick

    def update(self, tick: int) -> QuestStatus:
        if self.status != QuestStatus.ACTIVE:
            return self.status
        # Timeout
        if self.time_limit and (tick - self._start_tick) > self.time_limit:
            self.status = QuestStatus.FAILED
            return self.status
        # Kontrola objectives
        required = [o for o in self.objectives if not o.optional]
        if all(o.check() for o in required):
            self.status = QuestStatus.COMPLETED
        return self.status

    @property
    def progress(self) -> float:
        if not self.objectives:
            return 1.0 if self.status == QuestStatus.COMPLETED else 0.0
        done = sum(1 for o in self.objectives if o.completed)
        return done / len(self.objectives)


# ── Game Rules ────────────────────────────────────────────────────────────────

class GameRules:
    """
    Herní pravidla pro VoxForge Game Project.
    Blueprint §6: "game rules"
    """

    def __init__(self):
        self.max_players: int = 1
        self.respawn: bool = True
        self.respawn_delay: int = 100   # ticků
        self.pvp: bool = False
        self.friendly_fire: bool = False
        self.teams: Dict[str, Team] = {}
        self.quests: Dict[str, Quest] = {}
        self.win_conditions: List[Callable[[], bool]] = []
        self.lose_conditions: List[Callable[[], bool]] = []
        self._game_won = False
        self._game_lost = False
        self._tick = 0

    def add_team(self, team: Team) -> None:
        self.teams[team.team_id] = team

    def add_quest(self, quest: Quest) -> None:
        self.quests[quest.quest_id] = quest

    def add_win_condition(self, fn: Callable[[], bool]) -> None:
        self.win_conditions.append(fn)

    def add_lose_condition(self, fn: Callable[[], bool]) -> None:
        self.lose_conditions.append(fn)

    def tick(self, current_tick: int) -> Optional[str]:
        """
        Zkontroluj win/lose podmínky.
        Vrátí 'win', 'lose', nebo None.
        """
        self._tick = current_tick

        # Update questů
        for quest in self.quests.values():
            quest.update(current_tick)

        # Win podmínky
        if not self._game_won and any(fn() for fn in self.win_conditions):
            self._game_won = True
            return "win"

        # Lose podmínky
        if not self._game_lost and any(fn() for fn in self.lose_conditions):
            self._game_lost = True
            return "lose"

        return None

    def can_damage(self, attacker_team: str, target_team: str) -> bool:
        """Může útočník poškodit cíl?"""
        if attacker_team == target_team:
            return self.friendly_fire
        team = self.teams.get(attacker_team)
        if team:
            return team.is_enemy(target_team) or self.pvp
        return self.pvp

    @property
    def active_quests(self) -> List[Quest]:
        return [q for q in self.quests.values() if q.status == QuestStatus.ACTIVE]

    @property
    def is_over(self) -> bool:
        return self._game_won or self._game_lost
