#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
noctilith/multiscale.py
=======================
NOCTILITH MULTISCALE RESAMPLE ADAPTER (full unified package revision)
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional, Tuple, Type

import numpy as np


SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME = "noctilith.multiscale"
MODULE_VERSION = "1.0.0"


@dataclass
class MultiscaleConfig:
    base_scale_index: int = 4
    min_scale_index: int = 2
    max_scale_index: int = 7
    upshift_threshold: float = 0.68
    downshift_threshold: float = 0.32
    hysteresis_margin: float = 0.04
    switch_cooldown_steps: int = 12
    min_persistence_for_switch: int = 2
    activity_ema_alpha: float = 0.88
    w_phi_rms: float = 0.30
    w_zone: float = 0.22
    w_zone_rel: float = 0.16
    w_crit: float = 0.16
    w_omega: float = 0.10
    w_abs_dE: float = 0.06
    w_weff_unstable_penalty: float = 0.08
    phi_rms_scale: float = 0.12
    abs_dE_dt_scale: float = 0.08
    use_named_scales: bool = True
    include_ms_debug: bool = False
    enable_continuous_scale_percent: bool = True
    default_scale_percent: float = 50.0
    percent_affects_substeps: bool = True
    percent_affects_resample_blend: bool = True
    percent_affects_dt_eff: bool = True


@dataclass
class ResampleConfig:
    enable_resample_hooks: bool = True
    resample_on_scale_change: bool = True
    resample_mode: str = "smooth"
    smooth_blend: float = 0.35
    compression_enabled: bool = True
    decompression_enabled: bool = True
    upshift_resample_mode: Optional[str] = None
    downshift_resample_mode: Optional[str] = None
    upshift_smooth_blend: Optional[float] = None
    downshift_smooth_blend: Optional[float] = None
    enable_substeps: bool = True
    substep_policy: str = "higher_scale_more_substeps"
    base_substeps: int = 1
    substeps_per_scale: int = 1
    max_substeps: int = 6
    enable_dt_subdivision: bool = True
    min_dt: float = 1e-5
    damp_object_velocity_on_resample: bool = False
    object_velocity_damp_factor: float = 0.95


class NoctilithMultiscaleResampleAdapter:
    def __init__(self, sim_cfg: Any, ms_cfg: MultiscaleConfig, rs_cfg: ResampleConfig, SimClass: Type[Any]):
        self.sim_cfg = sim_cfg
        self.ms_cfg = ms_cfg
        self.rs_cfg = rs_cfg
        self.SimClass = SimClass
        self.sim = SimClass(sim_cfg)

        if ms_cfg.min_scale_index > ms_cfg.max_scale_index:
            raise ValueError("min_scale_index > max_scale_index")

        base = max(ms_cfg.min_scale_index, min(ms_cfg.max_scale_index, int(ms_cfg.base_scale_index)))
        self.scale_index = base
        self.prev_scale_index = base
        self.activity_ema: Optional[float] = None
        self.last_activity_raw: float = 0.0
        self.cooldown_left = 0
        self._persist_up_count = 0
        self._persist_down_count = 0
        self.ms_tick = 0
        self.last_transition_reason = "init"
        self.last_scale_changed = False
        self.last_resample_applied = False
        self.last_resample_mode = "none"
        self.last_substeps_used = 1
        self.last_dt_eff = 0.0
        self.last_engine_ticks_advanced = 0
        self.last_resample_upshift: Optional[bool] = None
        self.adaptive_enabled = True
        self.scale_locked = False
        self.last_manual_action = "init"
        self.last_control_mode = "adaptive"
        self.scale_percent: float = float(np.clip(ms_cfg.default_scale_percent, 0.0, 100.0))
        self.scale_percent_locked: bool = False

    def set_adaptive_enabled(self, enabled: bool, *, clear_cooldown: bool = False) -> None:
        self.adaptive_enabled = bool(enabled)
        if clear_cooldown: self.cooldown_left = 0
        self._reset_persistence()
        self.last_manual_action = f"adaptive_enabled:{int(self.adaptive_enabled)}"
        self.last_control_mode = self._control_mode()

    def lock_scale(self, scale_index=None, *, apply_resample=True, clear_cooldown=True, reason="manual_lock"):
        target = self.scale_index if scale_index is None else self._clamp_scale(scale_index)
        self.scale_locked = True
        if clear_cooldown: self.cooldown_left = 0
        self._reset_persistence()
        info = self._manual_set_scale_internal(target_scale=target, apply_resample=apply_resample, reason=reason)
        self.last_manual_action = f"{reason}:locked:S{self.scale_index}"
        self.last_control_mode = self._control_mode()
        return info

    def unlock_scale(self, *, enable_adaptive_if_disabled=False):
        self.scale_locked = False
        if enable_adaptive_if_disabled: self.adaptive_enabled = True
        self._reset_persistence()
        self.last_manual_action = "manual_unlock"
        self.last_control_mode = self._control_mode()

    def set_scale(self, scale_index, *, apply_resample=True, reason="manual_set_scale", clear_cooldown=True):
        target = self._clamp_scale(scale_index)
        if clear_cooldown: self.cooldown_left = 0
        self._reset_persistence()
        info = self._manual_set_scale_internal(target_scale=target, apply_resample=apply_resample, reason=reason)
        self.last_manual_action = f"{reason}:S{self.scale_index}"
        self.last_control_mode = self._control_mode()
        return info

    def nudge_scale(self, delta, *, apply_resample=True, reason="manual_nudge_scale", clear_cooldown=True):
        return self.set_scale(self._clamp_scale(int(self.scale_index)+int(delta)), apply_resample=apply_resample, reason=reason, clear_cooldown=clear_cooldown)

    def set_scale_percent(self, percent, *, lock_percent=False, clear_cooldown=True, reason="manual_set_scale_percent"):
        p = float(np.clip(percent, 0.0, 100.0))
        self.scale_percent = p
        if lock_percent: self.scale_percent_locked = True
        if clear_cooldown: self.cooldown_left = 0
        self._reset_persistence()
        self.last_manual_action = f"{reason}:{self.scale_percent:.2f}%"
        self.last_control_mode = self._control_mode()
        target_scale = self._percent_to_scale_index(self.scale_percent)
        info = self._manual_set_scale_internal(target_scale=target_scale, apply_resample=True, reason=reason)
        info["scale_percent"] = float(self.scale_percent)
        info["scale_float"] = float(self._scale_float_from_percent(self.scale_percent))
        return info

    def unlock_scale_percent(self):
        self.scale_percent_locked = False
        self.last_manual_action = "manual_unlock_scale_percent"
        self.last_control_mode = self._control_mode()

    def get_scale_slider_state(self):
        return {
            "scale_percent": float(self.scale_percent),
            "scale_percent_locked": bool(self.scale_percent_locked),
            "scale_float": float(self._scale_float_from_percent(self.scale_percent)),
            "scale_index_quantized": int(self._percent_to_scale_index(self.scale_percent)),
        }

    def get_control_state(self):
        return {
            "adaptive_enabled": bool(self.adaptive_enabled),
            "scale_locked": bool(self.scale_locked),
            "control_mode": self._control_mode(),
            "scale_index": int(self.scale_index),
            "scale_name": self._scale_name(self.scale_index),
            "cooldown_left": int(self.cooldown_left),
            "last_manual_action": str(self.last_manual_action),
            "scale_percent": float(self.scale_percent),
            "scale_percent_locked": bool(self.scale_percent_locked),
        }

    def step(self): return self._step_internal(want_hash=False)
    def step_verify(self): return self._step_internal(want_hash=True)

    def _step_internal(self, want_hash):
        self.ms_tick += 1
        self._reset_step_flags()
        n_sub = self._compute_substeps_for_scale(self.scale_index)
        self.last_substeps_used = n_sub
        tb = self._get_engine_tick(default=0)
        sim_metrics = self._run_sim_substeps(n_substeps=n_sub, want_hash=want_hash)
        ta = self._get_engine_tick(default=tb)
        self.last_engine_ticks_advanced = max(0, int(ta)-int(tb))
        self._update_dt_eff(sim_metrics)
        raw, smooth, parts = self._compute_activity(sim_metrics)
        self.last_activity_raw = raw
        reason = self._decide_scale_control(smooth)
        self.last_transition_reason = reason
        self.last_control_mode = self._control_mode()
        up_thr_eff = float(self.ms_cfg.upshift_threshold+self.ms_cfg.hysteresis_margin)
        down_thr_eff = float(self.ms_cfg.downshift_threshold-self.ms_cfg.hysteresis_margin)
        out = dict(sim_metrics)
        out.update({
            "schema_version": SCHEMA_VERSION, "module_name": MODULE_NAME, "module_version": MODULE_VERSION,
            "ms_tick": int(self.ms_tick), "ms_scale_index": int(self.scale_index),
            "ms_scale_name": self._scale_name(self.scale_index), "ms_prev_scale_index": int(self.prev_scale_index),
            "ms_scale_changed": bool(self.last_scale_changed), "ms_transition_reason": str(self.last_transition_reason),
            "ms_activity_raw": float(raw), "ms_activity": float(smooth), "ms_target_score": float(smooth),
            "ms_cooldown_left": int(self.cooldown_left), "ms_persist_up": int(self._persist_up_count),
            "ms_persist_down": int(self._persist_down_count), "ms_substeps_used": int(self.last_substeps_used),
            "ms_resample_applied": bool(self.last_resample_applied), "ms_resample_mode": str(self.last_resample_mode),
            "ms_in_cooldown": bool(self.cooldown_left>0), "ms_up_thr_effective": float(up_thr_eff),
            "ms_down_thr_effective": float(down_thr_eff), "ms_dt_eff": float(self.last_dt_eff),
            "ms_engine_ticks_advanced": int(self.last_engine_ticks_advanced),
            "ms_resample_upshift": None if self.last_resample_upshift is None else bool(self.last_resample_upshift),
            "ms_adaptive_enabled": bool(self.adaptive_enabled), "ms_scale_locked": bool(self.scale_locked),
            "ms_control_mode": str(self.last_control_mode), "ms_last_manual_action": str(self.last_manual_action),
            "ms_scale_percent": float(self.scale_percent), "ms_scale_percent_locked": bool(self.scale_percent_locked),
            "ms_scale_float": float(self._scale_float_from_percent(self.scale_percent)),
        })
        if self.ms_cfg.include_ms_debug:
            for k, v in parts.items(): out[f"ms_dbg_{k}"] = v
        return out

    def _run_sim_substeps(self, n_substeps, want_hash):
        n_substeps = max(1, int(n_substeps))
        rs = self.rs_cfg
        has_cfg = hasattr(self.sim, "cfg")
        has_dt = has_cfg and hasattr(self.sim.cfg, "dt")
        orig_dt = None
        actual_substeps = n_substeps
        if rs.enable_dt_subdivision and n_substeps > 1 and has_dt:
            orig_dt = float(self.sim.cfg.dt)
            max_allowed = max(1, int(orig_dt/max(float(rs.min_dt), 1e-18)))
            actual_substeps = max(1, min(n_substeps, max_allowed))
            self.sim.cfg.dt = orig_dt/actual_substeps
        last_metrics: Dict[str, Any] = {}
        try:
            for sub_i in range(actual_substeps):
                is_last = (sub_i == actual_substeps-1)
                if want_hash and is_last and hasattr(self.sim, "step_verify"):
                    ret = self.sim.step_verify()
                    m = self._normalize_step_result(ret, from_verify=True)
                else:
                    try: ret = self.sim.step(compute_hash=False)
                    except TypeError: ret = self.sim.step()
                    m = self._normalize_step_result(ret, from_verify=False)
                last_metrics = m
        finally:
            if orig_dt is not None and has_dt: self.sim.cfg.dt = orig_dt
        last_metrics = dict(last_metrics)
        last_metrics["ms_internal_substeps"] = int(actual_substeps)
        last_metrics["ms_requested_substeps"] = int(n_substeps)
        if orig_dt is not None: last_metrics["ms_internal_dt_restored"] = float(orig_dt)
        return last_metrics

    def _normalize_step_result(self, ret, from_verify):
        if isinstance(ret, dict): return dict(ret)
        if isinstance(ret, tuple) and len(ret)==2:
            a, b = ret
            if isinstance(a, dict): out=dict(a); out["hash" if from_verify else "extra"]=b; return out
            if isinstance(b, dict): out=dict(b); out["hash" if from_verify else "extra"]=a; return out
            return {"tuple_ret": ret}
        return {"step_ret": ret}

    def _compute_activity(self, m):
        c = self.ms_cfg
        phi_rms = float(m.get("phi_rms", m.get("phi_rms_total", 0.0)))
        zone = float(m.get("phantom_zone_fraction", 0.0))
        zone_rel = float(m.get("phantom_zone_fraction_rel_rms", zone))
        crit = float(m.get("regime_s_crit", 1.0 if str(m.get("regime",""))=="crit" else 0.0))
        omega = float(m.get("Omega_D", m.get("omega_D", 0.0)))
        abs_dE_dt = abs(float(m.get("dE_dt", 0.0)))
        w_eff_unstable = 1.0 if bool(m.get("w_eff_unstable", m.get("unstable", False))) else 0.0
        phi_rms_n = self._sat01(phi_rms/max(c.phi_rms_scale, 1e-12))
        zone_n = self._sat01(zone*20.0); zone_rel_n = self._sat01(zone_rel*10.0)
        crit_n = self._clamp01(crit); omega_n = self._clamp01(omega)
        dE_n = self._sat01(abs_dE_dt/max(c.abs_dE_dt_scale, 1e-12))
        raw = self._clamp01(c.w_phi_rms*phi_rms_n+c.w_zone*zone_n+c.w_zone_rel*zone_rel_n+
                            c.w_crit*crit_n+c.w_omega*omega_n+c.w_abs_dE*dE_n-c.w_weff_unstable_penalty*w_eff_unstable)
        if self.activity_ema is None:
            smooth = raw; self.activity_ema = raw
        else:
            a = self._clamp01(c.activity_ema_alpha)
            smooth = self._clamp01(a*self.activity_ema+(1.-a)*raw)
            self.activity_ema = smooth
        parts = {"phi_rms_n":float(phi_rms_n),"zone_n":float(zone_n),"zone_rel_n":float(zone_rel_n),
                 "crit_n":float(crit_n),"omega_n":float(omega_n),"dE_n":float(dE_n),
                 "w_eff_unstable":float(w_eff_unstable),"raw":float(raw),"smooth":float(smooth)}
        return float(raw), float(smooth), parts

    def _compute_substeps_for_scale(self, scale_index):
        rs = self.rs_cfg
        if not rs.enable_substeps: return 1
        base = int(self.ms_cfg.base_scale_index); offset = int(scale_index)-base; n = int(rs.base_substeps)
        if rs.substep_policy == "higher_scale_more_substeps":
            if offset > 0: n += offset*int(rs.substeps_per_scale)
        elif rs.substep_policy == "lower_scale_more_substeps":
            if offset < 0: n += (-offset)*int(rs.substeps_per_scale)
        else:
            if offset > 0: n += offset*int(rs.substeps_per_scale)
        n = max(1, min(int(rs.max_substeps), n))
        if self.ms_cfg.enable_continuous_scale_percent and self.ms_cfg.percent_affects_substeps:
            sf = self._scale_float_from_percent(self.scale_percent); frac = sf-math.floor(sf)
            if rs.substep_policy == "higher_scale_more_substeps": nf = float(n)+frac*float(rs.substeps_per_scale)
            elif rs.substep_policy == "lower_scale_more_substeps": nf = float(n)+(1.-frac)*0.
            else: nf = float(n)+frac*float(rs.substeps_per_scale)
            n = max(1, min(int(rs.max_substeps), int(round(nf))))
        return int(n)

    def _decide_scale_control(self, activity):
        if self.scale_locked:
            self._reset_persistence()
            if self.cooldown_left > 0: self.cooldown_left -= 1
            return "locked_hold"
        if self.scale_percent_locked:
            self._reset_persistence()
            if self.cooldown_left > 0: self.cooldown_left -= 1
            target = self._percent_to_scale_index(self.scale_percent)
            if target != self.scale_index:
                old = self.scale_index; self.scale_index = target; self.last_scale_changed = True
                applied, mode = self._handle_resample_after_scale_change(old_scale=old, new_scale=self.scale_index)
                self.last_resample_applied = bool(applied); self.last_resample_mode = str(mode)
                return f"percent_locked:{old}->{self.scale_index}"
            return "percent_locked_hold"
        if not self.adaptive_enabled:
            self._reset_persistence()
            if self.cooldown_left > 0: self.cooldown_left -= 1
            return "manual_hold"
        if self.cooldown_left > 0:
            self.cooldown_left -= 1; self._persist_up_count = 0; self._persist_down_count = 0
            return "cooldown_hold"
        return self._maybe_switch_scale(activity)

    def _maybe_switch_scale(self, activity):
        c = self.ms_cfg
        up_thr = c.upshift_threshold+c.hysteresis_margin; down_thr = c.downshift_threshold-c.hysteresis_margin
        can_up = self.scale_index < c.max_scale_index; can_down = self.scale_index > c.min_scale_index
        self._persist_up_count = self._persist_up_count+1 if activity>=up_thr and can_up else 0
        self._persist_down_count = self._persist_down_count+1 if activity<=down_thr and can_down else 0
        need = max(1, int(c.min_persistence_for_switch))
        if self._persist_up_count >= need and can_up:
            old = self.scale_index; self.scale_index += 1; self.last_scale_changed = True
            self.cooldown_left = max(0, int(c.switch_cooldown_steps)); self._reset_persistence()
            applied, mode = self._handle_resample_after_scale_change(old_scale=old, new_scale=self.scale_index)
            self.last_resample_applied = bool(applied); self.last_resample_mode = str(mode)
            return f"upshift:{old}->{self.scale_index}"
        if self._persist_down_count >= need and can_down:
            old = self.scale_index; self.scale_index -= 1; self.last_scale_changed = True
            self.cooldown_left = max(0, int(c.switch_cooldown_steps)); self._reset_persistence()
            applied, mode = self._handle_resample_after_scale_change(old_scale=old, new_scale=self.scale_index)
            self.last_resample_applied = bool(applied); self.last_resample_mode = str(mode)
            return f"downshift:{old}->{self.scale_index}"
        if activity > c.upshift_threshold: return "up_candidate_wait"
        if activity < c.downshift_threshold: return "down_candidate_wait"
        return "hold_band"

    def _manual_set_scale_internal(self, target_scale, *, apply_resample, reason):
        target_scale = self._clamp_scale(target_scale); old = int(self.scale_index)
        self.prev_scale_index = old; self.last_scale_changed = False
        self.last_resample_applied = False; self.last_resample_mode = "none"; self.last_resample_upshift = None
        if target_scale == old:
            return {"changed":False,"old_scale":old,"new_scale":target_scale,"resample_applied":False,"resample_mode":"none","reason":f"{reason}:no_change"}
        self.scale_index = int(target_scale); self.last_scale_changed = True
        if apply_resample:
            applied, mode = self._handle_resample_after_scale_change(old_scale=old, new_scale=self.scale_index)
            self.last_resample_applied = bool(applied); self.last_resample_mode = str(mode)
        else:
            applied, mode = False, "manual_no_resample"
            self.last_resample_applied = False; self.last_resample_mode = str(mode)
            self.last_resample_upshift = bool(self.scale_index > old)
        self.last_transition_reason = f"{reason}:{old}->{self.scale_index}"
        return {"changed":True,"old_scale":old,"new_scale":int(self.scale_index),"resample_applied":bool(applied),"resample_mode":str(mode),"reason":str(self.last_transition_reason)}

    def _get_resample_field_names(self):
        names = []
        for name in ("phi_g","phi_em","phi_s","phi_w"):
            if hasattr(self.sim, name):
                arr = getattr(self.sim, name)
                if isinstance(arr, np.ndarray) and arr.ndim==3: names.append(name)
        if hasattr(self.sim, "phi"):
            arr = getattr(self.sim, "phi")
            if isinstance(arr, np.ndarray) and arr.ndim==3: names.append("phi")
        out=[]; seen=set()
        for n in names:
            if n not in seen: out.append(n); seen.add(n)
        return tuple(out)

    def _get_primary_field_shape(self):
        for name in self._get_resample_field_names():
            arr = getattr(self.sim, name, None)
            if isinstance(arr, np.ndarray) and arr.ndim==3: return tuple(int(x) for x in arr.shape)
        return None

    def _handle_resample_after_scale_change(self, old_scale, new_scale):
        upshift = int(new_scale) > int(old_scale); self.last_resample_upshift = bool(upshift)
        if self.rs_cfg.enable_resample_hooks and self.rs_cfg.resample_on_scale_change:
            return self._apply_scale_change_resample(old_scale=old_scale, new_scale=new_scale)
        return False, "resample_disabled"

    def _apply_scale_change_resample(self, old_scale, new_scale):
        field_names = self._get_resample_field_names()
        if not field_names: return False, "no_resample_fields"
        shape = self._get_primary_field_shape()
        if shape is None: return False, "field_shape_invalid"
        upshift = bool(new_scale > old_scale)
        if upshift and not self.rs_cfg.compression_enabled: return False, "compression_disabled"
        if (not upshift) and not self.rs_cfg.decompression_enabled: return False, "decompression_disabled"
        mode = self.rs_cfg.upshift_resample_mode if upshift else self.rs_cfg.downshift_resample_mode
        mode = str(mode or self.rs_cfg.resample_mode).lower()
        if mode == "none": return False, "none"
        if mode == "smooth":
            self._resample_smooth_proxy(upshift=upshift); self._call_post_resample_hook()
            return True, f"smooth_{'compress' if upshift else 'decompress'}"
        if mode == "factor2":
            ok2 = self._resample_factor2_proxy(upshift=upshift); self._call_post_resample_hook()
            if ok2: return True, f"factor2_{'compress' if upshift else 'decompress'}"
            self._resample_smooth_proxy(upshift=upshift); self._call_post_resample_hook()
            return True, f"factor2_fallback_smooth_{'compress' if upshift else 'decompress'}"
        return False, f"unknown_mode:{mode}"

    def _resample_smooth_proxy(self, upshift):
        field_names = self._get_resample_field_names()
        if not field_names: return
        if upshift and self.rs_cfg.upshift_smooth_blend is not None: base_blend = float(self.rs_cfg.upshift_smooth_blend)
        elif (not upshift) and self.rs_cfg.downshift_smooth_blend is not None: base_blend = float(self.rs_cfg.downshift_smooth_blend)
        else: base_blend = float(self.rs_cfg.smooth_blend)
        blend = base_blend*(0.8 if upshift else 1.15)
        if self.ms_cfg.enable_continuous_scale_percent and self.ms_cfg.percent_affects_resample_blend:
            sf = self._scale_float_from_percent(self.scale_percent); frac = sf-math.floor(sf)
            blend *= (0.85+0.30*frac)
        blend = max(0., min(0.95, blend))
        for name in field_names:
            phi = getattr(self.sim, name)
            if phi.shape[0]<3 or phi.shape[1]<3 or phi.shape[2]<3: continue
            phi0 = phi.copy(); sm = phi0.copy()
            sm[1:-1,1:-1,1:-1] = (phi0[1:-1,1:-1,1:-1]+phi0[2:,1:-1,1:-1]+phi0[:-2,1:-1,1:-1]+
                                   phi0[1:-1,2:,1:-1]+phi0[1:-1,:-2,1:-1]+phi0[1:-1,1:-1,2:]+phi0[1:-1,1:-1,:-2])/7.
            phi[:] = (1.-blend)*phi0+blend*sm
        self._post_resample_object_adjust()

    def _resample_factor2_proxy(self, upshift):
        field_names = self._get_resample_field_names()
        if not field_names: return False
        shape = self._get_primary_field_shape()
        if shape is None: return False
        nx, ny, nz = shape
        if (nx%2) or (ny%2) or (nz%2) or nx<4 or ny<4 or nz<4: return False
        if upshift and self.rs_cfg.upshift_smooth_blend is not None: base_blend = float(self.rs_cfg.upshift_smooth_blend)
        elif (not upshift) and self.rs_cfg.downshift_smooth_blend is not None: base_blend = float(self.rs_cfg.downshift_smooth_blend)
        else: base_blend = float(self.rs_cfg.smooth_blend)
        blend = max(0., min(0.95, base_blend*(0.7 if upshift else 1.2)))
        for name in field_names:
            phi = getattr(self.sim, name); phi0 = phi.copy()
            coarse = phi0.reshape(nx//2,2,ny//2,2,nz//2,2).mean(axis=(1,3,5))
            up = np.repeat(np.repeat(np.repeat(coarse,2,axis=0),2,axis=1),2,axis=2)
            phi[:] = (1.-blend)*phi0+blend*up
        self._post_resample_object_adjust()
        return True

    def _call_post_resample_hook(self):
        for hook_name in ("on_resampled","after_resample","invalidate_caches"):
            if hasattr(self.sim, hook_name):
                try: getattr(self.sim, hook_name)(); return
                except TypeError:
                    try: getattr(self.sim, hook_name)(scale_index=self.scale_index); return
                    except: pass
                except: pass

    def _post_resample_object_adjust(self):
        if not self.rs_cfg.damp_object_velocity_on_resample or not hasattr(self.sim, "obj_v"): return
        fac = max(0., min(1., float(self.rs_cfg.object_velocity_damp_factor)))
        try: self.sim.obj_v[:] *= fac
        except: pass

    def _reset_step_flags(self):
        self.last_scale_changed = False; self.last_resample_applied = False
        self.last_resample_mode = "none"; self.last_resample_upshift = None
        self.prev_scale_index = self.scale_index

    def _reset_persistence(self):
        self._persist_up_count = 0; self._persist_down_count = 0

    def _control_mode(self):
        if self.scale_locked: return "locked"
        if self.scale_percent_locked: return "percent_locked"
        if self.adaptive_enabled: return "adaptive"
        return "manual"

    def _clamp_scale(self, idx):
        return max(int(self.ms_cfg.min_scale_index), min(int(self.ms_cfg.max_scale_index), int(idx)))

    def _scale_float_from_percent(self, percent):
        p = float(np.clip(percent,0.,100.))/100.
        lo = float(self.ms_cfg.min_scale_index); hi = float(self.ms_cfg.max_scale_index)
        return lo+(hi-lo)*p

    def _percent_to_scale_index(self, percent):
        return self._clamp_scale(int(round(self._scale_float_from_percent(percent))))

    def _scale_index_to_percent(self, idx):
        lo = float(self.ms_cfg.min_scale_index); hi = float(self.ms_cfg.max_scale_index)
        if hi<=lo: return 0.
        return float(np.clip(100.*(float(idx)-lo)/(hi-lo), 0., 100.))

    def _update_dt_eff(self, sim_metrics):
        if hasattr(self.sim,"cfg") and hasattr(self.sim.cfg,"dt"):
            if self.rs_cfg.enable_dt_subdivision and int(sim_metrics.get("ms_internal_substeps",1))>1:
                restored = float(sim_metrics.get("ms_internal_dt_restored", getattr(self.sim.cfg,"dt",0.)))
                used = max(1, int(sim_metrics.get("ms_internal_substeps", self.last_substeps_used)))
                dt_eff = restored/used
            else:
                dt_eff = float(getattr(self.sim.cfg,"dt",0.))
            if self.ms_cfg.enable_continuous_scale_percent and self.ms_cfg.percent_affects_dt_eff:
                sf = self._scale_float_from_percent(self.scale_percent); frac = sf-math.floor(sf)
                dt_eff *= (1.-0.15*frac)
            self.last_dt_eff = float(dt_eff)
        else:
            self.last_dt_eff = 0.

    def _get_engine_tick(self, default=0):
        for attr in ("tick","engine_tick","step_count","ticks"):
            if hasattr(self.sim, attr):
                try: return int(getattr(self.sim, attr))
                except: pass
        return int(default)

    def _scale_name(self, idx):
        if not self.ms_cfg.use_named_scales: return f"S{idx}"
        rel = idx-int(self.ms_cfg.base_scale_index)
        tag = {True: {-3:"micro+",-2:"micro",-1:"meso-",0:"base",1:"meso+",2:"macro"}}.get(True,{}).get(rel, "macro+" if rel>2 else "micro+")
        return f"S{idx}:{tag}"

    def state_snapshot(self):
        return {
            "schema_version": SCHEMA_VERSION, "module_name": MODULE_NAME, "module_version": MODULE_VERSION,
            "ms_tick": self.ms_tick, "scale_index": self.scale_index, "prev_scale_index": self.prev_scale_index,
            "scale_percent": self.scale_percent, "scale_percent_locked": self.scale_percent_locked,
            "activity_ema": self.activity_ema, "last_activity_raw": self.last_activity_raw,
            "cooldown_left": self.cooldown_left, "persist_up_count": self._persist_up_count,
            "persist_down_count": self._persist_down_count, "last_transition_reason": self.last_transition_reason,
            "last_scale_changed": self.last_scale_changed, "last_resample_applied": self.last_resample_applied,
            "last_resample_mode": self.last_resample_mode, "last_substeps_used": self.last_substeps_used,
            "last_dt_eff": self.last_dt_eff, "last_engine_ticks_advanced": self.last_engine_ticks_advanced,
            "last_resample_upshift": self.last_resample_upshift, "adaptive_enabled": self.adaptive_enabled,
            "scale_locked": self.scale_locked, "last_manual_action": self.last_manual_action,
            "control_mode": self._control_mode(), "ms_cfg": asdict(self.ms_cfg), "rs_cfg": asdict(self.rs_cfg),
        }

    def state_snapshot_json(self):
        return json.dumps(self.state_snapshot(), ensure_ascii=False, sort_keys=True)

    @staticmethod
    def _clamp01(x):
        return 0. if x<0. else (1. if x>1. else x)

    @staticmethod
    def _sat01(x):
        if x<=0.: return 0.
        y = 1.-math.exp(-x)
        return 1. if y>1. else y