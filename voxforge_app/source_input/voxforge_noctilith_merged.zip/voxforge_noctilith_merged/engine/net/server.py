"""
engine/net/server.py
=====================
Multiplayer server pro VoxForge platformu.

Blueprint §11: "Roblox-like část — uživatelé vytvářejí světy,
                 sdílejí assety, publikují hry/simulace"
Blueprint §11.1: "lokální singleplayer, peer-hosted multiplayer,
                   dedicated server, editor collaboration"
Blueprint §11.2: "sandbox skriptů, omezení nebezpečných operací,
                   asset validation, permission system"

Architektura:
    VoxServer
    ├── SessionManager  — správa hráčů a sessions
    ├── WorldSync       — delta synchronizace světa
    ├── MessageBroker   — routing zpráv mezi klienty
    ├── PermissionSystem — oprávnění (owner, editor, viewer)
    └── ChatSystem      — textová komunikace

Implementace:
    - asyncio-ready design (callbacks místo blocking calls)
    - Delta komprese změn světa
    - Authoritative server model (server = truth)
    - Lag compensation (input queue)

Pozn.: Skutečný network transport (TCP/WebSocket) je platformou-specifický.
       Tato implementace definuje server logiku; transport layer se doplní
       dle cílové platformy (pyglet socket, websockets, asyncio streams).
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple


# ─── Permission System ────────────────────────────────────────────────────────

class Permission(str, Enum):
    OWNER      = "owner"       # plná kontrola
    EDITOR     = "editor"      # může editovat svět
    BUILDER    = "builder"     # může stavět
    PLAYER     = "player"      # může hrát
    VIEWER     = "viewer"      # jen sleduje
    BANNED     = "banned"      # zablokovaný


PERMISSION_LEVELS = {
    Permission.OWNER:   100,
    Permission.EDITOR:  80,
    Permission.BUILDER: 60,
    Permission.PLAYER:  40,
    Permission.VIEWER:  10,
    Permission.BANNED:  -1,
}

PERMISSION_ALLOWS: Dict[Permission, Set[str]] = {
    Permission.OWNER:   {"build","destroy","fly","admin","chat","spawn","ban","kick","give_perm"},
    Permission.EDITOR:  {"build","destroy","fly","chat","spawn"},
    Permission.BUILDER: {"build","destroy","chat"},
    Permission.PLAYER:  {"move","interact","chat"},
    Permission.VIEWER:  {"chat"},
    Permission.BANNED:  set(),
}


def has_permission(perm: Permission, action: str) -> bool:
    return action in PERMISSION_ALLOWS.get(perm, set())


# ─── Message protokol ─────────────────────────────────────────────────────────

class MsgType(str, Enum):
    # Server → Client
    WELCOME           = "welcome"
    WORLD_SNAPSHOT    = "world_snapshot"
    WORLD_DELTA       = "world_delta"
    PLAYER_JOINED     = "player_joined"
    PLAYER_LEFT       = "player_left"
    PLAYER_MOVED      = "player_moved"
    VOXEL_CHANGED     = "voxel_changed"
    CHAT_MESSAGE      = "chat_message"
    ENTITY_SPAWNED    = "entity_spawned"
    ENTITY_DESTROYED  = "entity_destroyed"
    SIM_EVENT         = "sim_event"
    ERROR             = "error"
    PING              = "ping"
    PONG              = "pong"
    KICK              = "kick"
    SERVER_INFO       = "server_info"
    # Client → Server
    JOIN              = "join"
    LEAVE             = "leave"
    MOVE              = "move"
    PLACE_VOXEL       = "place_voxel"
    DESTROY_VOXEL     = "destroy_voxel"
    INTERACT          = "interact"
    CHAT              = "chat"
    SPAWN_ENTITY      = "spawn_entity"
    ADMIN_CMD         = "admin_cmd"
    REQUEST_CHUNK     = "request_chunk"


@dataclass
class Message:
    """Síťová zpráva VoxForge protokolu."""
    msg_type: MsgType
    sender_id: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    sequence: int = 0

    def to_json(self) -> str:
        d = asdict(self)
        d["msg_type"] = self.msg_type.value
        return json.dumps(d)

    @classmethod
    def from_json(cls, data: str) -> "Message":
        d = json.loads(data)
        d["msg_type"] = MsgType(d["msg_type"])
        return cls(**d)

    @classmethod
    def error(cls, sender: str, code: str, detail: str = "") -> "Message":
        return cls(MsgType.ERROR, sender,
                   {"code": code, "detail": detail})

    @classmethod
    def chat(cls, sender: str, text: str, channel: str = "global") -> "Message":
        return cls(MsgType.CHAT_MESSAGE, sender,
                   {"text": text, "channel": channel,
                    "sender_name": sender[:20]})


# ─── Session ──────────────────────────────────────────────────────────────────

@dataclass
class PlayerSession:
    """Jedna aktivní hráčská session."""
    session_id: str
    player_id: str
    display_name: str
    permission: Permission = Permission.PLAYER
    position: Tuple[float,float,float] = (0.0, 0.0, 0.0)
    rotation: float = 0.0
    health: float = 1.0
    connected_at: float = field(default_factory=time.time)
    last_ping: float = field(default_factory=time.time)
    ping_ms: float = 0.0
    # Input queue (lag compensation)
    pending_inputs: List[Dict] = field(default_factory=list)
    # Chunks které klient má
    loaded_chunks: Set[Tuple[int,int,int]] = field(default_factory=set)

    @property
    def is_alive(self) -> bool:
        return time.time() - self.last_ping < 30.0   # 30s timeout

    def can(self, action: str) -> bool:
        return has_permission(self.permission, action)


# ─── World Delta ──────────────────────────────────────────────────────────────

@dataclass
class VoxelChange:
    """Jedna změna voxelu v světě."""
    wx: int; wy: int; wz: int
    old_material: int
    new_material: int
    changed_by: str
    tick: int
    timestamp: float = field(default_factory=time.time)


class WorldDelta:
    """
    Sbírá změny světa a generuje delta zprávy pro klienty.
    Delta komprese: posílá jen změněné voxely, ne celý svět.
    """

    def __init__(self):
        self._changes: List[VoxelChange] = []
        self._last_sent: Dict[str, float] = {}    # session_id → timestamp

    def record(self, change: VoxelChange) -> None:
        self._changes.append(change)
        # Limit paměti
        if len(self._changes) > 50_000:
            self._changes = self._changes[-25_000:]

    def get_delta_since(self, since_time: float) -> List[VoxelChange]:
        """Vrátí změny od daného timestampu."""
        return [c for c in self._changes if c.timestamp > since_time]

    def to_message(self, since_time: float, sender_id: str = "server") -> Message:
        changes = self.get_delta_since(since_time)
        payload = {
            "changes": [
                {"wx": c.wx, "wy": c.wy, "wz": c.wz,
                 "material": c.new_material, "tick": c.tick}
                for c in changes[:500]    # max 500 změn per zpráva
            ],
            "count": len(changes),
        }
        return Message(MsgType.WORLD_DELTA, sender_id, payload)


# ─── Chat System ──────────────────────────────────────────────────────────────

@dataclass
class ChatMessage:
    sender_id: str
    sender_name: str
    text: str
    channel: str = "global"
    timestamp: float = field(default_factory=time.time)
    color: Tuple[int,int,int] = (255, 255, 255)


class ChatSystem:
    """Chat s kanály a moderací."""
    MAX_HISTORY = 200
    MAX_MSG_LEN = 256

    CHANNELS = {"global", "local", "team", "admin", "system"}

    def __init__(self):
        self._history: List[ChatMessage] = []
        self._muted: Set[str] = set()
        self._filters: List[str] = []   # zakázaná slova

    def post(self, session: PlayerSession, text: str,
             channel: str = "global") -> Optional[ChatMessage]:
        """Přijmi zprávu. Vrátí ChatMessage nebo None pokud je blokovaná."""
        if session.player_id in self._muted:
            return None
        if not session.can("chat"):
            return None
        if len(text) > self.MAX_MSG_LEN:
            text = text[:self.MAX_MSG_LEN] + "..."
        # Filter
        for bad_word in self._filters:
            text = text.replace(bad_word, "*" * len(bad_word))
        # Channel validation
        if channel not in self.CHANNELS:
            channel = "global"

        perm_colors = {
            Permission.OWNER:   (255, 215, 0),
            Permission.EDITOR:  (100, 200, 255),
            Permission.BUILDER: (150, 255, 150),
            Permission.PLAYER:  (255, 255, 255),
            Permission.VIEWER:  (180, 180, 180),
        }
        msg = ChatMessage(
            sender_id=session.player_id,
            sender_name=session.display_name,
            text=text,
            channel=channel,
            color=perm_colors.get(session.permission, (255,255,255)),
        )
        self._history.append(msg)
        self._history = self._history[-self.MAX_HISTORY:]
        return msg

    def post_system(self, text: str, channel: str = "global") -> ChatMessage:
        msg = ChatMessage("system", "[SERVER]", text, channel,
                          color=(255, 200, 50))
        self._history.append(msg)
        return msg

    def mute(self, player_id: str) -> None:
        self._muted.add(player_id)

    def unmute(self, player_id: str) -> None:
        self._muted.discard(player_id)

    def get_history(self, channel: str = "global", count: int = 50) -> List[ChatMessage]:
        return [m for m in self._history[-count*2:] if m.channel == channel][-count:]


# ─── Session Manager ──────────────────────────────────────────────────────────

class SessionManager:
    """Správa všech aktivních sessí."""

    def __init__(self, max_players: int = 20):
        self.max_players = max_players
        self._sessions: Dict[str, PlayerSession] = {}    # session_id → session
        self._player_sessions: Dict[str, str] = {}       # player_id → session_id
        self._permissions: Dict[str, Permission] = {}    # player_id → perm (persistent)

    def join(self, player_id: str, display_name: str) -> Tuple[Optional[PlayerSession], str]:
        """
        Přijmi hráče. Vrátí (session, error_msg).
        error_msg = "" pokud úspěšné.
        """
        if player_id in self._player_sessions:
            # Reconnect — aktualizuj existující session
            sid = self._player_sessions[player_id]
            session = self._sessions[sid]
            session.last_ping = time.time()
            return session, ""

        if len(self._sessions) >= self.max_players:
            return None, "Server je plný."

        sid = str(uuid.uuid4())[:8]
        perm = self._permissions.get(player_id, Permission.PLAYER)
        session = PlayerSession(
            session_id=sid,
            player_id=player_id,
            display_name=display_name[:32],
            permission=perm,
        )
        self._sessions[sid] = session
        self._player_sessions[player_id] = sid
        return session, ""

    def leave(self, session_id: str) -> Optional[PlayerSession]:
        """Odhlás hráče. Vrátí session nebo None."""
        session = self._sessions.pop(session_id, None)
        if session:
            self._player_sessions.pop(session.player_id, None)
        return session

    def get_by_session(self, session_id: str) -> Optional[PlayerSession]:
        return self._sessions.get(session_id)

    def get_by_player(self, player_id: str) -> Optional[PlayerSession]:
        sid = self._player_sessions.get(player_id)
        return self._sessions.get(sid) if sid else None

    def set_permission(self, player_id: str, perm: Permission,
                       by: PlayerSession) -> bool:
        """Nastav oprávnění hráči (vyžaduje OWNER)."""
        if not by.can("give_perm"):
            return False
        if PERMISSION_LEVELS[perm] >= PERMISSION_LEVELS[by.permission]:
            return False   # nelze udělat stejné nebo vyšší oprávnění
        self._permissions[player_id] = perm
        session = self.get_by_player(player_id)
        if session:
            session.permission = perm
        return True

    def kick(self, player_id: str, by: PlayerSession, reason: str = "") -> bool:
        if not by.can("kick"):
            return False
        session = self.get_by_player(player_id)
        if session:
            self.leave(session.session_id)
        return True

    def ban(self, player_id: str, by: PlayerSession, reason: str = "") -> bool:
        if not by.can("ban"):
            return False
        self._permissions[player_id] = Permission.BANNED
        return self.kick(player_id, by, reason)

    def update_position(self, session_id: str,
                        x: float, y: float, z: float, rot: float = 0.0) -> None:
        s = self._sessions.get(session_id)
        if s:
            s.position = (x, y, z)
            s.rotation = rot

    def ping(self, session_id: str, round_trip_ms: float = 0.0) -> None:
        s = self._sessions.get(session_id)
        if s:
            s.last_ping = time.time()
            s.ping_ms = round_trip_ms

    def cleanup_stale(self) -> List[PlayerSession]:
        """Odstraní timed-out sessí. Vrátí seznam odstraněných."""
        stale = [s for s in self._sessions.values() if not s.is_alive]
        for s in stale:
            self.leave(s.session_id)
        return stale

    def all_sessions(self) -> List[PlayerSession]:
        return list(self._sessions.values())

    @property
    def player_count(self) -> int:
        return len(self._sessions)


# ─── Message Broker ───────────────────────────────────────────────────────────

class MessageBroker:
    """
    Routing zpráv mezi klienty a serverem.
    Callbacks místo skutečného network (transport-agnostic).
    """

    def __init__(self):
        self._send_fns: Dict[str, Callable[[Message], None]] = {}
        self._broadcast_log: List[Message] = []
        self._total_sent = 0

    def register_client(self, session_id: str,
                        send_fn: Callable[[Message], None]) -> None:
        """Zaregistruj funkci pro odesílání zpráv konkrétnímu klientovi."""
        self._send_fns[session_id] = send_fn

    def unregister_client(self, session_id: str) -> None:
        self._send_fns.pop(session_id, None)

    def send(self, session_id: str, msg: Message) -> bool:
        """Pošli zprávu jednomu klientovi."""
        fn = self._send_fns.get(session_id)
        if fn:
            fn(msg)
            self._total_sent += 1
            return True
        return False

    def broadcast(self, msg: Message,
                  exclude: Optional[Set[str]] = None,
                  only: Optional[Set[str]] = None) -> int:
        """Pošli zprávu všem klientům (nebo podmnožině). Vrátí počet odeslaných."""
        sent = 0
        targets = set(self._send_fns.keys())
        if only:
            targets = targets & only
        if exclude:
            targets = targets - exclude
        for sid in targets:
            if self.send(sid, msg):
                sent += 1
        self._broadcast_log.append(msg)
        self._broadcast_log = self._broadcast_log[-100:]
        return sent

    @property
    def connected_count(self) -> int:
        return len(self._send_fns)


# ─── Admin Commands ───────────────────────────────────────────────────────────

class AdminSystem:
    """
    Admin příkazy pro serverovou správu.
    Blueprint §11.2: "permission system, moderace"
    """

    def __init__(self, sessions: SessionManager, chat: ChatSystem,
                 broker: MessageBroker):
        self.sessions = sessions
        self.chat = chat
        self.broker = broker

    def process_command(self, cmd: str, issuer: PlayerSession) -> str:
        """
        Zpracuj admin příkaz. Vrátí odpověď.
        Formát: /cmd [args...]
        """
        if not cmd.startswith('/'):
            return "Příkaz musí začínat /"
        parts = cmd[1:].split()
        if not parts:
            return "Prázdný příkaz"
        command = parts[0].lower()
        args = parts[1:]

        handlers = {
            "kick":    self._cmd_kick,
            "ban":     self._cmd_ban,
            "op":      self._cmd_op,
            "deop":    self._cmd_deop,
            "mute":    self._cmd_mute,
            "unmute":  self._cmd_unmute,
            "players": self._cmd_players,
            "help":    self._cmd_help,
            "say":     self._cmd_say,
            "tp":      self._cmd_tp,
            "heal":    self._cmd_heal,
        }
        handler = handlers.get(command)
        if handler:
            return handler(args, issuer)
        return f"Neznámý příkaz: /{command}. Nápověda: /help"

    def _cmd_kick(self, args: List[str], issuer: PlayerSession) -> str:
        if not args:
            return "Použití: /kick <player_id> [reason]"
        reason = " ".join(args[1:]) or "No reason"
        if self.sessions.kick(args[0], issuer, reason):
            self.chat.post_system(f"[KICK] {args[0]} was kicked: {reason}")
            return f"Hráč {args[0]} byl kicknut."
        return "Nepodařilo se kicknout hráče (chybí oprávnění nebo hráč nenalezen)."

    def _cmd_ban(self, args: List[str], issuer: PlayerSession) -> str:
        if not args:
            return "Použití: /ban <player_id> [reason]"
        reason = " ".join(args[1:]) or "No reason"
        if self.sessions.ban(args[0], issuer, reason):
            self.chat.post_system(f"[BAN] {args[0]} was banned: {reason}")
            return f"Hráč {args[0]} byl bannován."
        return "Nepodařilo se bannovat hráče."

    def _cmd_op(self, args: List[str], issuer: PlayerSession) -> str:
        if not args:
            return "Použití: /op <player_id>"
        if PERMISSION_LEVELS[issuer.permission] < PERMISSION_LEVELS[Permission.OWNER]:
            return "Pouze owner může udělovat editor oprávnění."
        if self.sessions.set_permission(args[0], Permission.EDITOR, issuer):
            return f"Hráč {args[0]} má nyní editor oprávnění."
        return "Nepodařilo se nastavit oprávnění."

    def _cmd_deop(self, args: List[str], issuer: PlayerSession) -> str:
        if not args:
            return "Použití: /deop <player_id>"
        if self.sessions.set_permission(args[0], Permission.PLAYER, issuer):
            return f"Hráč {args[0]} má nyní player oprávnění."
        return "Nepodařilo se nastavit oprávnění."

    def _cmd_mute(self, args: List[str], issuer: PlayerSession) -> str:
        if not args or not issuer.can("admin"):
            return "Chybí oprávnění nebo argument: /mute <player_id>"
        self.chat.mute(args[0])
        return f"Hráč {args[0]} byl zmutován."

    def _cmd_unmute(self, args: List[str], issuer: PlayerSession) -> str:
        if not args or not issuer.can("admin"):
            return "Chybí oprávnění nebo argument: /unmute <player_id>"
        self.chat.unmute(args[0])
        return f"Hráč {args[0]} byl odzmutován."

    def _cmd_players(self, args: List[str], issuer: PlayerSession) -> str:
        sessions = self.sessions.all_sessions()
        if not sessions:
            return "Žádní hráči online."
        lines = [f"Online ({len(sessions)}):"]
        for s in sessions:
            lines.append(f"  {s.display_name} [{s.permission.value}] "
                         f"@ {s.position[0]:.1f},{s.position[1]:.1f},{s.position[2]:.1f} "
                         f"ping={s.ping_ms:.0f}ms")
        return "\n".join(lines)

    def _cmd_help(self, args: List[str], issuer: PlayerSession) -> str:
        return ("/kick, /ban, /op, /deop, /mute, /unmute, "
                "/players, /say, /tp, /heal")

    def _cmd_say(self, args: List[str], issuer: PlayerSession) -> str:
        if not args or not issuer.can("admin"):
            return "Chybí oprávnění nebo zpráva."
        text = " ".join(args)
        msg = self.chat.post_system(f"[ADMIN] {text}")
        self.broker.broadcast(Message(MsgType.CHAT_MESSAGE, "system",
                                      {"text": msg.text, "channel": "global",
                                       "sender_name": "[SERVER]"}))
        return f"Zpráva odeslaná: {text}"

    def _cmd_tp(self, args: List[str], issuer: PlayerSession) -> str:
        if len(args) < 3:
            return "Použití: /tp <x> <y> <z>"
        try:
            x, y, z = float(args[0]), float(args[1]), float(args[2])
            issuer.position = (x, y, z)
            return f"Teleportován na ({x},{y},{z})"
        except ValueError:
            return "Neplatné souřadnice."

    def _cmd_heal(self, args: List[str], issuer: PlayerSession) -> str:
        issuer.health = 1.0
        return "Zdraví obnoveno."


# ─── VoxServer ────────────────────────────────────────────────────────────────

class VoxServer:
    """
    Hlavní server VoxForge multiplayer.

    Blueprint §11: "dedicated server, editor collaboration, publishable worlds"

    Použití (headless/embedded):
        server = VoxServer("MyWorld", max_players=10)
        server.set_owner("player_peiti")

        # Simulate join
        session, err = server.handle_join("player_peiti", "Peiti")

        # Simulate voxel change
        server.handle_place_voxel(session, wx=5, wy=1, wz=5, material_id=1)

        # Simulate tick
        for tick in range(100):
            events = server.tick(tick)
    """

    VERSION = "0.1.0"

    def __init__(self, world_name: str = "VoxWorld",
                 max_players: int = 20,
                 tick_rate: int = 20):
        self.world_name = world_name
        self.tick_rate = tick_rate
        self.started_at = time.time()
        self._tick = 0
        self._owner_id: Optional[str] = None

        # Subsystémy
        self.sessions = SessionManager(max_players)
        self.broker   = MessageBroker()
        self.chat     = ChatSystem()
        self.delta    = WorldDelta()
        self.admin    = AdminSystem(self.sessions, self.chat, self.broker)

        # World reference (nastavit externě)
        self.world = None
        self.sim_scheduler = None

        # Callbacks
        self._on_join:  List[Callable[[PlayerSession], None]] = []
        self._on_leave: List[Callable[[PlayerSession], None]] = []
        self._on_voxel_change: List[Callable[[VoxelChange], None]] = []

    def set_owner(self, player_id: str) -> None:
        """Nastav vlastníka serveru."""
        self._owner_id = player_id
        self.sessions._permissions[player_id] = Permission.OWNER

    # ── Hlavní handlers ───────────────────────────────────────────────────────

    def handle_join(self, player_id: str,
                    display_name: str) -> Tuple[Optional[PlayerSession], str]:
        """Zpracuj žádost o připojení."""
        if self.sessions._permissions.get(player_id) == Permission.BANNED:
            return None, "Jsi bannovaný z tohoto serveru."

        session, err = self.sessions.join(player_id, display_name)
        if err:
            return None, err

        # Nastav vlastníka
        if player_id == self._owner_id:
            session.permission = Permission.OWNER

        # Registruj klienta v brokeru (dummy send_fn pro embedded mode)
        self.broker.register_client(session.session_id, lambda msg: None)

        # Uvítací zpráva
        welcome = Message(MsgType.WELCOME, "server", {
            "session_id":   session.session_id,
            "world_name":   self.world_name,
            "server_version": self.VERSION,
            "player_count": self.sessions.player_count,
            "max_players":  self.sessions.max_players,
            "permission":   session.permission.value,
            "tick_rate":    self.tick_rate,
        })
        self.broker.send(session.session_id, welcome)

        # Oznámení ostatním
        joined_msg = Message(MsgType.PLAYER_JOINED, "server", {
            "player_id":   player_id,
            "display_name": display_name,
            "permission":  session.permission.value,
        })
        self.broker.broadcast(joined_msg, exclude={session.session_id})

        # System chat
        sys_msg = self.chat.post_system(f"➤ {display_name} se připojil/a.")
        self.broker.broadcast(Message(MsgType.CHAT_MESSAGE, "system", {
            "text": sys_msg.text, "channel": "global",
            "sender_name": "[SERVER]"
        }))

        for cb in self._on_join:
            cb(session)

        return session, ""

    def handle_leave(self, session_id: str, reason: str = "disconnect") -> None:
        session = self.sessions.leave(session_id)
        if session:
            self.broker.unregister_client(session_id)
            left_msg = Message(MsgType.PLAYER_LEFT, "server", {
                "player_id": session.player_id,
                "display_name": session.display_name,
                "reason": reason,
            })
            self.broker.broadcast(left_msg)
            sys_msg = self.chat.post_system(f"✕ {session.display_name} se odpojil/a.")
            self.broker.broadcast(Message(MsgType.CHAT_MESSAGE, "system", {
                "text": sys_msg.text, "channel": "global",
                "sender_name": "[SERVER]"
            }))
            for cb in self._on_leave:
                cb(session)

    def handle_move(self, session_id: str,
                    x: float, y: float, z: float, rot: float = 0.0) -> None:
        """Zpracuj pohyb hráče."""
        session = self.sessions.get_by_session(session_id)
        if not session or not session.can("move"):
            return
        self.sessions.update_position(session_id, x, y, z, rot)
        # Broadcast pohybu ostatním
        move_msg = Message(MsgType.PLAYER_MOVED, session.player_id, {
            "player_id": session.player_id,
            "x": x, "y": y, "z": z, "rot": rot,
        })
        self.broker.broadcast(move_msg, exclude={session_id})

    def handle_place_voxel(self, session: PlayerSession,
                           wx: int, wy: int, wz: int, material_id: int) -> bool:
        """Zpracuj umístění voxelu. Vrátí True pokud úspěšné."""
        if not session.can("build"):
            self.broker.send(session.session_id,
                             Message.error("server", "NO_PERMISSION", "Nemáš oprávnění stavět."))
            return False

        old_mat = 0
        if self.world:
            old_mat = self.world.get_material(wx, wy, wz)
            self.world.set_voxel(wx, wy, wz, material_id)

        change = VoxelChange(wx, wy, wz, old_mat, material_id,
                             session.player_id, self._tick)
        self.delta.record(change)
        for cb in self._on_voxel_change:
            cb(change)

        voxel_msg = Message(MsgType.VOXEL_CHANGED, session.player_id, {
            "wx": wx, "wy": wy, "wz": wz,
            "material_id": material_id,
            "placed_by": session.player_id,
        })
        self.broker.broadcast(voxel_msg)
        return True

    def handle_destroy_voxel(self, session: PlayerSession,
                             wx: int, wy: int, wz: int) -> bool:
        if not session.can("destroy"):
            return False
        old_mat = 0
        if self.world:
            old_mat = self.world.destroy_voxel(wx, wy, wz)
        change = VoxelChange(wx, wy, wz, old_mat, 0,
                             session.player_id, self._tick)
        self.delta.record(change)
        for cb in self._on_voxel_change:
            cb(change)
        self.broker.broadcast(Message(MsgType.VOXEL_CHANGED, session.player_id, {
            "wx": wx, "wy": wy, "wz": wz, "material_id": 0,
        }))
        return True

    def handle_chat(self, session_id: str, text: str, channel: str = "global") -> None:
        session = self.sessions.get_by_session(session_id)
        if not session:
            return
        if text.startswith('/'):
            response = self.admin.process_command(text, session)
            self.broker.send(session_id, Message(MsgType.CHAT_MESSAGE, "server", {
                "text": response, "channel": "system", "sender_name": "[SERVER]"
            }))
            return
        msg = self.chat.post(session, text, channel)
        if msg:
            self.broker.broadcast(Message(MsgType.CHAT_MESSAGE, session.player_id, {
                "text": msg.text,
                "channel": msg.channel,
                "sender_name": msg.sender_name,
                "color": list(msg.color),
            }))

    def handle_ping(self, session_id: str, client_time: float) -> None:
        rtt = (time.time() - client_time) * 1000
        self.sessions.ping(session_id, rtt)
        self.broker.send(session_id, Message(MsgType.PONG, "server",
                                             {"server_time": time.time(),
                                              "rtt_ms": rtt}))

    # ── Server tick ───────────────────────────────────────────────────────────

    def tick(self, tick: int) -> List[dict]:
        """
        Jeden server tick.
        Vrátí seznam interních eventů (pro integraci se Schedulerem).
        """
        self._tick = tick
        events: List[dict] = []

        # Cleanup stale sessions každých 100 ticků
        if tick % 100 == 0:
            stale = self.sessions.cleanup_stale()
            for s in stale:
                self.handle_leave(s.session_id, "timeout")
                events.append({"type": "player_timeout", "player": s.player_id})

        # Server info broadcast každých 300 ticků
        if tick % 300 == 0:
            self.broker.broadcast(Message(MsgType.SERVER_INFO, "server", {
                "tick": tick,
                "players": self.sessions.player_count,
                "uptime_s": round(time.time() - self.started_at, 1),
            }))

        return events

    # ── Callbacks ─────────────────────────────────────────────────────────────

    def on_join(self, fn: Callable[[PlayerSession], None]) -> None:
        self._on_join.append(fn)

    def on_leave(self, fn: Callable[[PlayerSession], None]) -> None:
        self._on_leave.append(fn)

    def on_voxel_change(self, fn: Callable[[VoxelChange], None]) -> None:
        self._on_voxel_change.append(fn)

    # ── Status ────────────────────────────────────────────────────────────────

    @property
    def stats(self) -> dict:
        return {
            "world_name":   self.world_name,
            "version":      self.VERSION,
            "players":      self.sessions.player_count,
            "max_players":  self.sessions.max_players,
            "tick":         self._tick,
            "uptime_s":     round(time.time() - self.started_at, 1),
            "msg_sent":     self.broker._total_sent,
            "delta_changes": len(self.delta._changes),
        }

    def __repr__(self) -> str:
        s = self.stats
        return (f"VoxServer('{s['world_name']}', "
                f"players={s['players']}/{s['max_players']}, "
                f"tick={s['tick']})")
