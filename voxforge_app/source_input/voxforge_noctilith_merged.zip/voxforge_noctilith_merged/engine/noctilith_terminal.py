#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
noctilith/terminal.py
=====================
NOCTILITH CONTROL TERMINAL (full unified package revision + patch 4 SimLoop)
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np

from engine.builder.builder_core import (
    SCHEMA_VERSION,
    BuilderConfig,
    EnvironmentProfile,
    GenomeProfile,
    BiomechProfile,
    MaterialProfile,
    NoctilithUniversalBuilder,
)
from engine.space3d import Space3DConfig, NoctilithSpace3DNumba
from engine.multiscale import (
    MultiscaleConfig,
    ResampleConfig,
    NoctilithMultiscaleResampleAdapter,
)
from engine.vision import (
    VisionConfigV240,
    NoctilithVisionModuleV240,
)
from engine.io_utils import (
    compute_state_hash,
    save_snapshot_json,
    save_snapshot_npz,
)
from engine.core.events import EventBus
from engine.sim import (
    ThermalCoupler,
    ThermalCouplerConfig,
    EntropyCoupler,
    EntropyCouplerConfig,
)

MODULE_NAME    = "engine.noctilith_terminal"
MODULE_VERSION = "1.1.0"   # bumped for patch 4


# ==============================================================================
# SimLoop helpers (module-level, not nested — keeps pickling / import simple)
# ==============================================================================

@dataclass
class SimLoopConfig:
    enabled: bool = False
    dt: float = 0.05
    emit_tick_events: bool = True
    emit_thermal_hotspot_events: bool = True
    thermal_hotspot_threshold: float = 0.05
    keep_last_n_events: int = 256


@dataclass
class SimLoopState:
    enabled: bool = False
    step_index: int = 0
    last_regime: str = "unknown"
    last_thermal: Dict[str, Any] = field(default_factory=dict)
    last_entropy: Dict[str, Any] = field(default_factory=dict)
    last_step_wall_time_s: float = 0.0


class _TerminalThermalGrid:
    """Minimal thermal grid used when no external grid is provided."""
    def __init__(self, shape):
        self.T = np.full(shape, 293.15, dtype=np.float64)

    @property
    def shape(self):
        return self.T.shape

    def add_heat(self, ix: int, iy: int, iz: int, delta: float) -> None:
        self.T[ix, iy, iz] += float(delta)

    def step(self, conductivity: float = 1.0) -> None:
        pass  # diffusion not needed for default grid


class _TerminalEntropyField:
    """Minimal entropy field used when no external field is provided."""
    def __init__(self, shape):
        self.S = np.zeros(shape, dtype=np.float64)

    @property
    def shape(self):
        return self.S.shape

    def add_entropy(self, ix: int, iy: int, iz: int, delta: float) -> None:
        self.S[ix, iy, iz] = float(np.clip(self.S[ix, iy, iz] + delta, 0.0, 1.0))


# ==============================================================================
# NoctilithControlTerminal
# ==============================================================================

class NoctilithControlTerminal:
    def __init__(
        self,
        builder_cfg: Optional[BuilderConfig] = None,
        engine_cfg: Optional[Space3DConfig] = None,
        ms_cfg: Optional[MultiscaleConfig] = None,
        rs_cfg: Optional[ResampleConfig] = None,
        vision_cfg: Optional[VisionConfigV240] = None,
        *,
        use_multiscale: bool = False,
    ):
        self.builder_cfg = builder_cfg or BuilderConfig()
        self.engine_cfg  = engine_cfg  or Space3DConfig()
        self.ms_cfg      = ms_cfg      or MultiscaleConfig()
        self.rs_cfg      = rs_cfg      or ResampleConfig()
        self.vision_cfg  = vision_cfg  or VisionConfigV240()
        self.use_multiscale = bool(use_multiscale)

        self.builder: Optional[NoctilithUniversalBuilder] = None
        self.engine:  Optional[NoctilithSpace3DNumba] = None
        self.ms:      Optional[NoctilithMultiscaleResampleAdapter] = None
        self.vision:  Optional[NoctilithVisionModuleV240] = None

        # ── SimLoop (patch 4) ─────────────────────────────────────────────────
        self.event_bus          = EventBus()
        self.sim_loop_config    = SimLoopConfig()
        self.sim_loop_state     = SimLoopState()
        self.thermal_coupler:   Optional[ThermalCoupler]   = None
        self.entropy_coupler:   Optional[EntropyCoupler]   = None
        self.thermal_grid:      Optional[Any]              = None
        self.entropy_field:     Optional[Any]              = None
        self._sim_event_history: List[Any]                 = []

    # ── original methods (unchanged) ─────────────────────────────────────────

    def new_builder(self, bounds=None) -> NoctilithUniversalBuilder:
        if bounds is None:
            bounds = (
                float(self.engine_cfg.nx * self.engine_cfg.dx),
                float(self.engine_cfg.ny * self.engine_cfg.dx),
                float(self.engine_cfg.nz * self.engine_cfg.dx),
            )
        self.builder = NoctilithUniversalBuilder(bounds=bounds, cfg=self.builder_cfg)
        return self.builder

    def build_preset(self, preset: str) -> NoctilithUniversalBuilder:
        b = self.new_builder()
        p = str(preset).lower().strip()

        if p == "galaxy":
            b.build_scene_galaxy(radius=min(b.bounds)*0.42, num_stars=180, arms=3)
        elif p == "dna":
            b.build_scene_dna(length=90, radius=0.75, pitch=0.33)
        elif p == "water":
            b.build_scene_water_cluster(n_molecules=40, spread=4.5)
        elif p == "molecules":
            b.build_scene_molecule_field(formula="C6H12O6", count=22, spread=5.0)
        elif p == "ecosystem":
            b.build_scene_ecosystem(biome_name="temperate", radius=8.0, population=14)
        elif p == "city":
            b.build_scene_city(name="Noctis", radius=10.0, population=300_000)
        elif p == "solar":
            b.build_scene_solar_system(n_planets=6, system_radius=min(b.bounds)*0.32, name="Helion")
        elif p == "materials":
            b.add_material(
                b.center,
                MaterialProfile(
                    name="stainless_steel", category="alloy",
                    density=7.9, hardness=0.82, toughness=0.77, ductility=0.55,
                    elasticity=0.62, thermal_conductivity=0.42,
                    oxidation_resistance=0.88, corrosion_resistance=0.90,
                    fatigue_resistance=0.76, wear_resistance=0.72, creep_resistance=0.69,
                ),
                size=3.0, tags=["test_material"],
            )
        elif p == "bioengineered":
            env = EnvironmentProfile(temperature_k=310.0, humidity=0.72, radiation=0.03, ph=7.35)
            genome = GenomeProfile(
                genome_id="nocti_bio_01", gene_count=18000, engineered=True,
                resilience_bias=0.82, growth_bias=0.61, locomotion_bias=0.66,
                edits=[
                    {"type": "promoter_gain", "target": "stress_response"},
                    {"type": "knockin",        "target": "repair_pathway"},
                ],
            )
            biomech = BiomechProfile(
                morphology="hexapedal", body_mass=12.0,
                muscle_factor=0.72, tendon_factor=0.68, bone_factor=0.59,
                thermal_regulation=0.81, damage_tolerance=0.77, healing_rate=0.73,
            )
            b.add_multicellular_organism(
                b.center, "nocti_bioform", body_scale=2.0,
                genome=genome, biomech=biomech, environment=env,
                phenotype={"skin": "dark_structural", "eyes": "bioluminescent"},
                selection_traits={"endurance": 0.8, "repair": 0.75, "camouflage": 0.62},
                engineering_notes=[{"lab": "Umbra", "batch": "A3"}],
            )
        else:
            raise ValueError(f"Unknown preset: {preset}")
        return b

    def build_engine(self) -> NoctilithSpace3DNumba:
        self.engine = NoctilithSpace3DNumba(self.engine_cfg)
        return self.engine

    def build_multiscale(self) -> NoctilithMultiscaleResampleAdapter:
        self.ms = NoctilithMultiscaleResampleAdapter(
            sim_cfg=self.engine_cfg,
            ms_cfg=self.ms_cfg,
            rs_cfg=self.rs_cfg,
            SimClass=NoctilithSpace3DNumba,
        )
        return self.ms

    def attach_builder(self) -> Dict[str, Any]:
        if self.builder is None:
            raise RuntimeError("Builder not initialized.")
        if self.use_multiscale:
            if self.ms is None:
                self.build_multiscale()
            return self.builder.inject_into_sim(self.ms.sim)
        else:
            if self.engine is None:
                self.build_engine()
            return self.builder.inject_into_sim(self.engine)

    def set_scale_percent(self, percent: float, *, lock_percent: bool = False) -> Dict[str, Any]:
        if not self.use_multiscale:
            raise RuntimeError("Scale percent slider is available only when use_multiscale=True.")
        if self.ms is None:
            self.build_multiscale()
        return self.ms.set_scale_percent(percent, lock_percent=lock_percent)

    def build_vision(self) -> NoctilithVisionModuleV240:
        self.vision = NoctilithVisionModuleV240(self.vision_cfg)
        return self.vision

    def step(self, verify: bool = False) -> Dict[str, Any]:
        if self.use_multiscale:
            if self.ms is None:
                self.build_multiscale()
            result = self.ms.step_verify() if verify else self.ms.step()
        else:
            if self.engine is None:
                self.build_engine()
            result = self.engine.step_verify() if verify else self.engine.step()

        # ── SimLoop hook (patch 4) ────────────────────────────────────────────
        if self.sim_loop_config.enabled:
            sim_loop_result = self._sim_loop_step(space3d_telemetry=result)
            result["sim_loop"] = sim_loop_result

        return result

    def run(self, steps: int, verify_every: int = 0):
        hist = []
        for i in range(int(steps)):
            hist.append(self.step(verify=(verify_every > 0 and (i+1) % verify_every == 0)))
        return hist

    def snapshot(self) -> Dict[str, Any]:
        if self.use_multiscale:
            if self.ms is None:
                raise RuntimeError("Multiscale adapter not initialized.")
            snap = self.ms.sim.snapshot()
            snap["multiscale"] = self.ms.state_snapshot()
        else:
            if self.engine is None:
                raise RuntimeError("Engine not initialized.")
            snap = self.engine.snapshot()
        snap["schema_version"] = SCHEMA_VERSION
        snap["state_hash_unified"] = compute_state_hash(snap)
        # attach sim_loop snapshot if active
        if self.sim_loop_config.enabled:
            snap["sim_loop"] = self.get_sim_loop_snapshot()
        return snap

    def render(self, stream_key: str = "main") -> Dict[str, Any]:
        if self.vision is None:
            self.build_vision()
        snap = self.snapshot()
        return self.vision.render_buffers(snap, stream_key=stream_key, return_linear=False)

    def export_snapshot_json(self, path: str) -> str:
        return save_snapshot_json(path, self.snapshot())

    def export_snapshot_npz(self, path: str) -> str:
        return save_snapshot_npz(path, self.snapshot())

    def report(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "module_name":    MODULE_NAME,
            "module_version": MODULE_VERSION,
            "builder_cfg":    asdict(self.builder_cfg),
            "engine_cfg":     asdict(self.engine_cfg),
            "ms_cfg":         asdict(self.ms_cfg),
            "rs_cfg":         asdict(self.rs_cfg),
            "vision_cfg":     asdict(self.vision_cfg),
            "use_multiscale": bool(self.use_multiscale),
        }
        if self.builder is not None:
            out["builder_summary"] = self.builder.summary()
        if self.engine is not None:
            out["engine_snapshot_head"] = {
                "tick":          int(self.engine.tick),
                "z":             float(self.engine.z),
                "n_obj":         int(self.engine.n_obj),
                "lights":        int(len(self.engine.light_sources)),
                "force_sources": int(len(self.engine.force_sources)),
            }
        if self.ms is not None:
            out["multiscale_state"]  = self.ms.state_snapshot()
            out["multiscale_slider"] = self.ms.get_scale_slider_state()
        if self.sim_loop_config.enabled:
            out["sim_loop"] = self.get_sim_loop_snapshot()
        return out

    # ==========================================================================
    # SimLoop API (patch 4)
    # ==========================================================================

    def enable_sim_loop(
        self,
        *,
        dt: float = 0.05,
        thermal_config: Optional[ThermalCouplerConfig] = None,
        entropy_config: Optional[EntropyCouplerConfig] = None,
        emit_tick_events: bool = True,
        emit_thermal_hotspot_events: bool = True,
        thermal_hotspot_threshold: float = 0.05,
    ) -> None:
        self.sim_loop_config = SimLoopConfig(
            enabled=True,
            dt=float(dt),
            emit_tick_events=bool(emit_tick_events),
            emit_thermal_hotspot_events=bool(emit_thermal_hotspot_events),
            thermal_hotspot_threshold=float(thermal_hotspot_threshold),
            keep_last_n_events=self.sim_loop_config.keep_last_n_events,
        )
        self.sim_loop_state.enabled = True
        self.thermal_coupler = ThermalCoupler(
            thermal_config if thermal_config is not None else ThermalCouplerConfig()
        )
        self.entropy_coupler = EntropyCoupler(
            entropy_config if entropy_config is not None else EntropyCouplerConfig()
        )
        self.event_bus.record_history = True
        self._ensure_sim_fields()

    def disable_sim_loop(self) -> None:
        self.sim_loop_config.enabled = False
        self.sim_loop_state.enabled = False

    def get_sim_loop_snapshot(self) -> Dict[str, Any]:
        thermal_max = None
        entropy_max = None
        if self.thermal_grid is not None:
            for attr in ("T", "temperatures"):
                arr = getattr(self.thermal_grid, attr, None)
                if isinstance(arr, np.ndarray):
                    thermal_max = float(np.max(arr))
                    break
        if self.entropy_field is not None:
            for attr in ("S", "E", "entropy", "values"):
                arr = getattr(self.entropy_field, attr, None)
                if isinstance(arr, np.ndarray):
                    entropy_max = float(np.max(arr))
                    break
        return {
            "config":  asdict(self.sim_loop_config),
            "state":   asdict(self.sim_loop_state),
            "thermal_max": thermal_max,
            "entropy_max": entropy_max,
            "recent_events": [
                {
                    "type":      evt.type,
                    "payload":   dict(evt.payload),
                    "tick":      getattr(evt, "tick", None),
                    "source_id": getattr(evt, "source_id", None),
                }
                for evt in self._sim_event_history
            ],
        }

    def clear_sim_events(self) -> None:
        self.event_bus.clear_history()
        self._sim_event_history = []

    # ── SimLoop internals ─────────────────────────────────────────────────────

    def _ensure_sim_fields(self) -> None:
        if self.thermal_grid is None:
            self.thermal_grid = _TerminalThermalGrid(self._space_shape())
        if self.entropy_field is None:
            self.entropy_field = _TerminalEntropyField(self._space_shape())

    def _space_shape(self) -> tuple:
        """Derive (nx, ny, nz) from whichever engine/sim is active."""
        # multiscale wraps engine as self.ms.sim
        if self.ms is not None and hasattr(self.ms, "sim"):
            cfg = getattr(self.ms.sim, "cfg", None)
            if cfg is not None:
                return int(cfg.nx), int(cfg.ny), int(cfg.nz)
        if self.engine is not None:
            cfg = getattr(self.engine, "cfg", None)
            if cfg is not None:
                return int(cfg.nx), int(cfg.ny), int(cfg.nz)
        # fallback to engine_cfg (set even before engine is built)
        return int(self.engine_cfg.nx), int(self.engine_cfg.ny), int(self.engine_cfg.nz)

    def _active_sim(self) -> Optional[NoctilithSpace3DNumba]:
        """Return the live Space3D instance regardless of multiscale wrapping."""
        if self.ms is not None:
            return self.ms.sim
        return self.engine

    def _extract_field_state(self) -> Dict[str, Any]:
        """Extract phi_em and phi_rms from the active sim."""
        sim = self._active_sim()
        if sim is None:
            return {}
        out: Dict[str, Any] = {}
        for key in ("phi_em", "phi_g", "phi_s", "phi_w"):
            val = getattr(sim, key, None)
            if val is not None:
                try:
                    out[key] = np.asarray(val, dtype=np.float64)
                except Exception:
                    pass
        return out

    def _build_telemetry(self, space3d_telemetry: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Build coupler telemetry from space3d step result or live sim attrs."""
        tel: Dict[str, Any] = {
            "step_index":    self.sim_loop_state.step_index,
            "phi_rms_total": 0.0,
            "unstable":      False,
            "regime":        "unknown",
        }
        # prefer the live telemetry dict from step()
        if space3d_telemetry:
            for k in ("phi_rms_total", "phi_rms", "unstable", "regime", "tick"):
                if k in space3d_telemetry:
                    tel[k] = space3d_telemetry[k]
            # normalise phi_rms → phi_rms_total
            if "phi_rms_total" not in space3d_telemetry and "phi_rms" in space3d_telemetry:
                tel["phi_rms_total"] = float(space3d_telemetry["phi_rms"])
        return tel

    def _sim_loop_step(
        self,
        dt: Optional[float] = None,
        space3d_telemetry: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if not self.sim_loop_config.enabled:
            return {"enabled": False, "step_index": self.sim_loop_state.step_index}

        self._ensure_sim_fields()

        step_dt   = float(self.sim_loop_config.dt if dt is None else dt)
        t0        = time.perf_counter()
        telemetry = self._build_telemetry(space3d_telemetry)
        field_state = self._extract_field_state()

        old_regime = self.sim_loop_state.last_regime
        new_regime = str(telemetry.get("regime", "unknown"))

        # ── thermal coupling ──────────────────────────────────────────────────
        thermal_result: Dict[str, Any] = {}
        if self.thermal_coupler is not None:
            thermal_result = self.thermal_coupler.apply(
                self.thermal_grid,
                dt=step_dt,
                field_state=field_state,
                telemetry=telemetry,
            )

        # ── entropy coupling ──────────────────────────────────────────────────
        entropy_result: Dict[str, Any] = {}
        if self.entropy_coupler is not None:
            entropy_result = self.entropy_coupler.apply(
                self.entropy_field,
                dt=step_dt,
                telemetry=telemetry,
                event_bus=self.event_bus,
            )

        # ── regime transition event ───────────────────────────────────────────
        if new_regime != old_regime:
            self.event_bus.emit(EventBus.make_regime_transition(
                step_index=self.sim_loop_state.step_index,
                old_regime=old_regime,
                new_regime=new_regime,
                phi_rms_total=float(telemetry.get("phi_rms_total", 0.0)),
                unstable=bool(telemetry.get("unstable", False)),
                source=MODULE_NAME,
            ))

        # ── thermal hotspot event ─────────────────────────────────────────────
        if (self.sim_loop_config.emit_thermal_hotspot_events and thermal_result and
                float(thermal_result.get("max_cell_heat", 0.0)) >=
                self.sim_loop_config.thermal_hotspot_threshold):
            self.event_bus.emit(EventBus.make_thermal_hotspot(
                step_index=self.sim_loop_state.step_index,
                total_added_heat=float(thermal_result.get("total_added_heat", 0.0)),
                max_cell_heat=float(thermal_result.get("max_cell_heat", 0.0)),
                active_cells=int(thermal_result.get("active_cells", 0)),
                source=MODULE_NAME,
            ))

        # ── tick completed event ──────────────────────────────────────────────
        if self.sim_loop_config.emit_tick_events:
            self.event_bus.emit(EventBus.make_sim_tick_completed(
                step_index=self.sim_loop_state.step_index,
                dt=step_dt,
                thermal=thermal_result,
                entropy=entropy_result,
                source=MODULE_NAME,
            ))

        # ── bounded history ───────────────────────────────────────────────────
        keep_n = max(1, int(self.sim_loop_config.keep_last_n_events))
        self._sim_event_history = self.event_bus.get_history()[-keep_n:]

        # ── update state ──────────────────────────────────────────────────────
        wall = time.perf_counter() - t0
        self.sim_loop_state.last_thermal           = dict(thermal_result)
        self.sim_loop_state.last_entropy           = dict(entropy_result)
        self.sim_loop_state.last_regime            = new_regime
        self.sim_loop_state.last_step_wall_time_s  = float(wall)

        out = {
            "enabled":                True,
            "step_index":             int(self.sim_loop_state.step_index),
            "dt":                     step_dt,
            "regime":                 new_regime,
            "thermal":                dict(thermal_result),
            "entropy":                dict(entropy_result),
            "event_count":            len(self._sim_event_history),
            "last_step_wall_time_s":  float(wall),
        }
        self.sim_loop_state.step_index += 1
        return out


# ==============================================================================
# CLI (unchanged)
# ==============================================================================

def _cli() -> int:
    ap = argparse.ArgumentParser(description="NOCTILITH unified control terminal")
    ap.add_argument("--preset", type=str, default="solar",
        choices=["galaxy","dna","water","molecules","ecosystem","city","solar","materials","bioengineered"])
    ap.add_argument("--steps", type=int, default=8)
    ap.add_argument("--verify-every", type=int, default=0)
    ap.add_argument("--use-multiscale", action="store_true")
    ap.add_argument("--auto-lights", action="store_true")
    ap.add_argument("--scale-percent", type=float, default=None)
    ap.add_argument("--lock-scale-percent", action="store_true")
    ap.add_argument("--export-json", type=str, default="")
    ap.add_argument("--export-npz",  type=str, default="")
    ap.add_argument("--sim-loop", action="store_true", help="Enable SimLoop (thermal+entropy)")
    args = ap.parse_args()

    term = NoctilithControlTerminal(
        builder_cfg=BuilderConfig(auto_add_scene_lights=bool(args.auto_lights)),
        engine_cfg=Space3DConfig(),
        ms_cfg=MultiscaleConfig(),
        rs_cfg=ResampleConfig(),
        vision_cfg=VisionConfigV240(),
        use_multiscale=bool(args.use_multiscale),
    )
    term.build_preset(args.preset)

    if args.use_multiscale:
        term.build_multiscale()
        term.attach_builder()
        if args.scale_percent is not None:
            term.set_scale_percent(args.scale_percent, lock_percent=bool(args.lock_scale_percent))
    else:
        term.build_engine()
        term.attach_builder()

    if args.sim_loop:
        term.enable_sim_loop()

    hist = term.run(args.steps, verify_every=args.verify_every)

    if args.export_json: term.export_snapshot_json(args.export_json)
    if args.export_npz:  term.export_snapshot_npz(args.export_npz)

    print(json.dumps({"report": term.report(), "last_metrics": hist[-1] if hist else {}},
                     indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())