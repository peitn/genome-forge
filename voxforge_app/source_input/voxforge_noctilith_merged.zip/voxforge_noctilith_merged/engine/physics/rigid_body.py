"""
engine/physics/rigid_body.py
=============================
Rigidní fyzika — základní physika objektů v VoxForge světě.

Blueprint §4.1: "rigid bodies, collision detection, constraints,
                  joints, gravity, impulses, friction, restitution, mass/inertia"

Implementuje:
  - RigidBody dataclass s plnými fyzikálními vlastnostmi
  - AABB collision detection (axis-aligned bounding box)
  - Discrete collision response s impulzy
  - Fyzikální omezení (pevná vzdálenost, kloub, pant)
  - Gravity, drag, friction
  - Broadphase spatial grid pro výkonnou detekci kolizí
  - Voxelový svět jako statická kolizní geometrie
  - Integrace Symplectic Euler

Pozn.: Pro produkci by se nasadil Bullet/Rapier přes binding.
       Tato implementace je architekturálně kompatibilní a slouží
       jako prototyp s čistým Python/NumPy backendem.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Dict, List, Optional, Set, Tuple

import numpy as np


# ─── Pomocné vektory ─────────────────────────────────────────────────────────

Vec3 = np.ndarray   # dtype float32, shape (3,)


def vec3(x: float = 0.0, y: float = 0.0, z: float = 0.0) -> Vec3:
    return np.array([x, y, z], dtype=np.float32)


def dot(a: Vec3, b: Vec3) -> float:
    return float(np.dot(a, b))


def cross(a: Vec3, b: Vec3) -> Vec3:
    return np.cross(a, b).astype(np.float32)


def normalize(v: Vec3) -> Vec3:
    n = np.linalg.norm(v)
    if n < 1e-9:
        return vec3(0, 1, 0)
    return (v / n).astype(np.float32)


def length(v: Vec3) -> float:
    return float(np.linalg.norm(v))


# ─── AABB ─────────────────────────────────────────────────────────────────────

@dataclass
class AABB:
    """Axis-Aligned Bounding Box."""
    min: Vec3 = field(default_factory=lambda: vec3(-0.5, -0.5, -0.5))
    max: Vec3 = field(default_factory=lambda: vec3( 0.5,  0.5,  0.5))

    @classmethod
    def from_center_half(cls, center: Vec3, half: Vec3) -> "AABB":
        return cls(min=center - half, max=center + half)

    @classmethod
    def from_size(cls, center: Vec3, size: Vec3) -> "AABB":
        half = size * 0.5
        return cls(min=center - half, max=center + half)

    def intersects(self, other: "AABB") -> bool:
        return (self.min[0] <= other.max[0] and self.max[0] >= other.min[0] and
                self.min[1] <= other.max[1] and self.max[1] >= other.min[1] and
                self.min[2] <= other.max[2] and self.max[2] >= other.min[2])

    def overlap(self, other: "AABB") -> Optional[Vec3]:
        """Vrátí overlap vektor (MTD) nebo None pokud se nepřekrývají."""
        if not self.intersects(other):
            return None
        ox = min(self.max[0], other.max[0]) - max(self.min[0], other.min[0])
        oy = min(self.max[1], other.max[1]) - max(self.min[1], other.min[1])
        oz = min(self.max[2], other.max[2]) - max(self.min[2], other.min[2])
        if ox <= 0 or oy <= 0 or oz <= 0:
            return None
        # Minimální osa průniku
        if ox <= oy and ox <= oz:
            sign = 1.0 if self.center[0] < other.center[0] else -1.0
            return vec3(-ox * sign, 0, 0)
        if oy <= ox and oy <= oz:
            sign = 1.0 if self.center[1] < other.center[1] else -1.0
            return vec3(0, -oy * sign, 0)
        sign = 1.0 if self.center[2] < other.center[2] else -1.0
        return vec3(0, 0, -oz * sign)

    @property
    def center(self) -> Vec3:
        return ((self.min + self.max) * 0.5).astype(np.float32)

    @property
    def size(self) -> Vec3:
        return (self.max - self.min).astype(np.float32)

    @property
    def half(self) -> Vec3:
        return (self.size * 0.5).astype(np.float32)

    def translated(self, offset: Vec3) -> "AABB":
        return AABB(min=self.min + offset, max=self.max + offset)

    def expanded(self, margin: float) -> "AABB":
        m = vec3(margin, margin, margin)
        return AABB(min=self.min - m, max=self.max + m)

    def contains_point(self, p: Vec3) -> bool:
        return (self.min[0] <= p[0] <= self.max[0] and
                self.min[1] <= p[1] <= self.max[1] and
                self.min[2] <= p[2] <= self.max[2])

    def surface_area(self) -> float:
        s = self.size
        return 2 * (s[0]*s[1] + s[1]*s[2] + s[2]*s[0])


# ─── Collision manifest ───────────────────────────────────────────────────────

@dataclass
class CollisionManifold:
    """Výsledek collision detection — normála, hloubka, kontaktní body."""
    body_a: "RigidBody"
    body_b: "RigidBody"
    normal: Vec3                    # z A do B
    depth: float                    # penetrační hloubka
    contact_points: List[Vec3] = field(default_factory=list)
    relative_velocity: Vec3 = field(default_factory=lambda: vec3())
    restitution: float = 0.3
    friction: float = 0.5


# ─── Rigid Body ──────────────────────────────────────────────────────────────

class BodyType(str, Enum):
    DYNAMIC  = "dynamic"     # plně fyzikální
    KINEMATIC = "kinematic"  # ovládaný kódem, ale kolize se počítají
    STATIC   = "static"      # nehybný (terrain, stěny)


@dataclass
class RigidBody:
    """
    Plný rigid body objekt.
    Blueprint §4.1: rigid bodies, mass/inertia, gravity, impulses, friction.
    """
    body_id: str
    body_type: BodyType = BodyType.DYNAMIC

    # Transformace
    position: Vec3 = field(default_factory=lambda: vec3())
    rotation: Vec3 = field(default_factory=lambda: vec3())     # Euler angles (rad)
    scale:    Vec3 = field(default_factory=lambda: vec3(1,1,1))

    # Kinematika
    velocity:         Vec3 = field(default_factory=lambda: vec3())
    angular_velocity: Vec3 = field(default_factory=lambda: vec3())
    acceleration:     Vec3 = field(default_factory=lambda: vec3())

    # Fyzikální vlastnosti
    mass:        float = 1.0        # kg
    restitution: float = 0.3        # 0 = plastický, 1 = dokonale elastický
    friction:    float = 0.5        # 0 = kluzký, 1 = hrubý
    linear_drag:  float = 0.01      # odpor pohybu vzduchem
    angular_drag: float = 0.05

    # Kolizní geometrie
    aabb_local: AABB = field(default_factory=AABB)    # v lokálním prostoru
    is_trigger:  bool = False    # trigger = detekuje, ale neblokuje

    # Flags
    use_gravity:  bool = True
    is_grounded:  bool = False
    is_sleeping:  bool = False
    sleep_threshold: float = 0.01   # rychlost pod níž těleso usne

    # Metadata
    material_id: int = 0
    entity_id:   str = ""
    tags: Set[str] = field(default_factory=set)

    # Akumulované síly (reset každý tick)
    _force_acc:  Vec3 = field(default_factory=lambda: vec3(), repr=False)
    _torque_acc: Vec3 = field(default_factory=lambda: vec3(), repr=False)

    def __post_init__(self):
        if not isinstance(self.position, np.ndarray):
            self.position = vec3(*self.position)
        if not isinstance(self.velocity, np.ndarray):
            self.velocity = vec3(*self.velocity)

    # ── API ──────────────────────────────────────────────────────────────────

    @property
    def inv_mass(self) -> float:
        return 0.0 if self.body_type == BodyType.STATIC or self.mass <= 0 else 1.0 / self.mass

    @property
    def inertia(self) -> float:
        """Zjednodušený skalární moment setrvačnosti (sphere approximation)."""
        s = self.aabb_local.size
        r = length(s) * 0.5
        return 0.4 * self.mass * r * r

    @property
    def aabb_world(self) -> AABB:
        """AABB v světových souřadnicích."""
        return self.aabb_local.translated(self.position)

    def apply_force(self, force: Vec3) -> None:
        """Přidej sílu (N) akumulovanou pro tento tick."""
        if self.body_type != BodyType.STATIC and not self.is_sleeping:
            self._force_acc = self._force_acc + force

    def apply_impulse(self, impulse: Vec3, contact_point: Optional[Vec3] = None) -> None:
        """Přidej okamžitý impuls (změna hybnosti)."""
        if self.body_type == BodyType.STATIC:
            return
        dv = impulse * self.inv_mass
        self.velocity = self.velocity + dv
        if contact_point is not None and length(contact_point) > 0:
            r = contact_point - self.position
            angular_impulse = cross(r, impulse) / max(self.inertia, 1e-6)
            self.angular_velocity = self.angular_velocity + angular_impulse
        self.is_sleeping = False

    def apply_torque(self, torque: Vec3) -> None:
        self._torque_acc = self._torque_acc + torque

    def reset_forces(self) -> None:
        self._force_acc[:] = 0
        self._torque_acc[:] = 0

    def speed(self) -> float:
        return length(self.velocity)

    def kinetic_energy(self) -> float:
        v2 = dot(self.velocity, self.velocity)
        w2 = dot(self.angular_velocity, self.angular_velocity)
        return 0.5 * self.mass * v2 + 0.5 * self.inertia * w2


# ─── Constraints ─────────────────────────────────────────────────────────────

class Constraint:
    """Základní fyzikální omezení."""
    def solve(self, dt: float) -> None:
        pass


@dataclass
class DistanceConstraint(Constraint):
    """Pevná vzdálenost mezi dvěma tělesy (lano, kost)."""
    body_a:    RigidBody
    body_b:    RigidBody
    rest_length: float
    stiffness: float = 0.8     # 0-1
    anchor_a:  Vec3 = field(default_factory=lambda: vec3())   # lokální bod na A
    anchor_b:  Vec3 = field(default_factory=lambda: vec3())   # lokální bod na B

    def solve(self, dt: float) -> None:
        pa = self.body_a.position + self.anchor_a
        pb = self.body_b.position + self.anchor_b
        delta = pb - pa
        dist = length(delta)
        if dist < 1e-9:
            return
        diff = (dist - self.rest_length) / dist * self.stiffness
        correction = delta * diff * 0.5
        m_a = self.body_a.inv_mass
        m_b = self.body_b.inv_mass
        total_inv_m = m_a + m_b
        if total_inv_m < 1e-9:
            return
        if self.body_a.body_type != BodyType.STATIC:
            self.body_a.position = self.body_a.position + correction * (m_a / total_inv_m)
        if self.body_b.body_type != BodyType.STATIC:
            self.body_b.position = self.body_b.position - correction * (m_b / total_inv_m)


@dataclass
class HingeConstraint(Constraint):
    """
    Pant — rotace jen kolem jedné osy.
    Blueprint §3.1: "hinge"
    """
    body_a:    RigidBody
    body_b:    RigidBody
    axis:      Vec3                 # osa rotace (world space)
    anchor:    Vec3                 # pivot bod (world space)
    min_angle: float = -math.pi    # rad
    max_angle: float =  math.pi
    stiffness: float = 0.9

    def solve(self, dt: float) -> None:
        # Zjednodušená implementace: oprav relativní rychlosti kolmo k ose
        rel_vel = self.body_b.velocity - self.body_a.velocity
        axis_n = normalize(self.axis)
        along = dot(rel_vel, axis_n) * axis_n
        perp = rel_vel - along
        # Omez pohyb kolmo k ose
        correction_impulse = -perp * self.stiffness * 0.5
        inv_m_total = self.body_a.inv_mass + self.body_b.inv_mass
        if inv_m_total < 1e-9:
            return
        if self.body_a.body_type != BodyType.STATIC:
            self.body_a.apply_impulse(-correction_impulse * self.body_a.inv_mass / inv_m_total)
        if self.body_b.body_type != BodyType.STATIC:
            self.body_b.apply_impulse(correction_impulse * self.body_b.inv_mass / inv_m_total)


@dataclass
class SpringConstraint(Constraint):
    """
    Pružina mezi dvěma tělesy.
    F = -k * (length - rest) * dir - c * relative_velocity
    """
    body_a:     RigidBody
    body_b:     RigidBody
    rest_length: float = 1.0
    stiffness:  float = 50.0    # N/m
    damping:    float = 5.0     # N·s/m

    def solve(self, dt: float) -> None:
        pa = self.body_a.position
        pb = self.body_b.position
        delta = pb - pa
        dist = length(delta)
        if dist < 1e-9:
            return
        dir_ab = delta / dist

        # Hookeův zákon
        extension = dist - self.rest_length
        spring_force = self.stiffness * extension

        # Útlum
        rel_vel = self.body_b.velocity - self.body_a.velocity
        damp_force = self.damping * dot(rel_vel, dir_ab)

        total_force = (spring_force + damp_force) * dir_ab
        self.body_a.apply_force( total_force)
        self.body_b.apply_force(-total_force)


@dataclass
class FixedConstraint(Constraint):
    """Fixní pevný spoj — těleso B se pohybuje s A."""
    body_a: RigidBody
    body_b: RigidBody
    offset: Vec3 = field(default_factory=lambda: vec3())

    def solve(self, dt: float) -> None:
        if self.body_b.body_type == BodyType.STATIC:
            return
        target = self.body_a.position + self.offset
        err = target - self.body_b.position
        self.body_b.position = self.body_b.position + err * 0.8
        self.body_b.velocity = self.body_a.velocity.copy()


# ─── Broadphase Grid ─────────────────────────────────────────────────────────

class SpatialGrid:
    """
    Uniform spatial grid pro broadphase collision detection.
    Vkládá AABB tělesa do buněk gridu a vrací kandidátní páry.
    """
    def __init__(self, cell_size: float = 4.0):
        self.cell_size = cell_size
        self._cells: Dict[Tuple[int,int,int], List[RigidBody]] = {}

    def _cell(self, x: float, y: float, z: float) -> Tuple[int,int,int]:
        cs = self.cell_size
        return (int(math.floor(x / cs)),
                int(math.floor(y / cs)),
                int(math.floor(z / cs)))

    def clear(self) -> None:
        self._cells.clear()

    def insert(self, body: RigidBody) -> None:
        aabb = body.aabb_world
        c0 = self._cell(*aabb.min)
        c1 = self._cell(*aabb.max)
        for cx in range(c0[0], c1[0] + 1):
            for cy in range(c0[1], c1[1] + 1):
                for cz in range(c0[2], c1[2] + 1):
                    key = (cx, cy, cz)
                    if key not in self._cells:
                        self._cells[key] = []
                    self._cells[key].append(body)

    def get_candidates(self) -> List[Tuple[RigidBody, RigidBody]]:
        """Vrátí kandidátní páry těles pro narrow-phase test."""
        seen: Set[Tuple[str, str]] = set()
        pairs: List[Tuple[RigidBody, RigidBody]] = []
        for bodies in self._cells.values():
            for i in range(len(bodies)):
                for j in range(i + 1, len(bodies)):
                    a, b = bodies[i], bodies[j]
                    key = (min(a.body_id, b.body_id), max(a.body_id, b.body_id))
                    if key not in seen:
                        seen.add(key)
                        # Skip static-static
                        if a.body_type == BodyType.STATIC and b.body_type == BodyType.STATIC:
                            continue
                        pairs.append((a, b))
        return pairs


# ─── Physics World ────────────────────────────────────────────────────────────

GRAVITY = vec3(0.0, -9.81, 0.0)    # m/s²


class PhysicsWorld:
    """
    Fyzikální svět — spravuje všechna tělesa, kolize, constrainty.

    Blueprint §4.1: kompletní fyzikální simulace.

    Použití:
        phys = PhysicsWorld()
        body = phys.create_body("player", BodyType.DYNAMIC,
                                 position=vec3(0,10,0), mass=70.0)
        for tick in range(1000):
            phys.step(dt=0.016)   # 60 FPS
    """

    def __init__(self, gravity: Vec3 = None, substeps: int = 3):
        self.gravity     = gravity if gravity is not None else GRAVITY.copy()
        self.substeps    = substeps
        self.bodies:      Dict[str, RigidBody]  = {}
        self.constraints: List[Constraint]       = []
        self._grid       = SpatialGrid(cell_size=3.0)
        self._tick        = 0
        self._callbacks: Dict[str, List[Callable]] = {
            "on_collision": [],
            "on_trigger":   [],
        }
        # Kolizní geomerie světa (voxel solid grid, nastavovat externě)
        self.voxel_solid: Optional[np.ndarray] = None
        self.voxel_size:  float = 1.0

    # ── Správa těles ─────────────────────────────────────────────────────────

    def create_body(self, body_id: str,
                    body_type: BodyType = BodyType.DYNAMIC,
                    position: Vec3 = None,
                    size: Vec3 = None,
                    mass: float = 1.0,
                    restitution: float = 0.3,
                    friction: float = 0.5,
                    **kwargs) -> RigidBody:
        """Vytvoř a zaregistruj nové těleso."""
        pos  = position if position is not None else vec3()
        sz   = size     if size     is not None else vec3(1, 1, 1)
        aabb = AABB.from_size(vec3(), sz)
        body = RigidBody(
            body_id=body_id, body_type=body_type,
            position=pos.copy(),
            mass=mass, restitution=restitution, friction=friction,
            aabb_local=aabb,
            **kwargs
        )
        self.bodies[body_id] = body
        return body

    def remove_body(self, body_id: str) -> None:
        self.bodies.pop(body_id, None)

    def get_body(self, body_id: str) -> Optional[RigidBody]:
        return self.bodies.get(body_id)

    def add_constraint(self, c: Constraint) -> None:
        self.constraints.append(c)

    def remove_constraints_for(self, body_id: str) -> None:
        self.constraints = [
            c for c in self.constraints
            if not (hasattr(c, 'body_a') and c.body_a.body_id == body_id)
            and not (hasattr(c, 'body_b') and c.body_b.body_id == body_id)
        ]

    # ── Simulační krok ────────────────────────────────────────────────────────

    def step(self, dt: float) -> List[CollisionManifold]:
        """
        Jeden fyzikální krok (typicky 1/60 s).
        Interně rozdělen do substeps pro stabilitu.
        Vrátí seznam kolizních manifestů.
        """
        sub_dt = dt / self.substeps
        manifolds: List[CollisionManifold] = []

        for _ in range(self.substeps):
            self._integrate(sub_dt)
            self._solve_constraints(sub_dt)
            manifolds.extend(self._detect_and_resolve(sub_dt))

        self._tick += 1
        return manifolds

    def _integrate(self, dt: float) -> None:
        """Symplectic Euler integrace."""
        for body in self.bodies.values():
            if body.body_type != BodyType.DYNAMIC or body.is_sleeping:
                body.reset_forces()
                continue

            # Gravitace
            if body.use_gravity:
                body.apply_force(self.gravity * body.mass)

            # Aktualizace rychlosti (síla → rychlost)
            accel = body._force_acc * body.inv_mass
            body.velocity = body.velocity + accel * dt

            # Drag (odpor vzduchu)
            body.velocity = body.velocity * (1.0 - body.linear_drag * dt * 60)
            body.angular_velocity = body.angular_velocity * (1.0 - body.angular_drag * dt * 60)

            # Aktualizace pozice (rychlost → pozice)
            body.position = body.position + body.velocity * dt
            body.rotation = body.rotation + body.angular_velocity * dt

            # Sleep check
            if body.speed() < body.sleep_threshold and body.is_grounded:
                body.is_sleeping = True
            else:
                body.is_sleeping = False

            body.reset_forces()

    def _solve_constraints(self, dt: float) -> None:
        """Iterativně řeš constrainty (Position-Based Dynamics přístup)."""
        for _ in range(4):   # iterace
            for constraint in self.constraints:
                constraint.solve(dt)

    def _detect_and_resolve(self, dt: float) -> List[CollisionManifold]:
        """Broadphase + narrow-phase collision detection + response."""
        manifolds: List[CollisionManifold] = []

        # Broadphase
        self._grid.clear()
        for body in self.bodies.values():
            if not body.is_sleeping:
                self._grid.insert(body)

        # Narrow-phase
        for (a, b) in self._grid.get_candidates():
            overlap = a.aabb_world.overlap(b.aabb_world)
            if overlap is None:
                continue

            depth = length(overlap)
            if depth < 1e-6:
                continue
            normal = normalize(overlap)

            # Trigger zpracování
            if a.is_trigger or b.is_trigger:
                manifold = CollisionManifold(a, b, normal, depth)
                for cb in self._callbacks["on_trigger"]:
                    cb(manifold)
                continue

            # Collision response
            manifold = self._resolve_collision(a, b, normal, depth)
            manifolds.append(manifold)
            for cb in self._callbacks["on_collision"]:
                cb(manifold)

        # Voxelová kolize (statická geometrie)
        if self.voxel_solid is not None:
            self._resolve_voxel_collisions(manifolds)

        return manifolds

    def _resolve_collision(self, a: RigidBody, b: RigidBody,
                           normal: Vec3, depth: float) -> CollisionManifold:
        """Impulzní collision response."""
        # Separace (positional correction)
        total_inv_m = a.inv_mass + b.inv_mass
        if total_inv_m > 1e-9:
            correction = normal * depth / total_inv_m * 0.8
            if a.body_type != BodyType.STATIC:
                a.position = a.position - correction * a.inv_mass
            if b.body_type != BodyType.STATIC:
                b.position = b.position + correction * b.inv_mass

        # Relativní rychlost
        rel_v = b.velocity - a.velocity
        vel_along = dot(rel_v, normal)

        # Nereaguj pokud se tělesa vzdalují
        if vel_along > 0:
            return CollisionManifold(a, b, normal, depth)

        # Koeficient restituce (min obou)
        e = min(a.restitution, b.restitution)

        # Impulz velikost
        j = -(1 + e) * vel_along / total_inv_m if total_inv_m > 1e-9 else 0

        # Normálový impulz
        impulse = normal * j
        if a.body_type != BodyType.STATIC:
            a.apply_impulse(-impulse)
        if b.body_type != BodyType.STATIC:
            b.apply_impulse(impulse)

        # Třecí impulz
        tangent = rel_v - vel_along * normal
        if length(tangent) > 1e-6:
            tangent = normalize(tangent)
            mu = math.sqrt(a.friction * b.friction)
            jt = -dot(rel_v, tangent) / total_inv_m if total_inv_m > 1e-9 else 0
            jt = max(-abs(j) * mu, min(abs(j) * mu, jt))
            friction_impulse = tangent * jt
            if a.body_type != BodyType.STATIC:
                a.apply_impulse(-friction_impulse)
            if b.body_type != BodyType.STATIC:
                b.apply_impulse(friction_impulse)

        # Grounded check (kolize zdola)
        if normal[1] > 0.7:
            b.is_grounded = True
        if normal[1] < -0.7:
            a.is_grounded = True

        return CollisionManifold(a, b, normal, depth,
                                 restitution=e,
                                 friction=math.sqrt(a.friction * b.friction))

    def _resolve_voxel_collisions(self, manifolds: List[CollisionManifold]) -> None:
        """
        Řeší kolize dynamických těles s voxelovým světem.
        Voxelová mřížka je statická geometrie.
        """
        if self.voxel_solid is None:
            return
        vs = self.voxel_size
        sx, sy, sz = self.voxel_solid.shape

        for body in self.bodies.values():
            if body.body_type != BodyType.DYNAMIC:
                continue

            aabb = body.aabb_world
            # Rozsah voxelů k testování
            x0 = max(0, int(math.floor(aabb.min[0] / vs)))
            y0 = max(0, int(math.floor(aabb.min[1] / vs)))
            z0 = max(0, int(math.floor(aabb.min[2] / vs)))
            x1 = min(sx - 1, int(math.ceil(aabb.max[0] / vs)))
            y1 = min(sy - 1, int(math.ceil(aabb.max[1] / vs)))
            z1 = min(sz - 1, int(math.ceil(aabb.max[2] / vs)))

            body.is_grounded = False

            for vx in range(x0, x1 + 1):
                for vy in range(y0, y1 + 1):
                    for vz in range(z0, z1 + 1):
                        if not self.voxel_solid[vx, vy, vz]:
                            continue
                        # AABB voxelu
                        vmin = vec3(vx * vs, vy * vs, vz * vs)
                        vmax = vmin + vec3(vs, vs, vs)
                        voxel_aabb = AABB(min=vmin, max=vmax)
                        overlap = aabb.overlap(voxel_aabb)
                        if overlap is None:
                            continue
                        depth = length(overlap)
                        if depth < 1e-6:
                            continue
                        normal = normalize(overlap)
                        # Pushback
                        body.position = body.position - overlap
                        # Velocity projection
                        vel_along = dot(body.velocity, normal)
                        if vel_along < 0:
                            refl = body.velocity - (1 + body.restitution) * vel_along * normal
                            # Friction na tangenciální složku
                            tangent = refl - dot(refl, normal) * normal
                            body.velocity = refl - tangent * body.friction * 0.5
                        if normal[1] > 0.7:
                            body.is_grounded = True

    # ── Callbacks ─────────────────────────────────────────────────────────────

    def on_collision(self, fn: Callable[[CollisionManifold], None]) -> None:
        self._callbacks["on_collision"].append(fn)

    def on_trigger(self, fn: Callable[[CollisionManifold], None]) -> None:
        self._callbacks["on_trigger"].append(fn)

    # ── Raycasting ────────────────────────────────────────────────────────────

    def raycast(self, origin: Vec3, direction: Vec3,
                max_distance: float = 100.0) -> Optional[Tuple[RigidBody, Vec3, float]]:
        """
        Vysílá paprsek a vrátí (těleso, hit_point, distance) nebo None.
        Používá slab method pro AABB intersection.
        """
        dir_n = normalize(direction)
        best_t = max_distance
        best_body = None
        best_point = None

        for body in self.bodies.values():
            aabb = body.aabb_world
            t = self._ray_aabb(origin, dir_n, aabb)
            if t is not None and t < best_t:
                best_t = t
                best_body = body
                best_point = origin + dir_n * t

        if best_body:
            return (best_body, best_point, best_t)
        return None

    def _ray_aabb(self, ro: Vec3, rd: Vec3, aabb: AABB) -> Optional[float]:
        """Slab method AABB raycast. Vrátí t nebo None."""
        tmin = -math.inf
        tmax =  math.inf
        for i in range(3):
            if abs(rd[i]) < 1e-9:
                if ro[i] < aabb.min[i] or ro[i] > aabb.max[i]:
                    return None
            else:
                t1 = (aabb.min[i] - ro[i]) / rd[i]
                t2 = (aabb.max[i] - ro[i]) / rd[i]
                tmin = max(tmin, min(t1, t2))
                tmax = min(tmax, max(t1, t2))
        if tmax < tmin or tmax < 0:
            return None
        return max(tmin, 0.0)

    # ── Status ───────────────────────────────────────────────────────────────

    @property
    def stats(self) -> dict:
        dynamic  = sum(1 for b in self.bodies.values() if b.body_type == BodyType.DYNAMIC)
        static   = sum(1 for b in self.bodies.values() if b.body_type == BodyType.STATIC)
        sleeping = sum(1 for b in self.bodies.values() if b.is_sleeping)
        return {
            "total_bodies":   len(self.bodies),
            "dynamic":        dynamic,
            "static":         static,
            "sleeping":       sleeping,
            "constraints":    len(self.constraints),
            "tick":           self._tick,
        }

    def __repr__(self) -> str:
        s = self.stats
        return (f"PhysicsWorld(bodies={s['total_bodies']}, "
                f"dynamic={s['dynamic']}, tick={s['tick']})")
