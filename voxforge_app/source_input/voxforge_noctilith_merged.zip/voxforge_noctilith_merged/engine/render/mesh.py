"""
engine/render/mesh.py
======================
Voxelové meshování — Greedy Meshing algoritmus.

Blueprint §2.2: "jednoduché meshování"
Blueprint §17: "jednoduchý renderer/debug přes pyglet, pygame, moderngl"

Implementuje:
  - Naivní meshování (jeden quad per viditelná stěna voxelu)
  - Greedy Meshing (merge sousedních stejných ploch → méně polygonů)
  - Ambient Occlusion sampling
  - Per-material UV koordináty a barvy
  - Výstup: vertex buffer + index buffer kompatibilní s OpenGL

Výstup mesh formátu:
  Vertices: [x, y, z, nx, ny, nz, u, v, r, g, b, ao] per vertex
  Indices:  [i0, i1, i2, i0, i2, i3] per quad (2 trojúhelníky)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np


# ─── Materiální vizuální data ─────────────────────────────────────────────────

MAT_COLORS: Dict[int, Tuple[float,float,float]] = {
    0:  (0.0, 0.0, 0.0),      # vzduch (neviditelný)
    1:  (0.47, 0.45, 0.43),   # stone
    2:  (0.39, 0.27, 0.20),   # dirt
    3:  (0.76, 0.70, 0.50),   # sand
    4:  (0.55, 0.35, 0.17),   # wood
    5:  (0.78, 0.86, 0.94),   # glass
    6:  (0.71, 0.73, 0.76),   # metal
    7:  (0.63, 0.62, 0.61),   # concrete
    8:  (0.71, 0.84, 0.94),   # ice
    9:  (0.86, 0.31, 0.08),   # lava
    10: (0.16, 0.39, 0.78),   # water
    11: (0.12, 0.12, 0.12),   # coal
    12: (0.78, 0.80, 0.84),   # titanium
}

# Emit pro materiály (světelný zdroj)
MAT_EMIT: Dict[int, float] = {
    9: 1.0,    # lava svítí
}


# ─── Mesh data ────────────────────────────────────────────────────────────────

@dataclass
class MeshData:
    """Výsledný mesh pro jeden chunk."""
    vertices: np.ndarray    # (N, 12) float32: x,y,z, nx,ny,nz, u,v, r,g,b, ao
    indices:  np.ndarray    # (M,) uint32
    chunk_pos: Tuple[int,int,int] = (0, 0, 0)
    vertex_count: int = 0
    triangle_count: int = 0
    is_empty: bool = True

    def __post_init__(self):
        self.vertex_count = len(self.vertices)
        self.triangle_count = len(self.indices) // 3
        self.is_empty = self.vertex_count == 0


# ─── Stěny voxelu (6 normál) ─────────────────────────────────────────────────

# (dx, dy, dz) normálové vektory pro každou ze 6 stěn
FACE_NORMALS = [
    ( 0,  1,  0),   # TOP
    ( 0, -1,  0),   # BOTTOM
    ( 1,  0,  0),   # EAST
    (-1,  0,  0),   # WEST
    ( 0,  0,  1),   # NORTH
    ( 0,  0, -1),   # SOUTH
]

# Vertex offsets pro každou stěnu (4 rohy quadu, CCW z venku)
FACE_VERTS = [
    # TOP (+y)
    [(0,1,0),(1,1,0),(1,1,1),(0,1,1)],
    # BOTTOM (-y)
    [(0,0,1),(1,0,1),(1,0,0),(0,0,0)],
    # EAST (+x)
    [(1,0,0),(1,1,0),(1,1,1),(1,0,1)],
    # WEST (-x)
    [(0,0,1),(0,1,1),(0,1,0),(0,0,0)],
    # NORTH (+z)
    [(1,0,1),(1,1,1),(0,1,1),(0,0,1)],
    # SOUTH (-z)
    [(0,0,0),(0,1,0),(1,1,0),(1,0,0)],
]

# UV souřadnice pro každý roh quadu
FACE_UVS = [(0,0),(0,1),(1,1),(1,0)]

# Offsety sousedních voxelů pro každou stěnu
FACE_NEIGHBORS = FACE_NORMALS


# ─── Naivní mesher ────────────────────────────────────────────────────────────

class NaiveMesher:
    """
    Naivní meshing — jeden quad pro každou viditelnou stěnu voxelu.
    Jednoduchý ale produkuje mnoho polygonů.
    Použití: debug, malé chunky.
    """

    def mesh(self, materials: np.ndarray,
             chunk_x: int = 0, chunk_y: int = 0, chunk_z: int = 0) -> MeshData:
        """
        Vytvoří mesh z numpy materiálového gridu.
        materials: (sx, sy, sz) uint8 pole material_id.
        Vrátí MeshData.
        """
        sx, sy, sz = materials.shape
        verts: List[List[float]] = []
        idxs:  List[int]         = []
        vi = 0   # vertex index counter

        for x in range(sx):
            for y in range(sy):
                for z in range(sz):
                    mat = int(materials[x, y, z])
                    if mat == 0:
                        continue   # vzduch = přeskočit

                    r, g, b = MAT_COLORS.get(mat, (0.5, 0.5, 0.5))
                    emit = MAT_EMIT.get(mat, 0.0)

                    for face_idx, (nx, ny, nz) in enumerate(FACE_NORMALS):
                        # Sousední voxel
                        nx2, ny2, nz2 = x+nx, y+ny, z+nz
                        if (0 <= nx2 < sx and 0 <= ny2 < sy and 0 <= nz2 < sz):
                            if materials[nx2, ny2, nz2] != 0:
                                continue  # soused je solid = stěna není viditelná
                        # Přidej quad
                        ao_vals = self._compute_ao(materials, x, y, z,
                                                   face_idx, sx, sy, sz)
                        for corner_idx, (vx, vy, vz) in enumerate(FACE_VERTS[face_idx]):
                            u, v = FACE_UVS[corner_idx]
                            ao = ao_vals[corner_idx]
                            # AO tmavost
                            shade = 1.0 - ao * 0.25
                            # Směrové osvětlení (simulace)
                            light = max(0.3, abs(nx)*0.6 + abs(ny)*1.0 + abs(nz)*0.7)
                            fr = r * shade * light
                            fg = g * shade * light
                            fb = b * shade * light
                            verts.append([
                                float(x + vx + chunk_x),
                                float(y + vy + chunk_y),
                                float(z + vz + chunk_z),
                                float(nx), float(ny), float(nz),
                                float(u), float(v),
                                min(1.0, fr + emit * r),
                                min(1.0, fg + emit * g),
                                min(1.0, fb + emit * b),
                                float(ao),
                            ])
                        # 2 trojúhelníky z quadu (0,1,2, 0,2,3)
                        idxs.extend([vi, vi+1, vi+2, vi, vi+2, vi+3])
                        vi += 4

        if not verts:
            return MeshData(
                vertices=np.zeros((0,12), dtype=np.float32),
                indices=np.zeros(0, dtype=np.uint32),
                chunk_pos=(chunk_x, chunk_y, chunk_z),
            )

        return MeshData(
            vertices=np.array(verts, dtype=np.float32),
            indices=np.array(idxs, dtype=np.uint32),
            chunk_pos=(chunk_x, chunk_y, chunk_z),
        )

    def _compute_ao(self, materials: np.ndarray,
                    x: int, y: int, z: int,
                    face_idx: int, sx: int, sy: int, sz: int) -> List[float]:
        """
        Ambient Occlusion pro 4 rohy quadu.
        Každý roh je AO dle 3 sousedních voxelů (side1, side2, corner).
        Vrátí [ao0, ao1, ao2, ao3] kde ao ∈ [0,3].
        """
        nx, ny, nz = FACE_NORMALS[face_idx]
        ao_values = []

        for corner_idx, (vx, vy, vz) in enumerate(FACE_VERTS[face_idx]):
            # Lokální roh relativně ke středu voxelu
            lx = vx - 0.5; ly = vy - 0.5; lz = vz - 0.5
            # Dva sousedé podél stěny + roh
            # Zjednodušení: jen počítáme bloky kolem rohu
            ao = 0
            check_offsets = []
            if nx == 0:  # stěna v X rovině
                for dx in [-1, 0, 1]:
                    for dy in [-1, 0, 1]:
                        if dx == 0 and dy == 0:
                            continue
                        check_offsets.append((x + dx, y + nz * int(round(lz)) + dy, z + nz))
            # Zjednodušení: jen blízké bloky
            for (cx, cy, cz) in check_offsets[:3]:
                if 0 <= cx < sx and 0 <= cy < sy and 0 <= cz < sz:
                    if materials[cx, cy, cz] != 0:
                        ao += 1
            ao_values.append(float(min(ao, 3)))

        return ao_values


# ─── Greedy Mesher ────────────────────────────────────────────────────────────

class GreedyMesher:
    """
    Greedy Meshing algoritmus pro efektivní voxelové renderování.

    Princip:
    1. Pro každou osu (x, y, z) a každý slice procházej plochu
    2. Najdi viditelné stěny (solid × vzduch)
    3. Sloučí sousední stěny se stejným materiálem do jednoho velkého quadu
    4. Mnohem méně polygonů než naivní meshing

    Výkonnost:
    - O(n²) per slice kde n = chunk_size
    - Typicky 5-20x méně polygonů než naivní meshing
    - Vhodné pro velké, monotónní plochy (terén, stěny)
    """

    def mesh(self, materials: np.ndarray,
             chunk_x: int = 0, chunk_y: int = 0, chunk_z: int = 0) -> MeshData:
        """Greedy mesh celého chunku."""
        verts: List[List[float]] = []
        idxs:  List[int]         = []
        vi = 0

        dims = list(materials.shape)    # [sx, sy, sz]

        for axis in range(3):
            u_axis = (axis + 1) % 3
            v_axis = (axis + 2) % 3
            dim = dims[axis]
            u_dim = dims[u_axis]
            v_dim = dims[v_axis]

            # Normály pro forward/backward stěny
            for backface in [False, True]:
                mask = np.zeros((u_dim, v_dim), dtype=np.int32)
                pos = [0, 0, 0]

                for d in range(dim):
                    pos[axis] = d
                    # Vytvoř masku pro tento slice
                    for u in range(u_dim):
                        for v in range(v_dim):
                            pos[u_axis] = u
                            pos[v_axis] = v
                            x, y, z = pos

                            # Aktuální blok
                            cur = int(materials[x, y, z]) if (
                                0 <= x < dims[0] and 0 <= y < dims[1] and 0 <= z < dims[2]
                            ) else 0

                            # Soused v ose
                            np_ = [x, y, z]
                            np_[axis] += -1 if backface else 1
                            nx, ny, nz = np_
                            nxt = int(materials[nx, ny, nz]) if (
                                0 <= nx < dims[0] and 0 <= ny < dims[1] and 0 <= nz < dims[2]
                            ) else 0

                            if not backface:
                                # Stěna kde cur=solid, nxt=vzduch
                                mask[u, v] = cur if (cur != 0 and nxt == 0) else 0
                            else:
                                # Stěna kde cur=vzduch, nxt=solid
                                mask[u, v] = nxt if (cur == 0 and nxt != 0) else 0

                    # Greedy merge
                    u = 0
                    while u < u_dim:
                        v = 0
                        while v < v_dim:
                            mat = mask[u, v]
                            if mat == 0:
                                v += 1
                                continue
                            # Šířka (u-směr)
                            w = 1
                            while u + w < u_dim and mask[u+w, v] == mat:
                                w += 1
                            # Výška (v-směr)
                            h = 1
                            done = False
                            while v + h < v_dim and not done:
                                for k in range(w):
                                    if mask[u+k, v+h] != mat:
                                        done = True
                                        break
                                if not done:
                                    h += 1

                            # Emit quad
                            pos[u_axis] = u
                            pos[v_axis] = v
                            pos[axis] = d + (0 if not backface else 0)

                            # 4 rohy quadu
                            vert_positions = []
                            for (du, dv) in [(0,0),(w,0),(w,h),(0,h)]:
                                vp = [float(pos[0]), float(pos[1]), float(pos[2])]
                                vp[u_axis] += du
                                vp[v_axis] += dv
                                vp[axis] += 0 if backface else 1
                                vert_positions.append(vp)

                            # Normála
                            norm = [0.0, 0.0, 0.0]
                            norm[axis] = -1.0 if backface else 1.0
                            r, g, b = MAT_COLORS.get(mat, (0.5, 0.5, 0.5))
                            emit = MAT_EMIT.get(mat, 0.0)
                            light = max(0.3, abs(norm[0])*0.6 + abs(norm[1])*1.0 + abs(norm[2])*0.7)

                            for ci, (vp, (fu, fv)) in enumerate(zip(vert_positions, FACE_UVS)):
                                verts.append([
                                    vp[0] + chunk_x,
                                    vp[1] + chunk_y,
                                    vp[2] + chunk_z,
                                    norm[0], norm[1], norm[2],
                                    float(fu) * (w if u_axis == 0 else h),
                                    float(fv) * (h if v_axis == 2 else w),
                                    min(1.0, r * light + emit * r),
                                    min(1.0, g * light + emit * g),
                                    min(1.0, b * light + emit * b),
                                    0.0,   # AO (TODO)
                                ])
                            if backface:
                                idxs.extend([vi, vi+2, vi+1, vi, vi+3, vi+2])
                            else:
                                idxs.extend([vi, vi+1, vi+2, vi, vi+2, vi+3])
                            vi += 4

                            # Vymaž zpracovanou oblast z masky
                            for ku in range(w):
                                for kv in range(h):
                                    mask[u+ku, v+kv] = 0

                            v += h
                        u += 1

        if not verts:
            return MeshData(
                vertices=np.zeros((0,12), dtype=np.float32),
                indices=np.zeros(0, dtype=np.uint32),
                chunk_pos=(chunk_x, chunk_y, chunk_z),
            )

        return MeshData(
            vertices=np.array(verts, dtype=np.float32),
            indices=np.array(idxs, dtype=np.uint32),
            chunk_pos=(chunk_x, chunk_y, chunk_z),
        )


# ─── Mesh Manager ─────────────────────────────────────────────────────────────

class MeshManager:
    """
    Spravuje meshe pro všechny načtené chunky.
    Automaticky přemeshuje dirty chunky.

    Blueprint §2.2: "jednoduché meshování"
    """

    def __init__(self, use_greedy: bool = True):
        self._mesher = GreedyMesher() if use_greedy else NaiveMesher()
        self._meshes: Dict[Tuple[int,int,int], MeshData] = {}
        self._dirty: set = set()
        self._total_vertices = 0
        self._total_triangles = 0

    def mark_dirty(self, cx: int, cy: int, cz: int) -> None:
        """Označ chunk jako potřebující přemeshování."""
        self._dirty.add((cx, cy, cz))
        # Okolní chunky také potřebují update (hranice)
        for dx, dy, dz in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]:
            self._dirty.add((cx+dx, cy+dy, cz+dz))

    def update_chunk(self, cx: int, cy: int, cz: int,
                     materials: np.ndarray) -> MeshData:
        """Přemeshuj konkrétní chunk."""
        mesh = self._mesher.mesh(materials,
                                 chunk_x=cx * materials.shape[0],
                                 chunk_y=cy * materials.shape[1],
                                 chunk_z=cz * materials.shape[2])
        self._meshes[(cx, cy, cz)] = mesh
        self._dirty.discard((cx, cy, cz))
        self._update_stats()
        return mesh

    def update_dirty(self, world) -> int:
        """
        Přemeshuje všechny dirty chunky ze světa.
        Vrátí počet přemeshovaných chunků.
        """
        updated = 0
        for (cx, cy, cz) in list(self._dirty):
            chunk = world.get_chunk(cx, cy, cz, create=False)
            if chunk is not None:
                self.update_chunk(cx, cy, cz, chunk.materials)
                updated += 1
        return updated

    def get_mesh(self, cx: int, cy: int, cz: int) -> Optional[MeshData]:
        return self._meshes.get((cx, cy, cz))

    def all_meshes(self) -> List[MeshData]:
        return [m for m in self._meshes.values() if not m.is_empty]

    def _update_stats(self) -> None:
        self._total_vertices  = sum(m.vertex_count for m in self._meshes.values())
        self._total_triangles = sum(m.triangle_count for m in self._meshes.values())

    @property
    def stats(self) -> dict:
        return {
            "chunks_meshed":   len(self._meshes),
            "dirty_chunks":    len(self._dirty),
            "total_vertices":  self._total_vertices,
            "total_triangles": self._total_triangles,
            "using_greedy":    isinstance(self._mesher, GreedyMesher),
        }
