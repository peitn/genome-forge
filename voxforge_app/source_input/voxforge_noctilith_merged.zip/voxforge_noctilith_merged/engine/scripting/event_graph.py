"""
engine/scripting/event_graph.py
================================
Vizuální Event Graph — systém triggerů a akcí pro scriptovatele.

Blueprint §7.1: "Visual Event Graph pro neprogramátory"
  Triggery: OnEnterZone, OnButtonPress, OnFluidLevelAbove,
            OnTemperatureAbove, OnObjectDestroyed, ...
  Akce: SpawnObject, PlaySound, OpenDoor, ChangeMaterial,
        TriggerSimulation, ActivatePump, EmitGas, ...

Blueprint §7.3: "Behavior Components"
  DoorBehavior, PumpBehavior, VehicleBehavior,
  FluidValveBehavior, HeatSourceBehavior,
  AIWanderBehavior, DestructibleBehavior
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple


# ── Trigger podmínky ──────────────────────────────────────────────────────────

@dataclass
class Trigger:
    """
    Podmínka která aktivuje akci.
    Blueprint §7.1 — built-in triggery.
    """
    trigger_id: str
    trigger_type: str     # typ (viz TRIGGER_TYPES)
    params: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    cooldown_ticks: int = 0     # minimální čas mezi aktivacemi
    _last_fired: int = field(default=-9999, init=False, repr=False)

    def can_fire(self, tick: int) -> bool:
        return self.enabled and (tick - self._last_fired) >= self.cooldown_ticks

    def mark_fired(self, tick: int) -> None:
        self._last_fired = tick


# Built-in trigger typy (blueprint §7.1)
TRIGGER_TYPES = {
    "on_enter_zone":         "Hráč/agent vstoupí do zóny",
    "on_leave_zone":         "Hráč/agent opustí zónu",
    "on_button_press":       "Hráč zmáčkne tlačítko",
    "on_fluid_level_above":  "Hladina kapaliny > threshold",
    "on_fluid_level_below":  "Hladina kapaliny < threshold",
    "on_temperature_above":  "Teplota v zóně > threshold",
    "on_temperature_below":  "Teplota v zóně < threshold",
    "on_object_destroyed":   "Voxel/objekt je zničen",
    "on_pressure_high":      "Tlak v systému > threshold",
    "on_energy_on":          "Obvod dostane proud",
    "on_energy_off":         "Obvod ztratí proud",
    "on_tick":               "Každých N ticků",
    "on_gas_detected":       "Plyn > threshold v zóně",
    "on_damage_above":       "Poškození objektu > threshold",
    "on_entity_spawned":     "Entita se spawne v zóně",
    "on_entity_died":        "Entita zemře v zóně",
    "on_weather_changed":    "Počasí se změní na typ",
}


# ── Akce ─────────────────────────────────────────────────────────────────────

@dataclass
class Action:
    """
    Akce provedená po spuštění triggeru.
    Blueprint §7.1 — built-in akce.
    """
    action_id: str
    action_type: str
    params: Dict[str, Any] = field(default_factory=dict)
    delay_ticks: int = 0     # zpoždění akce
    enabled: bool = True


# Built-in action typy (blueprint §7.1)
ACTION_TYPES = {
    "spawn_object":        "Spawni voxelový objekt na pozici",
    "destroy_object":      "Zniš voxel/objekt",
    "play_sound":          "Přehraj zvuk",
    "open_door":           "Otevři dveře (DoorBehavior)",
    "close_door":          "Zavři dveře",
    "change_material":     "Změň materiál voxelu",
    "trigger_simulation":  "Spusť/pozastav SimModule",
    "activate_pump":       "Aktivuj pumpu (PumpBehavior)",
    "emit_gas":            "Emituj plyn na pozici",
    "add_fluid":           "Přidej kapalinu na pozici",
    "set_temperature":     "Nastav teplotu v oblasti",
    "send_signal":         "Pošli signál jiné logice",
    "set_switch":          "Přepni elektrický switch",
    "spawn_entity":        "Spawni AI agenta",
    "set_weather":         "Přepni počasí",
    "camera_shake":        "Třes kamerou (game mode)",
    "show_message":        "Zobraz zprávu hráči",
    "give_item":           "Dej hráči předmět do inventáře",
    "teleport_player":     "Teleportuj hráče na pozici",
    "win_condition":       "Spusť win/lose podmínku",
}


# ── Event Graf ────────────────────────────────────────────────────────────────

@dataclass
class GraphNode:
    """Jeden uzel v event grafu."""
    node_id: str
    trigger: Trigger
    actions: List[Action] = field(default_factory=list)
    output_nodes: List[str] = field(default_factory=list)    # kaskáda


class EventGraph:
    """
    Vizuální Event Graph — srdce scriptovacího systému.

    Uzel = Trigger + seznam Akcí.
    Kaskáda: jedna akce může spustit další trigger.

    Blueprint §7.1: "event graph, jednoduché skripty, trigger zóny,
                     chování objektů, AI pravidla"

    Použití:
        graph = EventGraph(bus)
        graph.add_node("door_trigger",
            trigger=Trigger("t1", "on_button_press", {"button_id": "btn_door"}),
            actions=[Action("a1", "open_door", {"door_id": "door_main"})]
        )
        graph.evaluate(tick, world_state)
    """

    def __init__(self, bus=None):
        self.nodes: Dict[str, GraphNode] = {}
        self.bus = bus
        self._action_handlers: Dict[str, Callable] = {}
        self._pending_actions: List[Tuple[int, Action]] = []  # (fire_tick, action)

    def add_node(self, node_id: str, trigger: Trigger,
                 actions: Optional[List[Action]] = None) -> GraphNode:
        node = GraphNode(node_id=node_id, trigger=trigger, actions=actions or [])
        self.nodes[node_id] = node
        return node

    def register_handler(self, action_type: str, fn: Callable) -> None:
        """Zaregistruj Python handler pro typ akce."""
        self._action_handlers[action_type] = fn

    def evaluate(self, tick: int, world_state: dict) -> List[dict]:
        """
        Vyhodnoť všechny triggery na základě world_state.
        world_state: slovník s aktuálním stavem světa.
        """
        fired: List[dict] = []

        # Vykonej čekající akce
        still_pending = []
        for (fire_tick, action) in self._pending_actions:
            if tick >= fire_tick:
                result = self._execute_action(action, world_state, tick)
                if result:
                    fired.append(result)
            else:
                still_pending.append((fire_tick, action))
        self._pending_actions = still_pending

        # Vyhodnoť triggery
        for node in self.nodes.values():
            t = node.trigger
            if not t.can_fire(tick):
                continue

            if self._check_trigger(t, world_state, tick):
                t.mark_fired(tick)

                for action in node.actions:
                    if not action.enabled:
                        continue
                    if action.delay_ticks > 0:
                        self._pending_actions.append((tick + action.delay_ticks, action))
                    else:
                        result = self._execute_action(action, world_state, tick)
                        if result:
                            fired.append(result)

                # Kaskáda na output nodes
                for out_id in node.output_nodes:
                    out_node = self.nodes.get(out_id)
                    if out_node:
                        for action in out_node.actions:
                            result = self._execute_action(action, world_state, tick)
                            if result:
                                fired.append(result)

        return fired

    def _check_trigger(self, t: Trigger, ws: dict, tick: int) -> bool:
        """Zkontroluj zda je trigger aktivní."""
        tt = t.trigger_type
        p = t.params

        if tt == "on_tick":
            every = p.get("every", 1)
            return tick % every == 0

        elif tt == "on_fluid_level_above":
            level = ws.get("fluid_max", 0.0)
            return float(level) > float(p.get("threshold", 0.5))

        elif tt == "on_fluid_level_below":
            level = ws.get("fluid_total", 0.0)
            return float(level) < float(p.get("threshold", 0.1))

        elif tt == "on_temperature_above":
            temp = ws.get("thermal_max", 0.0)
            return float(temp) > float(p.get("threshold", 0.7))

        elif tt == "on_temperature_below":
            temp = ws.get("thermal_min", 1.0)
            return float(temp) < float(p.get("threshold", 0.1))

        elif tt == "on_object_destroyed":
            events = ws.get("recent_events", [])
            return "voxel_destroyed" in events or "material_fractured" in events

        elif tt == "on_energy_on":
            powered = ws.get("powered_nodes", set())
            return p.get("node_id", "") in powered

        elif tt == "on_energy_off":
            powered = ws.get("powered_nodes", set())
            return p.get("node_id", "") not in powered

        elif tt == "on_gas_detected":
            gas_level = ws.get("gas_concentration_max", 0.0)
            return float(gas_level) > float(p.get("threshold", 0.3))

        elif tt == "on_damage_above":
            dmg = ws.get("max_damage", 0.0)
            return float(dmg) > float(p.get("threshold", 0.5))

        elif tt == "on_weather_changed":
            return ws.get("weather") == p.get("weather_type", "rain")

        elif tt == "on_button_press":
            pressed = ws.get("buttons_pressed", set())
            return p.get("button_id", "__none__") in pressed

        elif tt == "on_enter_zone":
            zone_id = p.get("zone_id", "")
            agents_in_zones = ws.get("agents_in_zones", {})
            return bool(agents_in_zones.get(zone_id, False))

        elif tt == "on_pressure_high":
            return ws.get("fluid_pressure_high", False)

        return False

    def _execute_action(self, action: Action, ws: dict, tick: int) -> Optional[dict]:
        """Vykonej akci — zavolej registrovaný handler nebo vrátí event."""
        handler = self._action_handlers.get(action.action_type)
        if handler:
            try:
                handler(action.params, ws)
            except Exception as e:
                return {"type": "action_error", "action": action.action_id, "error": str(e)}

        return {
            "type": "action_fired",
            "action_type": action.action_type,
            "action_id": action.action_id,
            "tick": tick,
            "params": action.params,
        }

    def save(self, path: Path) -> None:
        data = {nid: asdict(n) for nid, n in self.nodes.items()}
        Path(path).write_text(json.dumps(data, indent=2))

    def __len__(self) -> int:
        return len(self.nodes)


# ── Behavior Components (blueprint §7.3) ─────────────────────────────────────

class BehaviorComponent:
    """Základní třída pro behavior komponenty."""
    def __init__(self, entity_id: str, graph: EventGraph):
        self.entity_id = entity_id
        self.graph = graph

    def tick(self, tick: int, world_state: dict) -> List[dict]:
        return []


class DoorBehavior(BehaviorComponent):
    """Blueprint §7.3: DoorBehavior"""
    def __init__(self, entity_id: str, graph: EventGraph,
                 open_pos: Tuple[int,int,int], closed_pos: Tuple[int,int,int]):
        super().__init__(entity_id, graph)
        self.open_pos = open_pos
        self.closed_pos = closed_pos
        self.is_open = False
        self.locked = False

    def open(self) -> bool:
        if self.locked:
            return False
        self.is_open = True
        return True

    def close(self) -> None:
        self.is_open = False

    def toggle(self) -> bool:
        if self.is_open:
            self.close()
        else:
            self.open()
        return self.is_open


class PumpBehavior(BehaviorComponent):
    """Blueprint §7.3: PumpBehavior"""
    def __init__(self, entity_id: str, graph: EventGraph,
                 flow_rate: float = 0.2, requires_energy: bool = True):
        super().__init__(entity_id, graph)
        self.flow_rate = flow_rate
        self.requires_energy = requires_energy
        self.active = False
        self.direction = (0, -1, 0)   # výchozí: pumpuje dolů

    def tick(self, tick: int, world_state: dict) -> List[dict]:
        if self.requires_energy:
            powered = world_state.get("powered_nodes", set())
            self.active = self.entity_id in powered
        if self.active:
            return [{"type": "pump_flow", "entity": self.entity_id,
                     "rate": self.flow_rate, "dir": self.direction}]
        return []


class FluidValveBehavior(BehaviorComponent):
    """Blueprint §7.3: FluidValveBehavior"""
    def __init__(self, entity_id: str, graph: EventGraph):
        super().__init__(entity_id, graph)
        self.open = False
        self.max_flow = 0.5

    def set_open(self, open: bool) -> None:
        self.open = open

    def tick(self, tick: int, world_state: dict) -> List[dict]:
        if not self.open:
            return [{"type": "valve_closed", "entity": self.entity_id}]
        return [{"type": "valve_open", "entity": self.entity_id, "flow": self.max_flow}]


class HeatSourceBehavior(BehaviorComponent):
    """Blueprint §7.3: HeatSourceBehavior"""
    def __init__(self, entity_id: str, graph: EventGraph,
                 heat_output: float = 0.1, radius: int = 3):
        super().__init__(entity_id, graph)
        self.heat_output = heat_output
        self.radius = radius
        self.active = True

    def tick(self, tick: int, world_state: dict) -> List[dict]:
        if not self.active:
            return []
        return [{"type": "heat_emit", "entity": self.entity_id,
                 "output": self.heat_output, "radius": self.radius}]


class DestructibleBehavior(BehaviorComponent):
    """Blueprint §7.3: DestructibleBehavior"""
    def __init__(self, entity_id: str, graph: EventGraph,
                 max_health: float = 1.0):
        super().__init__(entity_id, graph)
        self.max_health = max_health
        self.health = max_health
        self.destroyed = False

    def apply_damage(self, amount: float) -> bool:
        """Vrátí True pokud byl objekt právě zničen."""
        self.health = max(0.0, self.health - amount)
        if self.health <= 0 and not self.destroyed:
            self.destroyed = True
            return True
        return False


class AIWanderBehavior(BehaviorComponent):
    """Blueprint §7.3: AIWanderBehavior"""
    def __init__(self, entity_id: str, graph: EventGraph,
                 wander_radius: int = 8, speed: float = 1.0):
        super().__init__(entity_id, graph)
        self.wander_radius = wander_radius
        self.speed = speed
        self.target: Optional[Tuple[int,int,int]] = None

    def tick(self, tick: int, world_state: dict) -> List[dict]:
        if tick % int(max(1, 10 / self.speed)) == 0:
            # Vyber nový cíl každých N ticků
            return [{"type": "ai_wander", "entity": self.entity_id,
                     "radius": self.wander_radius}]
        return []
