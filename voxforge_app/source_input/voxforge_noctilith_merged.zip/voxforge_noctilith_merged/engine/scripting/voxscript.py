"""
engine/scripting/voxscript.py
==============================
VoxScript — jednoduchý sandboxovaný DSL pro VoxForge platformu.

Blueprint §7.2: "textový scripting — Python-like DSL, Lua-like scripting,
                  nebo vlastní VoxScript. Musí být sandboxovaný."

Gramatika VoxScript (EBNF):
    program     = { statement }
    statement   = assignment | if_stmt | while_stmt | on_stmt
                | call_stmt | emit_stmt | wait_stmt | comment
    assignment  = IDENT '=' expr NEWLINE
    if_stmt     = 'if' expr ':' NEWLINE block [ 'else' ':' NEWLINE block ]
    while_stmt  = 'while' expr ':' NEWLINE block
    on_stmt     = 'on' EVENT_TYPE ':' NEWLINE block
    call_stmt   = IDENT '(' [ arglist ] ')' NEWLINE
    emit_stmt   = 'emit' EVENT_TYPE [ expr ] NEWLINE
    wait_stmt   = 'wait' expr NEWLINE
    block       = { '    ' statement }   // 4-space indent
    expr        = or_expr
    or_expr     = and_expr { 'or' and_expr }
    and_expr    = not_expr { 'and' not_expr }
    not_expr    = [ 'not' ] compare_expr
    compare_expr = add_expr { CMP_OP add_expr }
    add_expr    = mul_expr { ('+' | '-') mul_expr }
    mul_expr    = unary_expr { ('*' | '/') unary_expr }
    unary_expr  = [ '-' ] primary
    primary     = NUMBER | STRING | BOOL | IDENT | '(' expr ')'
                | IDENT '.' IDENT | IDENT '[' expr ']'

Příklad skriptu:
    # Kontrola teploty každý tick
    on tick:
        temp = world.get_temperature(8, 4, 8)
        if temp > 0.7:
            emit thermal_alert temp
            call activate_pump()
            wait 50

    on fluid_filled:
        door_open = true
        call open_door(main_door)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple


# ─── Token typy ──────────────────────────────────────────────────────────────

class TT(str, Enum):
    NUMBER   = "NUMBER"
    STRING   = "STRING"
    BOOL     = "BOOL"
    IDENT    = "IDENT"
    NEWLINE  = "NEWLINE"
    INDENT   = "INDENT"
    DEDENT   = "DEDENT"
    EOF      = "EOF"
    # Operátory
    PLUS = "+"; MINUS = "-"; STAR = "*"; SLASH = "/"
    EQ = "=="; NEQ = "!="; LT = "<"; GT = ">"; LEQ = "<="; GEQ = ">="
    ASSIGN = "="; LPAREN = "("; RPAREN = ")"; LBRACKET = "["; RBRACKET = "]"
    DOT = "."; COMMA = ","
    COLON = ":"
    # Klíčová slova
    IF = "if"; ELSE = "else"; WHILE = "while"; ON = "on"
    AND = "and"; OR = "or"; NOT = "not"
    EMIT = "emit"; WAIT = "wait"; CALL = "call"
    RETURN = "return"; BREAK = "break"
    TRUE = "true"; FALSE = "false"
    COMMENT = "COMMENT"


KEYWORDS = {
    "if": TT.IF, "else": TT.ELSE, "while": TT.WHILE, "on": TT.ON,
    "and": TT.AND, "or": TT.OR, "not": TT.NOT,
    "emit": TT.EMIT, "wait": TT.WAIT, "call": TT.CALL,
    "return": TT.RETURN, "break": TT.BREAK,
    "true": TT.TRUE, "false": TT.FALSE,
}


@dataclass
class Token:
    type: TT
    value: Any
    line: int


# ─── Lexer ────────────────────────────────────────────────────────────────────

class VoxLexer:
    """
    Tokenizátor pro VoxScript.
    Zpracovává Python-style odsazení (INDENT/DEDENT tokeny).
    """

    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self._tokens: List[Token] = []
        self._indent_stack = [0]

    def tokenize(self) -> List[Token]:
        lines = self.source.split('\n')
        tokens: List[Token] = []

        for line_no, raw_line in enumerate(lines, 1):
            # Komentáře
            if raw_line.strip().startswith('#') or raw_line.strip() == '':
                if raw_line.strip() == '':
                    tokens.append(Token(TT.NEWLINE, '\n', line_no))
                continue

            # Indentation
            stripped = raw_line.lstrip()
            indent = len(raw_line) - len(stripped)
            current_indent = self._indent_stack[-1]

            if indent > current_indent:
                self._indent_stack.append(indent)
                tokens.append(Token(TT.INDENT, indent, line_no))
            while indent < self._indent_stack[-1]:
                self._indent_stack.pop()
                tokens.append(Token(TT.DEDENT, self._indent_stack[-1], line_no))

            # Tokenizuj řádek
            toks = self._tokenize_line(stripped, line_no)
            tokens.extend(toks)
            tokens.append(Token(TT.NEWLINE, '\n', line_no))

        # Uzavři otevřené INDENT bloky
        while len(self._indent_stack) > 1:
            self._indent_stack.pop()
            tokens.append(Token(TT.DEDENT, 0, len(lines)))

        tokens.append(Token(TT.EOF, None, len(lines) + 1))
        return tokens

    def _tokenize_line(self, line: str, line_no: int) -> List[Token]:
        tokens: List[Token] = []
        i = 0
        while i < len(line):
            ch = line[i]

            # Whitespace (uvnitř řádku)
            if ch == ' ' or ch == '\t':
                i += 1
                continue

            # Komentář
            if ch == '#':
                break

            # Číslo
            if ch.isdigit() or (ch == '-' and i+1 < len(line) and line[i+1].isdigit()):
                j = i + 1 if ch == '-' else i
                while j < len(line) and (line[j].isdigit() or line[j] == '.'):
                    j += 1
                num_str = line[i:j]
                val = float(num_str) if '.' in num_str else int(num_str)
                tokens.append(Token(TT.NUMBER, val, line_no))
                i = j
                continue

            # String
            if ch in ('"', "'"):
                j = i + 1
                while j < len(line) and line[j] != ch:
                    j += 1
                tokens.append(Token(TT.STRING, line[i+1:j], line_no))
                i = j + 1
                continue

            # Identifikátor nebo klíčové slovo
            if ch.isalpha() or ch == '_':
                j = i
                while j < len(line) and (line[j].isalnum() or line[j] == '_'):
                    j += 1
                word = line[i:j]
                tt = KEYWORDS.get(word, TT.IDENT)
                if tt == TT.TRUE:
                    tokens.append(Token(TT.BOOL, True, line_no))
                elif tt == TT.FALSE:
                    tokens.append(Token(TT.BOOL, False, line_no))
                else:
                    tokens.append(Token(tt, word, line_no))
                i = j
                continue

            # Dvou-znakové operátory
            two = line[i:i+2]
            if two in ("==", "!=", "<=", ">="):
                tt_map = {"==": TT.EQ, "!=": TT.NEQ, "<=": TT.LEQ, ">=": TT.GEQ}
                tokens.append(Token(tt_map[two], two, line_no))
                i += 2
                continue

            # Jedno-znakové
            one_map = {
                '+': TT.PLUS, '-': TT.MINUS, '*': TT.STAR, '/': TT.SLASH,
                '=': TT.ASSIGN, '(': TT.LPAREN, ')': TT.RPAREN,
                '[': TT.LBRACKET, ']': TT.RBRACKET,
                '.': TT.DOT, ',': TT.COMMA, ':': TT.COLON,
                '<': TT.LT, '>': TT.GT,
            }
            if ch in one_map:
                tokens.append(Token(one_map[ch], ch, line_no))
                i += 1
                continue

            # Neznámý znak — přeskoč
            i += 1

        return tokens


# ─── AST uzly ────────────────────────────────────────────────────────────────

@dataclass
class ASTNode:
    line: int = 0


@dataclass
class NumberLit(ASTNode):
    value: float = 0.0


@dataclass
class StringLit(ASTNode):
    value: str = ""


@dataclass
class BoolLit(ASTNode):
    value: bool = False


@dataclass
class Identifier(ASTNode):
    name: str = ""


@dataclass
class Attribute(ASTNode):
    obj: ASTNode = None
    attr: str = ""


@dataclass
class Subscript(ASTNode):
    obj: ASTNode = None
    index: ASTNode = None


@dataclass
class BinOp(ASTNode):
    op: str = ""
    left: ASTNode = None
    right: ASTNode = None


@dataclass
class UnaryOp(ASTNode):
    op: str = ""
    operand: ASTNode = None


@dataclass
class Assignment(ASTNode):
    target: str = ""
    value: ASTNode = None


@dataclass
class CallExpr(ASTNode):
    func: str = ""
    args: List[ASTNode] = field(default_factory=list)


@dataclass
class IfStmt(ASTNode):
    condition: ASTNode = None
    then_block: List[ASTNode] = field(default_factory=list)
    else_block: List[ASTNode] = field(default_factory=list)


@dataclass
class WhileStmt(ASTNode):
    condition: ASTNode = None
    body: List[ASTNode] = field(default_factory=list)
    max_iterations: int = 1000   # ochrana proti nekonečné smyčce


@dataclass
class OnStmt(ASTNode):
    event_type: str = ""
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class EmitStmt(ASTNode):
    event_type: str = ""
    value: Optional[ASTNode] = None


@dataclass
class WaitStmt(ASTNode):
    ticks: ASTNode = None


@dataclass
class ReturnStmt(ASTNode):
    value: Optional[ASTNode] = None


@dataclass
class BreakStmt(ASTNode):
    pass


# ─── Parser ───────────────────────────────────────────────────────────────────

class ParseError(Exception):
    def __init__(self, msg: str, line: int):
        super().__init__(f"[VoxScript Line {line}] ParseError: {msg}")
        self.line = line


class VoxParser:
    """
    Rekurzivní sestupný parser pro VoxScript.
    Produkuje AST seznam příkazů.
    """

    def __init__(self, tokens: List[Token]):
        self.tokens = [t for t in tokens if t.type != TT.COMMENT]
        self.pos = 0

    def current(self) -> Token:
        return self.tokens[self.pos] if self.pos < len(self.tokens) else Token(TT.EOF, None, 0)

    def peek(self, offset: int = 1) -> Token:
        p = self.pos + offset
        return self.tokens[p] if p < len(self.tokens) else Token(TT.EOF, None, 0)

    def consume(self, expected: TT = None) -> Token:
        tok = self.current()
        if expected and tok.type != expected:
            raise ParseError(f"Očekáváno {expected}, nalezeno {tok.type} ('{tok.value}')", tok.line)
        self.pos += 1
        return tok

    def skip_newlines(self) -> None:
        while self.current().type == TT.NEWLINE:
            self.pos += 1

    def parse(self) -> List[ASTNode]:
        stmts = []
        self.skip_newlines()
        while self.current().type != TT.EOF:
            stmt = self.parse_statement()
            if stmt is not None:
                stmts.append(stmt)
            self.skip_newlines()
        return stmts

    def parse_block(self) -> List[ASTNode]:
        """Parsuj odsazený blok."""
        stmts = []
        if self.current().type != TT.INDENT:
            return stmts
        self.consume(TT.INDENT)
        self.skip_newlines()
        while self.current().type not in (TT.DEDENT, TT.EOF):
            stmt = self.parse_statement()
            if stmt is not None:
                stmts.append(stmt)
            self.skip_newlines()
        if self.current().type == TT.DEDENT:
            self.consume(TT.DEDENT)
        return stmts

    def parse_statement(self) -> Optional[ASTNode]:
        tok = self.current()
        line = tok.line

        if tok.type == TT.NEWLINE:
            self.consume()
            return None

        if tok.type == TT.IF:
            return self.parse_if()

        if tok.type == TT.WHILE:
            return self.parse_while()

        if tok.type == TT.ON:
            return self.parse_on()

        if tok.type == TT.EMIT:
            return self.parse_emit()

        if tok.type == TT.WAIT:
            return self.parse_wait()

        if tok.type == TT.CALL:
            return self.parse_call_stmt()

        if tok.type == TT.RETURN:
            return self.parse_return()

        if tok.type == TT.BREAK:
            self.consume(TT.BREAK)
            if self.current().type == TT.NEWLINE:
                self.consume()
            return BreakStmt(line=line)

        # Přiřazení nebo výraz
        if tok.type == TT.IDENT and self.peek().type == TT.ASSIGN:
            return self.parse_assignment()

        # Funkční volání jako příkaz
        if tok.type == TT.IDENT and self.peek().type == TT.LPAREN:
            return self.parse_call_stmt()

        # Fallthrough — parsuj jako výraz (a zahoď)
        expr = self.parse_expr()
        if self.current().type == TT.NEWLINE:
            self.consume()
        return expr

    def parse_if(self) -> IfStmt:
        line = self.current().line
        self.consume(TT.IF)
        condition = self.parse_expr()
        self.consume(TT.COLON)
        if self.current().type == TT.NEWLINE:
            self.consume()
        then_block = self.parse_block()
        else_block = []
        self.skip_newlines()
        if self.current().type == TT.ELSE:
            self.consume(TT.ELSE)
            self.consume(TT.COLON)
            if self.current().type == TT.NEWLINE:
                self.consume()
            else_block = self.parse_block()
        return IfStmt(condition=condition, then_block=then_block,
                      else_block=else_block, line=line)

    def parse_while(self) -> WhileStmt:
        line = self.current().line
        self.consume(TT.WHILE)
        condition = self.parse_expr()
        self.consume(TT.COLON)
        if self.current().type == TT.NEWLINE:
            self.consume()
        body = self.parse_block()
        return WhileStmt(condition=condition, body=body, line=line)

    def parse_on(self) -> OnStmt:
        line = self.current().line
        self.consume(TT.ON)
        evt_tok = self.consume(TT.IDENT)
        self.consume(TT.COLON)
        if self.current().type == TT.NEWLINE:
            self.consume()
        body = self.parse_block()
        return OnStmt(event_type=evt_tok.value, body=body, line=line)

    def parse_assignment(self) -> Assignment:
        line = self.current().line
        name = self.consume(TT.IDENT).value
        self.consume(TT.ASSIGN)
        value = self.parse_expr()
        if self.current().type == TT.NEWLINE:
            self.consume()
        return Assignment(target=name, value=value, line=line)

    def parse_call_stmt(self) -> CallExpr:
        line = self.current().line
        if self.current().type == TT.CALL:
            self.consume(TT.CALL)
        func = self.consume(TT.IDENT).value
        args = []
        if self.current().type == TT.LPAREN:
            self.consume(TT.LPAREN)
            while self.current().type != TT.RPAREN and self.current().type != TT.EOF:
                args.append(self.parse_expr())
                if self.current().type == TT.COMMA:
                    self.consume()
            self.consume(TT.RPAREN)
        if self.current().type == TT.NEWLINE:
            self.consume()
        return CallExpr(func=func, args=args, line=line)

    def parse_emit(self) -> EmitStmt:
        line = self.current().line
        self.consume(TT.EMIT)
        evt = self.consume(TT.IDENT).value
        val = None
        if self.current().type not in (TT.NEWLINE, TT.EOF, TT.DEDENT):
            val = self.parse_expr()
        if self.current().type == TT.NEWLINE:
            self.consume()
        return EmitStmt(event_type=evt, value=val, line=line)

    def parse_wait(self) -> WaitStmt:
        line = self.current().line
        self.consume(TT.WAIT)
        ticks = self.parse_expr()
        if self.current().type == TT.NEWLINE:
            self.consume()
        return WaitStmt(ticks=ticks, line=line)

    def parse_return(self) -> ReturnStmt:
        line = self.current().line
        self.consume(TT.RETURN)
        val = None
        if self.current().type not in (TT.NEWLINE, TT.EOF, TT.DEDENT):
            val = self.parse_expr()
        if self.current().type == TT.NEWLINE:
            self.consume()
        return ReturnStmt(value=val, line=line)

    # ── Výrazy ────────────────────────────────────────────────────────────────

    def parse_expr(self) -> ASTNode:
        return self.parse_or()

    def parse_or(self) -> ASTNode:
        left = self.parse_and()
        while self.current().type == TT.OR:
            op = self.consume().value
            right = self.parse_and()
            left = BinOp(op=op, left=left, right=right, line=left.line)
        return left

    def parse_and(self) -> ASTNode:
        left = self.parse_not()
        while self.current().type == TT.AND:
            op = self.consume().value
            right = self.parse_not()
            left = BinOp(op=op, left=left, right=right, line=left.line)
        return left

    def parse_not(self) -> ASTNode:
        if self.current().type == TT.NOT:
            line = self.current().line
            self.consume()
            return UnaryOp(op="not", operand=self.parse_compare(), line=line)
        return self.parse_compare()

    def parse_compare(self) -> ASTNode:
        left = self.parse_add()
        cmp_ops = {TT.EQ, TT.NEQ, TT.LT, TT.GT, TT.LEQ, TT.GEQ}
        while self.current().type in cmp_ops:
            op = self.consume().value
            right = self.parse_add()
            left = BinOp(op=op, left=left, right=right, line=left.line)
        return left

    def parse_add(self) -> ASTNode:
        left = self.parse_mul()
        while self.current().type in (TT.PLUS, TT.MINUS):
            op = self.consume().value
            right = self.parse_mul()
            left = BinOp(op=op, left=left, right=right, line=left.line)
        return left

    def parse_mul(self) -> ASTNode:
        left = self.parse_unary()
        while self.current().type in (TT.STAR, TT.SLASH):
            op = self.consume().value
            right = self.parse_unary()
            left = BinOp(op=op, left=left, right=right, line=left.line)
        return left

    def parse_unary(self) -> ASTNode:
        if self.current().type == TT.MINUS:
            line = self.current().line
            self.consume()
            return UnaryOp(op="-", operand=self.parse_primary(), line=line)
        return self.parse_primary()

    def parse_primary(self) -> ASTNode:
        tok = self.current()
        if tok.type == TT.NUMBER:
            self.consume()
            return NumberLit(value=tok.value, line=tok.line)
        if tok.type == TT.STRING:
            self.consume()
            return StringLit(value=tok.value, line=tok.line)
        if tok.type in (TT.BOOL, TT.TRUE, TT.FALSE):
            self.consume()
            return BoolLit(value=bool(tok.value), line=tok.line)
        if tok.type == TT.IDENT:
            self.consume()
            node: ASTNode = Identifier(name=tok.value, line=tok.line)
            # Attribute access nebo subscript
            while self.current().type in (TT.DOT, TT.LBRACKET):
                if self.current().type == TT.DOT:
                    self.consume()
                    attr = self.consume(TT.IDENT).value
                    node = Attribute(obj=node, attr=attr, line=tok.line)
                else:
                    self.consume(TT.LBRACKET)
                    idx = self.parse_expr()
                    self.consume(TT.RBRACKET)
                    node = Subscript(obj=node, index=idx, line=tok.line)
            # Funkční volání
            if self.current().type == TT.LPAREN:
                self.consume(TT.LPAREN)
                args = []
                while self.current().type != TT.RPAREN and self.current().type != TT.EOF:
                    args.append(self.parse_expr())
                    if self.current().type == TT.COMMA:
                        self.consume()
                self.consume(TT.RPAREN)
                func_name = tok.value
                node = CallExpr(func=func_name, args=args, line=tok.line)
            return node
        if tok.type == TT.LPAREN:
            self.consume()
            expr = self.parse_expr()
            self.consume(TT.RPAREN)
            return expr
        raise ParseError(f"Neočekávaný token: {tok.type} ('{tok.value}')", tok.line)


# ─── Interpreter / Sandbox ────────────────────────────────────────────────────

class RuntimeError_(Exception):
    def __init__(self, msg: str, line: int = 0):
        super().__init__(f"[VoxScript Line {line}] RuntimeError: {msg}")
        self.line = line


class BreakSignal(Exception):
    pass


class ReturnSignal(Exception):
    def __init__(self, value: Any):
        self.value = value


MAX_OPS = 100_000    # sandbox: maximální počet operací


class VoxInterpreter:
    """
    Sandboxovaný interpreter pro VoxScript.

    Bezpečnostní omezení:
    - MAX_OPS operací na jedno spuštění
    - Povolené funkce jsou explicitně registrované
    - Žádný přímý přístup k Pythonu
    - Proměnné jsou izolovány v lokálním namespace

    Použití:
        interp = VoxInterpreter()
        interp.register("open_door", lambda args: ...)
        interp.register("get_temp",  lambda args: world.get_temperature(*args))
        script = VoxInterpreter.compile(source_code)
        interp.run(script, event="tick")
    """

    def __init__(self):
        self._globals: Dict[str, Any] = {}
        self._functions: Dict[str, Callable] = {}
        self._event_handlers: Dict[str, List[List[ASTNode]]] = {}
        self._emitted_events: List[Tuple[str, Any]] = []
        self._ops = 0
        self._max_ops = MAX_OPS
        self._wait_remaining: int = 0

    def register(self, name: str, fn: Callable) -> None:
        """Zaregistruj nativní funkci přístupnou ze skriptu."""
        self._functions[name] = fn

    def set_global(self, name: str, value: Any) -> None:
        self._globals[name] = value

    def get_global(self, name: str) -> Any:
        return self._globals.get(name)

    @staticmethod
    def compile(source: str) -> List[ASTNode]:
        """Zkompiluj zdrojový kód na AST."""
        lexer  = VoxLexer(source)
        tokens = lexer.tokenize()
        parser = VoxParser(tokens)
        return parser.parse()

    def load(self, source: str) -> None:
        """Načti a zkompiluj skript — zaregistruj on-handlery."""
        ast = self.compile(source)
        self._event_handlers.clear()
        for node in ast:
            if isinstance(node, OnStmt):
                if node.event_type not in self._event_handlers:
                    self._event_handlers[node.event_type] = []
                self._event_handlers[node.event_type].append(node.body)
            else:
                # Spusť top-level příkazy okamžitě (inicializace)
                self._exec(node, self._globals)

    def fire_event(self, event_type: str, payload: Any = None) -> List[Tuple[str, Any]]:
        """
        Spusť event handlery pro daný typ události.
        Vrátí seznam emitovaných událostí.
        """
        self._emitted_events.clear()
        self._ops = 0
        if payload is not None:
            self._globals['event_payload'] = payload
        for body in self._event_handlers.get(event_type, []):
            env = dict(self._globals)
            try:
                for stmt in body:
                    self._exec(stmt, env)
            except BreakSignal:
                pass
            except ReturnSignal:
                pass
        return list(self._emitted_events)

    def run(self, ast: List[ASTNode], env: Optional[Dict] = None) -> Any:
        """Spusť AST seznam příkazů."""
        self._ops = 0
        local_env = dict(self._globals)
        if env:
            local_env.update(env)
        result = None
        try:
            for stmt in ast:
                result = self._exec(stmt, local_env)
        except ReturnSignal as r:
            result = r.value
        return result

    def _check_ops(self, line: int = 0) -> None:
        self._ops += 1
        if self._ops > self._max_ops:
            raise RuntimeError_(f"Skript překročil limit operací ({self._max_ops})", line)

    def _exec(self, node: ASTNode, env: Dict) -> Any:
        self._check_ops(getattr(node, 'line', 0))

        if isinstance(node, Assignment):
            val = self._eval(node.value, env)
            env[node.target] = val
            self._globals[node.target] = val   # propaři do globalů
            return val

        if isinstance(node, IfStmt):
            cond = self._eval(node.condition, env)
            block = node.then_block if cond else node.else_block
            result = None
            for stmt in block:
                result = self._exec(stmt, env)
            return result

        if isinstance(node, WhileStmt):
            iterations = 0
            while self._eval(node.condition, env):
                iterations += 1
                if iterations > node.max_iterations:
                    raise RuntimeError_(f"Překročen limit iterací while ({node.max_iterations})", node.line)
                try:
                    for stmt in node.body:
                        self._exec(stmt, env)
                except BreakSignal:
                    break
            return None

        if isinstance(node, OnStmt):
            # On-handlery jsou registrované při load(), zde jen přeskočíme
            return None

        if isinstance(node, EmitStmt):
            val = self._eval(node.value, env) if node.value else None
            self._emitted_events.append((node.event_type, val))
            return None

        if isinstance(node, WaitStmt):
            ticks = int(self._eval(node.ticks, env))
            self._wait_remaining = max(0, ticks)
            return None

        if isinstance(node, CallExpr):
            return self._call(node.func, [self._eval(a, env) for a in node.args], node.line)

        if isinstance(node, ReturnStmt):
            val = self._eval(node.value, env) if node.value else None
            raise ReturnSignal(val)

        if isinstance(node, BreakStmt):
            raise BreakSignal()

        # Výraz jako příkaz
        return self._eval(node, env)

    def _eval(self, node: ASTNode, env: Dict) -> Any:
        self._check_ops(getattr(node, 'line', 0))

        if isinstance(node, NumberLit):
            return node.value
        if isinstance(node, StringLit):
            return node.value
        if isinstance(node, BoolLit):
            return node.value
        if isinstance(node, Identifier):
            if node.name in env:
                return env[node.name]
            if node.name in self._globals:
                return self._globals[node.name]
            return None

        if isinstance(node, Attribute):
            obj = self._eval(node.obj, env)
            if isinstance(obj, dict):
                return obj.get(node.attr)
            return getattr(obj, node.attr, None)

        if isinstance(node, Subscript):
            obj = self._eval(node.obj, env)
            idx = self._eval(node.index, env)
            try:
                return obj[idx]
            except (KeyError, IndexError, TypeError):
                return None

        if isinstance(node, CallExpr):
            args = [self._eval(a, env) for a in node.args]
            return self._call(node.func, args, node.line)

        if isinstance(node, BinOp):
            left = self._eval(node.left, env)
            right = self._eval(node.right, env)
            op = node.op
            try:
                if op == '+': return left + right
                if op == '-': return left - right
                if op == '*': return left * right
                if op == '/': return left / right if right != 0 else 0
                if op == '==': return left == right
                if op == '!=': return left != right
                if op == '<':  return left < right
                if op == '>':  return left > right
                if op == '<=': return left <= right
                if op == '>=': return left >= right
                if op == 'and': return bool(left) and bool(right)
                if op == 'or':  return bool(left) or bool(right)
            except TypeError:
                return None
            return None

        if isinstance(node, UnaryOp):
            operand = self._eval(node.operand, env)
            if node.op == '-': return -operand
            if node.op == 'not': return not operand
            return operand

        return None

    def _call(self, func_name: str, args: List[Any], line: int = 0) -> Any:
        fn = self._functions.get(func_name)
        if fn is None:
            # Builtin funkce
            return self._builtin(func_name, args, line)
        try:
            return fn(args)
        except Exception as e:
            raise RuntimeError_(f"Chyba ve funkci '{func_name}': {e}", line)

    def _builtin(self, name: str, args: List[Any], line: int) -> Any:
        """Vestavěné funkce VoxScriptu."""
        if name == 'print':
            print('[VoxScript]', *args)
            return None
        if name == 'abs':
            return abs(args[0]) if args else 0
        if name == 'min':
            return min(args) if args else 0
        if name == 'max':
            return max(args) if args else 0
        if name == 'int':
            return int(args[0]) if args else 0
        if name == 'float':
            return float(args[0]) if args else 0.0
        if name == 'str':
            return str(args[0]) if args else ""
        if name == 'len':
            return len(args[0]) if args else 0
        if name == 'clamp':
            v, lo, hi = args[0], args[1], args[2]
            return max(lo, min(hi, v))
        if name == 'lerp':
            a, b, t = args[0], args[1], args[2]
            return a + t * (b - a)
        # Neznámá funkce — mlčky vrátí None
        return None

    @property
    def registered_functions(self) -> List[str]:
        return list(self._functions.keys())

    def reset(self) -> None:
        """Reset stavu interpreteru (zachová registrované funkce)."""
        self._globals.clear()
        self._emitted_events.clear()
        self._ops = 0
        self._wait_remaining = 0


# ─── Convenience API ──────────────────────────────────────────────────────────

def compile_and_check(source: str) -> Tuple[bool, str, Optional[List[ASTNode]]]:
    """
    Zkompiluj skript a vrátí (ok, error_msg, ast).
    Použij pro validaci před uložením.
    """
    try:
        ast = VoxInterpreter.compile(source)
        return True, "", ast
    except Exception as e:
        return False, str(e), None


def make_interpreter_for_world(world, fluid_sim, energy_net) -> VoxInterpreter:
    """
    Vytvoří předkonfigurovaný interpreter s vazbami na svět.
    """
    interp = VoxInterpreter()

    # World funkce
    interp.register("get_material",    lambda a: world.get_material(int(a[0]), int(a[1]), int(a[2])))
    interp.register("set_material",    lambda a: world.set_voxel(int(a[0]), int(a[1]), int(a[2]), int(a[3])))
    interp.register("destroy_voxel",   lambda a: world.destroy_voxel(int(a[0]), int(a[1]), int(a[2])))
    interp.register("is_solid",        lambda a: world.is_solid(int(a[0]), int(a[1]), int(a[2])))

    # Fluid funkce
    interp.register("get_fluid",       lambda a: float(fluid_sim.grid.volume[int(a[0]), int(a[1]), int(a[2])]))
    interp.register("add_fluid",       lambda a: fluid_sim.grid.add_fluid(int(a[0]), int(a[1]), int(a[2]), float(a[3])))
    interp.register("drain_fluid",     lambda a: fluid_sim.grid.drain_fluid(int(a[0]), int(a[1]), int(a[2]), float(a[3])))

    # Energy funkce
    interp.register("set_switch",      lambda a: energy_net.set_switch(str(a[0]), bool(a[1])))
    interp.register("is_powered",      lambda a: energy_net.nodes.get(str(a[0]), None) and
                                                  energy_net.nodes[str(a[0])].powered)

    # Math
    interp.register("sqrt",  lambda a: a[0] ** 0.5 if a else 0)
    interp.register("pow",   lambda a: a[0] ** a[1] if len(a) >= 2 else 0)

    return interp
