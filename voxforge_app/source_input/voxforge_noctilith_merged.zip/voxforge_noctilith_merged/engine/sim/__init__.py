"""engine.sim — simulation modules for the VoxForge platform.

This package contains both the newer VoxForge platform simulations
(fluid/gas/weather/chemistry/energy) and the imported Noctilith advanced
material pipeline (entropy, fracture, degradation, debris coupling).
"""
from .fluid import FluidSimulation, FluidGrid, FluidEventType
from .thermal import ThermalGrid
from .chemistry import ChemistrySystem, Reaction, ReactionResult
from .energy import EnergyNetwork, EnergyNode, NodeType, EnergyEvent
from .gas import GasGrid, GasType
from .weather import WeatherSimulation, WeatherType, WeatherState

from .entropy import EntropyField
from .reactions import phase_transition, get_reactions_for, ReactionDef
from .material_degradation import MaterialDegradationModel, MaterialDegradationConfig
from .fracture import (
    compute_stress,
    compute_fracture_mask,
    FractureBridge,
    FractureBridgeConfig,
)
from .thermal_coupler import ThermalCoupler, ThermalCouplerConfig
from .entropy_coupler import EntropyCoupler, EntropyCouplerConfig
from .world_reaction import WorldReactionBridge, WorldReactionConfig
from .debris_execution import DebrisExecutionBridge, DebrisExecutionConfig
from .debris_world_coupling import DebrisWorldCoupling, DebrisWorldCouplingConfig
from .material_profiles import MaterialPipelineProfile, MaterialProfileCache, PROFILE_CACHE
from .local_material_map import LocalMaterialMap, evaluate_degradation_local
from .quantized_field_ops import (
    compute_overlap_eta,
    build_radius_kernel,
    scatter_deposit,
    batch_scatter_deposit,
)

__all__ = [
    "FluidSimulation", "FluidGrid", "FluidEventType",
    "ThermalGrid",
    "ChemistrySystem", "Reaction", "ReactionResult",
    "EnergyNetwork", "EnergyNode", "NodeType", "EnergyEvent",
    "GasGrid", "GasType",
    "WeatherSimulation", "WeatherType", "WeatherState",
    "EntropyField", "phase_transition", "get_reactions_for", "ReactionDef",
    "MaterialDegradationModel", "MaterialDegradationConfig",
    "compute_stress", "compute_fracture_mask", "FractureBridge", "FractureBridgeConfig",
    "ThermalCoupler", "ThermalCouplerConfig", "EntropyCoupler", "EntropyCouplerConfig",
    "WorldReactionBridge", "WorldReactionConfig",
    "DebrisExecutionBridge", "DebrisExecutionConfig",
    "DebrisWorldCoupling", "DebrisWorldCouplingConfig",
    "MaterialPipelineProfile", "MaterialProfileCache", "PROFILE_CACHE",
    "LocalMaterialMap", "evaluate_degradation_local",
    "compute_overlap_eta", "build_radius_kernel", "scatter_deposit", "batch_scatter_deposit",
]
