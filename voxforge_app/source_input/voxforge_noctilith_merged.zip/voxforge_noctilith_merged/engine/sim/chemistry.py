"""
engine/sim/chemistry.py
========================
Chemie, hoření, fázové přechody a materiálové reakce.

Blueprint §4.3: phase transitions, burning/ignition
Blueprint §4.7: materiálové reakce, hoření, koroze, rozpouštění,
                toxicita, směsi kapalin, reaktivní látky
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple
import numpy as np


# ── Reaction output ────────────────────────────────────────────────────────────

@dataclass
class ReactionResult:
    """Výsledek jedné chemické reakce v buňce."""
    pos: Tuple[int, int, int]
    old_material: int
    new_material: int
    heat_delta: float = 0.0       # změna teploty (pozitivní = exotermická)
    gas_emitted: str = ""         # typ emitovaného plynu ("smoke", "steam", "toxin")
    damage_delta: float = 0.0
    event_type: str = ""


# ── Reaction definitions ───────────────────────────────────────────────────────

@dataclass
class Reaction:
    """
    Jedna chemická reakce: za podmínek (teplota, sousednost, čas)
    se materiál A transformuje na materiál B.
    """
    name: str
    material_in: int              # vstupní material_id
    material_out: int             # výstupní material_id (0 = zmizí)
    min_temp: float = 0.0         # minimální teplota pro reakci
    max_temp: float = 1.0
    neighbor_material: int = -1   # -1 = nevyžaduje specifického souseda
    rate: float = 0.05            # pravděpodobnost reakce za tick
    heat_delta: float = 0.0       # teplo uvolněné při reakci
    gas_emitted: str = ""
    event_type: str = "material_reacted"
    requires_moisture: float = 0.0  # min vlhkost


class ChemistrySystem:
    """
    Systém materiálových reakcí, hoření a fázových přechodů.

    Blueprint §4.7: "materiálové reakce, hoření, koroze, rozpouštění,
                     toxicita, směsi kapalin, reaktivní látky"
    Blueprint §4.3: "phase transitions, burning/ignition"

    Použití:
        chem = ChemistrySystem(materials_array, temp_array, moisture_array)
        results = chem.step(tick)
    """

    def __init__(self,
                 materials: np.ndarray,
                 temperature: np.ndarray,
                 entropy: np.ndarray,
                 damage: np.ndarray,
                 moisture: np.ndarray,
                 rng_seed: int = 0):
        self.materials    = materials       # (X,Y,Z) uint8
        self.temperature  = temperature     # (X,Y,Z) float32, 0-1 normalized
        self.entropy      = entropy
        self.damage       = damage
        self.moisture     = moisture
        self._rng         = np.random.default_rng(rng_seed)
        self._reactions   = self._build_reactions()
        self._pending_changes: List[ReactionResult] = []

    # ── Reaction database (blueprint §4.7) ────────────────────────────────────

    def _build_reactions(self) -> List[Reaction]:
        """
        Kompletní sada reakcí pro VoxForge platformu.
        Material IDs odpovídají MaterialRegistry v voxel.py:
          1=stone, 2=dirt, 3=sand, 4=wood, 5=glass, 6=metal,
          7=concrete, 8=ice, 9=lava, 10=water, 11=coal, 12=titanium
        """
        return [
            # ── §4.3 Fázové přechody ─────────────────────────────────────────
            Reaction(
                name="ice_melt",
                material_in=8, material_out=10,
                min_temp=0.15, max_temp=1.0,
                rate=0.08, heat_delta=-0.05,
                gas_emitted="", event_type="material_melted",
            ),
            Reaction(
                name="water_freeze",
                material_in=10, material_out=8,
                min_temp=0.0, max_temp=0.08,
                rate=0.06, heat_delta=0.02,
                gas_emitted="", event_type="material_frozen",
            ),
            Reaction(
                name="water_evaporate",
                material_in=10, material_out=0,
                min_temp=0.85, max_temp=1.0,
                rate=0.04, heat_delta=0.10,
                gas_emitted="steam", event_type="material_evaporated",
            ),
            Reaction(
                name="lava_cool_to_stone",
                material_in=9, material_out=1,
                min_temp=0.0, max_temp=0.35,
                rate=0.05, heat_delta=0.0,
                gas_emitted="", event_type="material_solidified",
            ),
            Reaction(
                name="sand_melt_to_glass",
                material_in=3, material_out=5,
                min_temp=0.82, max_temp=1.0,
                rate=0.03, heat_delta=-0.10,
                gas_emitted="", event_type="material_melted",
            ),
            Reaction(
                name="stone_melt_to_lava",
                material_in=1, material_out=9,
                min_temp=0.95, max_temp=1.0,
                rate=0.02, heat_delta=-0.15,
                gas_emitted="smoke", event_type="material_melted",
            ),

            # ── §4.3 Hoření / Burning ────────────────────────────────────────
            Reaction(
                name="wood_burn",
                material_in=4, material_out=2,    # dřevo → popel (dirt)
                min_temp=0.40, max_temp=1.0,
                rate=0.07, heat_delta=0.25,        # exotermická!
                gas_emitted="smoke", event_type="material_burned",
            ),
            Reaction(
                name="coal_burn",
                material_in=11, material_out=2,   # uhlí → popel
                min_temp=0.35, max_temp=1.0,
                rate=0.04, heat_delta=0.40,        # silně exotermická
                gas_emitted="smoke", event_type="material_burned",
            ),

            # ── §4.7 Koroze ──────────────────────────────────────────────────
            Reaction(
                name="metal_rust",
                material_in=6, material_out=2,    # kov → hlína (rezavá troska)
                min_temp=0.10, max_temp=0.60,
                requires_moisture=0.3,
                rate=0.001, heat_delta=0.0,        # velmi pomalé
                gas_emitted="", event_type="material_corroded",
            ),
            Reaction(
                name="concrete_erode",
                material_in=7, material_out=3,    # beton → písek
                min_temp=0.05, max_temp=1.0,
                requires_moisture=0.6,
                rate=0.0005, heat_delta=0.0,
                gas_emitted="", event_type="material_eroded",
            ),

            # ── §4.7 Lava + water = stone + steam ───────────────────────────
            Reaction(
                name="lava_water_contact",
                material_in=9, material_out=1,    # láva → kámen při kontaktu s vodou
                min_temp=0.0, max_temp=1.0,
                neighbor_material=10,              # musí mít vodu jako souseda
                rate=0.90, heat_delta=0.30,
                gas_emitted="steam", event_type="lava_quenched",
            ),
            Reaction(
                name="water_lava_boil",
                material_in=10, material_out=0,   # voda zmizí při kontaktu s lávou
                min_temp=0.0, max_temp=1.0,
                neighbor_material=9,
                rate=0.85, heat_delta=0.20,
                gas_emitted="steam", event_type="water_boiled",
            ),
        ]

    # ── Simulační krok ────────────────────────────────────────────────────────

    def step(self, tick: int) -> List[ReactionResult]:
        """
        Jeden tick chemické simulace.
        Vrátí seznam výsledků reakcí (aplikovat na materials/fields).
        """
        results: List[ReactionResult] = []
        sx, sy, sz = self.materials.shape
        rnd = self._rng.random(self.materials.shape).astype(np.float32)

        for reaction in self._reactions:
            mat_mask = self.materials == reaction.material_in

            # Teplotní podmínka
            temp_ok = ((self.temperature >= reaction.min_temp) &
                       (self.temperature <= reaction.max_temp))

            # Vlhkostní podmínka
            moisture_ok = self.moisture >= reaction.requires_moisture

            # Základní maska
            mask = mat_mask & temp_ok & moisture_ok & (rnd < reaction.rate)

            if not np.any(mask):
                continue

            # Sousednostní podmínka (volitelná)
            if reaction.neighbor_material >= 0:
                neighbor_mask = self._has_neighbor(reaction.neighbor_material)
                mask = mask & neighbor_mask

            # Zpracuj buňky kde reakce nastane
            positions = list(zip(*np.where(mask)))
            for (x, y, z) in positions[:50]:   # limit 50 reakcí/tick pro výkon
                results.append(ReactionResult(
                    pos=(int(x), int(y), int(z)),
                    old_material=reaction.material_in,
                    new_material=reaction.material_out,
                    heat_delta=reaction.heat_delta,
                    gas_emitted=reaction.gas_emitted,
                    event_type=reaction.event_type,
                ))

        # Aplikuj výsledky
        for r in results:
            x, y, z = r.pos
            self.materials[x, y, z] = r.new_material
            self.temperature[x, y, z] = min(1.0, max(0.0,
                self.temperature[x, y, z] + r.heat_delta))

        return results

    def _has_neighbor(self, material_id: int) -> np.ndarray:
        """Vrátí bool array — True kde buňka má souseda s daným material_id."""
        target = (self.materials == material_id).astype(np.float32)
        result = np.zeros_like(target)
        result[1:,  :,  :] += target[:-1, :, :]
        result[:-1, :,  :] += target[1:,  :, :]
        result[:,  1:,  :] += target[:,  :-1, :]
        result[:, :-1,  :] += target[:,  1:,  :]
        result[:,   :, 1:] += target[:,   :, :-1]
        result[:,   :,:-1] += target[:,   :, 1:]
        return result > 0

    @property
    def active_reactions(self) -> List[str]:
        return [r.name for r in self._reactions]
