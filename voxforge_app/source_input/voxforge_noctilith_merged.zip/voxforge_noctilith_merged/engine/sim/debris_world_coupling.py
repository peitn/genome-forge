"""noctilith/sim/debris_world_coupling.py — M12.2 + M12.3 secondary fragmentation."""
from __future__ import annotations
import math
import numpy as np
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

from engine.sim.quantized_field_ops import build_radius_kernel, scatter_deposit
from engine.core.events import EventBus

SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME    = "noctilith.sim.debris_world_coupling"


class _ScalarFieldAdapter:
    def __init__(self, obj: Any):
        self._obj = obj
    @property
    def values(self) -> np.ndarray:
        if isinstance(self._obj, np.ndarray): return self._obj
        for attr in ("T", "S", "values", "temperatures", "entropy"):
            v = getattr(self._obj, attr, None)
            if v is not None and isinstance(v, np.ndarray): return v
        raise AttributeError(f"Cannot resolve array from {type(self._obj)}")


@dataclass
class DebrisWorldCouplingConfig:
    enabled: bool = True
    min_impact_threshold: float = 0.05
    damage_gain: float = 0.35
    max_damage: float = 1.0
    entropy_gain: float = 0.40
    max_entropy_delta: float = 2.0
    thermal_gain: float = 0.15
    max_thermal_delta: float = 200.0
    deposition_radius: int = 1
    smooth_deposition: bool = True
    apply_damage: bool = True
    apply_weakening: bool = True
    apply_entropy: bool = True
    apply_thermal: bool = True
    emit_events: bool = True
    epsilon: float = 1e-8
    # M12.3 secondary fragmentation
    enable_secondary_fragmentation: bool = True
    fragmentation_strength_threshold: float = 0.50
    fragmentation_strength_gain: float = 0.40
    fragmentation_min_strength: float = 0.05
    max_secondary_requests_per_hit: int = 1
    max_secondary_requests_per_step: int = 4


@dataclass
class DebrisWorldCouplingTelemetry:
    processed_hits: int = 0
    damage_applications: int = 0
    weakening_applications: int = 0
    entropy_applications: int = 0
    thermal_applications: int = 0
    emitted_events: int = 0
    secondary_fragments: int = 0


@dataclass
class DebrisWorldCoupling:
    config: DebrisWorldCouplingConfig = field(default_factory=DebrisWorldCouplingConfig)
    _kernel: object = field(default=None, repr=False, compare=False, hash=False)
    _last_step_index: int = field(default=-1, repr=False, compare=False, hash=False)
    _secondary_this_step: int = field(default=0, repr=False, compare=False, hash=False)

    def _get_kernel(self) -> np.ndarray:
        if self._kernel is None:
            self._kernel = build_radius_kernel(
                self.config.deposition_radius, smooth=self.config.smooth_deposition)
        return self._kernel

    def _deposit(self, field_obj: Any, center: Tuple[int,int,int],
                 delta: float, clamp: float) -> None:
        arr = _ScalarFieldAdapter(field_obj).values
        scatter_deposit(arr, center, delta, kernel=self._get_kernel(), clamp=clamp)

    def _emit_event(self, event_bus: Any, evt: Any) -> bool:
        if event_bus is None or evt is None: return False
        fn = getattr(event_bus, "emit", getattr(event_bus, "publish", None))
        if callable(fn): fn(evt); return True
        return False

    def apply_ground_hit(self, *, world_obj: Any, thermal_grid: Any,
                         entropy_field: Any, debris_entity: Any,
                         step_index: int, event_bus: Any) -> Dict[str, Any]:
        cfg = self.config
        out = DebrisWorldCouplingTelemetry()

        if not cfg.enabled:
            return self._telemetry_dict(out)

        pos = debris_entity.position
        vel = debris_entity.velocity
        strength = float(getattr(debris_entity, "strength", 1.0))
        speed = math.sqrt(sum(v*v for v in vel))
        impact = strength * speed

        if impact < cfg.min_impact_threshold:
            return self._telemetry_dict(out)

        shape = getattr(world_obj, "shape", None)
        if shape is None and entropy_field is not None:
            arr = getattr(entropy_field, "S", None)
            if arr is not None: shape = arr.shape
        if shape is None:
            return self._telemetry_dict(out)

        ix = int(round(pos[0])); iy = int(round(pos[1])); iz = int(round(pos[2]))
        in_bounds_fn = getattr(world_obj, "in_bounds", None)
        if callable(in_bounds_fn):
            if not in_bounds_fn(ix, iy, iz):
                return self._telemetry_dict(out)
        else:
            if not (0 <= ix < shape[0] and 0 <= iy < shape[1] and 0 <= iz < shape[2]):
                return self._telemetry_dict(out)

        out.processed_hits += 1
        center = (ix, iy, iz)

        # Damage
        damage = min(cfg.max_damage, cfg.damage_gain * impact)
        if cfg.apply_damage:
            fn = getattr(world_obj, "mark_damage", None)
            if callable(fn):
                fn(ix, iy, iz, damage)
                out.damage_applications += 1
        if cfg.apply_weakening:
            fn = getattr(world_obj, "weaken_voxel", None)
            if callable(fn):
                fn(ix, iy, iz, damage)
                out.weakening_applications += 1

        # Entropy deposition
        entropy_delta = min(cfg.max_entropy_delta, cfg.entropy_gain * impact)
        if cfg.apply_entropy and entropy_field is not None:
            self._deposit(entropy_field, center, entropy_delta, cfg.max_entropy_delta)
            out.entropy_applications += 1

        # Thermal deposition
        thermal_delta = min(cfg.max_thermal_delta, cfg.thermal_gain * impact)
        if cfg.apply_thermal and thermal_grid is not None:
            self._deposit(thermal_grid, center, thermal_delta, 5000.0)
            out.thermal_applications += 1

        # Event
        if cfg.emit_events:
            evt = EventBus.make_world_damage_applied(
                step_index=int(step_index), index=(ix, iy, iz),
                risk=float(impact), damage=float(damage), source=MODULE_NAME)
            out.emitted_events += int(self._emit_event(event_bus, evt))

        # M12.3 secondary fragmentation
        if cfg.enable_secondary_fragmentation:
            si = int(step_index)
            if si != self._last_step_index:
                self._last_step_index     = si
                self._secondary_this_step = 0
            can_fragment = (
                impact >= cfg.fragmentation_strength_threshold
                and self._secondary_this_step < cfg.max_secondary_requests_per_step
            )
            if can_fragment:
                sec_strength = max(cfg.fragmentation_min_strength,
                                   cfg.fragmentation_strength_gain * impact)
                fn = getattr(world_obj, "request_debris_spawn", None)
                if callable(fn):
                    fn(ix, iy, iz, float(sec_strength))
                    out.secondary_fragments += 1
                    self._secondary_this_step += cfg.max_secondary_requests_per_hit
                    if cfg.emit_events:
                        evt2 = EventBus.make_debris_spawn_requested(
                            step_index=si, index=(ix, iy, iz),
                            risk=float(impact), strength=float(sec_strength),
                            source=MODULE_NAME)
                        out.emitted_events += int(self._emit_event(event_bus, evt2))

        return self._telemetry_dict(out)

    def _telemetry_dict(self, out: DebrisWorldCouplingTelemetry) -> Dict[str, Any]:
        return {
            "schema_version":       SCHEMA_VERSION,
            "module_name":          MODULE_NAME,
            "processed_hits":       int(out.processed_hits),
            "damage_applications":  int(out.damage_applications),
            "weakening_applications": int(out.weakening_applications),
            "entropy_applications": int(out.entropy_applications),
            "thermal_applications": int(out.thermal_applications),
            "emitted_events":       int(out.emitted_events),
            "secondary_fragments":  int(out.secondary_fragments),
        }
