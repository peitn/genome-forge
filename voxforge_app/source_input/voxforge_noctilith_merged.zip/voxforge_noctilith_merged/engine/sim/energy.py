"""
engine/sim/energy.py
====================
Elektřina a energetická síť.

Blueprint §4.6: "jednoduchá energetická síť, vodiče, baterie,
                  generátory, spotřebiče, logické obvody,
                  přetížení, zkraty, propojení s Builderem"
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple
import numpy as np


# ── Typy uzlů energetické sítě ────────────────────────────────────────────────

class NodeType(str, Enum):
    GENERATOR  = "generator"   # produkuje energii
    BATTERY    = "battery"     # ukládá a vydává energii
    WIRE       = "wire"        # přenáší energii (nulová spotřeba)
    CONSUMER   = "consumer"    # spotřebovává energii
    SWITCH     = "switch"      # přepínač (on/off)
    FUSE       = "fuse"        # pojistka (přeruší při přetížení)
    LOGIC_GATE = "logic"       # logický obvod (AND, OR, NOT)
    SENSOR     = "sensor"      # emituje signál (light, temp, fluid)


# ── Energetický uzel ──────────────────────────────────────────────────────────

@dataclass
class EnergyNode:
    """
    Jeden uzel energetické sítě.
    Propojení: node.connections = seznam sousedních node_id.
    """
    node_id: str
    node_type: NodeType
    world_pos: Tuple[int, int, int]

    # Kapacity a stav
    max_output: float  = 1.0    # W (normalizovaná)
    max_input: float   = 1.0
    capacity: float    = 0.0    # pro baterie: max nabitý výkon
    current_charge: float = 0.0 # pro baterie
    consumption: float = 0.5    # pro spotřebiče: spotřeba při plném výkonu

    # Runtime stav
    powered: bool   = False     # má dostatek energie?
    voltage: float  = 0.0       # aktuální napětí (0-1)
    current: float  = 0.0       # aktuální proud
    blown: bool     = False     # pojistka přepálená / vodiče zkratovány

    # Propojení
    connections: List[str] = field(default_factory=list)

    # Logická brána
    gate_type: str  = "AND"     # AND, OR, NOT, XOR
    gate_inputs: List[bool] = field(default_factory=list)

    # Switch stav
    switch_on: bool = True


@dataclass
class EnergyEvent:
    type: str     # "power_on", "power_off", "overload", "short_circuit", "battery_low"
    node_id: str
    pos: Tuple[int, int, int]
    value: float = 0.0


# ── Energetická síť ──────────────────────────────────────────────────────────

class EnergyNetwork:
    """
    Grafová energetická síť pro VoxForge platformu.

    Algoritmus (BFS propagace od generátorů):
    1. Všechny generátory + nabité baterie = zdroje
    2. BFS po spojích → distribuuj energii
    3. Spotřebiče odečítají z dostupné energie
    4. Přetížení → přepal pojistku, emituj event
    5. Baterie nabíjej přebytečnou energií

    Blueprint §4.6 + §3 (propojení s Builderem):
    Builder díly (pipe, engine, pump) potřebují energii → konsumery v síti.
    """

    MAX_CURRENT = 5.0   # maximální proud před přetížením

    def __init__(self, bus=None):
        self.nodes: Dict[str, EnergyNode] = {}
        self.bus = bus
        self._tick = 0
        self._total_produced = 0.0
        self._total_consumed = 0.0

    # ── Správa sítě ───────────────────────────────────────────────────────────

    def add_node(self, node: EnergyNode) -> None:
        self.nodes[node.node_id] = node

    def remove_node(self, node_id: str) -> None:
        self.nodes.pop(node_id, None)
        for n in self.nodes.values():
            if node_id in n.connections:
                n.connections.remove(node_id)

    def connect(self, node_id_a: str, node_id_b: str) -> None:
        a = self.nodes.get(node_id_a)
        b = self.nodes.get(node_id_b)
        if a and b:
            if node_id_b not in a.connections:
                a.connections.append(node_id_b)
            if node_id_a not in b.connections:
                b.connections.append(node_id_a)

    def disconnect(self, node_id_a: str, node_id_b: str) -> None:
        a = self.nodes.get(node_id_a)
        b = self.nodes.get(node_id_b)
        if a:
            a.connections = [c for c in a.connections if c != node_id_b]
        if b:
            b.connections = [c for c in b.connections if c != node_id_a]

    def set_switch(self, node_id: str, on: bool) -> None:
        n = self.nodes.get(node_id)
        if n and n.node_type == NodeType.SWITCH:
            n.switch_on = on

    # ── Simulační krok ────────────────────────────────────────────────────────

    def step(self, tick: int) -> List[EnergyEvent]:
        """
        Jeden tick energetické simulace.
        BFS propagace napájení od zdrojů ke spotřebičům.
        """
        self._tick = tick
        events: List[EnergyEvent] = []

        # Reset voltage na všech uzlech
        for n in self.nodes.values():
            n.voltage = 0.0
            n.powered = False

        if not self.nodes:
            return events

        # Sesbírej dostupnou energii ze zdrojů
        available_energy = 0.0
        sources: List[str] = []

        for nid, n in self.nodes.items():
            if n.blown:
                continue
            if n.node_type == NodeType.GENERATOR:
                available_energy += n.max_output
                n.voltage = 1.0
                sources.append(nid)
            elif n.node_type == NodeType.BATTERY and n.current_charge > 0.01:
                discharge = min(n.max_output, n.current_charge)
                available_energy += discharge
                n.voltage = n.current_charge / max(n.capacity, 0.001)
                sources.append(nid)

        self._total_produced = available_energy

        # BFS propagace napájení
        visited: Set[str] = set()
        queue = deque(sources)
        for s in sources:
            visited.add(s)

        consumers_powered: List[EnergyNode] = []

        while queue and available_energy > 0.001:
            nid = queue.popleft()
            node = self.nodes.get(nid)
            if node is None or node.blown:
                continue

            # Switch přeruší tok
            if node.node_type == NodeType.SWITCH and not node.switch_on:
                continue

            node.powered = True

            if node.node_type == NodeType.CONSUMER:
                consumers_powered.append(node)

            # Šíř na sousedy
            for neighbor_id in node.connections:
                if neighbor_id not in visited and neighbor_id in self.nodes:
                    neighbor = self.nodes[neighbor_id]
                    if not neighbor.blown:
                        visited.add(neighbor_id)
                        queue.append(neighbor_id)

        # Spotřeba energie
        total_demand = sum(n.consumption for n in consumers_powered)
        self._total_consumed = min(total_demand, available_energy)

        # Distribuuj napájení spotřebičům (poměrné)
        for node in consumers_powered:
            if total_demand > 0:
                ratio = node.consumption / total_demand
                node.current = ratio * self._total_consumed
                node.voltage = min(1.0, available_energy / max(total_demand, 0.001))
            else:
                node.current = 0.0
                node.voltage = 0.0

        # Kontrola přetížení
        for nid, node in self.nodes.items():
            if node.current > self.MAX_CURRENT:
                if node.node_type == NodeType.FUSE:
                    node.blown = True
                    events.append(EnergyEvent("fuse_blown", nid, node.world_pos, node.current))
                else:
                    events.append(EnergyEvent("overload", nid, node.world_pos, node.current))

        # Baterie: nabíjej přebytky
        surplus = max(0.0, available_energy - self._total_consumed)
        for nid, node in self.nodes.items():
            if node.node_type == NodeType.BATTERY and node.powered:
                charge_rate = min(surplus * 0.1, node.max_input,
                                  node.capacity - node.current_charge)
                node.current_charge = min(node.capacity, node.current_charge + charge_rate)
                # Vybíjej při zásobování
                if node.nid in sources if hasattr(node, 'nid') else False:
                    node.current_charge = max(0, node.current_charge - node.max_output * 0.1)

            # Baterie nízká
            if node.node_type == NodeType.BATTERY and node.current_charge < node.capacity * 0.1:
                events.append(EnergyEvent("battery_low", nid, node.world_pos, node.current_charge))

        # Power on/off eventy
        for nid, node in self.nodes.items():
            prev = node.powered
            if node.node_type == NodeType.CONSUMER:
                node.powered = node.current > 0.05
            if node.powered != prev:
                evt_type = "power_on" if node.powered else "power_off"
                events.append(EnergyEvent(evt_type, nid, node.world_pos))

        return events

    # ── Factory metody ────────────────────────────────────────────────────────

    @staticmethod
    def make_generator(nid: str, pos: Tuple[int,int,int], output: float = 1.0) -> EnergyNode:
        return EnergyNode(nid, NodeType.GENERATOR, pos, max_output=output)

    @staticmethod
    def make_battery(nid: str, pos: Tuple[int,int,int],
                     capacity: float = 10.0, charge: float = 5.0) -> EnergyNode:
        n = EnergyNode(nid, NodeType.BATTERY, pos,
                       max_output=1.0, capacity=capacity, consumption=0.0)
        n.current_charge = charge
        return n

    @staticmethod
    def make_wire(nid: str, pos: Tuple[int,int,int]) -> EnergyNode:
        return EnergyNode(nid, NodeType.WIRE, pos, max_output=10.0, consumption=0.0)

    @staticmethod
    def make_consumer(nid: str, pos: Tuple[int,int,int], consumption: float = 0.5) -> EnergyNode:
        return EnergyNode(nid, NodeType.CONSUMER, pos, consumption=consumption)

    @staticmethod
    def make_switch(nid: str, pos: Tuple[int,int,int]) -> EnergyNode:
        n = EnergyNode(nid, NodeType.SWITCH, pos, consumption=0.0)
        n.switch_on = True
        return n

    @staticmethod
    def make_fuse(nid: str, pos: Tuple[int,int,int], max_current: float = 3.0) -> EnergyNode:
        n = EnergyNode(nid, NodeType.FUSE, pos, consumption=0.0)
        n.max_input = max_current
        return n

    # ── Status ────────────────────────────────────────────────────────────────

    @property
    def stats(self) -> dict:
        powered = sum(1 for n in self.nodes.values() if n.powered)
        blown   = sum(1 for n in self.nodes.values() if n.blown)
        return {
            "nodes":    len(self.nodes),
            "powered":  powered,
            "blown":    blown,
            "produced": round(self._total_produced, 3),
            "consumed": round(self._total_consumed, 3),
            "surplus":  round(self._total_produced - self._total_consumed, 3),
        }
