#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
noctilith/sim/entropy_coupler.py
================================
NOCTILITH ENTROPY COUPLER
Effective bridge between Space3D telemetry and the entropy field.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np


SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME = "noctilith.sim.entropy_coupler"
MODULE_VERSION = "1.0.0"

Vec3i = Tuple[int, int, int]
Vec3f = Tuple[float, float, float]


@dataclass
class EntropyCouplerConfig:
    enabled: bool = True
    rms_gain: float = 0.05
    unstable_gain: float = 1.0
    unstable_spike: float = 0.25
    source_gain: float = 0.20
    object_gain: float = 0.08
    ambient_entropy: float = 0.0
    ambient_relaxation: float = 0.001
    deposition_radius: int = 1
    smooth_deposition: bool = True
    max_entropy_delta_per_step: float = 2.0
    emit_entropy_storm_events: bool = True
    crit_regime_name: str = "crit"
    unstable_event_name: str = "entropy_spike"
    storm_event_name: str = "entropy_storm"
    epsilon: float = 1e-8


@dataclass
class EntropyStepTelemetry:
    step_index: int = 0
    total_added_entropy: float = 0.0
    max_cell_entropy: float = 0.0
    active_cells: int = 0
    ambient_relaxation_amount: float = 0.0
    phi_rms_total: float = 0.0
    unstable: bool = False
    regime: str = "unknown"
    emitted_events: int = 0


class EntropyFieldAdapter:
    """Protocol adapter for entropy field implementations.

    Supports:
      - noctilith EntropyField (.S array)
      - raw np.ndarray
      - objects with .E, .entropy, or .values
      - optional .add_entropy(ix, iy, iz, delta)
    """

    def __init__(self, entropy_field: Any):
        self.entropy_field = entropy_field

    @property
    def values(self) -> np.ndarray:
        f = self.entropy_field
        if isinstance(f, np.ndarray):
            return f
        # noctilith EntropyField uses .S
        for attr in ("S", "E", "entropy", "values"):
            arr = getattr(f, attr, None)
            if arr is not None and isinstance(arr, np.ndarray):
                return arr
        raise AttributeError(
            "Entropy field must expose .S, .E, .entropy, .values, or be an ndarray"
        )

    @property
    def shape(self) -> Tuple[int, int, int]:
        shape = getattr(self.entropy_field, "shape", None)
        if shape is not None:
            return tuple(shape)
        return tuple(self.values.shape)

    def add_entropy(self, ix: int, iy: int, iz: int, delta: float) -> None:
        fn = getattr(self.entropy_field, "add_entropy", None)
        if callable(fn):
            fn(ix, iy, iz, float(delta))
        else:
            vals = self.values
            vals[ix, iy, iz] = float(np.clip(
                vals[ix, iy, iz] + delta, 0.0, 1.0
            ))


@dataclass
class EntropyCoupler:
    config: EntropyCouplerConfig = field(default_factory=EntropyCouplerConfig)

    def apply(
        self,
        entropy_field: Any,
        *,
        dt: float,
        telemetry: Optional[Dict[str, Any]] = None,
        event_bus: Optional[Any] = None,
        sources: Optional[Iterable[Dict[str, Any]]] = None,
        objects: Optional[Iterable[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Apply one deterministic entropy coupling step.

        Parameters
        ----------
        entropy_field : Any
            noctilith EntropyField, np.ndarray, or object with .E/.entropy/.values
        dt : float
            Simulation step duration.
        telemetry : dict, optional
            Keys: phi_rms_total, unstable, regime, step_index
        event_bus : Any, optional
            Supports .emit(), .publish(), or .push()
        sources / objects : iterables, optional
            Local emitters: {pos, entropy/activity/intensity}
        """
        adapter = EntropyFieldAdapter(entropy_field)
        cfg = self.config
        out = EntropyStepTelemetry()

        if not cfg.enabled or dt <= 0.0:
            return self._telemetry_dict(out)

        telemetry = telemetry or {}
        sources   = list(sources or [])
        objects   = list(objects or [])

        out.step_index    = int(telemetry.get("step_index", 0))
        out.phi_rms_total = float(telemetry.get("phi_rms_total", 0.0))
        out.unstable      = bool(telemetry.get("unstable", False))
        out.regime        = str(telemetry.get("regime", "unknown"))

        # 1) global baseline from phi_rms_total
        self._deposit_global_baseline(adapter, dt, out)

        # 2) instability spike + event
        if out.unstable:
            self._deposit_instability(adapter, dt, out)
            out.emitted_events += int(self._emit_event(event_bus, {
                "type":           cfg.unstable_event_name,
                "schema_version": SCHEMA_VERSION,
                "module_name":    MODULE_NAME,
                "module_version": MODULE_VERSION,
                "step_index":     out.step_index,
                "phi_rms_total":  out.phi_rms_total,
                "regime":         out.regime,
                "unstable":       True,
            }))

        # 3) crit regime → entropy storm event
        if cfg.emit_entropy_storm_events and out.regime == cfg.crit_regime_name:
            out.emitted_events += int(self._emit_event(event_bus, {
                "type":           cfg.storm_event_name,
                "schema_version": SCHEMA_VERSION,
                "module_name":    MODULE_NAME,
                "module_version": MODULE_VERSION,
                "step_index":     out.step_index,
                "phi_rms_total":  out.phi_rms_total,
                "regime":         out.regime,
                "unstable":       out.unstable,
                "severity":       self._storm_severity(out.phi_rms_total, out.unstable),
            }))

        # 4) source-local deposition
        if sources and cfg.source_gain > 0.0:
            for src in sources:
                pos       = tuple(src.get("pos", (0.0, 0.0, 0.0)))
                intensity = float(src.get("entropy", src.get("activity", src.get("intensity", 1.0))))
                self._deposit_local(adapter, pos, dt * cfg.source_gain * intensity, out)

        # 5) object-local deposition
        if objects and cfg.object_gain > 0.0:
            for obj in objects:
                pos      = tuple(obj.get("pos", (0.0, 0.0, 0.0)))
                activity = float(obj.get("entropy", obj.get("activity", 1.0)))
                self._deposit_local(adapter, pos, dt * cfg.object_gain * activity, out)

        # 6) passive relaxation toward ambient_entropy
        out.ambient_relaxation_amount = self._apply_ambient_relaxation(adapter, dt)

        return self._telemetry_dict(out)

    # ── internals ─────────────────────────────────────────────────────────────

    def _deposit_global_baseline(self, adapter, dt, out):
        cfg  = self.config
        vals = adapter.values
        base = dt * cfg.rms_gain * max(0.0, out.phi_rms_total)
        base = max(-cfg.max_entropy_delta_per_step,
                   min(cfg.max_entropy_delta_per_step, base))
        if abs(base) == 0.0:
            return
        np.clip(vals + base, 0.0, 1.0, out=vals)
        out.total_added_entropy += float(base * vals.size)
        out.max_cell_entropy = max(out.max_cell_entropy, abs(base))
        out.active_cells += int(vals.size)

    def _deposit_instability(self, adapter, dt, out):
        cfg   = self.config
        vals  = adapter.values
        mul   = dt * cfg.unstable_gain * max(0.0, out.phi_rms_total)
        delta = max(-cfg.max_entropy_delta_per_step,
                    min(cfg.max_entropy_delta_per_step, mul + cfg.unstable_spike))
        if abs(delta) == 0.0:
            return
        np.clip(vals + delta, 0.0, 1.0, out=vals)
        out.total_added_entropy += float(delta * vals.size)
        out.max_cell_entropy = max(out.max_cell_entropy, abs(delta))
        out.active_cells += int(vals.size)

    def _deposit_local(self, adapter, pos, delta, out):
        cfg = self.config
        nx, ny, nz = adapter.shape
        cx, cy, cz = self._map_world_pos_to_cell(pos, adapter.shape)
        r = max(0, int(cfg.deposition_radius))

        if r == 0:
            d = max(-cfg.max_entropy_delta_per_step,
                    min(cfg.max_entropy_delta_per_step, delta))
            adapter.add_entropy(cx, cy, cz, d)
            out.total_added_entropy += d
            out.max_cell_entropy = max(out.max_cell_entropy, abs(d))
            out.active_cells += 1
            return

        weights: List[Tuple[int, int, int, float]] = []
        wsum = 0.0
        for ix in range(max(0, cx-r), min(nx, cx+r+1)):
            for iy in range(max(0, cy-r), min(ny, cy+r+1)):
                for iz in range(max(0, cz-r), min(nz, cz+r+1)):
                    dist = math.sqrt((ix-cx)**2+(iy-cy)**2+(iz-cz)**2)
                    w = 1.0/(1.0+dist) if cfg.smooth_deposition else 1.0
                    weights.append((ix, iy, iz, w))
                    wsum += w
        if wsum <= cfg.epsilon:
            return
        for ix, iy, iz, w in weights:
            d = max(-cfg.max_entropy_delta_per_step,
                    min(cfg.max_entropy_delta_per_step, delta * (w / wsum)))
            adapter.add_entropy(ix, iy, iz, d)
            out.total_added_entropy += d
            out.max_cell_entropy = max(out.max_cell_entropy, abs(d))
            out.active_cells += 1

    def _map_world_pos_to_cell(self, pos, shape):
        def map_one(v, n):
            if n <= 1: return 0
            idx = int(v*(n-1)) if 0.0 <= v <= 1.0 else int(round(v)) % n
            return max(0, min(n-1, idx))
        x,y,z = float(pos[0]),float(pos[1]),float(pos[2])
        return map_one(x,shape[0]), map_one(y,shape[1]), map_one(z,shape[2])

    def _apply_ambient_relaxation(self, adapter, dt):
        cfg   = self.config
        vals  = adapter.values
        before = vals.copy()
        np.clip(vals + dt*cfg.ambient_relaxation*(cfg.ambient_entropy - vals),
                0.0, 1.0, out=vals)
        return float(np.sum(np.abs(vals - before)))

    def _storm_severity(self, phi_rms_total, unstable):
        sev = float(phi_rms_total)
        if unstable: sev *= 1.5
        return sev

    def _emit_event(self, event_bus, event):
        if event_bus is None:
            return False
        for name in ("emit", "publish", "push"):
            fn = getattr(event_bus, name, None)
            if callable(fn):
                fn(event)
                return True
        return False

    def _telemetry_dict(self, out):
        return {
            "schema_version":           SCHEMA_VERSION,
            "module_name":              MODULE_NAME,
            "module_version":           MODULE_VERSION,
            "step_index":               int(out.step_index),
            "total_added_entropy":      float(out.total_added_entropy),
            "max_cell_entropy":         float(out.max_cell_entropy),
            "active_cells":             int(out.active_cells),
            "ambient_relaxation_amount":float(out.ambient_relaxation_amount),
            "phi_rms_total":            float(out.phi_rms_total),
            "unstable":                 bool(out.unstable),
            "regime":                   str(out.regime),
            "emitted_events":           int(out.emitted_events),
        }