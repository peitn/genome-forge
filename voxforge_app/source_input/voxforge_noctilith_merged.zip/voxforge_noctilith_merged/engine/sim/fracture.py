"""noctilith/sim/fracture.py — FractureBridge with vectorized ops."""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from engine.sim.quantized_field_ops import (
    build_radius_kernel, vectorized_propagate, vectorized_extract_candidates,
)

SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME    = "noctilith.sim.fracture"


def _upsample(arr: np.ndarray, target: tuple) -> np.ndarray:
    nx, ny, nz = target
    fx = nx/arr.shape[0]; fy = ny/arr.shape[1]; fz = nz/arr.shape[2]
    ix = np.clip((np.arange(nx)/fx).astype(int), 0, arr.shape[0]-1)
    iy = np.clip((np.arange(ny)/fy).astype(int), 0, arr.shape[1]-1)
    iz = np.clip((np.arange(nz)/fz).astype(int), 0, arr.shape[2]-1)
    return arr[np.ix_(ix, iy, iz)]


def compute_stress(voxel_ids: np.ndarray, thermal_T: np.ndarray, entropy_S: np.ndarray,
                   *, ambient_T: float = 293.15, thermal_expansion_coeff: float = 1e-5,
                   entropy_damage_scale: float = 0.3) -> np.ndarray:
    target = voxel_ids.shape
    T_up = _upsample(thermal_T.astype(np.float32), target)
    S_up = _upsample(entropy_S.astype(np.float32), target)
    thermal = np.clip(np.abs(T_up - ambient_T) * thermal_expansion_coeff, 0.0, 1.0)
    damage  = np.clip(S_up * entropy_damage_scale, 0.0, 1.0)
    stress  = np.clip((thermal + damage).astype(np.float32), 0.0, 1.0)
    stress[voxel_ids == 0] = 0.0
    return stress


def compute_fracture_mask(stress: np.ndarray, threshold: float = 0.5) -> np.ndarray:
    return stress >= float(threshold)


@dataclass
class FractureBridgeConfig:
    enabled: bool = True
    external_risk_weight: float = 0.75
    base_stress_weight: float = 0.25
    fracture_risk_threshold: float = 0.80
    propagation_enabled: bool = True
    propagation_radius: int = 1
    propagation_gain: float = 0.35
    propagation_seed_top_k: int = 8
    return_fracture_risk_field: bool = True
    candidate_limit: int = 256
    emit_events: bool = False
    _kernel: object = field(default=None, repr=False, compare=False, hash=False)


class FractureBridge:
    def __init__(self, config: Optional[FractureBridgeConfig] = None):
        self.config = config or FractureBridgeConfig()
        self._kernel = None

    def _get_kernel(self) -> np.ndarray:
        if self._kernel is None:
            self._kernel = build_radius_kernel(
                self.config.propagation_radius, smooth=True)
        return self._kernel

    def extract_candidates(self, fracture_risk: np.ndarray) -> List[Tuple[int,int,int,float]]:
        cfg = self.config
        return vectorized_extract_candidates(
            fracture_risk, cfg.fracture_risk_threshold,
            max_candidates=max(1, int(cfg.candidate_limit)))

    def propagate_fracture_risk(self, fracture_risk: np.ndarray) -> np.ndarray:
        cfg = self.config
        if not cfg.propagation_enabled:
            return fracture_risk.copy()
        seeds = self.extract_candidates(fracture_risk)
        if not seeds:
            return fracture_risk.astype(np.float64, copy=True)
        return vectorized_propagate(
            fracture_risk, seeds[:max(1, int(cfg.propagation_seed_top_k))],
            kernel=self._get_kernel(), gain=float(cfg.propagation_gain), clamp=1.0)

    def compute_fracture_risk(self, external_failure_risk: np.ndarray,
                               base_stress: Optional[np.ndarray] = None) -> np.ndarray:
        cfg = self.config
        ext = np.clip(external_failure_risk.astype(np.float64), 0.0, 1.0)
        if base_stress is not None:
            base = np.clip(base_stress.astype(np.float64), 0.0, 1.0)
            risk = cfg.external_risk_weight * ext + cfg.base_stress_weight * base
        else:
            risk = ext
        return np.clip(risk, 0.0, 1.0)

    def evaluate(self, *, external_failure_risk_field: np.ndarray,
                 base_stress_field: Optional[np.ndarray] = None,
                 telemetry: Optional[Dict[str, Any]] = None,
                 event_bus: Optional[Any] = None) -> Dict[str, Any]:
        cfg = self.config
        if not cfg.enabled:
            return {"enabled": False, "candidate_count": 0,
                    "fracture_risk_max": 0.0, "candidates": []}

        fracture_risk = self.compute_fracture_risk(
            external_failure_risk_field, base_stress_field)

        if cfg.propagation_enabled:
            fracture_risk = self.propagate_fracture_risk(fracture_risk)

        candidates_raw = self.extract_candidates(fracture_risk)
        candidates = [{"index": (ix, iy, iz), "risk": r}
                      for ix, iy, iz, r in candidates_raw]

        zone_fraction = float(np.mean(fracture_risk >= cfg.fracture_risk_threshold))
        result = {
            "schema_version":    SCHEMA_VERSION,
            "module_name":       MODULE_NAME,
            "candidate_count":   len(candidates),
            "fracture_risk_max": float(np.max(fracture_risk)),
            "fracture_zone_fraction": zone_fraction,
            "candidates":        candidates,
        }
        if cfg.return_fracture_risk_field:
            result["fracture_risk_field"] = fracture_risk.astype(np.float32, copy=True)
        return result
