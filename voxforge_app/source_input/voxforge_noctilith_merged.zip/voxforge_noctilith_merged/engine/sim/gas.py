"""
engine/sim/gas.py
=================
Aerodynamika a plyny — simulace kouře, páry, toxinů, vzduchového proudění.

Blueprint §4.5: "jednoduché proudění vzduchu, kouř, pára, toxické plyny,
                  tlakové vlny, ventilace, podtlak/přetlak"
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Dict, List, Optional, Tuple
import numpy as np


# ── Typy plynů ────────────────────────────────────────────────────────────────

class GasType(IntEnum):
    NONE   = 0
    AIR    = 1    # vzduch (neutrální, ventilace)
    SMOKE  = 2    # kouř (stoupá, pohlcuje světlo, dusí)
    STEAM  = 3    # pára (stoupá, kondenzuje při chladu → voda)
    TOXIN  = 4    # toxický plyn (hustý, klesá)
    FLAME  = 5    # hořící plyn / plazma (krátkodobý, šíří teplo)


GAS_PROPS = {
    GasType.AIR:   {"density": 0.5, "rises": True,  "toxic": False, "flammable": False},
    GasType.SMOKE: {"density": 0.3, "rises": True,  "toxic": True,  "flammable": False},
    GasType.STEAM: {"density": 0.2, "rises": True,  "toxic": False, "flammable": False},
    GasType.TOXIN: {"density": 0.9, "rises": False, "toxic": True,  "flammable": False},
    GasType.FLAME: {"density": 0.1, "rises": True,  "toxic": False, "flammable": True},
}


# ── Gas Grid ──────────────────────────────────────────────────────────────────

class GasGrid:
    """
    3D pole plynů pro VoxForge platformu.

    Každá buňka má:
    - gas_type : typ plynu (GasType enum)
    - concentration : množství plynu (0-1)
    - pressure : tlak (pro tlakové vlny)
    - temperature: lokální teplota (ovlivňuje výstup)

    Fyzika:
    - kouř + pára stoupají (y+)
    - toxiny klesají (y-)
    - všechny se horizontálně šíří (gradient koncentrace)
    - disperzní útlum (plyny se ředí)
    - solid buňky blokují tok
    """

    DISPERSION = 0.15     # rychlost šíření do stran
    RISE_SPEED = 0.25     # rychlost stoupání lehkých plynů
    SINK_SPEED = 0.20     # rychlost klesání těžkých plynů
    DECAY      = 0.008    # přirozený rozptyl

    def __init__(self, sx: int, sy: int, sz: int):
        self.sx, self.sy, self.sz = sx, sy, sz
        self.gas_type     = np.zeros((sx, sy, sz), dtype=np.uint8)
        self.concentration = np.zeros((sx, sy, sz), dtype=np.float32)
        self.pressure     = np.zeros((sx, sy, sz), dtype=np.float32)
        self.solid        = np.zeros((sx, sy, sz), dtype=bool)
        self._events: List[dict] = []

    def emit(self, x: int, y: int, z: int,
             gas_type: GasType, amount: float = 0.5) -> None:
        """Emituj plyn v buňce."""
        if not self.solid[x, y, z]:
            self.gas_type[x, y, z] = int(gas_type)
            self.concentration[x, y, z] = min(1.0,
                self.concentration[x, y, z] + amount)

    def step(self, tick: int, temperature: Optional[np.ndarray] = None) -> List[dict]:
        """Jeden tick plynové simulace."""
        self._events.clear()
        new_conc = self.concentration.copy()
        new_type = self.gas_type.copy()

        sx, sy, sz = self.sx, self.sy, self.sz

        # Pro každý typ plynu aplikuj odlišnou fyziku
        for gtype_val in [GasType.SMOKE, GasType.STEAM, GasType.TOXIN, GasType.FLAME, GasType.AIR]:
            mask = (self.gas_type == int(gtype_val)) & (self.concentration > 0.01) & ~self.solid
            if not np.any(mask):
                continue

            props = GAS_PROPS.get(gtype_val, {})
            rises = props.get("rises", True)

            # Vertikální pohyb
            if rises and sy > 1:
                # Stoupání: přesuň do y+1
                can_rise = mask[:-1, :, :] & ~self.solid[1:, :, :]  # spodní → horní
                # Ale jen kde je horní buňka méně plná
                # (wait, in our world y is horizontal - let's use y+1 = up)
                # Actually let's fix: y-axis, higher y = higher altitude
                can_rise = mask[:, :-1, :] & ~self.solid[:, 1:, :]
                flow = np.minimum(new_conc[:, :-1, :], self.RISE_SPEED) * can_rise
                new_conc[:, :-1, :] -= flow
                new_conc[:, 1:,  :] += flow * (1 - np.float32(self.solid[:, 1:, :]))

            elif not rises and sy > 1:
                # Klesání: přesuň do y-1
                can_sink = mask[:, 1:, :] & ~self.solid[:, :-1, :]
                flow = np.minimum(new_conc[:, 1:, :], self.SINK_SPEED) * can_sink
                new_conc[:, 1:,  :] -= flow
                new_conc[:, :-1, :] += flow * (1 - np.float32(self.solid[:, :-1, :]))

            # Horizontální šíření (X, Z)
            for dx, dz in [(1,0),(-1,0),(0,1),(0,-1)]:
                xs = slice(max(0,-dx), sx-max(0,dx))
                zs = slice(max(0,-dz), sz-max(0,dz))
                xd = slice(max(0, dx), sx-max(0,-dx))
                zd = slice(max(0, dz), sz-max(0,-dz))

                src = new_conc[xs, :, zs]
                dst = new_conc[xd, :, zd]
                dst_solid = self.solid[xd, :, zd]

                diff = (src - dst) * self.DISPERSION * 0.5
                flow = np.maximum(diff, 0.0) * ~dst_solid
                new_conc[xs, :, zs] -= flow
                new_conc[xd, :, zd] += flow

        # Přirozený útlum
        new_conc *= (1.0 - self.DECAY)
        new_conc = np.clip(new_conc, 0.0, 1.0)
        new_conc[self.solid] = 0.0

        # Pára kondenzuje při nízké teplotě
        if temperature is not None:
            steam_mask = (self.gas_type == int(GasType.STEAM)) & (temperature < 0.20)
            condensed = new_conc * steam_mask * 0.3
            new_conc[steam_mask] -= condensed[steam_mask]
            if np.any(steam_mask & (condensed > 0.01)):
                self._events.append({"type": "steam_condensed"})

        # Plamen se gasí (krátkodobý)
        flame_mask = self.gas_type == int(GasType.FLAME)
        new_conc[flame_mask] *= 0.7   # rychlé hasnutí

        # Aktualizuj gas_type kde koncentrace klesla na nulu
        new_type[new_conc < 0.005] = int(GasType.NONE)

        # Tlakové vlny (zjednodušené: šok z míst s vysokou koncentrací)
        high_pressure = new_conc > 0.85
        if np.any(high_pressure):
            self._events.append({
                "type": "gas_pressure_high",
                "count": int(np.sum(high_pressure)),
                "max":   float(new_conc[high_pressure].max()),
            })
            # Tlakové šíření
            self.pressure[high_pressure] = new_conc[high_pressure] * 0.5

        self.concentration[:] = new_conc
        self.gas_type[:] = new_type
        self.pressure *= 0.85   # pressure decay

        return list(self._events)

    def emit_from_chemistry(self, gas_name: str, x: int, y: int, z: int,
                             amount: float = 0.3) -> None:
        """Rozhraní pro ChemistrySystem — emituje plyn podle jména."""
        mapping = {
            "smoke": GasType.SMOKE,
            "steam": GasType.STEAM,
            "toxin": GasType.TOXIN,
            "flame": GasType.FLAME,
        }
        gtype = mapping.get(gas_name.lower(), GasType.SMOKE)
        self.emit(x, y, z, gtype, amount)

    def toxic_cells(self) -> np.ndarray:
        """Bool array — kde je toxická koncentrace."""
        return (
            ((self.gas_type == int(GasType.TOXIN)) |
             (self.gas_type == int(GasType.SMOKE))) &
            (self.concentration > 0.4)
        )

    def total_gas(self, gas_type: Optional[GasType] = None) -> float:
        if gas_type is None:
            return float(self.concentration.sum())
        return float(self.concentration[self.gas_type == int(gas_type)].sum())

    def cross_section(self, y: int) -> str:
        """ASCII vizualizace plynů na výšce y."""
        chars = {
            GasType.NONE:  " ",
            GasType.AIR:   "·",
            GasType.SMOKE: "░",
            GasType.STEAM: "~",
            GasType.TOXIN: "▒",
            GasType.FLAME: "▓",
        }
        lines = []
        for z in range(self.sz):
            row = ""
            for x in range(self.sx):
                if self.solid[x, y, z]:
                    row += "█"
                elif self.concentration[x, y, z] < 0.01:
                    row += " "
                else:
                    gtype = GasType(int(self.gas_type[x, y, z]))
                    row += chars.get(gtype, "?")
            lines.append(row)
        return "\n".join(lines)
