"""noctilith/sim/material_degradation.py — M11 MaterialDegradationModel."""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME    = "noctilith.sim.material_degradation"
MODULE_VERSION = "1.0.0"


class ScalarFieldAdapter:
    """Resolves .T / .S / .values / raw ndarray."""
    def __init__(self, obj: Any):
        self._obj = obj

    @property
    def values(self) -> np.ndarray:
        if isinstance(self._obj, np.ndarray):
            return self._obj
        for attr in ("T", "S", "values", "temperatures", "entropy", "E"):
            v = getattr(self._obj, attr, None)
            if v is not None and isinstance(v, np.ndarray):
                return v
        raise AttributeError(f"Cannot resolve array from {type(self._obj)}")


@dataclass
class MaterialDegradationConfig:
    enabled: bool = True
    temp_weight: float = 0.45
    entropy_weight: float = 0.40
    rms_weight: float = 0.15
    fatigue_exponent: float = 1.35
    risk_gain: float = 0.65
    risk_bias: float = 0.0
    ambient_temperature: float = 293.15
    temperature_scale_K: float = 500.0
    entropy_scale: float = 1.0
    phi_rms_scale: float = 1.0
    max_fatigue_multiplier: float = 100.0
    smoothing: float = 0.15
    return_risk_field: bool = True
    risk_field_dtype: str = "float32"
    risk_event_threshold: float = 0.65
    emit_events: bool = False
    epsilon: float = 1e-8


@dataclass
class MaterialDegradationTelemetry:
    step_index: int = 0
    phi_rms_total: float = 0.0
    fatigue_mean: float = 0.0
    fatigue_max: float = 0.0
    risk_mean: float = 0.0
    risk_max: float = 0.0
    risk_zone_fraction: float = 0.0
    hot_fraction: float = 0.0
    entropic_fraction: float = 0.0
    emitted_events: int = 0


class MaterialDegradationModel:
    def __init__(self, config: Optional[MaterialDegradationConfig] = None):
        self.config = config or MaterialDegradationConfig()

    def compute_fatigue_multiplier(self, *, T: np.ndarray, S: np.ndarray,
                                   phi_rms_total: float) -> np.ndarray:
        cfg = self.config
        dT         = np.maximum(0.0, T - cfg.ambient_temperature) / max(cfg.temperature_scale_K, cfg.epsilon)
        entropy_term = np.maximum(0.0, S) / max(cfg.entropy_scale, cfg.epsilon)
        rms_term   = max(0.0, phi_rms_total) / max(cfg.phi_rms_scale, cfg.epsilon)
        raw = cfg.temp_weight * dT + cfg.entropy_weight * entropy_term + cfg.rms_weight * rms_term
        fatigue = 1.0 + np.power(np.maximum(0.0, raw), cfg.fatigue_exponent)
        if cfg.smoothing > 0.0:
            fatigue = (1.0 - cfg.smoothing) * fatigue + cfg.smoothing * float(np.mean(fatigue))
        return np.clip(fatigue, 1.0, cfg.max_fatigue_multiplier)

    def compute_failure_risk(self, fatigue_multiplier: np.ndarray) -> np.ndarray:
        cfg = self.config
        x = np.maximum(0.0, fatigue_multiplier - 1.0)
        risk = 1.0 - np.exp(-(cfg.risk_gain * x + cfg.risk_bias))
        return np.clip(risk, 0.0, 1.0)

    def evaluate(self, *, thermal_grid: Any, entropy_field: Any,
                 telemetry: Optional[Dict[str, Any]] = None,
                 event_bus: Optional[Any] = None) -> Dict[str, Any]:
        cfg = self.config
        out = MaterialDegradationTelemetry()
        if not cfg.enabled:
            return self._telemetry_dict(out)

        telemetry = telemetry or {}
        T = np.asarray(ScalarFieldAdapter(thermal_grid).values, dtype=np.float64)
        S = np.asarray(ScalarFieldAdapter(entropy_field).values, dtype=np.float64)

        out.step_index    = int(telemetry.get("step_index", 0))
        out.phi_rms_total = float(telemetry.get("phi_rms_total", 0.0))

        fatigue = self.compute_fatigue_multiplier(T=T, S=S, phi_rms_total=out.phi_rms_total)
        risk    = self.compute_failure_risk(fatigue)

        out.fatigue_mean       = float(np.mean(fatigue))
        out.fatigue_max        = float(np.max(fatigue))
        out.risk_mean          = float(np.mean(risk))
        out.risk_max           = float(np.max(risk))
        out.risk_zone_fraction = float(np.mean(risk >= cfg.risk_event_threshold))
        out.hot_fraction       = float(np.mean(T > cfg.ambient_temperature))
        out.entropic_fraction  = float(np.mean(S > cfg.entropy_scale))

        result = self._telemetry_dict(out)
        if cfg.return_risk_field:
            dtype = np.float32 if cfg.risk_field_dtype == "float32" else np.float64
            result["risk_field"] = risk.astype(dtype, copy=True)
        return result

    def _telemetry_dict(self, out: MaterialDegradationTelemetry) -> Dict[str, Any]:
        return {
            "schema_version":   SCHEMA_VERSION,
            "module_name":      MODULE_NAME,
            "step_index":       int(out.step_index),
            "phi_rms_total":    float(out.phi_rms_total),
            "fatigue_mean":     float(out.fatigue_mean),
            "fatigue_max":      float(out.fatigue_max),
            "risk_mean":        float(out.risk_mean),
            "risk_max":         float(out.risk_max),
            "risk_zone_fraction": float(out.risk_zone_fraction),
            "hot_fraction":     float(out.hot_fraction),
            "entropic_fraction": float(out.entropic_fraction),
            "emitted_events":   int(out.emitted_events),
        }
