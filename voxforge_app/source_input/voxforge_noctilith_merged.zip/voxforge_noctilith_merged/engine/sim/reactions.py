"""noctilith/sim/reactions.py — phase transitions & reactions."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional

@dataclass
class ReactionDef:
    name: str
    reactant: str
    product: str
    condition: str
    temp_min_k: float = 0.0
    temp_max_k: float = 1e9
    requires_oxygen: bool = False
    latent_heat_j_kg: float = 0.0
    heat_release_j_kg: float = 0.0

_BUILTIN: List[ReactionDef] = [
    ReactionDef("water_freeze",  "water", "ice",   "T<273.15", temp_max_k=273.15,  latent_heat_j_kg=334_000),
    ReactionDef("water_boil",    "water", "steam", "T>373.15", temp_min_k=373.15,  latent_heat_j_kg=2_260_000),
    ReactionDef("ice_melt",      "ice",   "water", "T>273.15", temp_min_k=273.15,  latent_heat_j_kg=334_000),
    ReactionDef("lava_solidify", "lava",  "stone", "T<900",    temp_max_k=900.0,   latent_heat_j_kg=400_000),
    ReactionDef("stone_melt",    "stone", "lava",  "T>1986",   temp_min_k=1986.0,  latent_heat_j_kg=400_000),
    ReactionDef("wood_burn",     "wood",  "ash",   "T>573",    temp_min_k=573.0,   requires_oxygen=True, heat_release_j_kg=15_000_000),
]

_INDEX: Dict[str, List[ReactionDef]] = {}
for _r in _BUILTIN:
    _INDEX.setdefault(_r.reactant, []).append(_r)

def phase_transition(material_name: str, temperature_k: float, *, has_oxygen: bool = True) -> Optional[str]:
    for rxn in _INDEX.get(material_name, []):
        if rxn.requires_oxygen and not has_oxygen:
            continue
        if rxn.temp_min_k <= temperature_k <= rxn.temp_max_k:
            return rxn.product
    return None

def get_reactions_for(material_name: str) -> List[ReactionDef]:
    return list(_INDEX.get(material_name, []))

def load_reactions_from_yaml_dir(path: str) -> int:
    raise NotImplementedError("TASK B-007: implement YAML reaction loader")
