"""noctilith/sim/thermal.py — ThermalGrid field."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Tuple

import numpy as np


@dataclass(init=False)
class ThermalGrid:
    """Simple thermal field with backward-compatible constructor.

    Supports both:
      - ThermalGrid((nx, ny, nz), dx=..., dt=..., ambient_temp=...)
      - ThermalGrid(existing_ndarray)
      - ThermalGrid(T=existing_ndarray)
    """

    T: np.ndarray = field(init=False)
    dx: float = field(init=False, default=1.0)
    dt: float = field(init=False, default=0.1)
    ambient_temp: float = field(init=False, default=293.15)

    def __init__(self, shape_or_array: Any = (1, 1, 1), *, dx: float = 1.0, dt: float = 0.1,
                 ambient_temp: float = 293.15, T: Any = None):
        if T is not None:
            arr = np.asarray(T, dtype=np.float64)
        elif isinstance(shape_or_array, np.ndarray):
            arr = np.asarray(shape_or_array, dtype=np.float64)
        else:
            arr = np.full(tuple(shape_or_array), float(ambient_temp), dtype=np.float64)
        if arr.ndim != 3:
            raise ValueError("ThermalGrid expects a 3D array or 3D shape")
        self.T = arr
        self.dx = float(dx)
        self.dt = float(dt)
        self.ambient_temp = float(ambient_temp)

    @classmethod
    def uniform(cls, shape: Tuple[int, ...], temp_k: float = 293.15, **kwargs) -> "ThermalGrid":
        return cls(shape, ambient_temp=temp_k, **kwargs)

    @property
    def shape(self) -> Tuple[int, ...]:
        return self.T.shape

    @property
    def temperatures(self) -> np.ndarray:
        return self.T

    def add_heat(self, ix: int, iy: int, iz: int, delta: float) -> None:
        self.T[ix, iy, iz] += float(delta)

    def step(self, conductivity: float = 1.0) -> None:
        # Conservative no-op placeholder: enough for coupling tests and preserves compatibility.
        _ = conductivity

    def max_temp(self) -> float:
        return float(np.max(self.T))

    def mean_temp(self) -> float:
        return float(np.mean(self.T))
