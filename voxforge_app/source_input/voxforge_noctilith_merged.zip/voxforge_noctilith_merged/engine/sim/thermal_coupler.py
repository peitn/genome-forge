#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
noctilith/sim/thermal_coupler.py
================================
NOCTILITH THERMAL COUPLER
Effective bridge between Space3D field state and the thermal grid.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np


SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME = "noctilith.sim.thermal_coupler"
MODULE_VERSION = "1.0.0"

Vec3i = Tuple[int, int, int]
Vec3f = Tuple[float, float, float]


@dataclass
class ThermalCouplerConfig:
    enabled: bool = True
    joule_gain: float = 0.12
    rms_gain: float = 0.01
    source_gain: float = 0.25
    object_gain: float = 0.10
    max_heat_delta_per_step: float = 5.0
    ambient_temperature: float = 293.15
    ambient_relaxation: float = 0.0025
    deposition_radius: int = 1
    smooth_deposition: bool = True
    epsilon: float = 1e-8


@dataclass
class ThermalStepTelemetry:
    step_index: int = 0
    total_added_heat: float = 0.0
    max_cell_heat: float = 0.0
    active_cells: int = 0
    ambient_cooling_energy: float = 0.0
    phi_em_mean: float = 0.0
    phi_em_max: float = 0.0
    phi_rms_total: float = 0.0


class ThermalGridAdapter:
    """Protocol adapter for thermal grid implementations."""

    def __init__(self, thermal_grid: Any):
        self.thermal_grid = thermal_grid

    @property
    def shape(self) -> Tuple[int, int, int]:
        shape = getattr(self.thermal_grid, "shape", None)
        if shape is not None:
            return tuple(shape)
        temps = getattr(self.thermal_grid, "temperatures", None)
        if temps is None:
            raise AttributeError("Thermal grid must expose .shape or .temperatures")
        return tuple(temps.shape)

    @property
    def temperatures(self) -> np.ndarray:
        # Try .T first (ThermalGrid uses .T), then .temperatures
        T = getattr(self.thermal_grid, "T", None)
        if T is not None and isinstance(T, np.ndarray):
            return T
        temps = getattr(self.thermal_grid, "temperatures", None)
        if temps is None:
            raise AttributeError("Thermal grid must expose .T or .temperatures")
        return temps

    def add_heat(self, ix: int, iy: int, iz: int, delta: float) -> None:
        fn = getattr(self.thermal_grid, "add_heat", None)
        if callable(fn):
            fn(ix, iy, iz, float(delta))
        else:
            self.temperatures[ix, iy, iz] += float(delta)


@dataclass
class ThermalCoupler:
    config: ThermalCouplerConfig = field(default_factory=ThermalCouplerConfig)

    def apply(
        self,
        thermal_grid: Any,
        *,
        dt: float,
        field_state: Optional[Dict[str, Any]] = None,
        telemetry: Optional[Dict[str, Any]] = None,
        sources: Optional[Iterable[Dict[str, Any]]] = None,
        objects: Optional[Iterable[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Apply one deterministic thermal coupling step.

        Parameters
        ----------
        thermal_grid : Any
            Object exposing .shape + (.T or .temperatures), optional .add_heat()
        dt : float
            Simulation step duration.
        field_state : dict, optional
            Keys: phi_em, phi_rms, phi_g, phi_s, phi_w
        telemetry : dict, optional
            Keys: phi_rms_total, unstable, regime
        sources / objects : iterables, optional
            Local emitters. Each item: {pos, heat/intensity/activity}
        """
        adapter = ThermalGridAdapter(thermal_grid)
        cfg = self.config
        out = ThermalStepTelemetry()

        if not cfg.enabled or dt <= 0.0:
            return self._telemetry_dict(out)

        field_state = field_state or {}
        telemetry   = telemetry   or {}
        sources     = list(sources or [])
        objects     = list(objects or [])

        phi_em  = self._extract_array(field_state, "phi_em")
        phi_rms = self._extract_array(field_state, "phi_rms")

        if phi_em is not None and phi_em.size > 0:
            out.phi_em_mean = float(np.mean(phi_em))
            out.phi_em_max  = float(np.max(phi_em))

        out.phi_rms_total = float(telemetry.get("phi_rms_total", 0.0))

        # 1) Joule-like heating: phi_em^2 → heat
        if phi_em is not None:
            self._deposit_from_field(
                adapter=adapter, scalar_field=phi_em,
                dt=dt, gain=cfg.joule_gain, square=True, out=out,
            )

        # 2) Low-amplitude activity from phi_rms
        if phi_rms is not None and cfg.rms_gain > 0.0:
            self._deposit_from_field(
                adapter=adapter, scalar_field=phi_rms,
                dt=dt, gain=cfg.rms_gain, square=False, out=out,
            )

        # 3) Source-local additive heating
        if sources and cfg.source_gain > 0.0:
            for src in sources:
                pos       = tuple(src.get("pos", (0.0, 0.0, 0.0)))
                intensity = float(src.get("heat", src.get("intensity", 1.0)))
                self._deposit_local(adapter, pos, dt * cfg.source_gain * intensity, out)

        # 4) Object-local activity heating
        if objects and cfg.object_gain > 0.0:
            for obj in objects:
                pos      = tuple(obj.get("pos", (0.0, 0.0, 0.0)))
                activity = float(obj.get("heat", obj.get("activity", 1.0)))
                self._deposit_local(adapter, pos, dt * cfg.object_gain * activity, out)

        # 5) Passive ambient relaxation
        out.ambient_cooling_energy = self._apply_ambient_relaxation(adapter, dt)

        return self._telemetry_dict(out)

    # ── helpers ───────────────────────────────────────────────────────────────

    def _extract_array(self, state: Dict[str, Any], key: str) -> Optional[np.ndarray]:
        arr = state.get(key)
        if arr is None:
            return None
        arr = np.asarray(arr, dtype=np.float64)
        return arr if arr.ndim == 3 else None

    def _deposit_from_field(
        self, *, adapter, scalar_field, dt, gain, square, out,
    ) -> None:
        cfg = self.config
        src_shape = scalar_field.shape
        dst_shape = adapter.shape
        sx, sy, sz = (max(s, 1) for s in src_shape)
        dx, dy, dz = (max(d, 1) for d in dst_shape)

        for ix in range(dx):
            fx = min(int(ix * sx / dx), sx - 1)
            for iy in range(dy):
                fy = min(int(iy * sy / dy), sy - 1)
                for iz in range(dz):
                    fz = min(int(iz * sz / dz), sz - 1)
                    raw = float(scalar_field[fx, fy, fz])
                    val = raw * raw if square else abs(raw)
                    delta = dt * gain * val
                    delta = max(-cfg.max_heat_delta_per_step,
                                min(cfg.max_heat_delta_per_step, delta))
                    if abs(delta) == 0.0:
                        continue
                    adapter.add_heat(ix, iy, iz, delta)
                    out.total_added_heat += delta
                    out.max_cell_heat = max(out.max_cell_heat, abs(delta))
                    out.active_cells += 1

    def _deposit_local(
        self, adapter, pos: Tuple[float, ...], delta: float, out,
    ) -> None:
        cfg = self.config
        nx, ny, nz = adapter.shape
        cx, cy, cz = self._map_world_pos_to_cell(pos, adapter.shape)
        r = max(0, int(cfg.deposition_radius))

        if r == 0:
            d = max(-cfg.max_heat_delta_per_step,
                    min(cfg.max_heat_delta_per_step, delta))
            adapter.add_heat(cx, cy, cz, d)
            out.total_added_heat += d
            out.max_cell_heat = max(out.max_cell_heat, abs(d))
            out.active_cells += 1
            return

        weights: List[Tuple[int, int, int, float]] = []
        wsum = 0.0
        for ix in range(max(0, cx - r), min(nx, cx + r + 1)):
            for iy in range(max(0, cy - r), min(ny, cy + r + 1)):
                for iz in range(max(0, cz - r), min(nz, cz + r + 1)):
                    dist = math.sqrt((ix-cx)**2 + (iy-cy)**2 + (iz-cz)**2)
                    w = 1.0 / (1.0 + dist) if cfg.smooth_deposition else 1.0
                    weights.append((ix, iy, iz, w))
                    wsum += w

        if wsum <= cfg.epsilon:
            return

        for ix, iy, iz, w in weights:
            d = delta * (w / wsum)
            d = max(-cfg.max_heat_delta_per_step,
                    min(cfg.max_heat_delta_per_step, d))
            adapter.add_heat(ix, iy, iz, d)
            out.total_added_heat += d
            out.max_cell_heat = max(out.max_cell_heat, abs(d))
            out.active_cells += 1

    def _map_world_pos_to_cell(
        self, pos: Tuple[float, ...], shape: Tuple[int, int, int],
    ) -> Vec3i:
        def map_one(v: float, n: int) -> int:
            if n <= 1:
                return 0
            idx = int(v * (n - 1)) if 0.0 <= v <= 1.0 else int(round(v)) % n
            return max(0, min(n - 1, idx))
        x, y, z = float(pos[0]), float(pos[1]), float(pos[2])
        return map_one(x, shape[0]), map_one(y, shape[1]), map_one(z, shape[2])

    def _apply_ambient_relaxation(self, adapter, dt: float) -> float:
        cfg   = self.config
        temps = adapter.temperatures
        before = temps.copy()
        temps += dt * cfg.ambient_relaxation * (cfg.ambient_temperature - temps)
        return float(np.sum(np.abs(temps - before)))

    def _telemetry_dict(self, out: ThermalStepTelemetry) -> Dict[str, Any]:
        return {
            "schema_version":          SCHEMA_VERSION,
            "module_name":             MODULE_NAME,
            "module_version":          MODULE_VERSION,
            "step_index":              int(out.step_index),
            "total_added_heat":        float(out.total_added_heat),
            "max_cell_heat":           float(out.max_cell_heat),
            "active_cells":            int(out.active_cells),
            "ambient_cooling_energy":  float(out.ambient_cooling_energy),
            "phi_em_mean":             float(out.phi_em_mean),
            "phi_em_max":              float(out.phi_em_max),
            "phi_rms_total":           float(out.phi_rms_total),
        }