"""
engine/sim/weather.py
=====================
Počasí — dynamický weather systém ovlivňující svět.

Blueprint §5: "WeatherSimulation"
Ovlivňuje: teplotu, vlhkost, fluid (déšť), gas (mlha, bouře).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple
import numpy as np


class WeatherType(str, Enum):
    CLEAR    = "clear"
    CLOUDY   = "cloudy"
    RAIN     = "rain"
    STORM    = "storm"
    SNOW     = "snow"
    FOG      = "fog"
    HEAT_WAVE = "heat_wave"
    BLIZZARD = "blizzard"


@dataclass
class WeatherState:
    type: WeatherType = WeatherType.CLEAR
    temperature: float = 0.5     # ambient teplota (0-1)
    humidity: float    = 0.3     # vlhkost vzduchu
    wind_x: float      = 0.0     # síla větru X
    wind_z: float      = 0.0     # síla větru Z
    precipitation: float = 0.0   # intenzita srážek
    fog_density: float = 0.0
    intensity: float   = 1.0     # celková intenzita (multiplier)
    tick_remaining: int = 200    # jak dlouho trvá toto počasí


WEATHER_TRANSITIONS = {
    WeatherType.CLEAR:     [WeatherType.CLOUDY, WeatherType.CLEAR, WeatherType.CLEAR, WeatherType.HEAT_WAVE],
    WeatherType.CLOUDY:    [WeatherType.RAIN, WeatherType.CLEAR, WeatherType.STORM, WeatherType.FOG],
    WeatherType.RAIN:      [WeatherType.STORM, WeatherType.CLOUDY, WeatherType.RAIN, WeatherType.CLEAR],
    WeatherType.STORM:     [WeatherType.RAIN, WeatherType.CLOUDY, WeatherType.CLEAR],
    WeatherType.SNOW:      [WeatherType.BLIZZARD, WeatherType.CLEAR, WeatherType.SNOW],
    WeatherType.FOG:       [WeatherType.CLEAR, WeatherType.RAIN, WeatherType.CLOUDY],
    WeatherType.HEAT_WAVE: [WeatherType.CLEAR, WeatherType.STORM],
    WeatherType.BLIZZARD:  [WeatherType.SNOW, WeatherType.CLEAR],
}

WEATHER_PARAMS = {
    WeatherType.CLEAR:     dict(temp=0.55, humidity=0.2, precip=0.0, fog=0.0, dur=400),
    WeatherType.CLOUDY:    dict(temp=0.45, humidity=0.5, precip=0.0, fog=0.05, dur=300),
    WeatherType.RAIN:      dict(temp=0.35, humidity=0.9, precip=0.6, fog=0.1, dur=200),
    WeatherType.STORM:     dict(temp=0.30, humidity=1.0, precip=1.0, fog=0.2, dur=100),
    WeatherType.SNOW:      dict(temp=0.10, humidity=0.7, precip=0.5, fog=0.15, dur=250),
    WeatherType.FOG:       dict(temp=0.40, humidity=0.8, precip=0.05, fog=0.8, dur=150),
    WeatherType.HEAT_WAVE: dict(temp=0.85, humidity=0.1, precip=0.0, fog=0.0, dur=300),
    WeatherType.BLIZZARD:  dict(temp=0.05, humidity=1.0, precip=0.9, fog=0.5, dur=80),
}


class WeatherSimulation:
    """
    Dynamický weather systém.

    Stav počasí se mění podle Markovského přechodu.
    Ovlivňuje fieldy světa: moisture, temperature surface layer.

    Použití:
        weather = WeatherSimulation(world_size=(32,8,32), seed=42)
        scheduler.register(SimModule("weather", weather.step, every_n_ticks=5, priority=10))
        # každých 5 ticků = šetří výkon
    """

    def __init__(self, world_size: Tuple[int,int,int], seed: int = 42):
        self.sx, self.sy, self.sz = world_size
        self._rng = np.random.default_rng(seed)
        self.state = WeatherState()
        self._set_weather(WeatherType.CLEAR)
        self._history: List[WeatherType] = []
        self._wind_angle = 0.0

    def _set_weather(self, wtype: WeatherType) -> None:
        p = WEATHER_PARAMS[wtype]
        self.state.type = wtype
        self.state.temperature  = p["temp"]   + float(self._rng.uniform(-0.05, 0.05))
        self.state.humidity     = p["humidity"]
        self.state.precipitation = p["precip"]
        self.state.fog_density  = p["fog"]
        self.state.tick_remaining = p["dur"] + int(self._rng.integers(-50, 50))
        self.state.intensity    = float(self._rng.uniform(0.7, 1.3))
        # Náhodný vítr
        angle = float(self._rng.uniform(0, 2 * math.pi))
        speed = float(self._rng.uniform(0, 0.3))
        self.state.wind_x = math.cos(angle) * speed
        self.state.wind_z = math.sin(angle) * speed

    def step(self, tick: int) -> List[dict]:
        """Jeden tick weather simulace. Vrátí seznam world effects."""
        effects: List[dict] = []

        self.state.tick_remaining -= 1
        if self.state.tick_remaining <= 0:
            self._transition()
            effects.append({
                "type": "weather_changed",
                "new": self.state.type.value,
                "temp": self.state.temperature,
                "humidity": self.state.humidity,
            })

        # Efekty počasí
        if self.state.precipitation > 0.3:
            # Déšť / sníh → přidej vlhkost na povrch
            rain_amount = self.state.precipitation * 0.02 * self.state.intensity
            effects.append({
                "type": "precipitation",
                "amount": rain_amount,
                "is_snow": self.state.temperature < 0.15,
            })

        if self.state.fog_density > 0.4:
            effects.append({
                "type": "fog",
                "density": self.state.fog_density * self.state.intensity,
            })

        if self.state.type == WeatherType.STORM:
            # Bouře → náhodné blesky
            if self._rng.random() < 0.05:
                lx = int(self._rng.integers(0, self.sx))
                lz = int(self._rng.integers(0, self.sz))
                effects.append({
                    "type": "lightning",
                    "pos": (lx, self.sy - 1, lz),
                    "damage": 0.8,
                })

        if self.state.type == WeatherType.HEAT_WAVE:
            effects.append({
                "type": "ambient_heat",
                "delta": 0.005 * self.state.intensity,
            })

        # Vítr ovlivní gas simulaci (odkazem)
        if abs(self.state.wind_x) > 0.1 or abs(self.state.wind_z) > 0.1:
            effects.append({
                "type": "wind",
                "dx": self.state.wind_x,
                "dz": self.state.wind_z,
            })

        return effects

    def _transition(self) -> None:
        options = WEATHER_TRANSITIONS.get(self.state.type, [WeatherType.CLEAR])
        idx = int(self._rng.integers(0, len(options)))
        next_w = options[idx]
        self._history.append(self.state.type)
        self._history = self._history[-20:]
        self._set_weather(next_w)

    def apply_to_world(self,
                       moisture: np.ndarray,
                       temperature: np.ndarray,
                       effects: List[dict]) -> None:
        """
        Aplikuj weather efekty na world fieldy.
        Volat po step() s výsledkem.
        """
        for eff in effects:
            if eff["type"] == "precipitation":
                # Déšť zvyšuje vlhkost na vrchní vrstvě
                moisture[:, -1, :] = np.minimum(
                    moisture[:, -1, :] + eff["amount"], 1.0)
                # Sníh snižuje teplotu
                if eff["is_snow"]:
                    temperature[:, -1, :] = np.maximum(
                        temperature[:, -1, :] - 0.002, 0.0)

            elif eff["type"] == "ambient_heat":
                temperature += eff["delta"]
                np.clip(temperature, 0, 1, out=temperature)

            elif eff["type"] == "lightning":
                lx, _, lz = eff["pos"]
                # Tepelný šok sloupci
                x0, x1 = max(0, lx-1), min(self.sx, lx+2)
                z0, z1 = max(0, lz-1), min(self.sz, lz+2)
                temperature[x0:x1, :, z0:z1] = np.minimum(
                    temperature[x0:x1, :, z0:z1] + eff["damage"], 1.0)

    @property
    def current(self) -> WeatherState:
        return self.state

    def __repr__(self) -> str:
        s = self.state
        return (f"Weather({s.type.value}, "
                f"T={s.temperature:.2f}, "
                f"rain={s.precipitation:.2f}, "
                f"remaining={s.tick_remaining})")
