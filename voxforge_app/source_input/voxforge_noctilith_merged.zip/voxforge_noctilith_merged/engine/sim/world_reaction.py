"""noctilith/sim/world_reaction.py — WorldReactionBridge."""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME    = "noctilith.sim.world_reaction"


@dataclass
class WorldReactionConfig:
    enabled: bool = True
    candidate_limit: int = 32
    damage_threshold: float = 0.70
    debris_threshold: float = 0.88
    base_damage: float = 0.10
    damage_gain: float = 0.65
    max_damage_per_step: float = 1.0
    mark_damage: bool = True
    weaken_voxels: bool = True
    request_debris_spawn: bool = True
    emit_events: bool = True
    dry_run: bool = False


@dataclass
class WorldReactionTelemetry:
    step_index: int = 0
    processed_candidates: int = 0
    damaged_voxels: int = 0
    weakened_voxels: int = 0
    debris_requests: int = 0
    emitted_events: int = 0


class WorldAdapter:
    def __init__(self, world_obj: Any):
        self._obj = world_obj

    def in_bounds(self, ix: int, iy: int, iz: int) -> bool:
        fn = getattr(self._obj, "in_bounds", None)
        if callable(fn):
            return bool(fn(ix, iy, iz))
        shape = getattr(self._obj, "shape", None)
        if shape:
            return 0 <= ix < shape[0] and 0 <= iy < shape[1] and 0 <= iz < shape[2]
        return True

    def mark_damage(self, ix: int, iy: int, iz: int, damage: float) -> bool:
        fn = getattr(self._obj, "mark_damage", None)
        if callable(fn):
            fn(ix, iy, iz, damage); return True
        return False

    def weaken_voxel(self, ix: int, iy: int, iz: int, amount: float) -> bool:
        fn = getattr(self._obj, "weaken_voxel", None)
        if callable(fn):
            fn(ix, iy, iz, amount); return True
        return False

    def request_debris_spawn(self, ix: int, iy: int, iz: int, strength: float) -> bool:
        fn = getattr(self._obj, "request_debris_spawn", None)
        if callable(fn):
            fn(ix, iy, iz, strength); return True
        # Fallback: append to _debris_requests list
        lst = getattr(self._obj, "_debris_requests", None)
        if lst is not None:
            lst.append({"index": (ix, iy, iz), "strength": strength}); return True
        return False


class WorldReactionBridge:
    def __init__(self, config: Optional[WorldReactionConfig] = None):
        self.config = config or WorldReactionConfig()

    def _damage_from_risk(self, risk: float) -> float:
        cfg = self.config
        return min(cfg.max_damage_per_step,
                   cfg.base_damage + cfg.damage_gain * max(0.0, risk))

    def _emit_event(self, event_bus: Any, evt: Any) -> bool:
        if event_bus is None or evt is None:
            return False
        fn = getattr(event_bus, "emit", getattr(event_bus, "publish", None))
        if callable(fn):
            fn(evt); return True
        return False

    def apply(self, *, world_obj: Any, fracture_result: Dict[str, Any],
              telemetry: Optional[Dict[str, Any]] = None,
              event_bus: Optional[Any] = None) -> Dict[str, Any]:
        cfg = self.config
        out = WorldReactionTelemetry()
        if not cfg.enabled:
            return self._telemetry_dict(out)

        telemetry = telemetry or {}
        out.step_index = int(telemetry.get("step_index", 0))
        adapter = WorldAdapter(world_obj)
        candidates = list(fracture_result.get("candidates", []))[:max(0, int(cfg.candidate_limit))]

        for entry in candidates:
            idx  = entry.get("index")
            risk = float(entry.get("risk", 0.0))
            if idx is None or len(idx) != 3:
                continue
            ix, iy, iz = int(idx[0]), int(idx[1]), int(idx[2])
            if not adapter.in_bounds(ix, iy, iz):
                continue

            out.processed_candidates += 1
            damage = self._damage_from_risk(risk)

            if risk >= cfg.damage_threshold:
                if cfg.mark_damage and not cfg.dry_run:
                    if adapter.mark_damage(ix, iy, iz, damage):
                        out.damaged_voxels += 1
                elif cfg.dry_run:
                    out.damaged_voxels += 1
                if cfg.weaken_voxels and not cfg.dry_run:
                    if adapter.weaken_voxel(ix, iy, iz, damage):
                        out.weakened_voxels += 1
                elif cfg.dry_run:
                    out.weakened_voxels += 1

            if risk >= cfg.debris_threshold and cfg.request_debris_spawn:
                if cfg.dry_run:
                    out.debris_requests += 1
                elif adapter.request_debris_spawn(ix, iy, iz, risk):
                    out.debris_requests += 1

        return self._telemetry_dict(out)

    def _telemetry_dict(self, out: WorldReactionTelemetry) -> Dict[str, Any]:
        return {
            "schema_version":       SCHEMA_VERSION,
            "module_name":          MODULE_NAME,
            "step_index":           int(out.step_index),
            "processed_candidates": int(out.processed_candidates),
            "damaged_voxels":       int(out.damaged_voxels),
            "weakened_voxels":      int(out.weakened_voxels),
            "debris_requests":      int(out.debris_requests),
            "emitted_events":       int(out.emitted_events),
        }
