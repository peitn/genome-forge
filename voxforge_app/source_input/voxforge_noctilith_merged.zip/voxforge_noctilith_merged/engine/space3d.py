#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
noctilith/space3d.py
====================

NOCTILITH SPACE 3D (full unified package revision)
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

import numpy as np

try:
    from numba import njit
except Exception:
    def njit(*args, **kwargs):
        def deco(fn):
            return fn
        return deco


SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME = "noctilith.space3d"
MODULE_VERSION = "1.0.0"


@dataclass
class Space3DConfig:
    nx: int = 48
    ny: int = 48
    nz: int = 48
    dx: float = 1.0
    dt: float = 0.01
    seed: int = 123
    tau_phi: float = 1.0
    D_g: float = 0.10
    D_em: float = 0.15
    D_s: float = 0.08
    D_w: float = 0.12
    mu_g: float = 0.03
    mu_em: float = 0.04
    mu_s: float = 0.06
    mu_w: float = 0.05
    lambda_g: float = 0.05
    lambda_em: float = 0.08
    lambda_s: float = 0.10
    lambda_w: float = 0.09
    field_mix_ge: float = 0.00
    field_mix_gs: float = 0.00
    field_mix_gw: float = 0.00
    field_mix_es: float = 0.00
    field_mix_ew: float = 0.00
    field_mix_sw: float = 0.00
    enable_dynamic_mix: bool = False
    mix_energy_center: float = 0.05
    mix_energy_width: float = 0.02
    mix_scale_max: float = 1.0
    kappa: float = 0.10
    chi: float = 0.20
    eta: float = 1.0
    alpha_max: float = 1.2
    alpha_sigma: float = 1.0
    enable_dynamic_switches: bool = True
    omega_low: float = 0.08
    omega_high: float = 0.22
    omega_crit: float = 0.45
    omega_gate_width: float = 0.03
    phi_rms_crit_center: float = 0.10
    phi_rms_crit_width: float = 0.03
    low_D_mul: float = 0.95
    low_mu_mul: float = 1.10
    low_lambda_mul: float = 1.00
    low_gamma_v_mul: float = 1.05
    low_alpha_mul: float = 0.90
    low_vmax_mul: float = 0.90
    high_D_mul: float = 1.05
    high_mu_mul: float = 0.95
    high_lambda_mul: float = 1.05
    high_gamma_v_mul: float = 0.95
    high_alpha_mul: float = 1.10
    high_vmax_mul: float = 1.05
    crit_D_mul: float = 1.15
    crit_mu_mul: float = 0.90
    crit_lambda_mul: float = 1.15
    crit_gamma_v_mul: float = 0.90
    crit_alpha_mul: float = 1.25
    crit_vmax_mul: float = 1.15
    beta_h: float = 0.0
    h_proxy_ema_alpha: float = 0.95
    gamma_v: float = 0.20
    v_max: float = 5.0
    n_obj: int = 4
    drive_eps: float = 1e-9
    source_radius_g: float = 3.0
    source_radius_em: float = 2.5
    source_radius_s: float = 1.25
    source_radius_w: float = 1.75
    phantom_threshold_g: float = 0.08
    phantom_threshold_em: float = 0.08
    phantom_threshold_s: float = 0.20
    phantom_threshold_w: float = 0.10
    phantom_fraction_threshold: float = 0.02
    phantom_meanabs_threshold: float = 0.08
    boundary_mode: str = "dirichlet"
    object_boundary_mode: str = "bounce"
    default_compute_hash_in_step: bool = True
    include_config_in_hash: bool = False
    eps: float = 1e-12
    G_sigma: float = 10.0
    enable_source_superposition: bool = False
    source_superposition_mode: str = "voxel_bin"
    source_superposition_centroid_weight: str = "q_abs"
    source_superposition_quant_scale: float = 1e9
    source_superposition_merge_abs_min: float = 0.0
    source_superposition_max_groups: int = 0
    source_superposition_sort_keys: bool = False
    source_scale_gravity: float = 0.10
    source_scale_electromagnetic: float = 1.00
    source_scale_strong: float = 0.80
    source_scale_weak: float = 0.30
    motion_scale_gravity: float = 0.08
    motion_scale_electromagnetic: float = 1.00
    motion_scale_strong: float = 0.50
    motion_scale_weak: float = 0.20
    source_bias_C: float = 0.00
    source_bias_P: float = 0.00
    source_bias_T: float = 0.00
    source_bias_CP: float = 0.10
    source_bias_CPT: float = 0.05
    motion_bias_C: float = 0.00
    motion_bias_P: float = 0.00
    motion_bias_T: float = 0.00
    motion_bias_CP: float = 0.10
    motion_bias_CPT: float = 0.05
    min_symmetry_bias: float = -4.0
    max_symmetry_bias: float = 4.0
    enable_force_sources: bool = True
    force_source_scale_gravity: float = 1.00
    force_source_scale_electromagnetic: float = 1.00
    force_source_scale_strong: float = 1.20
    force_source_scale_weak: float = 0.60
    force_source_scale_symmetry_region: float = 0.50
    fail_fast_on_unstable: bool = False


@njit(cache=True)
def _compact_kernel(r: float, R: float) -> float:
    if r >= R:
        return 0.0
    t = 1.0 - r / (R + 1e-12)
    return t * t


@njit(cache=True)
def lap6_kernel(phi: np.ndarray, lap_out: np.ndarray, inv_dx2: float) -> None:
    nx, ny, nz = phi.shape
    lap_out.fill(0.0)
    for i in range(1, nx - 1):
        for j in range(1, ny - 1):
            for k in range(1, nz - 1):
                lap_out[i, j, k] = (
                    phi[i+1,j,k] + phi[i-1,j,k] +
                    phi[i,j+1,k] + phi[i,j-1,k] +
                    phi[i,j,k+1] + phi[i,j,k-1] -
                    6.0 * phi[i,j,k]
                ) * inv_dx2


@njit(cache=True)
def step_field_kernel(phi, phi_new, lap, S, G, dt, tau_phi, D_eff, mu_eff, lambda_eff,
                      alpha_eff, z_dot, beta_h, h_proxy, mix_term):
    nx, ny, nz = phi.shape
    inv_tau = 1.0 / max(tau_phi, 1e-12)
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                x = phi[i,j,k]
                uprime = np.tanh(x)
                phi_dot = inv_tau * (
                    D_eff * lap[i,j,k]
                    - mu_eff * x
                    - lambda_eff * uprime
                    + S[i,j,k]
                    + alpha_eff * z_dot * G[i,j,k]
                    + beta_h * h_proxy * x
                    + mix_term[i,j,k]
                )
                phi_new[i,j,k] = x + dt * phi_dot


@njit(cache=True)
def splat_sources_weighted_kernel(S, obj_r, obj_amp, dx, source_radius):
    nx, ny, nz = S.shape
    S.fill(0.0)
    vox_R = int(np.ceil(source_radius / dx))
    n_obj = obj_r.shape[0]
    for n in range(n_obj):
        rx, ry, rz = obj_r[n,0], obj_r[n,1], obj_r[n,2]
        amp = obj_amp[n]
        cx, cy, cz = int(rx/dx), int(ry/dx), int(rz/dx)
        xmin = max(0, cx-vox_R); xmax = min(nx-1, cx+vox_R)
        ymin = max(0, cy-vox_R); ymax = min(ny-1, cy+vox_R)
        zmin = max(0, cz-vox_R); zmax = min(nz-1, cz+vox_R)
        for i in range(xmin, xmax+1):
            dx0 = (i*dx) - rx
            for j in range(ymin, ymax+1):
                dy0 = (j*dx) - ry
                for k in range(zmin, zmax+1):
                    dz0 = (k*dx) - rz
                    dist = np.sqrt(dx0*dx0 + dy0*dy0 + dz0*dz0)
                    w = _compact_kernel(dist, source_radius)
                    if w > 0.0:
                        S[i,j,k] += amp * w


@njit(cache=True)
def sample_trilinear_kernel(field, rx, ry, rz, dx):
    nx, ny, nz = field.shape
    eps = 1e-9
    x = max(0.0, min((nx-2)-eps, rx/dx))
    y = max(0.0, min((ny-2)-eps, ry/dx))
    z = max(0.0, min((nz-2)-eps, rz/dx))
    i, j, k = int(x), int(y), int(z)
    fx, fy, fz = x-i, y-j, z-k
    c000=field[i,j,k]; c100=field[i+1,j,k]; c010=field[i,j+1,k]; c110=field[i+1,j+1,k]
    c001=field[i,j,k+1]; c101=field[i+1,j,k+1]; c011=field[i,j+1,k+1]; c111=field[i+1,j+1,k+1]
    c00=c000*(1-fx)+c100*fx; c10=c010*(1-fx)+c110*fx
    c01=c001*(1-fx)+c101*fx; c11=c011*(1-fx)+c111*fx
    c0=c00*(1-fy)+c10*fy; c1=c01*(1-fy)+c11*fy
    return c0*(1-fz)+c1*fz


@njit(cache=True)
def sample_grad4_central_kernel(phi_g, phi_em, phi_s, phi_w, rx, ry, rz, dx):
    inv = 1.0 / (2.0*dx)
    def g(phi):
        px=sample_trilinear_kernel(phi,rx+dx,ry,rz,dx); mx=sample_trilinear_kernel(phi,rx-dx,ry,rz,dx)
        py=sample_trilinear_kernel(phi,rx,ry+dx,rz,dx); my=sample_trilinear_kernel(phi,rx,ry-dx,rz,dx)
        pz=sample_trilinear_kernel(phi,rx,ry,rz+dx,dx); mz=sample_trilinear_kernel(phi,rx,ry,rz-dx,dx)
        return (px-mx)*inv,(py-my)*inv,(pz-mz)*inv
    gx_g,gy_g,gz_g=g(phi_g); gx_em,gy_em,gz_em=g(phi_em)
    gx_s,gy_s,gz_s=g(phi_s); gx_w,gy_w,gz_w=g(phi_w)
    return gx_g,gy_g,gz_g,gx_em,gy_em,gz_em,gx_s,gy_s,gz_s,gx_w,gy_w,gz_w


@njit(cache=True)
def step_objects_multifield_kernel(phi_g, phi_em, phi_s, phi_w,
                                    obj_r, obj_v, obj_m,
                                    obj_drive_g, obj_drive_em, obj_drive_s, obj_drive_w,
                                    dt, dx, gamma_v, v_max, drive_eps):
    n_obj = obj_r.shape[0]
    vmax2 = v_max*v_max
    for i in range(n_obj):
        rx,ry,rz = obj_r[i,0],obj_r[i,1],obj_r[i,2]
        dg=obj_drive_g[i]; de=obj_drive_em[i]; ds=obj_drive_s[i]; dw=obj_drive_w[i]
        active_g=abs(dg)>drive_eps; active_e=abs(de)>drive_eps
        active_s=abs(ds)>drive_eps; active_w=abs(dw)>drive_eps
        gx_g=gy_g=gz_g=gx_em=gy_em=gz_em=gx_s=gy_s=gz_s=gx_w=gy_w=gz_w=0.0
        if active_g or active_e or active_s or active_w:
            gx_g,gy_g,gz_g,gx_em,gy_em,gz_em,gx_s,gy_s,gz_s,gx_w,gy_w,gz_w = \
                sample_grad4_central_kernel(phi_g,phi_em,phi_s,phi_w,rx,ry,rz,dx)
            if not active_g: gx_g=gy_g=gz_g=0.0
            if not active_e: gx_em=gy_em=gz_em=0.0
            if not active_s: gx_s=gy_s=gz_s=0.0
            if not active_w: gx_w=gy_w=gz_w=0.0
        m=max(obj_m[i],1e-12)
        fx=-gamma_v*obj_v[i,0]-dg*gx_g-de*gx_em-ds*gx_s-dw*gx_w
        fy=-gamma_v*obj_v[i,1]-dg*gy_g-de*gy_em-ds*gy_s-dw*gy_w
        fz=-gamma_v*obj_v[i,2]-dg*gz_g-de*gz_em-ds*gz_s-dw*gz_w
        inv_m=1.0/m
        obj_v[i,0]+=dt*fx*inv_m; obj_v[i,1]+=dt*fy*inv_m; obj_v[i,2]+=dt*fz*inv_m
        v2=obj_v[i,0]**2+obj_v[i,1]**2+obj_v[i,2]**2
        if v2>vmax2 and vmax2>0.0:
            scale=v_max/(np.sqrt(v2)+1e-12)
            obj_v[i,0]*=scale; obj_v[i,1]*=scale; obj_v[i,2]*=scale
        obj_r[i,0]+=dt*obj_v[i,0]; obj_r[i,1]+=dt*obj_v[i,1]; obj_r[i,2]+=dt*obj_v[i,2]


class NoctilithSpace3DNumba:
    def __init__(self, cfg: Space3DConfig):
        self.cfg = cfg
        self._validate_config()
        self.rng = np.random.default_rng(cfg.seed)
        shape = (cfg.nx, cfg.ny, cfg.nz)
        self.phi_g   = np.zeros(shape, dtype=np.float64)
        self.phi_em  = np.zeros(shape, dtype=np.float64)
        self.phi_s   = np.zeros(shape, dtype=np.float64)
        self.phi_w   = np.zeros(shape, dtype=np.float64)
        self.phi_g_new  = np.zeros_like(self.phi_g)
        self.phi_em_new = np.zeros_like(self.phi_g)
        self.phi_s_new  = np.zeros_like(self.phi_g)
        self.phi_w_new  = np.zeros_like(self.phi_g)
        self.lap_g  = np.zeros_like(self.phi_g)
        self.lap_em = np.zeros_like(self.phi_g)
        self.lap_s  = np.zeros_like(self.phi_g)
        self.lap_w  = np.zeros_like(self.phi_g)
        self.S_g  = np.zeros_like(self.phi_g)
        self.S_em = np.zeros_like(self.phi_g)
        self.S_s  = np.zeros_like(self.phi_g)
        self.S_w  = np.zeros_like(self.phi_g)
        self.mix_g  = np.zeros_like(self.phi_g)
        self.mix_em = np.zeros_like(self.phi_g)
        self.mix_s  = np.zeros_like(self.phi_g)
        self.mix_w  = np.zeros_like(self.phi_g)
        self.G = self._build_G_profile()
        self._sumG = float(np.sum(self.G))
        self._sumG_safe = self._sumG if self._sumG > cfg.eps else 1.0
        self._inv_dx2 = 1.0 / (cfg.dx * cfg.dx)
        self.z = 0.0
        self.tick = 0
        self._h_proxy_ema = 0.0
        self._last_unstable = False
        self._last_regime = "mid"
        self._last_omega_D = 0.0
        self._last_phi_rms_total = 0.0
        self._last_mix_scale = 1.0
        self.n_obj = int(cfg.n_obj)
        self.obj_r  = np.zeros((self.n_obj, 3), dtype=np.float64)
        self.obj_v  = np.zeros((self.n_obj, 3), dtype=np.float64)
        self.obj_m  = np.ones((self.n_obj,), dtype=np.float64)
        self.obj_q  = np.zeros((self.n_obj,), dtype=np.float64)
        self.obj_force_gravity        = np.zeros((self.n_obj,), dtype=np.float64)
        self.obj_force_electromagnetic = np.zeros((self.n_obj,), dtype=np.float64)
        self.obj_force_strong         = np.zeros((self.n_obj,), dtype=np.float64)
        self.obj_force_weak           = np.zeros((self.n_obj,), dtype=np.float64)
        self.obj_sym_C   = np.ones((self.n_obj,), dtype=np.float64)
        self.obj_sym_P   = np.ones((self.n_obj,), dtype=np.float64)
        self.obj_sym_T   = np.ones((self.n_obj,), dtype=np.float64)
        self.obj_sym_CP  = np.ones((self.n_obj,), dtype=np.float64)
        self.obj_sym_CPT = np.ones((self.n_obj,), dtype=np.float64)
        self.obj_meta:     List[Dict[str, Any]] = []
        self.obj_symmetry: List[Dict[str, Any]] = []
        self.force_sources: List[Dict[str, Any]] = []
        self.light_sources: List[Dict[str, Any]] = []
        self._obj_source_g  = np.zeros((self.n_obj,), dtype=np.float64)
        self._obj_source_em = np.zeros((self.n_obj,), dtype=np.float64)
        self._obj_source_s  = np.zeros((self.n_obj,), dtype=np.float64)
        self._obj_source_w  = np.zeros((self.n_obj,), dtype=np.float64)
        self._obj_drive_g   = np.zeros((self.n_obj,), dtype=np.float64)
        self._obj_drive_em  = np.zeros((self.n_obj,), dtype=np.float64)
        self._obj_drive_s   = np.zeros((self.n_obj,), dtype=np.float64)
        self._obj_drive_w   = np.zeros((self.n_obj,), dtype=np.float64)
        self._agg_obj_r = np.zeros((max(self.n_obj,1), 3), dtype=np.float64)
        self._agg_amp   = np.zeros((max(self.n_obj,1),), dtype=np.float64)
        self._src_superposition_last_by_field = {
            k: {"enabled": bool(cfg.enable_source_superposition),
                "groups": int(self.n_obj),
                "ratio": 1.0 if self.n_obj > 0 else 0.0,
                "pruned_groups": 0}
            for k in ("g","em","s","w")
        }
        self._init_objects()
        self._warmup()

    def _validate_config(self):
        c = self.cfg
        if c.nx < 3 or c.ny < 3 or c.nz < 3: raise ValueError("nx, ny, nz must be >= 3")
        if c.dx <= 0.0: raise ValueError("dx must be > 0")
        if c.dt <= 0.0: raise ValueError("dt must be > 0")
        if c.tau_phi <= 0.0: raise ValueError("tau_phi must be > 0")

    def _build_G_profile(self):
        c = self.cfg
        x = np.linspace(0.0, (c.nx-1)*c.dx, c.nx)
        y = np.linspace(0.0, (c.ny-1)*c.dx, c.ny)
        z = np.linspace(0.0, (c.nz-1)*c.dx, c.nz)
        X,Y,Z = np.meshgrid(x,y,z,indexing="ij")
        center = np.array([x[-1]/2, y[-1]/2, z[-1]/2], dtype=np.float64)
        sigma = max(c.G_sigma, c.eps)
        dist_sq = (X-center[0])**2+(Y-center[1])**2+(Z-center[2])**2
        return np.exp(-dist_sq/(2*sigma*sigma)).astype(np.float64)

    def _init_objects(self):
        c = self.cfg
        bounds = np.array([c.nx,c.ny,c.nz],dtype=np.float64)*c.dx
        for i in range(self.n_obj):
            margin = min(5.0, max(c.dx, 0.15*np.min(bounds)))
            lo = np.full(3, margin, dtype=np.float64)
            hi = np.maximum(lo+c.dx, bounds-margin)
            self.obj_r[i] = self.rng.uniform(lo, hi)
            self.obj_v[i] = (self.rng.random(3)-0.5)*2.0
            self.obj_m[i] = 1.0+0.2*i
            self.obj_q[i] = 1.0 if i%2==0 else -0.8
        self.obj_force_gravity[:] = np.abs(self.obj_m)
        self.obj_force_electromagnetic[:] = self.obj_q

    def _warmup(self):
        lap6_kernel(self.phi_g,  self.lap_g,  self._inv_dx2)
        lap6_kernel(self.phi_em, self.lap_em, self._inv_dx2)
        lap6_kernel(self.phi_s,  self.lap_s,  self._inv_dx2)
        lap6_kernel(self.phi_w,  self.lap_w,  self._inv_dx2)
        self._sync_object_aux_buffers_to_current_objects()
        self._compute_effective_object_channels()
        if self.n_obj > 0:
            self._splat_all_sources()

    def _sync_object_aux_buffers_to_current_objects(self):
        n = int(self.obj_r.shape[0])
        if self.obj_v.shape != (n,3):   self.obj_v = np.zeros((n,3),dtype=np.float64)
        if self.obj_m.shape != (n,):    self.obj_m = np.ones((n,),dtype=np.float64)
        if self.obj_q.shape != (n,):    self.obj_q = np.zeros((n,),dtype=np.float64)
        def z1(): return np.zeros((n,),dtype=np.float64)
        def o1(): return np.ones((n,),dtype=np.float64)
        if self.obj_force_gravity.shape        != (n,): self.obj_force_gravity        = z1()
        if self.obj_force_electromagnetic.shape != (n,): self.obj_force_electromagnetic = z1()
        if self.obj_force_strong.shape         != (n,): self.obj_force_strong         = z1()
        if self.obj_force_weak.shape           != (n,): self.obj_force_weak           = z1()
        if self.obj_sym_C.shape   != (n,): self.obj_sym_C   = o1()
        if self.obj_sym_P.shape   != (n,): self.obj_sym_P   = o1()
        if self.obj_sym_T.shape   != (n,): self.obj_sym_T   = o1()
        if self.obj_sym_CP.shape  != (n,): self.obj_sym_CP  = o1()
        if self.obj_sym_CPT.shape != (n,): self.obj_sym_CPT = o1()
        if self._obj_source_g.shape != (n,):
            self._obj_source_g=z1(); self._obj_source_em=z1()
            self._obj_source_s=z1(); self._obj_source_w=z1()
            self._obj_drive_g=z1();  self._obj_drive_em=z1()
            self._obj_drive_s=z1();  self._obj_drive_w=z1()
            self._agg_obj_r=np.zeros((max(n,1),3),dtype=np.float64)
            self._agg_amp=np.zeros((max(n,1),),dtype=np.float64)
        self.n_obj = n
        self._src_superposition_last_by_field = {
            k: {"enabled": bool(self.cfg.enable_source_superposition),
                "groups": int(n), "ratio": 1.0 if n>0 else 0.0, "pruned_groups": 0}
            for k in ("g","em","s","w")
        }

    def set_objects_from_arrays(self, obj_r, obj_v=None, obj_m=None, obj_q=None,
                                 force_gravity=None, force_electromagnetic=None,
                                 force_strong=None, force_weak=None,
                                 sym_C=None, sym_P=None, sym_T=None, sym_CP=None, sym_CPT=None,
                                 obj_meta=None):
        obj_r = np.asarray(obj_r, dtype=np.float64)
        if obj_r.ndim != 2 or obj_r.shape[1] != 3:
            raise ValueError("obj_r must have shape (n,3)")
        n = int(obj_r.shape[0])
        self.obj_r = np.ascontiguousarray(obj_r.copy())
        self.obj_v = np.zeros((n,3),dtype=np.float64) if obj_v is None else np.ascontiguousarray(np.asarray(obj_v,dtype=np.float64).copy())
        self.obj_m = np.ones((n,),dtype=np.float64)   if obj_m is None else np.ascontiguousarray(np.asarray(obj_m,dtype=np.float64).copy())
        self.obj_q = np.zeros((n,),dtype=np.float64)  if obj_q is None else np.ascontiguousarray(np.asarray(obj_q,dtype=np.float64).copy())
        self._sync_object_aux_buffers_to_current_objects()
        def assign(dst, src, fallback):
            if src is None:
                setattr(self, dst, np.full((n,), fallback, dtype=np.float64))
            else:
                arr = np.asarray(src, dtype=np.float64)
                if arr.shape != (n,): raise ValueError(f"{dst} must have shape (n,)")
                setattr(self, dst, np.ascontiguousarray(arr.copy()))
        assign("obj_force_gravity",        force_gravity,        0.0)
        assign("obj_force_electromagnetic", force_electromagnetic, 0.0)
        assign("obj_force_strong",         force_strong,         0.0)
        assign("obj_force_weak",           force_weak,           0.0)
        if force_gravity        is None: self.obj_force_gravity[:]        = np.abs(self.obj_m)
        if force_electromagnetic is None: self.obj_force_electromagnetic[:] = self.obj_q
        assign("obj_sym_C",   sym_C,   1.0)
        assign("obj_sym_P",   sym_P,   1.0)
        assign("obj_sym_T",   sym_T,   1.0)
        assign("obj_sym_CP",  sym_CP,  1.0)
        assign("obj_sym_CPT", sym_CPT, 1.0)
        self.obj_meta = [] if obj_meta is None else list(obj_meta)
        self._compute_effective_object_channels()

    def set_force_sources(self, force_sources):
        self.force_sources = [] if force_sources is None else list(force_sources)

    def set_light_sources(self, light_sources):
        self.light_sources = [] if light_sources is None else list(light_sources)

    def _field_bounds(self):
        return np.array([(self.cfg.nx-1)*self.cfg.dx,(self.cfg.ny-1)*self.cfg.dx,(self.cfg.nz-1)*self.cfg.dx],dtype=np.float64)

    def _apply_object_boundaries(self):
        mode = str(self.cfg.object_boundary_mode).lower()
        if mode=="none" or self.n_obj==0: return
        bounds = self._field_bounds()
        if mode=="wrap":
            for axis in range(3):
                size=bounds[axis]
                if size>0.0: self.obj_r[:,axis]=np.mod(self.obj_r[:,axis],size)
            return
        for i in range(self.n_obj):
            for axis in range(3):
                lo,hi=0.0,bounds[axis]
                if self.obj_r[i,axis]<lo:
                    if mode=="bounce": self.obj_r[i,axis]=lo+(lo-self.obj_r[i,axis]); self.obj_v[i,axis]*=-1.0
                    else: self.obj_r[i,axis]=lo; self.obj_v[i,axis]=0.0
                elif self.obj_r[i,axis]>hi:
                    if mode=="bounce": self.obj_r[i,axis]=hi-(self.obj_r[i,axis]-hi); self.obj_v[i,axis]*=-1.0
                    else: self.obj_r[i,axis]=hi; self.obj_v[i,axis]=0.0

    def _apply_field_boundaries(self, phi):
        mode = str(self.cfg.boundary_mode).lower()
        if mode=="none": return
        if mode=="dirichlet":
            phi[0,:,:]=0.; phi[-1,:,:]=0.; phi[:,0,:]=0.; phi[:,-1,:]=0.; phi[:,:,0]=0.; phi[:,:,-1]=0.
        elif mode=="clamp":
            phi[0,:,:]=phi[1,:,:]; phi[-1,:,:]=phi[-2,:,:]
            phi[:,0,:]=phi[:,1,:]; phi[:,-1,:]=phi[:,-2,:]
            phi[:,:,0]=phi[:,:,1]; phi[:,:,-1]=phi[:,:,-2]

    def _clip_symmetry(self, x):
        return np.clip(x, self.cfg.min_symmetry_bias, self.cfg.max_symmetry_bias)

    def _compute_effective_object_channels(self):
        self._sync_object_aux_buffers_to_current_objects()
        c = self.cfg
        sC=self._clip_symmetry(self.obj_sym_C); sP=self._clip_symmetry(self.obj_sym_P)
        sT=self._clip_symmetry(self.obj_sym_T); sCP=self._clip_symmetry(self.obj_sym_CP)
        sCPT=self._clip_symmetry(self.obj_sym_CPT)
        sb = c.source_bias_C*sC+c.source_bias_P*sP+c.source_bias_T*sT+c.source_bias_CP*sCP+c.source_bias_CPT*sCPT
        mb = c.motion_bias_C*sC+c.motion_bias_P*sP+c.motion_bias_T*sT+c.motion_bias_CP*sCP+c.motion_bias_CPT*sCPT
        sm=np.maximum(0.,1.+sb); mm=np.maximum(0.,1.+mb)
        self._obj_source_g[:]  = c.source_scale_gravity*self.obj_force_gravity*sm
        self._obj_source_em[:] = c.source_scale_electromagnetic*self.obj_force_electromagnetic*sm
        self._obj_source_s[:]  = c.source_scale_strong*self.obj_force_strong*sm
        self._obj_source_w[:]  = c.source_scale_weak*self.obj_force_weak*sm
        self._obj_drive_g[:]   = c.motion_scale_gravity*self.obj_force_gravity*mm
        self._obj_drive_em[:]  = c.motion_scale_electromagnetic*self.obj_force_electromagnetic*mm
        self._obj_drive_s[:]   = c.motion_scale_strong*self.obj_force_strong*mm
        self._obj_drive_w[:]   = c.motion_scale_weak*self.obj_force_weak*mm

    def _field_energy(self):
        return float(np.mean(self.phi_g**2)+np.mean(self.phi_em**2)+np.mean(self.phi_s**2)+np.mean(self.phi_w**2))

    def _phi_rms_total(self):
        return float(np.sqrt(max(self._field_energy(), 0.0)))

    def _total_energy_proxy(self):
        return float(self._field_energy()+self.cfg.eta*self.z*self.z)

    def _compute_omega_D(self):
        ef=self._field_energy(); ez=self.cfg.eta*self.z*self.z
        return float(ez/(ef+ez+self.cfg.eps))

    def _smooth_gate(self, x, center, width):
        width=max(width, self.cfg.eps)
        return 0.5*(1.0+np.tanh((x-center)/width))

    def _compute_regime(self, omega_D, phi_rms_total):
        c=self.cfg
        if not c.enable_dynamic_switches: return "mid"
        co=self._smooth_gate(omega_D,c.omega_crit,c.omega_gate_width)
        cr=self._smooth_gate(phi_rms_total,c.phi_rms_crit_center,c.phi_rms_crit_width)
        if max(co,cr)>0.5: return "crit"
        if omega_D<c.omega_low: return "low"
        if omega_D>c.omega_high: return "high"
        return "mid"

    def _apply_regime_scalars(self, regime):
        c=self.cfg
        out={"D_mul":1.,"mu_mul":1.,"lambda_mul":1.,"gamma_v_mul":1.,"alpha_mul":1.,"vmax_mul":1.}
        if regime=="low":
            out.update(D_mul=c.low_D_mul,mu_mul=c.low_mu_mul,lambda_mul=c.low_lambda_mul,
                       gamma_v_mul=c.low_gamma_v_mul,alpha_mul=c.low_alpha_mul,vmax_mul=c.low_vmax_mul)
        elif regime=="high":
            out.update(D_mul=c.high_D_mul,mu_mul=c.high_mu_mul,lambda_mul=c.high_lambda_mul,
                       gamma_v_mul=c.high_gamma_v_mul,alpha_mul=c.high_alpha_mul,vmax_mul=c.high_vmax_mul)
        elif regime=="crit":
            out.update(D_mul=c.crit_D_mul,mu_mul=c.crit_mu_mul,lambda_mul=c.crit_lambda_mul,
                       gamma_v_mul=c.crit_gamma_v_mul,alpha_mul=c.crit_alpha_mul,vmax_mul=c.crit_vmax_mul)
        return out

    def _alpha_B(self, omega_D):
        return float(self.cfg.alpha_max*np.tanh(self.cfg.alpha_sigma*max(omega_D,0.)))

    def _effective_mix_scale(self, energy_total):
        c=self.cfg
        if not c.enable_dynamic_mix: return 1.0
        w=max(c.mix_energy_width,c.eps)
        s=0.5*(1.+np.tanh((energy_total-c.mix_energy_center)/w))
        return float(1.+c.mix_scale_max*s)

    def _compute_mix_terms(self):
        c=self.cfg; scale=self._effective_mix_scale(self._total_energy_proxy())
        self._last_mix_scale=scale
        ge=c.field_mix_ge*scale; gs=c.field_mix_gs*scale; gw=c.field_mix_gw*scale
        es=c.field_mix_es*scale; ew=c.field_mix_ew*scale; sw=c.field_mix_sw*scale
        self.mix_g[:]  = ge*self.phi_em+gs*self.phi_s+gw*self.phi_w
        self.mix_em[:] = ge*self.phi_g +es*self.phi_s+ew*self.phi_w
        self.mix_s[:]  = gs*self.phi_g +es*self.phi_em+sw*self.phi_w
        self.mix_w[:]  = gw*self.phi_g +ew*self.phi_em+sw*self.phi_s

    def _aggregate_sources(self, amps, field_key):
        n=int(self.n_obj)
        if n==0:
            self._src_superposition_last_by_field[field_key]={"enabled":bool(self.cfg.enable_source_superposition),"groups":0,"ratio":0.,"pruned_groups":0}
            return self.obj_r[:0], amps[:0]
        if not self.cfg.enable_source_superposition:
            self._src_superposition_last_by_field[field_key]={"enabled":False,"groups":n,"ratio":1.,"pruned_groups":0}
            return self.obj_r, amps
        merge_abs_min=max(0.,self.cfg.source_superposition_merge_abs_min)
        keep_mask=np.abs(amps)>=merge_abs_min
        r_in=self.obj_r[keep_mask] if np.any(keep_mask) else self.obj_r
        a_in=amps[keep_mask] if np.any(keep_mask) else amps
        mode=str(self.cfg.source_superposition_mode).lower()
        use_abs=str(self.cfg.source_superposition_centroid_weight).lower()=="q_abs"
        groups: Dict[Any,List[int]]={}
        for idx in range(r_in.shape[0]):
            rx,ry,rz=r_in[idx]
            if mode=="voxel_bin":
                key=(int(np.floor(rx/self.cfg.dx)),int(np.floor(ry/self.cfg.dx)),int(np.floor(rz/self.cfg.dx)))
            else:
                qs=self.cfg.source_superposition_quant_scale
                key=(int(np.round(rx*qs)),int(np.round(ry*qs)),int(np.round(rz*qs)))
            groups.setdefault(key,[]).append(idx)
        keys=list(groups.keys())
        if self.cfg.source_superposition_sort_keys: keys.sort()
        mg=int(self.cfg.source_superposition_max_groups)
        if mg>0 and len(keys)>mg: keys=keys[:mg]
        gc=len(keys)
        if self._agg_obj_r.shape[0]<max(gc,1):
            self._agg_obj_r=np.zeros((max(gc,1),3),dtype=np.float64)
            self._agg_amp=np.zeros((max(gc,1),),dtype=np.float64)
        for oi,key in enumerate(keys):
            idxs=groups[key]; ag=a_in[idxs]; pg=r_in[idxs]
            w=np.abs(ag) if use_abs else ag.copy()
            if np.abs(np.sum(w))<self.cfg.eps: w=np.abs(ag)
            ws=float(np.sum(w))
            centroid=np.mean(pg,axis=0) if abs(ws)<self.cfg.eps else np.sum(pg*w[:,None],axis=0)/ws
            self._agg_obj_r[oi]=centroid; self._agg_amp[oi]=float(np.sum(ag))
        pruned=max(0,n-gc)
        self._src_superposition_last_by_field[field_key]={"enabled":True,"groups":int(gc),"ratio":float(gc/max(n,1)),"pruned_groups":int(pruned)}
        return self._agg_obj_r[:gc], self._agg_amp[:gc]

    def _splat_effective_sources(self, S, amps, radius, field_key):
        if self.n_obj==0:
            S.fill(0.)
            self._src_superposition_last_by_field[field_key]={"enabled":bool(self.cfg.enable_source_superposition),"groups":0,"ratio":0.,"pruned_groups":0}
            return
        r_used,a_used=self._aggregate_sources(amps,field_key)
        splat_sources_weighted_kernel(S,r_used,a_used,self.cfg.dx,radius)

    def _inject_force_sources(self):
        if not self.cfg.enable_force_sources or not self.force_sources: return
        scale_map={"gravity":("g",self.cfg.force_source_scale_gravity),"g":("g",self.cfg.force_source_scale_gravity),
                   "electromagnetic":("em",self.cfg.force_source_scale_electromagnetic),"em":("em",self.cfg.force_source_scale_electromagnetic),
                   "strong":("s",self.cfg.force_source_scale_strong),"s":("s",self.cfg.force_source_scale_strong),
                   "weak":("w",self.cfg.force_source_scale_weak),"w":("w",self.cfg.force_source_scale_weak),
                   "symmetry_region":("sym",self.cfg.force_source_scale_symmetry_region),
                   "symmetry":("sym",self.cfg.force_source_scale_symmetry_region)}
        field_map={"g":self.S_g,"em":self.S_em,"s":self.S_s,"w":self.S_w}
        for src in self.force_sources:
            kind_raw=str(src.get("kind",src.get("type","gravity"))).lower()
            mapped=scale_map.get(kind_raw)
            if mapped is None: continue
            target,scale=mapped
            pos=np.asarray(src.get("pos",src.get("position",[0.,0.,0.])),dtype=np.float64)
            if pos.shape!=(3,): continue
            amp=float(src.get("amp",src.get("strength",1.)))*scale
            radius=float(src.get("radius",max(self.cfg.dx,1.5*self.cfg.dx)))
            if radius<=0.: continue
            if target=="sym":
                sC=float(src.get("sym_C",src.get("C",0.))); sP=float(src.get("sym_P",src.get("P",0.)))
                sT=float(src.get("sym_T",src.get("T",0.))); sCP=float(src.get("sym_CP",src.get("CP",0.)))
                sCPT=float(src.get("sym_CPT",src.get("CPT",0.)))
                sym_sum=(sC*self.cfg.source_bias_C+sP*self.cfg.source_bias_P+sT*self.cfg.source_bias_T+
                         sCP*self.cfg.source_bias_CP+sCPT*self.cfg.source_bias_CPT)
                amp*=(1.+sym_sum); targets=(self.S_g,self.S_em,self.S_s,self.S_w)
            else:
                targets=(field_map[target],)
            vox_R=int(np.ceil(radius/self.cfg.dx))
            cx=int(pos[0]/self.cfg.dx); cy=int(pos[1]/self.cfg.dx); cz=int(pos[2]/self.cfg.dx)
            for S in targets:
                nx2,ny2,nz2=S.shape
                xmin=max(0,cx-vox_R); xmax=min(nx2-1,cx+vox_R)
                ymin=max(0,cy-vox_R); ymax=min(ny2-1,cy+vox_R)
                zmin=max(0,cz-vox_R); zmax=min(nz2-1,cz+vox_R)
                for i in range(xmin,xmax+1):
                    dx0=(i*self.cfg.dx)-pos[0]
                    for j in range(ymin,ymax+1):
                        dy0=(j*self.cfg.dx)-pos[1]
                        for k in range(zmin,zmax+1):
                            dz0=(k*self.cfg.dx)-pos[2]
                            dist=np.sqrt(dx0*dx0+dy0*dy0+dz0*dz0)
                            w=(1.-dist/(radius+self.cfg.eps))**2 if dist<radius else 0.
                            if w>0.: S[i,j,k]+=amp*w

    def _splat_all_sources(self):
        self._splat_effective_sources(self.S_g,  self._obj_source_g,  self.cfg.source_radius_g,  "g")
        self._splat_effective_sources(self.S_em, self._obj_source_em, self.cfg.source_radius_em, "em")
        self._splat_effective_sources(self.S_s,  self._obj_source_s,  self.cfg.source_radius_s,  "s")
        self._splat_effective_sources(self.S_w,  self._obj_source_w,  self.cfg.source_radius_w,  "w")
        self._inject_force_sources()

    def _compute_z_dot(self):
        g_mean=float(np.sum(self.G*(self.phi_g+self.phi_em+self.phi_s+self.phi_w))/self._sumG_safe)
        return float(-self.cfg.kappa*self.z+self.cfg.chi*g_mean)

    def _swap_fields(self):
        self.phi_g,self.phi_g_new   = self.phi_g_new,  self.phi_g
        self.phi_em,self.phi_em_new = self.phi_em_new, self.phi_em
        self.phi_s,self.phi_s_new   = self.phi_s_new,  self.phi_s
        self.phi_w,self.phi_w_new   = self.phi_w_new,  self.phi_w

    def _state_hash(self):
        h=hashlib.sha256()
        def upd(arr): h.update(np.ascontiguousarray(arr).view(np.uint8))
        for arr in (self.phi_g,self.phi_em,self.phi_s,self.phi_w,
                    self.obj_r,self.obj_v,self.obj_m,self.obj_q,
                    self.obj_force_gravity,self.obj_force_electromagnetic,
                    self.obj_force_strong,self.obj_force_weak,
                    self.obj_sym_C,self.obj_sym_P,self.obj_sym_T,self.obj_sym_CP,self.obj_sym_CPT):
            upd(arr)
        h.update(np.float64(self.z).tobytes())
        h.update(np.float64(self._h_proxy_ema).tobytes())
        h.update(np.float64(self._last_mix_scale).tobytes())
        h.update(np.int64(self.tick).tobytes())
        try: fs=json.dumps(self.force_sources,sort_keys=True,ensure_ascii=False).encode()
        except: fs=repr(self.force_sources).encode()
        h.update(hashlib.sha256(fs).digest())
        try: ls=json.dumps(self.light_sources,sort_keys=True,ensure_ascii=False).encode()
        except: ls=repr(self.light_sources).encode()
        h.update(hashlib.sha256(ls).digest())
        if self.cfg.include_config_in_hash:
            h.update(json.dumps(asdict(self.cfg),sort_keys=True).encode())
        return h.hexdigest()

    def _detect_unstable(self):
        for arr in (self.phi_g,self.phi_em,self.phi_s,self.phi_w,self.obj_r,self.obj_v):
            if not np.isfinite(arr).all(): return True
        return not np.isfinite(self.z)

    def _telemetry(self, compute_hash):
        rg=float(np.sqrt(np.mean(self.phi_g**2))); re=float(np.sqrt(np.mean(self.phi_em**2)))
        rs=float(np.sqrt(np.mean(self.phi_s**2))); rw=float(np.sqrt(np.mean(self.phi_w**2)))
        rt=self._phi_rms_total(); fe=self._field_energy()
        ok=float(0.5*np.sum(self.obj_m*np.sum(self.obj_v**2,axis=1))) if self.n_obj>0 else 0.
        et=fe+ok+self.cfg.eta*self.z*self.z
        ag=np.abs(self.phi_g); ae=np.abs(self.phi_em); as2=np.abs(self.phi_s); aw=np.abs(self.phi_w)
        mg=ag>=self.cfg.phantom_threshold_g; me=ae>=self.cfg.phantom_threshold_em
        ms=as2>=self.cfg.phantom_threshold_s; mw=aw>=self.cfg.phantom_threshold_w
        pm=mg|me|ms|mw; pf=float(np.mean(pm))
        pma=float(np.mean((ag+ae+as2+aw)[pm])) if np.any(pm) else 0.
        pa=bool(pf>=self.cfg.phantom_fraction_threshold or pma>=self.cfg.phantom_meanabs_threshold)
        out={
            "schema_version":SCHEMA_VERSION,"module_name":MODULE_NAME,"module_version":MODULE_VERSION,
            "tick":int(self.tick),"z":float(self.z),
            "omega_D":float(self._last_omega_D),"Omega_D":float(self._last_omega_D),
            "regime":str(self._last_regime),"regime_s_crit":1. if self._last_regime=="crit" else 0.,
            "phi_rms":rt,"phi_rms_g":rg,"phi_rms_em":re,"phi_rms_s":rs,"phi_rms_w":rw,"phi_rms_total":rt,
            "field_energy":fe,"obj_kinetic":ok,"energy_total":et,"dE_dt":0.,
            "phantom_zone_fraction":pf,"phantom_zone_fraction_rel_rms":float(pf/max(rt,self.cfg.eps)),
            "phantom_meanabs":pma,"phantom_active":pa,
            "phantom_fraction_g":float(np.mean(mg)),"phantom_fraction_em":float(np.mean(me)),
            "phantom_fraction_s":float(np.mean(ms)),"phantom_fraction_w":float(np.mean(mw)),
            "h_proxy_ema":float(self._h_proxy_ema),"mix_scale":float(self._last_mix_scale),
            "unstable":bool(self._last_unstable),"w_eff_unstable":bool(self._last_unstable),
            "superposition":self._src_superposition_last_by_field.copy(),
        }
        if compute_hash: out["state_hash"]=self._state_hash()
        return out

    def step(self, compute_hash=None):
        if compute_hash is None: compute_hash=bool(self.cfg.default_compute_hash_in_step)
        self._sync_object_aux_buffers_to_current_objects()
        self._compute_effective_object_channels()
        omega_D=self._compute_omega_D(); rt=self._phi_rms_total()
        regime=self._compute_regime(omega_D,rt); rsc=self._apply_regime_scalars(regime)
        alpha_eff=self._alpha_B(omega_D)*rsc["alpha_mul"]
        self._compute_mix_terms(); self._splat_all_sources()
        z_dot=self._compute_z_dot(); c=self.cfg
        lap6_kernel(self.phi_g, self.lap_g, self._inv_dx2)
        lap6_kernel(self.phi_em,self.lap_em,self._inv_dx2)
        lap6_kernel(self.phi_s, self.lap_s, self._inv_dx2)
        lap6_kernel(self.phi_w, self.lap_w, self._inv_dx2)
        hp=self._h_proxy_ema
        step_field_kernel(self.phi_g, self.phi_g_new, self.lap_g, self.S_g, self.G,c.dt,c.tau_phi,c.D_g*rsc["D_mul"],c.mu_g*rsc["mu_mul"],c.lambda_g*rsc["lambda_mul"],alpha_eff,z_dot,c.beta_h,hp,self.mix_g)
        step_field_kernel(self.phi_em,self.phi_em_new,self.lap_em,self.S_em,self.G,c.dt,c.tau_phi,c.D_em*rsc["D_mul"],c.mu_em*rsc["mu_mul"],c.lambda_em*rsc["lambda_mul"],alpha_eff,z_dot,c.beta_h,hp,self.mix_em)
        step_field_kernel(self.phi_s, self.phi_s_new, self.lap_s, self.S_s, self.G,c.dt,c.tau_phi,c.D_s*rsc["D_mul"],c.mu_s*rsc["mu_mul"],c.lambda_s*rsc["lambda_mul"],alpha_eff,z_dot,c.beta_h,hp,self.mix_s)
        step_field_kernel(self.phi_w, self.phi_w_new, self.lap_w, self.S_w, self.G,c.dt,c.tau_phi,c.D_w*rsc["D_mul"],c.mu_w*rsc["mu_mul"],c.lambda_w*rsc["lambda_mul"],alpha_eff,z_dot,c.beta_h,hp,self.mix_w)
        self._swap_fields()
        for phi in (self.phi_g,self.phi_em,self.phi_s,self.phi_w): self._apply_field_boundaries(phi)
        gv_eff=c.gamma_v*rsc["gamma_v_mul"]; vm_eff=c.v_max*rsc["vmax_mul"]
        if self.n_obj>0:
            step_objects_multifield_kernel(
                self.phi_g,self.phi_em,self.phi_s,self.phi_w,
                self.obj_r,self.obj_v,self.obj_m,
                self._obj_drive_g,self._obj_drive_em,self._obj_drive_s,self._obj_drive_w,
                c.dt,c.dx,gv_eff,vm_eff,c.drive_eps)
            self._apply_object_boundaries()
        self.z+=c.dt*z_dot; self.tick+=1
        rt2=self._phi_rms_total()
        self._h_proxy_ema=c.h_proxy_ema_alpha*self._h_proxy_ema+(1.-c.h_proxy_ema_alpha)*rt2
        self._last_regime=regime; self._last_omega_D=omega_D; self._last_phi_rms_total=rt2
        unstable=self._detect_unstable(); self._last_unstable=bool(unstable)
        if unstable and self.cfg.fail_fast_on_unstable:
            raise FloatingPointError("Simulation became unstable.")
        return self._telemetry(bool(compute_hash))

    def step_verify(self):
        return self.step(compute_hash=True)

    def run(self, steps, compute_hash_every=0):
        out=[]
        for t in range(int(steps)):
            out.append(self.step(compute_hash=(compute_hash_every>0 and (t+1)%compute_hash_every==0)))
        return out

    def snapshot(self):
        return {
            "schema_version":SCHEMA_VERSION,"module_name":MODULE_NAME,"module_version":MODULE_VERSION,
            "config":asdict(self.cfg),"tick":int(self.tick),"z":float(self.z),
            "h_proxy_ema":float(self._h_proxy_ema),"mix_scale":float(self._last_mix_scale),
            "unstable":bool(self._last_unstable),
            "obj_r":self.obj_r.copy(),"obj_v":self.obj_v.copy(),
            "obj_m":self.obj_m.copy(),"obj_q":self.obj_q.copy(),
            "obj_force_gravity":self.obj_force_gravity.copy(),
            "obj_force_electromagnetic":self.obj_force_electromagnetic.copy(),
            "obj_force_strong":self.obj_force_strong.copy(),
            "obj_force_weak":self.obj_force_weak.copy(),
            "obj_sym_C":self.obj_sym_C.copy(),"obj_sym_P":self.obj_sym_P.copy(),
            "obj_sym_T":self.obj_sym_T.copy(),"obj_sym_CP":self.obj_sym_CP.copy(),
            "obj_sym_CPT":self.obj_sym_CPT.copy(),
            "phi_g":self.phi_g.copy(),"phi_em":self.phi_em.copy(),
            "phi_s":self.phi_s.copy(),"phi_w":self.phi_w.copy(),
            "force_sources":list(self.force_sources),"light_sources":list(self.light_sources),
            "obj_meta":list(self.obj_meta),
            "metadata":{"schema_version":SCHEMA_VERSION,"module_name":MODULE_NAME,"module_version":MODULE_VERSION,
                        "force_sources":list(self.force_sources),"light_sources":list(self.light_sources),
                        "obj_meta":list(self.obj_meta)},
            "state_hash":self._state_hash(),
        }


def demo_run():
    cfg=Space3DConfig(nx=24,ny=24,nz=24,dt=0.01,n_obj=6,
                      enable_source_superposition=True,source_superposition_mode="voxel_bin",
                      enable_dynamic_mix=True,field_mix_ew=0.02)
    sim=NoctilithSpace3DNumba(cfg)
    sim.set_force_sources([
        {"kind":"gravity","pos":[12.,12.,12.],"amp":1.5,"radius":4.},
        {"kind":"electromagnetic","pos":[8.,16.,10.],"amp":-1.,"radius":3.},
        {"kind":"symmetry_region","pos":[16.,8.,14.],"amp":0.6,"radius":3.5,"CP":1.,"CPT":0.5},
    ])
    t0=time.perf_counter()
    hist=sim.run(steps=20,compute_hash_every=10)
    print("NOCTILITH SPACE 3D demo")
    print(f"ticks={sim.tick} wall_s={time.perf_counter()-t0:.4f}")
    print(json.dumps(hist[-1],indent=2))