"""noctilith/tools/benchmark.py — pipeline benchmark runner."""
from __future__ import annotations
import time
import numpy as np
from typing import Any, Dict

SCHEMA_VERSION = "noctilith.schema.v1"


def run_benchmark(pipeline_fn, *, n_runs: int = 100, shape=(32,32,32),
                  seed: int = 42, label: str = "benchmark") -> Dict[str, Any]:
    """Run a pipeline function n_runs times and report timing statistics."""
    np.random.seed(seed)
    times = []
    errors = 0
    for _ in range(n_runs):
        t0 = time.perf_counter()
        try:
            pipeline_fn()
        except Exception:
            errors += 1
        times.append(time.perf_counter() - t0)

    times_ms = [t * 1000 for t in times]
    times_ms.sort()
    return {
        "schema_version": SCHEMA_VERSION,
        "label":          label,
        "n_runs":         n_runs,
        "mean_ms":        float(sum(times_ms) / len(times_ms)),
        "min_ms":         float(times_ms[0]),
        "max_ms":         float(times_ms[-1]),
        "p50_ms":         float(times_ms[len(times_ms)//2]),
        "p95_ms":         float(times_ms[int(len(times_ms)*0.95)]),
        "errors":         errors,
    }
