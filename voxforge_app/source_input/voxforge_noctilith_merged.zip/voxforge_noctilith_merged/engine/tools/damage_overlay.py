"""noctilith/tools/damage_overlay.py — DamageOverlayBuilder."""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME    = "noctilith.tools.damage_overlay"


@dataclass
class DamageOverlayConfig:
    enabled: bool = True
    hot_spot_threshold: float = 0.5
    max_hot_spots: int = 32
    include_fracture_risk: bool = True
    include_damage_marks: bool = True


class DamageOverlayBuilder:
    def __init__(self, config: Optional[DamageOverlayConfig] = None):
        self.config = config or DamageOverlayConfig()

    def build_snapshot(self, *, world_obj: Any,
                       fracture_result: Optional[Dict[str, Any]] = None,
                       step_index: int = 0) -> Dict[str, Any]:
        cfg = self.config
        damage_marks = getattr(world_obj, "_damage_marks", {})
        hot_spots: List[Dict[str, Any]] = []

        if cfg.include_damage_marks:
            sorted_dm = sorted(damage_marks.items(), key=lambda x: -x[1])
            for (ix, iy, iz), dmg in sorted_dm[:cfg.max_hot_spots]:
                if dmg >= cfg.hot_spot_threshold:
                    hot_spots.append({"index": [ix,iy,iz], "damage": float(dmg),
                                      "source": "damage_mark"})

        fracture_candidates: List[Dict] = []
        if cfg.include_fracture_risk and fracture_result:
            for c in fracture_result.get("candidates", [])[:cfg.max_hot_spots]:
                fracture_candidates.append(c)

        return {
            "schema_version":     SCHEMA_VERSION,
            "module_name":        MODULE_NAME,
            "step_index":         step_index,
            "hot_spots":          hot_spots,
            "hot_spot_count":     len(hot_spots),
            "fracture_candidates": fracture_candidates,
            "total_damage_voxels": len(damage_marks),
            "total_damage_sum":    float(sum(damage_marks.values())),
        }
