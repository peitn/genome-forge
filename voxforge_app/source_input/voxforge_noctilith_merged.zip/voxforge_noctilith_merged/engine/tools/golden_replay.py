"""noctilith/tools/golden_replay.py — deterministic golden record/verify."""
from __future__ import annotations
import json, pathlib, hashlib
from typing import Any, Dict

SCHEMA_VERSION = "noctilith.schema.v1"


def _fingerprint(data: Dict[str, Any]) -> str:
    blob = json.dumps(data, sort_keys=True, default=str).encode()
    return hashlib.sha256(blob).hexdigest()[:16]


def record_golden(path: str, data: Dict[str, Any]) -> str:
    record = {"schema_version": SCHEMA_VERSION,
              "fingerprint": _fingerprint(data), "data": data}
    p = pathlib.Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(record, indent=2, default=str))
    return str(p)


def verify_golden(path: str, data: Dict[str, Any]) -> bool:
    p = pathlib.Path(path)
    if not p.exists():
        return False
    record = json.loads(p.read_text())
    expected_fp = record.get("fingerprint", "")
    actual_fp   = _fingerprint(data)
    return expected_fp == actual_fp
