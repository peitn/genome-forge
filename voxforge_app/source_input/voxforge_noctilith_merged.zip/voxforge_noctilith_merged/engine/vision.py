#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
noctilith/vision.py
===================
NOCTILITH VISION MODULE (full unified package revision)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple, List

import numpy as np

try:
    from numba import njit, prange
except Exception:
    def njit(*args, **kwargs):
        def deco(fn): return fn
        return deco
    def prange(x): return range(x)


SCHEMA_VERSION = "noctilith.schema.v1"
MODULE_NAME = "noctilith.vision"
MODULE_VERSION = "1.0.0"

RESOLUTION_PRESETS = {
    "hd":  (1280, 720),
    "fhd": (1920, 1080),
    "qhd": (2560, 1440),
    "4k":  (3840, 2160),
    "uhd": (3840, 2160),
}


@dataclass
class VisionConfigV240:
    output_preset: str = "fhd"
    output_width: int = 0
    output_height: int = 0
    render_scale: float = 0.5
    max_internal_width: int = 1920
    max_internal_height: int = 1080
    fov_y_deg: float = 60.0
    near_plane: float = 0.0
    far_plane_mul: float = 2.2
    far_plane_abs: float = 0.0
    ray_steps: int = 72
    early_stop_transmittance: float = 0.02
    wavelengths_nm: np.ndarray = field(
        default_factory=lambda: np.array([380.,430.,480.,530.,580.,630.,680.,730.], dtype=np.float64))
    density_scale_g: float = 0.12
    density_scale_em: float = 0.28
    density_scale_s: float = 0.18
    density_scale_w: float = 0.15
    emission_scale_g: float = 0.28
    emission_scale_em: float = 0.85
    emission_scale_s: float = 0.42
    emission_scale_w: float = 0.32
    absorption_gain: float = 1.15
    emission_gain: float = 1.10
    enable_gradient_shading: bool = True
    gradient_shading_gain: float = 0.18
    gradient_stride: int = 4
    gradient_mode: str = "em_intensity"
    use_abs_emission: bool = True
    use_abs_density: bool = True
    use_abs_shading: Optional[bool] = None
    enable_normals: bool = False
    phantom_threshold_g: float = 0.08
    phantom_threshold_em: float = 0.08
    phantom_threshold_s: float = 0.20
    phantom_threshold_w: float = 0.10
    background_rgb: Tuple[float, float, float] = (0.015, 0.02, 0.03)
    exposure: float = 1.15
    gamma: float = 2.2
    enable_postprocess: bool = True
    diffusion_iterations: int = 2
    diffusion_dt: float = 0.22
    diffusion_kappa: float = 0.10
    enable_consolidation: bool = True
    consolidation_rho: float = 0.12
    consolidation_strength: float = 0.35
    consolidation_tau: float = 0.008
    consolidation_alpha: float = 80.0
    enable_phantom_overlay: bool = False
    phantom_overlay_strength: float = 0.55
    enable_object_glow: bool = True
    object_glow_strength: float = 0.85
    object_glow_sigma_px: float = 1.6
    object_glow_softclip: float = 1.5
    object_glow_charge_ref: float = 1.0
    object_glow_mass_ref: float = 1.0
    validate_shapes: bool = True
    camera_up_fallback: Tuple[float, float, float] = (0.0, 0.0, 1.0)
    light_transport_mode: str = "hybrid"
    source_scatter_gain: float = 0.85
    source_scatter_density_gate: float = 0.85
    light_shadow_mode: str = "short_march"
    light_shadow_mu: float = 0.35
    light_shadow_steps: int = 6
    light_shadow_step_scale: float = 1.0
    max_lights_per_sample: int = 2
    max_total_lights: int = 8
    eps: float = 1e-12


@dataclass
class CameraPose:
    pos: np.ndarray
    target: np.ndarray
    up: np.ndarray


@dataclass
class SpectralLightSource:
    pos: np.ndarray                                    # FIX: correct indent (was ' pos')
    intensity: float = 1.0
    radius: float = 0.0
    color_temperature_k: float = 6500.0
    spectral_weights: Optional[np.ndarray] = None
    field_coupling_g: float = 0.0
    field_coupling_em: float = 1.0
    field_coupling_s: float = 0.0
    field_coupling_w: float = 0.0
    kind: str = "point"
    tags: Tuple[str, ...] = ()
    metadata: Dict[str, Any] = field(default_factory=dict)


def _gauss(x: np.ndarray, mu: float, sigma: float) -> np.ndarray:
    sigma = max(float(sigma), 1e-9)
    return np.exp(-0.5 * ((x - mu) / sigma) ** 2)


def build_band_rgb_response(wavelengths_nm: np.ndarray) -> np.ndarray:
    wl = wavelengths_nm.astype(np.float64)
    r = 1.00*_gauss(wl,610.,45.) + 0.40*_gauss(wl,690.,24.)
    g = 1.00*_gauss(wl,545.,35.) + 0.15*_gauss(wl,505.,24.)
    b = 1.00*_gauss(wl,460.,26.) + 0.25*_gauss(wl,410.,18.)
    band = np.stack([r, g, b], axis=1)
    band /= np.maximum(np.max(band, axis=0, keepdims=True), 1e-12)
    return band.astype(np.float64)


def build_field_spectral_profiles(wavelengths_nm: np.ndarray) -> np.ndarray:
    wl = wavelengths_nm.astype(np.float64)
    sg = 0.65*_gauss(wl,620.,55.) + 0.20*_gauss(wl,700.,25.) + 0.10*_gauss(wl,560.,45.)
    se = 0.55*_gauss(wl,470.,35.) + 0.45*_gauss(wl,530.,60.) + 0.20*_gauss(wl,620.,70.)
    ss = 0.70*_gauss(wl,415.,24.) + 0.50*_gauss(wl,670.,30.)
    sw = 0.75*_gauss(wl,535.,28.) + 0.30*_gauss(wl,580.,30.) + 0.18*_gauss(wl,490.,24.)
    prof = np.stack([sg, se, ss, sw], axis=0)
    prof /= np.maximum(np.max(prof, axis=1, keepdims=True), 1e-12)
    return prof.astype(np.float64)


def build_field_rgb_basis(wavelengths_nm: np.ndarray) -> np.ndarray:
    band_rgb = build_band_rgb_response(wavelengths_nm)
    field_spec = build_field_spectral_profiles(wavelengths_nm)
    rgb = field_spec @ band_rgb
    rgb /= np.maximum(np.max(rgb, axis=1, keepdims=True), 1e-12)
    return rgb.astype(np.float64)


def approximate_blackbody_spectrum(wavelengths_nm: np.ndarray, T: float) -> np.ndarray:
    T = float(max(T, 100.0))
    wl = wavelengths_nm.astype(np.float64)
    peak = 2.897e6 / T
    sigma = 0.22*peak + 35.0
    spec = 0.85*_gauss(wl, peak, sigma) + 0.35*_gauss(wl, peak*1.25, sigma*1.35)
    spec = np.maximum(spec, 0.0)
    spec /= np.maximum(np.max(spec), 1e-12)
    return spec


def _normalize(v: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    n = float(np.linalg.norm(v))
    return v * 0.0 if n < eps else v / n


def _default_camera_for_grid(nx: int, ny: int, nz: int, dx: float) -> CameraPose:
    bounds = np.array([(nx-1)*dx, (ny-1)*dx, (nz-1)*dx], dtype=np.float64)
    center = 0.5*bounds
    maxdim = float(np.max(bounds))
    pos = center + np.array([0., -1.65*maxdim, 0.55*maxdim], dtype=np.float64)
    return CameraPose(pos=pos, target=center, up=np.array([0.,0.,1.], dtype=np.float64))


def _robust_camera_basis(fwd, up, fallback_up, eps):
    fwd = _normalize(fwd, eps)
    c = np.cross(fwd, up)
    if float(np.linalg.norm(c)) < 1e-6:
        up = fallback_up
        c = np.cross(fwd, up)
        if float(np.linalg.norm(c)) < 1e-6:
            up = np.array([0., 1., 0.], dtype=np.float64)
            c = np.cross(fwd, up)
    right = _normalize(c, eps)
    up2 = _normalize(np.cross(right, fwd), eps)
    return fwd, right, up2


@njit(cache=True)
def _prepare_trilinear_coords(rx, ry, rz, dx, nx, ny, nz):
    eps = 1e-9
    x = max(0., min((nx-2)-eps, rx/dx))
    y = max(0., min((ny-2)-eps, ry/dx))
    z = max(0., min((nz-2)-eps, rz/dx))
    i, j, k = int(x), int(y), int(z)
    return i, j, k, x-i, y-j, z-k


@njit(cache=True)
def _sample_trilinear(field, i, j, k, fx, fy, fz):
    c000=field[i,j,k]; c100=field[i+1,j,k]; c010=field[i,j+1,k]; c110=field[i+1,j+1,k]
    c001=field[i,j,k+1]; c101=field[i+1,j,k+1]; c011=field[i,j+1,k+1]; c111=field[i+1,j+1,k+1]
    c00=c000*(1-fx)+c100*fx; c10=c010*(1-fx)+c110*fx
    c01=c001*(1-fx)+c101*fx; c11=c011*(1-fx)+c111*fx
    c0=c00*(1-fy)+c10*fy; c1=c01*(1-fy)+c11*fy
    return c0*(1-fz)+c1*fz


@njit(cache=True)
def _sample4(phi_g, phi_em, phi_s, phi_w, rx, ry, rz, dx):
    nx, ny, nz = phi_g.shape
    i, j, k, fx, fy, fz = _prepare_trilinear_coords(rx, ry, rz, dx, nx, ny, nz)
    return (_sample_trilinear(phi_g,i,j,k,fx,fy,fz), _sample_trilinear(phi_em,i,j,k,fx,fy,fz),
            _sample_trilinear(phi_s,i,j,k,fx,fy,fz), _sample_trilinear(phi_w,i,j,k,fx,fy,fz))


@njit(cache=True)
def _density_from_samples(vg, ve, vs, vw, dg, de, ds, dw, use_abs):
    if use_abs: ag=abs(vg); ae=abs(ve); ass=abs(vs); aw=abs(vw)
    else:
        ag=vg if vg>0. else 0.; ae=ve if ve>0. else 0.
        ass=vs if vs>0. else 0.; aw=vw if vw>0. else 0.
    return dg*ag + de*ae + ds*ass + dw*aw


@njit(cache=True)
def _density_at(phi_g, phi_em, phi_s, phi_w, x, y, z, dx, dg, de, ds, dw, use_abs):
    vg,ve,vs,vw = _sample4(phi_g,phi_em,phi_s,phi_w,x,y,z,dx)
    return _density_from_samples(vg,ve,vs,vw,dg,de,ds,dw,use_abs)


@njit(cache=True)
def _sample_grad_density(phi_g, phi_em, phi_s, phi_w, rx, ry, rz, dx, dg, de, ds, dw, use_abs):
    eps = 1e-12
    px=_density_at(phi_g,phi_em,phi_s,phi_w,rx+dx,ry,rz,dx,dg,de,ds,dw,use_abs)
    mx=_density_at(phi_g,phi_em,phi_s,phi_w,rx-dx,ry,rz,dx,dg,de,ds,dw,use_abs)
    py=_density_at(phi_g,phi_em,phi_s,phi_w,rx,ry+dx,rz,dx,dg,de,ds,dw,use_abs)
    my=_density_at(phi_g,phi_em,phi_s,phi_w,rx,ry-dx,rz,dx,dg,de,ds,dw,use_abs)
    pz=_density_at(phi_g,phi_em,phi_s,phi_w,rx,ry,rz+dx,dx,dg,de,ds,dw,use_abs)
    mz=_density_at(phi_g,phi_em,phi_s,phi_w,rx,ry,rz-dx,dx,dg,de,ds,dw,use_abs)
    inv=1./(2.*dx+eps)
    return (px-mx)*inv,(py-my)*inv,(pz-mz)*inv


@njit(cache=True)
def ray_aabb_intersect_bounds(ox,oy,oz,dxr,dyr,dzr,minx,miny,minz,maxx,maxy,maxz,eps=1e-12):
    tmin=-1e30; tmax=1e30
    for o,d,lo,hi in ((ox,dxr,minx,maxx),(oy,dyr,miny,maxy),(oz,dzr,minz,maxz)):
        if abs(d)<eps:
            if o<lo or o>hi: return False,0.,0.
        else:
            inv=1./d; t1=(lo-o)*inv; t2=(hi-o)*inv
            if t1>t2: t1,t2=t2,t1
            if t1>tmin: tmin=t1
            if t2<tmax: tmax=t2
            if tmin>tmax: return False,0.,0.
    return True,tmin,tmax


@njit(cache=True)
def _scatter_response_from_fields(vg,ve,vs,vw,cg,ce,cs,cw,use_abs):
    if use_abs: ag=abs(vg);ae=abs(ve);ass=abs(vs);aw=abs(vw)
    else:
        ag=vg if vg>0. else 0.;ae=ve if ve>0. else 0.
        ass=vs if vs>0. else 0.;aw=vw if vw>0. else 0.
    return cg*ag+ce*ae+cs*ass+cw*aw


@njit(cache=True)
def _shadow_approx_local(mu, density_here, dist):
    return np.exp(-mu*density_here*dist)


@njit(cache=True)
def _shadow_short_march(phi_g,phi_em,phi_s,phi_w,x0,y0,z0,x1,y1,z1,dx_grid,steps,step_scale,dg,de,ds_s,dw,use_abs,mu):
    s=max(1,int(steps)); sc=max(float(step_scale),1.)
    eff=max(1,int(round(s/sc)))
    vx=x1-x0;vy=y1-y0;vz=z1-z0
    dist=np.sqrt(vx*vx+vy*vy+vz*vz)+1e-12
    step_len=dist/eff; inv_d=1./dist
    ux=vx*inv_d;uy=vy*inv_d;uz=vz*inv_d
    tau=0.; t=0.5*step_len
    for _ in range(eff):
        if t>dist: break
        vg,ve,vs,vw=_sample4(phi_g,phi_em,phi_s,phi_w,x0+ux*t,y0+uy*t,z0+uz*t,dx_grid)
        tau+=mu*_density_from_samples(vg,ve,vs,vw,dg,de,ds_s,dw,use_abs)*step_len
        t+=step_len
    return np.exp(-tau)


@njit(cache=True)
def _select_topk_lights_coupling(light_pos,light_int,light_radius,light_coupling,sx,sy,sz,kmax):
    L=light_pos.shape[0]
    if kmax<1: return np.empty((1,),np.int64),0
    idxs=np.empty((kmax,),np.int64); scores=np.empty((kmax,),np.float64)
    for i in range(kmax): idxs[i]=-1; scores[i]=-1.
    for li in range(L):
        dxl=sx-light_pos[li,0];dyl=sy-light_pos[li,1];dzl=sz-light_pos[li,2]
        d2=dxl*dxl+dyl*dyl+dzl*dzl+1e-12
        r0=max(light_radius[li],0.)
        cn=abs(light_coupling[li,0])+abs(light_coupling[li,1])+abs(light_coupling[li,2])+abs(light_coupling[li,3])
        score=light_int[li]*cn/(d2+r0*r0+1e-12)
        worst=0; ws=scores[0]
        for j in range(1,kmax):
            if scores[j]<ws: worst=j; ws=scores[j]
        if score>ws: scores[worst]=score; idxs[worst]=li
    count=0
    for i in range(kmax):
        if idxs[i]>=0: count+=1
    return idxs,count


@njit(cache=True, parallel=True)
def render_buffers_kernel_v240(
    phi_g, phi_em, phi_s, phi_w,
    out_rgb, out_depth, out_phantom, out_normal01, enable_normals,
    cam_pos, cam_fwd, cam_right, cam_up,
    tan_half_fov_y, aspect, dx_grid, ray_steps, near_plane, far_plane,
    minx, miny, minz, maxx, maxy, maxz,
    density_scales, emission_scales, field_rgb_basis,
    absorption_gain, emission_gain,
    enable_grad_shading, grad_gain, grad_mode_density_combo, grad_stride,
    early_stop_T, bg_rgb,
    use_abs_emission, use_abs_density, use_abs_shading,
    mode_self_emissive, mode_source_driven, mode_hybrid,
    source_scatter_gain, source_scatter_density_gate,
    light_shadow_mode_id, light_shadow_mu, light_shadow_steps, light_shadow_step_scale,
    max_lights_per_sample,
    light_pos, light_rgb, light_intensity, light_radius, light_coupling,
    th_g, th_em, th_s, th_w,
):
    H,W,_=out_rgb.shape
    far_plane=max(far_plane,near_plane+dx_grid)
    dt_ray=(far_plane-near_plane)/max(ray_steps,1)
    if grad_stride<1: grad_stride=1
    L=light_pos.shape[0]
    kmax=max_lights_per_sample
    if kmax<0: kmax=0
    if kmax>4: kmax=4

    for py in prange(H):
        for px in range(W):
            u=((px+.5)/W)*2.-1.; v=1.-((py+.5)/H)*2.
            dirx=cam_fwd[0]+u*aspect*tan_half_fov_y*cam_right[0]+v*tan_half_fov_y*cam_up[0]
            diry=cam_fwd[1]+u*aspect*tan_half_fov_y*cam_right[1]+v*tan_half_fov_y*cam_up[1]
            dirz=cam_fwd[2]+u*aspect*tan_half_fov_y*cam_right[2]+v*tan_half_fov_y*cam_up[2]
            dn=np.sqrt(dirx*dirx+diry*diry+dirz*dirz)+1e-12
            dirx/=dn; diry/=dn; dirz/=dn

            hit,t0,t1=ray_aabb_intersect_bounds(cam_pos[0],cam_pos[1],cam_pos[2],dirx,diry,dirz,minx,miny,minz,maxx,maxy,maxz,1e-12)
            if not hit:
                out_rgb[py,px,0]=bg_rgb[0]; out_rgb[py,px,1]=bg_rgb[1]; out_rgb[py,px,2]=bg_rgb[2]
                out_depth[py,px]=1.; out_phantom[py,px]=0.
                if enable_normals: out_normal01[py,px,0]=.5; out_normal01[py,px,1]=.5; out_normal01[py,px,2]=1.
                continue

            t_enter=t0 if t0>=near_plane else near_plane
            t_exit=t1 if t1<=far_plane else far_plane
            if t_exit<=t_enter:
                out_rgb[py,px,0]=bg_rgb[0]; out_rgb[py,px,1]=bg_rgb[1]; out_rgb[py,px,2]=bg_rgb[2]
                out_depth[py,px]=1.; out_phantom[py,px]=0.
                if enable_normals: out_normal01[py,px,0]=.5; out_normal01[py,px,1]=.5; out_normal01[py,px,2]=1.
                continue

            seg_len=t_exit-t_enter
            nstep=max(1,int(np.ceil(seg_len/(dt_ray+1e-12))))
            if nstep>ray_steps: nstep=ray_steps
            ds=seg_len/nstep

            T=1.; r_acc=g_acc=b_acc=0.; w_depth=depth_acc=0.; phantom_sum=phantom_wsum=0.
            shade_cached=1.; best_score=-1.; best_nx=best_ny=0.; best_nz=1.
            t=t_enter

            for si in range(nstep):
                sx=cam_pos[0]+t*dirx; sy=cam_pos[1]+t*diry; sz=cam_pos[2]+t*dirz
                vg,ve,vs,vw=_sample4(phi_g,phi_em,phi_s,phi_w,sx,sy,sz,dx_grid)

                pg=1. if abs(vg)>=th_g else 0.; pe=1. if abs(ve)>=th_em else 0.
                ps_v=1. if abs(vs)>=th_s else 0.; pw=1. if abs(vw)>=th_w else 0.
                p_here=1. if (pg+pe+ps_v+pw)>0. else 0.

                density=_density_from_samples(vg,ve,vs,vw,density_scales[0],density_scales[1],density_scales[2],density_scales[3],use_abs_density)
                alpha=1.-np.exp(-absorption_gain*density*ds)
                if alpha<0.: alpha=0.
                if alpha>0.995: alpha=0.995
                w=T*alpha

                if enable_grad_shading:
                    if (si%grad_stride)==0:
                        if grad_mode_density_combo:
                            gx,gy,gz=_sample_grad_density(phi_g,phi_em,phi_s,phi_w,sx,sy,sz,dx_grid,density_scales[0],density_scales[1],density_scales[2],density_scales[3],use_abs_density)
                            shade_cached=1.+grad_gain*np.sqrt(gx*gx+gy*gy+gz*gz)
                        else:
                            ve_mag=abs(ve) if use_abs_shading else (ve if ve>0. else 0.)
                            shade_cached=1.+grad_gain*ve_mag
                    shade=shade_cached
                else:
                    shade=1.

                sr=sg=sb=0.
                if mode_self_emissive or mode_hybrid:
                    if use_abs_emission: eg0=abs(vg);ee0=abs(ve);es0=abs(vs);ew0=abs(vw)
                    else:
                        eg0=vg if vg>0. else 0.; ee0=ve if ve>0. else 0.
                        es0=vs if vs>0. else 0.; ew0=vw if vw>0. else 0.
                    er=shade*(emission_scales[0]*eg0*field_rgb_basis[0,0]+emission_scales[1]*ee0*field_rgb_basis[1,0]+emission_scales[2]*es0*field_rgb_basis[2,0]+emission_scales[3]*ew0*field_rgb_basis[3,0])
                    egc=shade*(emission_scales[0]*eg0*field_rgb_basis[0,1]+emission_scales[1]*ee0*field_rgb_basis[1,1]+emission_scales[2]*es0*field_rgb_basis[2,1]+emission_scales[3]*ew0*field_rgb_basis[3,1])
                    eb=shade*(emission_scales[0]*eg0*field_rgb_basis[0,2]+emission_scales[1]*ee0*field_rgb_basis[1,2]+emission_scales[2]*es0*field_rgb_basis[2,2]+emission_scales[3]*ew0*field_rgb_basis[3,2])
                    sr+=w*emission_gain*er; sg+=w*emission_gain*egc; sb+=w*emission_gain*eb

                if mode_source_driven or mode_hybrid:
                    if L>0 and kmax>0:
                        idxs,_=_select_topk_lights_coupling(light_pos,light_intensity,light_radius,light_coupling,sx,sy,sz,kmax)
                        lr=lg=lb=resp_total=0.
                        for ii in range(kmax):
                            li=idxs[ii]
                            if li<0: continue
                            lx=light_pos[li,0];ly=light_pos[li,1];lz=light_pos[li,2]
                            dxl=sx-lx;dyl=sy-ly;dzl=sz-lz
                            d2=dxl*dxl+dyl*dyl+dzl*dzl+1e-12
                            dist=np.sqrt(d2); r0=max(light_radius[li],0.)
                            atten=light_intensity[li]/(d2+r0*r0+1e-12)
                            if light_shadow_mode_id==0: Tl=1.
                            elif light_shadow_mode_id==1: Tl=_shadow_approx_local(light_shadow_mu,density,dist)
                            else: Tl=_shadow_short_march(phi_g,phi_em,phi_s,phi_w,lx,ly,lz,sx,sy,sz,dx_grid,light_shadow_steps,light_shadow_step_scale,density_scales[0],density_scales[1],density_scales[2],density_scales[3],use_abs_density,light_shadow_mu)
                            resp=_scatter_response_from_fields(vg,ve,vs,vw,light_coupling[li,0],light_coupling[li,1],light_coupling[li,2],light_coupling[li,3],use_abs_density)
                            wL=atten*Tl*resp; resp_total+=wL
                            lr+=wL*light_rgb[li,0]; lg+=wL*light_rgb[li,1]; lb+=wL*light_rgb[li,2]
                        scatter_term=1.-np.exp(-source_scatter_gain*resp_total)
                        if source_scatter_density_gate>0.: scatter_term*=(1.-np.exp(-source_scatter_density_gate*density))
                        sr+=w*shade*scatter_term*lr; sg+=w*shade*scatter_term*lg; sb+=w*shade*scatter_term*lb

                r_acc+=sr; g_acc+=sg; b_acc+=sb

                if enable_normals:
                    lum=0.2126*sr+0.7152*sg+0.0722*sb
                    if lum>best_score:
                        best_score=lum
                        gx,gy,gz=_sample_grad_density(phi_g,phi_em,phi_s,phi_w,sx,sy,sz,dx_grid,density_scales[0],density_scales[1],density_scales[2],density_scales[3],use_abs_density)
                        nx2=-gx;ny2=-gy;nz2=-gz; nn=np.sqrt(nx2*nx2+ny2*ny2+nz2*nz2)+1e-12
                        best_nx=nx2/nn; best_ny=ny2/nn; best_nz=nz2/nn

                dnorm=(t-near_plane)/(far_plane-near_plane+1e-12)
                if dnorm<0.: dnorm=0.
                if dnorm>1.: dnorm=1.
                depth_acc+=w*dnorm; w_depth+=w
                phantom_sum+=w*p_here; phantom_wsum+=w
                T*=(1.-alpha)
                if T<early_stop_T: break
                t+=ds

            r_acc+=T*bg_rgb[0]; g_acc+=T*bg_rgb[1]; b_acc+=T*bg_rgb[2]
            out_rgb[py,px,0]=r_acc; out_rgb[py,px,1]=g_acc; out_rgb[py,px,2]=b_acc
            out_depth[py,px]=depth_acc/w_depth if w_depth>1e-12 else 1.
            out_phantom[py,px]=phantom_sum/phantom_wsum if phantom_wsum>1e-12 else 0.
            if enable_normals:
                if best_score<0.: out_normal01[py,px,0]=.5;out_normal01[py,px,1]=.5;out_normal01[py,px,2]=1.
                else: out_normal01[py,px,0]=.5+.5*best_nx;out_normal01[py,px,1]=.5+.5*best_ny;out_normal01[py,px,2]=.5+.5*best_nz


@njit(cache=True)
def edge_aware_diffusion_step_rgb(src, dst, kappa, dt):
    H,W,C=src.shape; dst[:]=src; eps=1e-12; kk=kappa*kappa+eps
    for y in range(1,H-1):
        for x in range(1,W-1):
            c0=src[y,x]; lum0=0.2126*c0[0]+0.7152*c0[1]+0.0722*c0[2]
            a0=a1=a2=wsum=0.
            for yy,xx in ((y-1,x),(y+1,x),(y,x-1),(y,x+1)):
                c1=src[yy,xx]; lum1=0.2126*c1[0]+0.7152*c1[1]+0.0722*c1[2]
                d=lum1-lum0; ww=1./(1.+(d*d)/kk)
                a0+=ww*(c1[0]-c0[0]); a1+=ww*(c1[1]-c0[1]); a2+=ww*(c1[2]-c0[2]); wsum+=ww
            if wsum>eps:
                dst[y,x,0]=c0[0]+dt*a0/wsum; dst[y,x,1]=c0[1]+dt*a1/wsum; dst[y,x,2]=c0[2]+dt*a2/wsum


def _sigmoid(x):
    x=float(np.clip(x,-60.,60.))
    return 1./(1.+np.exp(-x))


def _apply_consolidation(frame_rgb, memory_rgb, rho, strength, tau, alpha, eps):
    if memory_rgb is None or memory_rgb.shape != frame_rgb.shape:
        return frame_rgb.copy(), frame_rgb.copy()
    delta=frame_rgb-memory_rgb
    e_delta=float(np.mean(delta*delta)/(np.mean(frame_rgb*frame_rgb)+eps))
    q=_sigmoid(alpha*(tau-e_delta))
    mem=memory_rgb+rho*q*(frame_rgb-memory_rgb)
    out=np.maximum(frame_rgb+strength*(mem-frame_rgb), 0.)
    return out, mem


def resize_bilinear_rgb(img, out_h, out_w):
    in_h,in_w,c=img.shape
    if in_h==out_h and in_w==out_w: return img.copy()
    y=np.linspace(0.,in_h-1,out_h); x=np.linspace(0.,in_w-1,out_w)
    y0=np.floor(y).astype(np.int64); x0=np.floor(x).astype(np.int64)
    y1=np.minimum(y0+1,in_h-1); x1=np.minimum(x0+1,in_w-1)
    wy=(y-y0).astype(np.float64); wx=(x-x0).astype(np.float64)
    out=np.empty((out_h,out_w,c),dtype=np.float64)
    for j in range(out_h):
        r0=img[y0[j]]; r1=img[y1[j]]
        a=r0[x0]*(1.-wx)[:,None]+r0[x1]*wx[:,None]
        b=r1[x0]*(1.-wx)[:,None]+r1[x1]*wx[:,None]
        out[j]=a*(1.-wy[j])+b*wy[j]
    return out


def resize_bilinear_1c(img, out_h, out_w):
    in_h,in_w=img.shape
    if in_h==out_h and in_w==out_w: return img.copy()
    y=np.linspace(0.,in_h-1,out_h); x=np.linspace(0.,in_w-1,out_w)
    y0=np.floor(y).astype(np.int64); x0=np.floor(x).astype(np.int64)
    y1=np.minimum(y0+1,in_h-1); x1=np.minimum(x0+1,in_w-1)
    wy=(y-y0).astype(np.float64); wx=(x-x0).astype(np.float64)
    out=np.empty((out_h,out_w),dtype=np.float64)
    for j in range(out_h):
        r0=img[y0[j]]; r1=img[y1[j]]
        a=r0[x0]*(1.-wx)+r0[x1]*wx; b=r1[x0]*(1.-wx)+r1[x1]*wx
        out[j]=a*(1.-wy[j])+b*wy[j]
    return out


def renormalize_normal01(normal01, eps):
    n=2.*normal01-1.
    ln=np.sqrt(np.sum(n*n,axis=2,keepdims=True))+eps
    return 0.5+0.5*(n/ln)


def tone_map_to_uint8(rgb_linear, exposure, gamma):
    x=np.maximum(rgb_linear*exposure, 0.)
    x=x/(1.+x)
    x=np.power(np.clip(x,0.,1.), 1./max(gamma,1e-9))
    return np.clip(np.round(255.*x),0,255).astype(np.uint8)

def encode_normal_to_uint8(n01): return np.clip(np.round(255.*np.clip(n01,0.,1.)),0,255).astype(np.uint8)
def depth_to_uint8(d01):         return np.clip(np.round(255.*np.clip(d01,0.,1.)),0,255).astype(np.uint8)
def mask_to_uint8(m01):          return np.clip(np.round(255.*np.clip(m01,0.,1.)),0,255).astype(np.uint8)


class NoctilithVisionModuleV240:
    def __init__(self, cfg: VisionConfigV240):
        self.cfg = cfg
        self._cfg_baseline = VisionConfigV240(**{
            k: (v.copy() if isinstance(v, np.ndarray) else v)
            for k, v in cfg.__dict__.items()
        })
        self.band_rgb = build_band_rgb_response(cfg.wavelengths_nm)
        self.field_rgb_basis = build_field_rgb_basis(cfg.wavelengths_nm)
        self._field_rgb_basis64 = np.ascontiguousarray(self.field_rgb_basis, dtype=np.float64)
        self._memory_by_key: Dict[str, np.ndarray] = {}
        self._tmp_a: Optional[np.ndarray] = None
        self._tmp_b: Optional[np.ndarray] = None
        self._glow_kernel_cache: Dict[Tuple[int,int], np.ndarray] = {}
        self._scene_lights: List[SpectralLightSource] = []    # FIX: correct indent
        self._manual_lights: List[SpectralLightSource] = []
        self._manual_mode: str = "scene"
        self.light_sources: List[SpectralLightSource] = []

    def set_render_profile(self, name: str) -> None:
        n = str(name).lower().strip()
        if n not in {"preview","balanced","cinematic","analysis"}: raise ValueError(f"Unknown profile: {name}")
        base = self._cfg_baseline
        for k, v in base.__dict__.items(): setattr(self.cfg, k, (v.copy() if isinstance(v, np.ndarray) else v))
        if n == "preview":
            self.cfg.render_scale=min(self.cfg.render_scale,0.40); self.cfg.ray_steps=min(int(self.cfg.ray_steps),48)
            self.cfg.light_shadow_mode="approx_local"; self.cfg.light_shadow_steps=min(int(self.cfg.light_shadow_steps),4)
            self.cfg.max_lights_per_sample=min(int(self.cfg.max_lights_per_sample),1)
            self.cfg.enable_postprocess=False; self.cfg.enable_consolidation=False
            self.cfg.enable_normals=False; self.cfg.enable_object_glow=False
        elif n == "balanced":
            self.cfg.light_transport_mode="hybrid"; self.cfg.light_shadow_mode="short_march"
            self.cfg.ray_steps=int(max(self.cfg.ray_steps,72))
            self.cfg.max_lights_per_sample=int(np.clip(self.cfg.max_lights_per_sample,1,2))
            self.cfg.enable_postprocess=True; self.cfg.enable_consolidation=True
        elif n == "cinematic":
            self.cfg.light_transport_mode="hybrid"; self.cfg.light_shadow_mode="short_march"
            self.cfg.ray_steps=int(max(self.cfg.ray_steps,96))
            self.cfg.max_lights_per_sample=int(np.clip(self.cfg.max_lights_per_sample,2,4))
            self.cfg.enable_postprocess=True; self.cfg.diffusion_iterations=max(int(self.cfg.diffusion_iterations),2)
            self.cfg.enable_consolidation=True; self.cfg.enable_normals=True; self.cfg.enable_object_glow=True
        elif n == "analysis":
            self.cfg.light_transport_mode="source_driven"; self.cfg.light_shadow_mode="none"
            self.cfg.enable_postprocess=False; self.cfg.enable_consolidation=False
            self.cfg.enable_phantom_overlay=False; self.cfg.enable_object_glow=False
            self.cfg.gamma=1.; self.cfg.exposure=1.

    def reset_render_profile(self):
        base=self._cfg_baseline
        for k,v in base.__dict__.items(): setattr(self.cfg,k,(v.copy() if isinstance(v,np.ndarray) else v))

    def reset_memory(self, stream_key=None):
        if stream_key is None: self._memory_by_key={}
        else: self._memory_by_key.pop(str(stream_key),None)

    def clear_all_memory(self): self._memory_by_key={}

    def set_manual_mode(self, mode):
        m=str(mode).lower().strip()
        if m not in {"scene","add","replace","disable"}: raise ValueError(f"Unknown mode: {mode}")
        self._manual_mode=m

    def set_manual_light_sources(self, lights): self._manual_lights=[self._coerce_light(l) for l in list(lights or [])]
    def clear_manual_lights(self): self._manual_lights=[]
    def set_light_sources(self, lights): self.light_sources=list(lights)
    def clear_light_sources(self): self.light_sources=[]

    def _resolve_output_size(self):
        if self.cfg.output_width>0 and self.cfg.output_height>0: return int(self.cfg.output_width),int(self.cfg.output_height)
        preset=str(self.cfg.output_preset).lower()
        if preset not in RESOLUTION_PRESETS: raise ValueError(f"Unknown output_preset: {preset}")
        return RESOLUTION_PRESETS[preset]

    def _resolve_internal_size(self, out_w, out_h):
        scale=float(np.clip(self.cfg.render_scale,0.05,1.))
        w=max(32,int(round(out_w*scale))); h=max(32,int(round(out_h*scale)))
        if self.cfg.max_internal_width>0: w=min(w,int(self.cfg.max_internal_width))
        if self.cfg.max_internal_height>0: h=min(h,int(self.cfg.max_internal_height))
        return w,h

    def _validated_gradient_mode(self):
        mode=str(self.cfg.gradient_mode).lower()
        if mode not in {"em_intensity","em","density_combo"}: raise ValueError(f"Unknown gradient_mode: {mode}")
        return "em_intensity" if mode=="em" else mode

    def _validated_transport_mode(self):
        m=str(self.cfg.light_transport_mode).lower()
        if m not in {"self_emissive","source_driven","hybrid"}: raise ValueError(f"Unknown transport_mode: {m}")
        return m

    def _validated_shadow_mode(self):
        m=str(self.cfg.light_shadow_mode).lower()
        if m not in {"none","approx_local","short_march"}: raise ValueError(f"Unknown shadow_mode: {m}")
        return m

    def _extract_fields_and_grid(self, sim_or_snapshot):
        if isinstance(sim_or_snapshot, dict):
            snap=sim_or_snapshot
            phi_g=np.ascontiguousarray(np.asarray(snap["phi_g"],dtype=np.float64))
            phi_em=np.ascontiguousarray(np.asarray(snap["phi_em"],dtype=np.float64))
            phi_s=np.ascontiguousarray(np.asarray(snap["phi_s"],dtype=np.float64))
            phi_w=np.ascontiguousarray(np.asarray(snap["phi_w"],dtype=np.float64))
            cfg=snap["config"]; dx=float(cfg["dx"]); nx=int(cfg["nx"]); ny=int(cfg["ny"]); nz=int(cfg["nz"])
        else:
            sim=sim_or_snapshot
            phi_g=np.ascontiguousarray(np.asarray(sim.phi_g,dtype=np.float64))
            phi_em=np.ascontiguousarray(np.asarray(sim.phi_em,dtype=np.float64))
            phi_s=np.ascontiguousarray(np.asarray(sim.phi_s,dtype=np.float64))
            phi_w=np.ascontiguousarray(np.asarray(sim.phi_w,dtype=np.float64))
            dx=float(sim.cfg.dx); nx=int(sim.cfg.nx); ny=int(sim.cfg.ny); nz=int(sim.cfg.nz)
        if self.cfg.validate_shapes:
            if phi_g.shape!=phi_em.shape or phi_g.shape!=phi_s.shape or phi_g.shape!=phi_w.shape: raise ValueError("Field shapes mismatch")
            if phi_g.ndim!=3: raise ValueError("Fields must be 3D")
            if phi_g.shape[0]<3 or phi_g.shape[1]<3 or phi_g.shape[2]<3: raise ValueError(f"Grid too small: {phi_g.shape}")
            if (nx,ny,nz)!=phi_g.shape: raise ValueError(f"Config/field shape mismatch")
            if dx<=0.: raise ValueError("dx must be > 0")
        return phi_g,phi_em,phi_s,phi_w,dx,nx,ny,nz

    def _coerce_light(self, x):
        if isinstance(x, SpectralLightSource): return x
        if isinstance(x, dict):
            d=x; pos=np.asarray(d.get("pos",[0.,0.,0.]),dtype=np.float64).reshape(3)
            return SpectralLightSource(
                pos=pos, intensity=float(d.get("intensity",1.)), radius=float(d.get("radius",0.)),
                color_temperature_k=float(d.get("color_temperature_k",6500.)),
                spectral_weights=None,
                field_coupling_g=float(d.get("field_coupling_g",0.)),
                field_coupling_em=float(d.get("field_coupling_em",1.)),
                field_coupling_s=float(d.get("field_coupling_s",0.)),
                field_coupling_w=float(d.get("field_coupling_w",0.)),
                kind=str(d.get("kind","point")), tags=tuple(d.get("tags",[]) or ()),
                metadata=dict(d.get("metadata",{}) or {}))
        raise TypeError(f"Unsupported light type: {type(x)}")

    def _extract_scene_light_dicts(self, sim_or_snapshot):
        if isinstance(sim_or_snapshot, dict):
            snap=sim_or_snapshot
            if isinstance(snap.get("light_sources"),list): return list(snap["light_sources"])
            meta=snap.get("metadata")
            if isinstance(meta,dict) and isinstance(meta.get("light_sources"),list): return list(meta["light_sources"])
            return []
        ls=getattr(sim_or_snapshot,"light_sources",None)
        return list(ls) if isinstance(ls,list) else []

    def load_lights_from_scene(self, sim_or_snapshot):
        recs=self._extract_scene_light_dicts(sim_or_snapshot)
        self._scene_lights=[self._coerce_light(r) for r in recs]
        return int(len(self._scene_lights))

    def _resolve_effective_lights(self, sim_or_snapshot):
        self.load_lights_from_scene(sim_or_snapshot)
        legacy=list(self.light_sources) if self.light_sources else []
        mode=str(self._manual_mode).lower().strip()
        if mode=="disable": return []
        if mode=="scene": return list(self._scene_lights)
        manual=list(self._manual_lights)
        if legacy: manual=manual+legacy
        if mode=="replace": return manual
        return list(self._scene_lights)+manual

    def _camera_basis(self, cam):
        eps=self.cfg.eps
        fwd_raw=np.asarray(cam.target,dtype=np.float64)-np.asarray(cam.pos,dtype=np.float64)
        if float(np.linalg.norm(fwd_raw))<eps: raise ValueError("Camera target must differ from position")
        return _robust_camera_basis(fwd_raw, np.asarray(cam.up,dtype=np.float64),
                                    np.asarray(self.cfg.camera_up_fallback,dtype=np.float64), eps)

    def _compute_far_plane(self, nx, ny, nz, dx):
        if self.cfg.far_plane_abs>0.: return float(self.cfg.far_plane_abs)
        diag=float(np.linalg.norm(np.array([(nx-1)*dx,(ny-1)*dx,(nz-1)*dx],dtype=np.float64)))
        return float(max(diag*self.cfg.far_plane_mul, self.cfg.near_plane+dx))

    def _get_glow_kernel(self, sigma):
        sigma=max(float(sigma),0.5); rad=int(np.ceil(3.*sigma))
        key=(int(round(sigma*1000.)),rad)
        cached=self._glow_kernel_cache.get(key)
        if cached is not None: return cached
        yy=np.arange(-rad,rad+1,dtype=np.float64); xx=np.arange(-rad,rad+1,dtype=np.float64)
        GX,GY=np.meshgrid(xx,yy)
        K=np.exp(-(GX*GX+GY*GY)/(2.*sigma*sigma))
        K/=np.maximum(np.sum(K),self.cfg.eps)
        self._glow_kernel_cache[key]=K
        return K

    def _project_points(self, pts_world, cam, W, H):
        fwd,right,up=self._camera_basis(cam)
        thf=np.tan(np.deg2rad(self.cfg.fov_y_deg)*0.5); aspect=float(W)/float(max(H,1))
        rel=pts_world-cam.pos[None,:]
        z=rel@fwd; x=(rel@right)/np.maximum(z,self.cfg.eps); y=(rel@up)/np.maximum(z,self.cfg.eps)
        ndc_x=x/(aspect*thf); ndc_y=y/thf
        return (ndc_x*0.5+0.5)*W,(0.5-ndc_y*0.5)*H,z

    def _add_object_glow(self, rgb_linear, sim_or_snapshot, cam):
        if not self.cfg.enable_object_glow: return
        if isinstance(sim_or_snapshot,dict):
            obj_r=np.asarray(sim_or_snapshot.get("obj_r",np.zeros((0,3))),dtype=np.float64)
            obj_q=np.asarray(sim_or_snapshot.get("obj_q",np.zeros((0,))),dtype=np.float64)
            obj_m=np.asarray(sim_or_snapshot.get("obj_m",np.zeros((0,))),dtype=np.float64)
        else:
            obj_r=np.asarray(getattr(sim_or_snapshot,"obj_r",np.zeros((0,3))),dtype=np.float64)
            obj_q=np.asarray(getattr(sim_or_snapshot,"obj_q",np.zeros((0,))),dtype=np.float64)
            obj_m=np.asarray(getattr(sim_or_snapshot,"obj_m",np.zeros((0,))),dtype=np.float64)
        if obj_r.shape[0]==0: return
        H,W,_=rgb_linear.shape
        px,py,pz=self._project_points(obj_r,cam,W,H)
        K=self._get_glow_kernel(self.cfg.object_glow_sigma_px); rad=(K.shape[0]-1)//2
        q_ref=max(self.cfg.object_glow_charge_ref,self.cfg.eps); m_ref=max(self.cfg.object_glow_mass_ref,self.cfg.eps)
        soft=max(self.cfg.object_glow_softclip,self.cfg.eps)
        for i in range(obj_r.shape[0]):
            if pz[i]<=0.: continue
            x0=int(round(px[i])); y0=int(round(py[i]))
            if x0<-rad or x0>=W+rad or y0<-rad or y0>=H+rad: continue
            charge=abs(float(obj_q[i])) if i<obj_q.shape[0] else 0.
            mass=abs(float(obj_m[i])) if i<obj_m.shape[0] else 1.
            cq=np.log1p(charge/q_ref); cm=np.log1p(mass/m_ref)
            cq=cq/(1.+cq/soft); cm=cm/(1.+cm/soft)
            glow_rgb=(0.45*cm*self._field_rgb_basis64[0]+0.95*cq*self._field_rgb_basis64[1])
            amp=self.cfg.object_glow_strength/np.sqrt(max(pz[i],1.)); glow_rgb=amp*glow_rgb
            ys0=max(0,y0-rad); ys1=min(H,y0+rad+1); xs0=max(0,x0-rad); xs1=min(W,x0+rad+1)
            ky0=ys0-(y0-rad); ky1=K.shape[0]-((y0+rad+1)-ys1)
            kx0=xs0-(x0-rad); kx1=K.shape[1]-((x0+rad+1)-xs1)
            rgb_linear[ys0:ys1,xs0:xs1]+=K[ky0:ky1,kx0:kx1][:,:,None]*glow_rgb[None,None,:]

    def _pack_lights(self, lights):
        Lmax=int(max(self.cfg.max_total_lights,0))
        empty=(np.zeros((0,3),dtype=np.float64),np.zeros((0,3),dtype=np.float64),
               np.zeros((0,),dtype=np.float64),np.zeros((0,),dtype=np.float64),np.zeros((0,4),dtype=np.float64))
        if Lmax<=0 or not lights: return empty
        wl=self.cfg.wavelengths_nm; out_pos=[]; out_rgb=[]; out_I=[]; out_R=[]; out_C=[]
        for src in lights[:Lmax]:
            pos=np.asarray(src.pos,dtype=np.float64).reshape(3)
            if src.spectral_weights is not None:
                w=np.asarray(src.spectral_weights,dtype=np.float64).copy()
                w=np.maximum(w,0.); w=w/np.maximum(np.max(w),1e-12) if float(np.max(w))>0. else np.ones_like(w)/len(w)
            else:
                w=approximate_blackbody_spectrum(wl,float(src.color_temperature_k))
            rgb=(w[:,None]*self.band_rgb).sum(axis=0); rgb/=np.maximum(np.max(rgb),1e-12)
            out_pos.append(pos); out_rgb.append(rgb.astype(np.float64))
            out_I.append(float(src.intensity)); out_R.append(float(src.radius))
            out_C.append(np.array([src.field_coupling_g,src.field_coupling_em,src.field_coupling_s,src.field_coupling_w],dtype=np.float64))
        if not out_pos: return empty
        return (np.ascontiguousarray(np.stack(out_pos),dtype=np.float64),
                np.ascontiguousarray(np.stack(out_rgb),dtype=np.float64),
                np.ascontiguousarray(np.array(out_I,dtype=np.float64)),
                np.ascontiguousarray(np.array(out_R,dtype=np.float64)),
                np.ascontiguousarray(np.stack(out_C),dtype=np.float64))

    def render_buffers(self, sim_or_snapshot, camera=None, stream_key="main", return_linear=False):
        mode_grad=self._validated_gradient_mode()
        mode_transport=self._validated_transport_mode()
        mode_shadow=self._validated_shadow_mode()
        phi_g,phi_em,phi_s,phi_w,dx,nx,ny,nz=self._extract_fields_and_grid(sim_or_snapshot)
        out_w,out_h=self._resolve_output_size(); int_w,int_h=self._resolve_internal_size(out_w,out_h)
        if camera is None: camera=_default_camera_for_grid(nx,ny,nz,dx)
        fwd,right,up=self._camera_basis(camera)
        cam_pos=np.ascontiguousarray(np.asarray(camera.pos,dtype=np.float64))
        cam_fwd=np.ascontiguousarray(fwd.astype(np.float64))
        cam_right=np.ascontiguousarray(right.astype(np.float64))
        cam_up=np.ascontiguousarray(up.astype(np.float64))
        thf=float(np.tan(np.deg2rad(self.cfg.fov_y_deg)*0.5)); aspect=float(int_w)/float(max(int_h,1))
        far_plane=self._compute_far_plane(nx,ny,nz,dx)
        maxx=float((nx-1)*dx); maxy=float((ny-1)*dx); maxz=float((nz-1)*dx)
        rgb_linear=np.zeros((int_h,int_w,3),dtype=np.float64)
        depth01=np.ones((int_h,int_w),dtype=np.float64)
        phantom01=np.zeros((int_h,int_w),dtype=np.float64)
        enable_normals=bool(self.cfg.enable_normals)
        normal01=np.zeros((int_h,int_w,3),dtype=np.float64) if enable_normals else np.zeros((1,1,3),dtype=np.float64)
        density_scales=np.ascontiguousarray(np.array([self.cfg.density_scale_g,self.cfg.density_scale_em,self.cfg.density_scale_s,self.cfg.density_scale_w],dtype=np.float64))
        emission_scales=np.ascontiguousarray(np.array([self.cfg.emission_scale_g,self.cfg.emission_scale_em,self.cfg.emission_scale_s,self.cfg.emission_scale_w],dtype=np.float64))
        bg_rgb=np.ascontiguousarray(np.array(self.cfg.background_rgb,dtype=np.float64))
        use_abs_shading=self.cfg.use_abs_emission if self.cfg.use_abs_shading is None else bool(self.cfg.use_abs_shading)
        mode_self=(mode_transport=="self_emissive"); mode_src=(mode_transport=="source_driven"); mode_hyb=(mode_transport=="hybrid")
        shadow_id=0
        if mode_shadow=="approx_local": shadow_id=1    # FIX: correct elif → if chain
        elif mode_shadow=="short_march": shadow_id=2
        eff_lights=self._resolve_effective_lights(sim_or_snapshot)
        light_pos,light_rgb,light_I,light_R,light_C=self._pack_lights(eff_lights)

        render_buffers_kernel_v240(
            phi_g,phi_em,phi_s,phi_w,rgb_linear,depth01,phantom01,normal01,enable_normals,
            cam_pos,cam_fwd,cam_right,cam_up,float(thf),float(aspect),
            float(dx),int(self.cfg.ray_steps),float(self.cfg.near_plane),float(far_plane),
            0.,0.,0.,maxx,maxy,maxz,density_scales,emission_scales,self._field_rgb_basis64,
            float(self.cfg.absorption_gain),float(self.cfg.emission_gain),
            bool(self.cfg.enable_gradient_shading),float(self.cfg.gradient_shading_gain),
            bool(mode_grad=="density_combo"),int(self.cfg.gradient_stride),
            float(self.cfg.early_stop_transmittance),bg_rgb,
            bool(self.cfg.use_abs_emission),bool(self.cfg.use_abs_density),bool(use_abs_shading),
            bool(mode_self),bool(mode_src),bool(mode_hyb),
            float(self.cfg.source_scatter_gain),float(self.cfg.source_scatter_density_gate),
            int(shadow_id),float(self.cfg.light_shadow_mu),int(self.cfg.light_shadow_steps),float(self.cfg.light_shadow_step_scale),
            int(self.cfg.max_lights_per_sample),
            light_pos,light_rgb,light_I,light_R,light_C,
            float(self.cfg.phantom_threshold_g),float(self.cfg.phantom_threshold_em),
            float(self.cfg.phantom_threshold_s),float(self.cfg.phantom_threshold_w),
        )

        self._add_object_glow(rgb_linear,sim_or_snapshot,camera)

        if self.cfg.enable_postprocess:
            if self._tmp_a is None or self._tmp_a.shape!=rgb_linear.shape:
                self._tmp_a=rgb_linear.copy(); self._tmp_b=rgb_linear.copy()
            self._tmp_a[:]=rgb_linear
            for _ in range(max(0,int(self.cfg.diffusion_iterations))):
                edge_aware_diffusion_step_rgb(self._tmp_a,self._tmp_b,float(self.cfg.diffusion_kappa),float(self.cfg.diffusion_dt))
                self._tmp_a,self._tmp_b=self._tmp_b,self._tmp_a
            rgb_linear=self._tmp_a.copy()

        if self.cfg.enable_consolidation:
            mem=self._memory_by_key.get(stream_key)
            rgb_linear,mem2=_apply_consolidation(rgb_linear,mem,float(self.cfg.consolidation_rho),
                float(self.cfg.consolidation_strength),float(self.cfg.consolidation_tau),
                float(self.cfg.consolidation_alpha),float(self.cfg.eps))
            self._memory_by_key[stream_key]=mem2

        if self.cfg.enable_phantom_overlay:
            tint=self._field_rgb_basis64[1].astype(np.float64)
            a=float(self.cfg.phantom_overlay_strength)*phantom01[:,:,None]
            rgb_linear=rgb_linear+(tint[None,None,:]-rgb_linear)*a

        rgb_linear=np.maximum(rgb_linear,0.)
        if int_w!=out_w or int_h!=out_h:
            rgb_linear=resize_bilinear_rgb(rgb_linear,out_h,out_w)
            depth01=resize_bilinear_1c(depth01,out_h,out_w)
            phantom01=resize_bilinear_1c(phantom01,out_h,out_w)
            if enable_normals: normal01=renormalize_normal01(resize_bilinear_rgb(normal01,out_h,out_w),self.cfg.eps)

        rgb_linear=np.maximum(rgb_linear,0.); depth01=np.clip(depth01,0.,1.); phantom01=np.clip(phantom01,0.,1.)
        rgb_u8=tone_map_to_uint8(rgb_linear,float(self.cfg.exposure),float(self.cfg.gamma))
        depth_u8=depth_to_uint8(depth01); phantom_u8=mask_to_uint8(phantom01)
        if enable_normals: normal_u8=encode_normal_to_uint8(np.clip(normal01,0.,1.))
        else:
            normal_u8=np.empty((out_h,out_w,3),dtype=np.uint8)
            normal_u8[:,:,0]=128; normal_u8[:,:,1]=128; normal_u8[:,:,2]=255

        out={"schema_version":SCHEMA_VERSION,"module_name":MODULE_NAME,"module_version":MODULE_VERSION,
             "rgb_u8":rgb_u8,"depth_u8":depth_u8,"normal_u8":normal_u8,"phantom_u8":phantom_u8,
             "render_metadata":{"schema_version":SCHEMA_VERSION,"module_name":MODULE_NAME,"module_version":MODULE_VERSION,
                                "light_count":int(light_pos.shape[0]),"transport_mode":mode_transport,
                                "shadow_mode":mode_shadow,"internal_size":[int(int_w),int(int_h)],"output_size":[int(out_w),int(out_h)]}}
        if return_linear:
            out.update(rgb_linear=rgb_linear,depth01=depth01,phantom01=phantom01)
            if enable_normals: out["normal01"]=normal01
        return out

    def render_rgb(self, sim_or_snapshot, camera=None, stream_key="main"):
        return self.render_buffers(sim_or_snapshot,camera=camera,stream_key=stream_key)["rgb_u8"]

    def render_multiview(self, sim_or_snapshot, cameras, keys=None):
        if keys is None: keys=[f"view{i}" for i in range(len(cameras))]
        if len(keys)!=len(cameras): raise ValueError("keys length must match cameras")
        return [self.render_buffers(sim_or_snapshot,camera=cam,stream_key=key) for cam,key in zip(cameras,keys)]