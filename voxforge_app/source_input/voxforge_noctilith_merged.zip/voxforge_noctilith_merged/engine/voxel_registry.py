"""noctilith/voxel_registry.py — global voxel material registry."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional

SCHEMA_VERSION = "noctilith.schema.v1"

@dataclass
class VoxelDef:
    id: int
    name: str
    color_rgb: tuple = (0.5, 0.5, 0.5)
    density: float = 1.0
    hardness: float = 0.5
    young_modulus: float = 10e9
    yield_stress: float = 5e6
    brittleness: float = 0.5
    cp: float = 800.0
    thermal_conductivity: float = 0.5
    melting_point_k: float = 2000.0
    boiling_point_k: float = 4000.0
    flammability: float = 0.0
    oxidation_rate: float = 0.0
    porosity: float = 0.0
    phase: str = "solid"
    transparent: bool = False
    emissive: bool = False
    emissive_strength: float = 0.0
    tags: List[str] = field(default_factory=list)


class VoxelRegistry:
    def __init__(self) -> None:
        self._by_id: Dict[int, VoxelDef] = {}
        self._by_name: Dict[str, VoxelDef] = {}
        self._register_defaults()

    def register(self, vdef: VoxelDef) -> None:
        self._by_id[vdef.id] = vdef
        self._by_name[vdef.name] = vdef

    def _register_defaults(self) -> None:
        defaults = [
            VoxelDef(id=0, name="air", color_rgb=(0,0,0), density=1.2, hardness=0.0,
                     young_modulus=0, yield_stress=0, cp=1005, thermal_conductivity=0.026,
                     melting_point_k=0, boiling_point_k=0, phase="gas", transparent=True, tags=["gas"]),
            VoxelDef(id=1, name="stone", color_rgb=(0.45,0.45,0.45), density=2700, hardness=0.8,
                     young_modulus=50e9, yield_stress=40e6, brittleness=0.9, cp=840,
                     thermal_conductivity=1.7, melting_point_k=1986, tags=["rock"]),
            VoxelDef(id=2, name="grass", color_rgb=(0.3,0.6,0.2), density=1200, hardness=0.3,
                     cp=1200, thermal_conductivity=0.5, flammability=0.25, tags=["organic","surface"]),
            VoxelDef(id=3, name="dirt", color_rgb=(0.5,0.35,0.15), density=1300, hardness=0.25,
                     cp=800, thermal_conductivity=0.5, porosity=0.4, tags=["soil"]),
            VoxelDef(id=4, name="water", color_rgb=(0.1,0.3,0.8), density=1000, hardness=0.0,
                     cp=4186, thermal_conductivity=0.606, melting_point_k=273.15,
                     boiling_point_k=373.15, phase="liquid", transparent=True, tags=["liquid","fluid"]),
            VoxelDef(id=5, name="lava", color_rgb=(0.9,0.3,0.05), density=3000, hardness=0.0,
                     cp=1200, thermal_conductivity=1.0, melting_point_k=900, phase="liquid",
                     emissive=True, emissive_strength=2.5, tags=["liquid","hot"]),
            VoxelDef(id=6, name="wood", color_rgb=(0.55,0.35,0.15), density=600, hardness=0.35,
                     young_modulus=12e9, yield_stress=40e6, cp=1700, thermal_conductivity=0.13,
                     flammability=0.8, tags=["organic","structural"]),
            VoxelDef(id=7, name="sand", color_rgb=(0.85,0.80,0.50), density=1600, hardness=0.1,
                     cp=840, thermal_conductivity=0.3, porosity=0.35, tags=["loose","soil"]),
        ]
        for d in defaults:
            self.register(d)

    def by_id(self, voxel_id: int) -> Optional[VoxelDef]:
        return self._by_id.get(voxel_id)

    def by_name(self, name: str) -> Optional[VoxelDef]:
        return self._by_name.get(name)

    def by_tag(self, tag: str) -> List[VoxelDef]:
        return [v for v in self._by_id.values() if tag in v.tags]

    def all_ids(self) -> List[int]:
        return sorted(self._by_id.keys())

    def __len__(self) -> int:
        return len(self._by_id)


REGISTRY = VoxelRegistry()
