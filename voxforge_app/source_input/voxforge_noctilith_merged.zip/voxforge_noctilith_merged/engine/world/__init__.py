"""engine.world — voxel world, chunks, materials."""
from .voxel import VoxelData, Material, MaterialRegistry, MATERIALS
from .chunk import Chunk, ChunkStorage, CHUNK_SIZE
from .world import World, WorldMetadata

__all__ = ["VoxelData", "Material", "MaterialRegistry", "MATERIALS",
           "Chunk", "ChunkStorage", "CHUNK_SIZE", "World", "WorldMetadata"]

# Imported Noctilith world helpers / compatibility layer
from .meshing import Quad, greedy_mesh
from .save_load import save_world, load_world
from .persistence_damage import (
    export_world_reaction_state,
    import_world_reaction_state,
    save_world_reaction_state,
    load_world_reaction_state,
)
from .noctilith_chunk import ChunkData as NoctilithChunkData, ChunkManager as NoctilithChunkManager
from .noctilith_gen import TerrainGen as NoctilithTerrainGen
