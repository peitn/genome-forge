"""
engine/world/chunk.py
=====================
Chunk systém — základ voxelového světa.

Blueprint §2.1: "chunk systém, streaming světa"
Blueprint §2.2: "chunked voxel world, LOD systém, regiony a zóny"
"""
from __future__ import annotations

import json
import os
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterator, Optional, Tuple

import numpy as np

from .voxel import VoxelData, MATERIALS


CHUNK_SIZE = 16   # 16×16×16 voxelů na chunk (konfigurovatelné)


# ── Chunk ──────────────────────────────────────────────────────────────────────

class Chunk:
    """
    Jeden chunk světa = CHUNK_SIZE³ voxelů.

    Ukládá data ve dvou vrstvách:
    - `materials`: numpy uint8 array (material_id per voxel)
    - `fields`:    numpy float32 arrays (temperature, entropy, damage, moisture, pressure)
    - `fluid`:     numpy float32 array  (fluid_volume per voxel)

    Separace materials vs. fields umožňuje efektivní NumPy operace
    na simulačních polích bez procházení každého voxelu.
    """

    def __init__(self, cx: int, cy: int, cz: int, size: int = CHUNK_SIZE):
        self.cx = cx          # chunk koordináty v chunkspace
        self.cy = cy
        self.cz = cz
        self.size = size
        self.dirty = False    # needs save/remesh
        self.loaded = True

        S = (size, size, size)
        self.materials  = np.zeros(S, dtype=np.uint8)
        self.temperature = np.zeros(S, dtype=np.float32)
        self.entropy     = np.zeros(S, dtype=np.float32)
        self.damage      = np.zeros(S, dtype=np.float32)
        self.moisture    = np.zeros(S, dtype=np.float32)
        self.pressure    = np.zeros(S, dtype=np.float32)
        self.fluid_vol   = np.zeros(S, dtype=np.float32)

    @property
    def world_origin(self) -> Tuple[int, int, int]:
        """Světové souřadnice voxelu [0,0,0] tohoto chunku."""
        s = self.size
        return (self.cx * s, self.cy * s, self.cz * s)

    def get(self, lx: int, ly: int, lz: int) -> VoxelData:
        """Vrátí VoxelData pro lokální souřadnice v chunku."""
        return VoxelData(
            material_id=int(self.materials[lx, ly, lz]),
            temperature=float(self.temperature[lx, ly, lz]),
            entropy=float(self.entropy[lx, ly, lz]),
            damage=float(self.damage[lx, ly, lz]),
            moisture=float(self.moisture[lx, ly, lz]),
            pressure=float(self.pressure[lx, ly, lz]),
            fluid_volume=float(self.fluid_vol[lx, ly, lz]),
        )

    def set_material(self, lx: int, ly: int, lz: int, material_id: int) -> None:
        self.materials[lx, ly, lz] = material_id
        self.dirty = True

    def fill(self, material_id: int,
             lx0: int = 0, ly0: int = 0, lz0: int = 0,
             lx1: Optional[int] = None, ly1: Optional[int] = None,
             lz1: Optional[int] = None) -> None:
        """Vyplň oblast materiálem."""
        s = self.size
        lx1 = s if lx1 is None else lx1
        ly1 = s if ly1 is None else ly1
        lz1 = s if lz1 is None else lz1
        self.materials[lx0:lx1, ly0:ly1, lz0:lz1] = material_id
        self.dirty = True

    def is_empty(self) -> bool:
        return bool(np.all(self.materials == 0))

    def voxel_count(self, material_id: Optional[int] = None) -> int:
        if material_id is None:
            return int(np.sum(self.materials > 0))
        return int(np.sum(self.materials == material_id))

    # ── Serialization ──────────────────────────────────────────────────────────

    def to_bytes(self) -> bytes:
        """Kompaktní binární serializace chunků."""
        header = struct.pack(">iiiH", self.cx, self.cy, self.cz, self.size)
        mats = self.materials.tobytes()
        temps = self.temperature.tobytes()
        ents = self.entropy.tobytes()
        dmgs = self.damage.tobytes()
        flvol = self.fluid_vol.tobytes()
        return header + mats + temps + ents + dmgs + flvol

    @classmethod
    def from_bytes(cls, data: bytes) -> "Chunk":
        cx, cy, cz, size = struct.unpack_from(">iiiH", data, 0)
        chunk = cls(cx, cy, cz, size)
        offset = struct.calcsize(">iiiH")
        vol = size ** 3
        u8 = vol
        f32 = vol * 4
        chunk.materials    = np.frombuffer(data[offset:offset+u8], dtype=np.uint8).reshape((size,)*3).copy()
        offset += u8
        chunk.temperature  = np.frombuffer(data[offset:offset+f32], dtype=np.float32).reshape((size,)*3).copy()
        offset += f32
        chunk.entropy      = np.frombuffer(data[offset:offset+f32], dtype=np.float32).reshape((size,)*3).copy()
        offset += f32
        chunk.damage       = np.frombuffer(data[offset:offset+f32], dtype=np.float32).reshape((size,)*3).copy()
        offset += f32
        chunk.fluid_vol    = np.frombuffer(data[offset:offset+f32], dtype=np.float32).reshape((size,)*3).copy()
        chunk.dirty = False
        return chunk

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.to_bytes())
        self.dirty = False

    @classmethod
    def load(cls, path: Path) -> "Chunk":
        return cls.from_bytes(path.read_bytes())

    def __repr__(self) -> str:
        return f"Chunk(cx={self.cx}, cy={self.cy}, cz={self.cz}, voxels={self.voxel_count()})"


# ── Chunk Storage ──────────────────────────────────────────────────────────────

class ChunkStorage:
    """
    Spravuje načítání a ukládání chunků.
    Blueprint §2.1: "chunk systém, streaming světa, save/load"

    V budoucnu: LRU cache + background streaming.
    """

    def __init__(self, root_dir: Path, chunk_size: int = CHUNK_SIZE):
        self.root = Path(root_dir)
        self.chunk_size = chunk_size
        self._loaded: Dict[Tuple[int,int,int], Chunk] = {}

    def _chunk_path(self, cx: int, cy: int, cz: int) -> Path:
        # Hierarchie: world/regions/cx_cy/chunk_cx_cy_cz.vox
        rx = cx // 8
        ry = cy // 8
        return self.root / f"r{rx}_{ry}" / f"c{cx}_{cy}_{cz}.vox"

    def get_or_create(self, cx: int, cy: int, cz: int) -> Chunk:
        key = (cx, cy, cz)
        if key in self._loaded:
            return self._loaded[key]
        path = self._chunk_path(cx, cy, cz)
        if path.exists():
            chunk = Chunk.load(path)
        else:
            chunk = Chunk(cx, cy, cz, self.chunk_size)
        self._loaded[key] = chunk
        return chunk

    def get(self, cx: int, cy: int, cz: int) -> Optional[Chunk]:
        key = (cx, cy, cz)
        if key in self._loaded:
            return self._loaded[key]
        path = self._chunk_path(cx, cy, cz)
        if path.exists():
            c = Chunk.load(path)
            self._loaded[key] = c
            return c
        return None

    def save_dirty(self) -> int:
        """Ulož všechny dirty chunky. Vrátí počet uložených."""
        saved = 0
        for key, chunk in self._loaded.items():
            if chunk.dirty:
                chunk.save(self._chunk_path(*key))
                saved += 1
        return saved

    def save_all(self) -> int:
        count = 0
        for key, chunk in self._loaded.items():
            chunk.save(self._chunk_path(*key))
            count += 1
        return count

    @property
    def loaded_count(self) -> int:
        return len(self._loaded)

    def loaded_chunks(self) -> Iterator[Chunk]:
        yield from self._loaded.values()
