"""noctilith/world/meshing.py — greedy mesh."""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class Quad:
    voxel_id: int
    axis: int
    position: Tuple[int,int,int]
    size: Tuple[int,int]
    face_normal: int


def greedy_mesh(voxel_ids: np.ndarray) -> List[Quad]:
    """Minimal greedy meshing — returns list of Quad faces."""
    quads: List[Quad] = []
    nx, ny, nz = voxel_ids.shape
    for axis in range(3):
        shape = [nx, ny, nz]
        d = shape[axis]
        for i in range(d):
            slc = [slice(None)] * 3
            slc[axis] = i
            layer = voxel_ids[tuple(slc)]
            visited = np.zeros_like(layer, dtype=bool)
            rows, cols = layer.shape
            for r in range(rows):
                for c in range(cols):
                    if not visited[r, c] and layer[r, c] != 0:
                        vid = int(layer[r, c])
                        w = 1
                        while c + w < cols and layer[r, c+w] == vid and not visited[r, c+w]:
                            w += 1
                        h = 1
                        while r + h < rows:
                            if all(layer[r+h, c:c+w] == vid) and not any(visited[r+h, c:c+w]):
                                h += 1
                            else:
                                break
                        visited[r:r+h, c:c+w] = True
                        pos = [0, 0, 0]
                        pos[axis] = i
                        dims = [0, 1, 2]
                        dims.remove(axis)
                        pos[dims[0]] = r; pos[dims[1]] = c
                        quads.append(Quad(voxel_id=vid, axis=axis,
                                          position=tuple(pos), size=(w, h), face_normal=1))
    return quads
