"""noctilith/world/chunk.py — ChunkData + ChunkManager."""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

CHUNK_NX: int = 16
CHUNK_NY: int = 256
CHUNK_NZ: int = 16
ChunkKey = Tuple[int, int]


@dataclass
class ChunkData:
    cx: int
    cz: int
    voxel_ids: np.ndarray = field(
        default_factory=lambda: np.zeros((CHUNK_NX, CHUNK_NY, CHUNK_NZ), dtype=np.int16))
    dirty: bool = True
    mesh_dirty: bool = True
    metadata: Dict = field(default_factory=dict)

    @property
    def key(self) -> ChunkKey:
        return (self.cx, self.cz)

    def get_voxel(self, lx: int, ly: int, lz: int) -> int:
        return int(self.voxel_ids[lx, ly, lz])

    def set_voxel(self, lx: int, ly: int, lz: int, voxel_id: int) -> None:
        self.voxel_ids[lx, ly, lz] = voxel_id
        self.dirty = True; self.mesh_dirty = True

    def world_origin(self, dx: float = 1.0) -> tuple:
        return (self.cx * CHUNK_NX * dx, 0.0, self.cz * CHUNK_NZ * dx)


class ChunkManager:
    def __init__(self) -> None:
        self._chunks: Dict[ChunkKey, ChunkData] = {}

    def get_or_create(self, cx: int, cz: int) -> ChunkData:
        key = (cx, cz)
        if key not in self._chunks:
            self._chunks[key] = ChunkData(cx=cx, cz=cz)
        return self._chunks[key]

    def get(self, cx: int, cz: int) -> Optional[ChunkData]:
        return self._chunks.get((cx, cz))

    def loaded_keys(self):
        return list(self._chunks.keys())

    def __len__(self) -> int:
        return len(self._chunks)
