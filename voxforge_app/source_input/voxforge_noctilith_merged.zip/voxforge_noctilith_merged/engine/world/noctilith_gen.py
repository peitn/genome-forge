"""noctilith/world/gen.py — TerrainGen."""
from __future__ import annotations
import numpy as np
from engine.world.noctilith_chunk import ChunkData, CHUNK_NX, CHUNK_NY, CHUNK_NZ


class TerrainGen:
    def __init__(self, seed: int = 42):
        self.seed = seed
        self._rng = np.random.default_rng(seed)

    def generate_chunk(self, cx: int, cz: int, sea_level: int = 64) -> ChunkData:
        chunk = ChunkData(cx=cx, cz=cz)
        rng = np.random.default_rng(self.seed ^ (cx * 73856093) ^ (cz * 19349663))
        heights = sea_level + (rng.integers(-4, 5, (CHUNK_NX, CHUNK_NZ))).astype(int)
        for lx in range(CHUNK_NX):
            for lz in range(CHUNK_NZ):
                h = int(heights[lx, lz])
                for ly in range(min(h, CHUNK_NY)):
                    if ly < h - 3:
                        chunk.voxel_ids[lx, ly, lz] = 1   # stone
                    elif ly < h - 1:
                        chunk.voxel_ids[lx, ly, lz] = 3   # dirt
                    else:
                        chunk.voxel_ids[lx, ly, lz] = 2   # grass
        return chunk
