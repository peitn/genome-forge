"""noctilith/world/persistence_damage.py — damage state persistence."""
from __future__ import annotations
import json, pathlib
from typing import Any, Dict

SCHEMA_VERSION = "noctilith.schema.v1"
_FILENAME = "world_reaction_state.json"


def export_world_reaction_state(world_obj: Any) -> Dict[str, Any]:
    damage_marks   = getattr(world_obj, "_damage_marks",   {})
    voxel_weakness = getattr(world_obj, "_voxel_weakness", {})
    debris_requests = getattr(world_obj, "_debris_requests", [])
    return {
        "schema_version": SCHEMA_VERSION,
        "damage_marks":    {str(k): float(v) for k, v in damage_marks.items()},
        "voxel_weakness":  {str(k): float(v) for k, v in voxel_weakness.items()},
        "debris_requests": list(debris_requests),
    }


def import_world_reaction_state(data: Dict[str, Any], world_obj: Any) -> bool:
    if data.get("schema_version") != SCHEMA_VERSION:
        return False
    def parse_key(k: str):
        parts = k.strip("()").split(",")
        return tuple(int(p.strip()) for p in parts)
    dm = getattr(world_obj, "_damage_marks", None)
    if dm is None: world_obj._damage_marks = {}; dm = world_obj._damage_marks
    for k, v in data.get("damage_marks", {}).items():
        dm[parse_key(k)] = float(v)
    vw = getattr(world_obj, "_voxel_weakness", None)
    if vw is None: world_obj._voxel_weakness = {}; vw = world_obj._voxel_weakness
    for k, v in data.get("voxel_weakness", {}).items():
        vw[parse_key(k)] = float(v)
    dr = getattr(world_obj, "_debris_requests", None)
    if dr is None: world_obj._debris_requests = []; dr = world_obj._debris_requests
    dr.extend(data.get("debris_requests", []))
    return True


def save_world_reaction_state(directory: str, world_obj: Any) -> str:
    p = pathlib.Path(directory)
    p.mkdir(parents=True, exist_ok=True)
    path = str(p / _FILENAME)
    (p / _FILENAME).write_text(json.dumps(export_world_reaction_state(world_obj), indent=2))
    return path


def load_world_reaction_state(directory: str, world_obj: Any) -> bool:
    p = pathlib.Path(directory) / _FILENAME
    if not p.exists(): return False
    data = json.loads(p.read_text())
    return import_world_reaction_state(data, world_obj)
