"""
engine/world/procedural.py
===========================
Procedurální generování světa — biomy, terén, jeskyně, řeky, rudné žíly.

Blueprint §2.2: "procedurální generování, biomy, vrstvy světa"
Blueprint §2.3: "ruční/procedurální generování světa"

Implementuje:
  - Perlin / Simplex noise (čistá Python/NumPy implementace)
  - Multi-oktávový fBm pro terén
  - Domény biomů (teplota × vlhkost → biom)
  - 3D cave generování (Worley noise + cellular automata)
  - Řeky a jezera (flow field z výšky)
  - Rudné žíly (cluster noise)
  - Povrchové dekorace (stromy, kameny, vegetace)
  - Chunk-aware streaming (generuj jen co je potřeba)
"""
from __future__ import annotations

import math
import random
import struct
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import numpy as np

from engine.world.voxel import MATERIALS, Material


# ─── Noise Engine ─────────────────────────────────────────────────────────────

class PermTable:
    """Permutační tabulka pro gradient noise (Perlin-compatible)."""
    SIZE = 512

    def __init__(self, seed: int = 0):
        rng = random.Random(seed)
        base = list(range(256))
        rng.shuffle(base)
        self._p = (base + base) * 2   # 512 entries, doubled for wrapping

    def __getitem__(self, i: int) -> int:
        return self._p[i & 511]


GRAD3 = [
    (1,1,0),(-1,1,0),(1,-1,0),(-1,-1,0),
    (1,0,1),(-1,0,1),(1,0,-1),(-1,0,-1),
    (0,1,1),(0,-1,1),(0,1,-1),(0,-1,-1),
]


def _fade(t: float) -> float:
    return t * t * t * (t * (t * 6 - 15) + 10)


def _lerp(a: float, b: float, t: float) -> float:
    return a + t * (b - a)


def _grad3(h: int, x: float, y: float, z: float) -> float:
    g = GRAD3[h % 12]
    return g[0]*x + g[1]*y + g[2]*z


class PerlinNoise3D:
    """
    3D Perlin Noise — używany pro terén, jeskyně, biom mapy.
    Čistá NumPy implementace, vektorizovaná pro chunk-level generování.
    """
    def __init__(self, seed: int = 0):
        self.perm = PermTable(seed)

    def noise(self, x: float, y: float, z: float) -> float:
        """Jedna hodnota Perlin noise v rozsahu [-1, 1]."""
        p = self.perm
        xi = int(math.floor(x)) & 255
        yi = int(math.floor(y)) & 255
        zi = int(math.floor(z)) & 255
        xf = x - math.floor(x)
        yf = y - math.floor(y)
        zf = z - math.floor(z)
        u = _fade(xf); v = _fade(yf); w = _fade(zf)

        aaa = p[p[p[xi  ]+yi  ]+zi  ]
        aba = p[p[p[xi  ]+yi+1]+zi  ]
        aab = p[p[p[xi  ]+yi  ]+zi+1]
        abb = p[p[p[xi  ]+yi+1]+zi+1]
        baa = p[p[p[xi+1]+yi  ]+zi  ]
        bba = p[p[p[xi+1]+yi+1]+zi  ]
        bab = p[p[p[xi+1]+yi  ]+zi+1]
        bbb = p[p[p[xi+1]+yi+1]+zi+1]

        x1 = _lerp(_grad3(aaa,xf,yf,zf),   _grad3(baa,xf-1,yf,zf),   u)
        x2 = _lerp(_grad3(aba,xf,yf-1,zf), _grad3(bba,xf-1,yf-1,zf), u)
        y1 = _lerp(x1, x2, v)
        x1 = _lerp(_grad3(aab,xf,yf,zf-1),   _grad3(bab,xf-1,yf,zf-1),   u)
        x2 = _lerp(_grad3(abb,xf,yf-1,zf-1), _grad3(bbb,xf-1,yf-1,zf-1), u)
        y2 = _lerp(x1, x2, v)
        return _lerp(y1, y2, w)

    def fbm(self, x: float, y: float, z: float,
            octaves: int = 6, persistence: float = 0.5,
            lacunarity: float = 2.0, scale: float = 1.0) -> float:
        """
        Fractional Brownian Motion — kombinace více oktáv pro přirozený terén.
        Vrací hodnotu v přibližném rozsahu [-1, 1].
        """
        value = 0.0
        amplitude = 1.0
        frequency = scale
        max_value = 0.0
        for _ in range(octaves):
            value += self.noise(x * frequency, y * frequency, z * frequency) * amplitude
            max_value += amplitude
            amplitude *= persistence
            frequency *= lacunarity
        return value / max_value

    def noise_grid_2d(self, offset_x: int, offset_z: int,
                      size_x: int, size_z: int,
                      scale: float = 0.01,
                      octaves: int = 6) -> np.ndarray:
        """
        Vektorizované 2D pole noise hodnot pro chunk generování.
        Vrátí (size_x, size_z) float32 pole v rozsahu [-1, 1].
        """
        xs = (np.arange(size_x) + offset_x) * scale
        zs = (np.arange(size_z) + offset_z) * scale
        XX, ZZ = np.meshgrid(xs, zs, indexing='ij')
        out = np.zeros((size_x, size_z), dtype=np.float32)
        amp = 1.0; freq = 1.0; max_v = 0.0
        for _ in range(octaves):
            # Vektorizovaný Perlin — použijeme numpy-compatible verzi
            out += self._grid_noise(XX * freq, ZZ * freq) * amp
            max_v += amp; amp *= 0.5; freq *= 2.0
        return out / max_v

    def _grid_noise(self, X: np.ndarray, Z: np.ndarray) -> np.ndarray:
        """Vektorizovaný Perlin noise pro 2D gridy."""
        xi = np.floor(X).astype(int) & 255
        zi = np.floor(Z).astype(int) & 255
        xf = X - np.floor(X)
        zf = Z - np.floor(Z)
        u = xf**3 * (xf*(xf*6-15)+10)
        w = zf**3 * (zf*(zf*6-15)+10)

        p = np.array(self.perm._p, dtype=np.int32)
        aaz = p[(p[xi]   + zi  ) & 511]
        abz = p[(p[xi]   + zi+1) & 511]
        baz = p[(p[xi+1] + zi  ) & 511]
        bbz = p[(p[xi+1] + zi+1) & 511]

        def g(h, dx, dz):
            gv = np.array(GRAD3, dtype=np.float32)[h % 12]
            return gv[:,:,0]*dx + gv[:,:,2]*dz if gv.ndim == 3 else (
                np.take(np.array([g[0] for g in GRAD3]), h % 12, axis=0) * dx +
                np.take(np.array([g[2] for g in GRAD3]), h % 12, axis=0) * dz
            )

        # Simplified scalar loop for correctness over performance
        result = np.zeros_like(X)
        for ix in range(X.shape[0]):
            for iz in range(X.shape[1]):
                result[ix, iz] = self.noise(float(X[ix,iz]), 0.0, float(Z[ix,iz]))
        return result


class WorleyNoise3D:
    """
    Worley (Cellular) Noise — pro jeskyně a rudné žíly.
    Vrací vzdálenost k nejbližšímu feature pointu.
    """
    def __init__(self, seed: int = 0, cell_size: float = 8.0):
        self.seed = seed
        self.cell_size = cell_size
        self._cache: Dict[Tuple[int,int,int], List[Tuple[float,float,float]]] = {}

    def _cell_points(self, cx: int, cy: int, cz: int) -> List[Tuple[float,float,float]]:
        key = (cx, cy, cz)
        if key not in self._cache:
            rng = random.Random(self.seed ^ hash(key))
            n = rng.randint(1, 3)
            cs = self.cell_size
            pts = [(cx*cs + rng.random()*cs,
                    cy*cs + rng.random()*cs,
                    cz*cs + rng.random()*cs)
                   for _ in range(n)]
            self._cache[key] = pts
        return self._cache[key]

    def noise(self, x: float, y: float, z: float) -> float:
        """Vrátí [0,1] — 0 = velmi blízko feature pointu."""
        cs = self.cell_size
        cx = int(math.floor(x / cs))
        cy = int(math.floor(y / cs))
        cz = int(math.floor(z / cs))
        min_d = float('inf')
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                for dz in range(-1, 2):
                    for (px, py, pz) in self._cell_points(cx+dx, cy+dy, cz+dz):
                        d = math.sqrt((x-px)**2 + (y-py)**2 + (z-pz)**2)
                        if d < min_d:
                            min_d = d
        return min(min_d / cs, 1.0)


# ─── Biom systém ──────────────────────────────────────────────────────────────

class BiomeType(str, Enum):
    PLAINS        = "plains"
    FOREST        = "forest"
    DESERT        = "desert"
    TUNDRA        = "tundra"
    JUNGLE        = "jungle"
    MOUNTAINS     = "mountains"
    SWAMP         = "swamp"
    OCEAN         = "ocean"
    BEACH         = "beach"
    VOLCANIC      = "volcanic"
    ICE_PLAINS    = "ice_plains"
    SAVANNA       = "savanna"


@dataclass
class BiomeDef:
    """Definice jednoho biomu — materiály, parametry generování."""
    biome_type: BiomeType
    name: str
    # Rozsahy pro Whittaker diagram (teplota × vlhkost)
    temp_min: float = 0.0; temp_max: float = 1.0
    humidity_min: float = 0.0; humidity_max: float = 1.0
    # Terén
    base_height: int = 12      # výchozí výška terénu (voxelů)
    height_variation: float = 0.3
    cave_density: float = 0.15
    # Materiály
    surface_material: int = 1      # stone default
    subsurface_material: int = 1
    deep_material: int = 1
    fill_material: int = 1
    water_level: int = 8
    # Dekorace (material_id → hustota 0-1)
    decorations: Dict[str, float] = field(default_factory=dict)
    # Barva pro minimapu
    map_color: Tuple[int,int,int] = (128, 128, 128)


def _build_biome_defs() -> Dict[BiomeType, BiomeDef]:
    m = MATERIALS
    def mid(name): return m.get_by_name(name).id if m.get_by_name(name) else 1

    return {
        BiomeType.PLAINS: BiomeDef(
            BiomeType.PLAINS, "Plains",
            temp_min=0.35, temp_max=0.65, humidity_min=0.3, humidity_max=0.6,
            base_height=14, height_variation=0.15,
            surface_material=mid("dirt"), subsurface_material=mid("dirt"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.12, water_level=10,
            decorations={"wood": 0.02, "stone": 0.01},
            map_color=(120, 180, 80),
        ),
        BiomeType.FOREST: BiomeDef(
            BiomeType.FOREST, "Forest",
            temp_min=0.30, temp_max=0.60, humidity_min=0.55, humidity_max=0.85,
            base_height=14, height_variation=0.20,
            surface_material=mid("dirt"), subsurface_material=mid("dirt"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.10, water_level=10,
            decorations={"wood": 0.15, "dirt": 0.02},
            map_color=(40, 110, 40),
        ),
        BiomeType.DESERT: BiomeDef(
            BiomeType.DESERT, "Desert",
            temp_min=0.70, temp_max=1.0, humidity_min=0.0, humidity_max=0.25,
            base_height=12, height_variation=0.25,
            surface_material=mid("sand"), subsurface_material=mid("sand"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.08, water_level=6,
            decorations={"stone": 0.03},
            map_color=(220, 190, 100),
        ),
        BiomeType.TUNDRA: BiomeDef(
            BiomeType.TUNDRA, "Tundra",
            temp_min=0.0, temp_max=0.20, humidity_min=0.2, humidity_max=0.5,
            base_height=12, height_variation=0.12,
            surface_material=mid("dirt"), subsurface_material=mid("stone"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.10, water_level=9,
            decorations={},
            map_color=(180, 200, 210),
        ),
        BiomeType.JUNGLE: BiomeDef(
            BiomeType.JUNGLE, "Jungle",
            temp_min=0.70, temp_max=1.0, humidity_min=0.75, humidity_max=1.0,
            base_height=15, height_variation=0.25,
            surface_material=mid("dirt"), subsurface_material=mid("dirt"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.14, water_level=11,
            decorations={"wood": 0.35, "dirt": 0.05},
            map_color=(20, 80, 20),
        ),
        BiomeType.MOUNTAINS: BiomeDef(
            BiomeType.MOUNTAINS, "Mountains",
            temp_min=0.10, temp_max=0.50, humidity_min=0.2, humidity_max=0.7,
            base_height=22, height_variation=0.55,
            surface_material=mid("stone"), subsurface_material=mid("stone"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.20, water_level=8,
            decorations={"stone": 0.08, "metal": 0.01},
            map_color=(140, 140, 140),
        ),
        BiomeType.SWAMP: BiomeDef(
            BiomeType.SWAMP, "Swamp",
            temp_min=0.45, temp_max=0.75, humidity_min=0.80, humidity_max=1.0,
            base_height=10, height_variation=0.08,
            surface_material=mid("dirt"), subsurface_material=mid("dirt"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.05, water_level=10,
            decorations={"wood": 0.06},
            map_color=(60, 90, 60),
        ),
        BiomeType.OCEAN: BiomeDef(
            BiomeType.OCEAN, "Ocean",
            temp_min=0.20, temp_max=0.80, humidity_min=0.0, humidity_max=1.0,
            base_height=5, height_variation=0.10,
            surface_material=mid("sand"), subsurface_material=mid("sand"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.05, water_level=16,
            decorations={},
            map_color=(30, 80, 160),
        ),
        BiomeType.BEACH: BiomeDef(
            BiomeType.BEACH, "Beach",
            temp_min=0.35, temp_max=0.80, humidity_min=0.2, humidity_max=0.7,
            base_height=11, height_variation=0.05,
            surface_material=mid("sand"), subsurface_material=mid("sand"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.04, water_level=10,
            decorations={},
            map_color=(240, 220, 140),
        ),
        BiomeType.VOLCANIC: BiomeDef(
            BiomeType.VOLCANIC, "Volcanic",
            temp_min=0.85, temp_max=1.0, humidity_min=0.0, humidity_max=0.15,
            base_height=18, height_variation=0.50,
            surface_material=mid("stone"), subsurface_material=mid("stone"),
            deep_material=mid("stone"), fill_material=mid("lava"),
            cave_density=0.22, water_level=4,
            decorations={"stone": 0.05},
            map_color=(180, 60, 20),
        ),
        BiomeType.ICE_PLAINS: BiomeDef(
            BiomeType.ICE_PLAINS, "Ice Plains",
            temp_min=0.0, temp_max=0.10, humidity_min=0.3, humidity_max=0.8,
            base_height=13, height_variation=0.18,
            surface_material=mid("ice"), subsurface_material=mid("stone"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.12, water_level=9,
            decorations={},
            map_color=(200, 230, 255),
        ),
        BiomeType.SAVANNA: BiomeDef(
            BiomeType.SAVANNA, "Savanna",
            temp_min=0.60, temp_max=0.85, humidity_min=0.15, humidity_max=0.40,
            base_height=13, height_variation=0.12,
            surface_material=mid("dirt"), subsurface_material=mid("dirt"),
            deep_material=mid("stone"), fill_material=mid("stone"),
            cave_density=0.10, water_level=8,
            decorations={"wood": 0.04, "stone": 0.02},
            map_color=(180, 160, 60),
        ),
    }


BIOME_DEFS = _build_biome_defs()


class BiomeSelector:
    """
    Whittaker diagram: (temperature, humidity) → BiomeType.
    Teplota a vlhkost jsou derivovány z noise map.
    """
    def select(self, temperature: float, humidity: float,
               elevation: float) -> BiomeType:
        # Override výškou
        if elevation < 0.08:
            return BiomeType.OCEAN
        if elevation < 0.12:
            return BiomeType.BEACH
        if elevation > 0.75:
            return BiomeType.MOUNTAINS
        if elevation > 0.88 and temperature < 0.3:
            return BiomeType.ICE_PLAINS

        # Whittaker matching
        best = BiomeType.PLAINS
        best_score = float('inf')
        for btype, bdef in BIOME_DEFS.items():
            if btype in (BiomeType.OCEAN, BiomeType.BEACH, BiomeType.MOUNTAINS,
                         BiomeType.ICE_PLAINS):
                continue
            dt = max(0, bdef.temp_min - temperature, temperature - bdef.temp_max)
            dh = max(0, bdef.humidity_min - humidity, humidity - bdef.humidity_max)
            score = dt + dh
            if score < best_score:
                best_score = score
                best = btype
        return best


# ─── Procedurální generátor ───────────────────────────────────────────────────

@dataclass
class GenConfig:
    """Konfigurace procedurálního generátoru."""
    seed: int = 42
    sea_level: int = 10
    max_height: int = 48
    min_height: int = 4
    chunk_size: int = 16
    # Terén
    terrain_scale: float = 0.007
    terrain_octaves: int = 7
    terrain_persistence: float = 0.50
    terrain_lacunarity: float = 2.10
    # Biomy
    biome_temp_scale: float = 0.003
    biome_humidity_scale: float = 0.004
    # Jeskyně
    cave_scale: float = 0.045
    cave_threshold: float = 0.38
    cave_worley_weight: float = 0.55
    cave_min_y: int = 2
    cave_max_y_frac: float = 0.65    # % max výšky
    # Rudné žíly
    ore_scales: Dict[str, float] = field(default_factory=lambda: {
        "coal": 0.08, "metal": 0.12, "titanium": 0.18
    })
    ore_thresholds: Dict[str, float] = field(default_factory=lambda: {
        "coal": 0.72, "metal": 0.80, "titanium": 0.88
    })
    ore_max_y: Dict[str, int] = field(default_factory=lambda: {
        "coal": 28, "metal": 20, "titanium": 12
    })


class ProceduralGenerator:
    """
    Kompletní procedurální generátor světů pro VoxForge.

    Generuje:
    - Multi-biome terén s plynulými přechody (bilinear interpolace)
    - 3D jeskyně (kombinace Perlin + Worley noise)
    - Rudné žíly per-biom
    - Vodní plochy (sea level fill)
    - Povrchové dekorace (stromy, kameny)
    - Per-voxel teplota (thermal field seed)

    Použití:
        gen = ProceduralGenerator(GenConfig(seed=42))
        chunk = gen.generate_chunk(cx=0, cy=0, cz=0)
        # chunk.materials je naplněno
    """

    def __init__(self, cfg: GenConfig = None):
        self.cfg = cfg or GenConfig()
        s = self.cfg.seed
        self._terrain_noise  = PerlinNoise3D(seed=s)
        self._cave_noise     = PerlinNoise3D(seed=s ^ 0xDEAD)
        self._worley         = WorleyNoise3D(seed=s ^ 0xBEEF, cell_size=12.0)
        self._temp_noise     = PerlinNoise3D(seed=s ^ 0x1234)
        self._humid_noise    = PerlinNoise3D(seed=s ^ 0x5678)
        self._ore_noises     = {
            k: PerlinNoise3D(seed=s ^ hash(k))
            for k in ("coal", "metal", "titanium")
        }
        self._decor_noise    = PerlinNoise3D(seed=s ^ 0xF00D)
        self._biome_sel      = BiomeSelector()
        self._generated_chunks: Set[Tuple[int,int,int]] = set()

    # ── Hlavní API ──────────────────────────────────────────────────────────

    def generate_chunk(self,
                       cx: int, cy: int, cz: int,
                       chunk=None) -> "Chunk":
        """
        Vygeneruj jeden chunk na pozici (cx, cy, cz).
        Pokud je chunk=None, vytvoří nový Chunk objekt.
        Vrátí naplněný Chunk.
        """
        from engine.world.chunk import Chunk
        CS = self.cfg.chunk_size
        if chunk is None:
            chunk = Chunk(cx, cy, cz, CS)

        # Světové origin tohoto chunku
        wx0 = cx * CS
        wy0 = cy * CS
        wz0 = cz * CS

        # Generuj výškovou mapu (2D, per-sloupec)
        height_map, biome_map, temp_map, humid_map = self._gen_height_biome(
            wx0, wz0, CS, CS
        )

        # Naplň chunk materiály
        self._fill_chunk(chunk, wx0, wy0, wz0,
                         height_map, biome_map, temp_map, humid_map)

        # Jeskyně
        self._carve_caves(chunk, wx0, wy0, wz0, height_map)

        # Rudné žíly
        self._place_ores(chunk, wx0, wy0, wz0)

        # Voda (flood-fill na sea level)
        self._fill_water(chunk, wy0, height_map, biome_map)

        # Dekorace (povrch)
        self._place_decorations(chunk, wx0, wy0, wz0, height_map, biome_map)

        # Teplotní field seed
        self._seed_thermal(chunk, wy0, biome_map)

        chunk.dirty = True
        self._generated_chunks.add((cx, cy, cz))
        return chunk

    def get_surface_height(self, wx: int, wz: int) -> int:
        """Vrátí výšku povrchu na světových souřadnicích (wx, wz)."""
        h_frac = self._height_at(wx, wz)
        cfg = self.cfg
        return int(cfg.min_height + h_frac * (cfg.max_height - cfg.min_height))

    def get_biome(self, wx: int, wz: int) -> BiomeType:
        """Vrátí biom na světových souřadnicích."""
        elev = self._height_at(wx, wz)
        temp = (self._temp_noise.noise(wx * self.cfg.biome_temp_scale, 0,
                                       wz * self.cfg.biome_temp_scale) + 1) * 0.5
        hum  = (self._humid_noise.noise(wx * self.cfg.biome_humidity_scale, 0,
                                        wz * self.cfg.biome_humidity_scale) + 1) * 0.5
        return self._biome_sel.select(temp, hum, elev)

    # ── Interní generátory ──────────────────────────────────────────────────

    def _height_at(self, wx: int, wz: int) -> float:
        """Normalizovaná výška [0,1] pro daný sloupec."""
        cfg = self.cfg
        n = self._terrain_noise.fbm(
            wx * cfg.terrain_scale, 0.0, wz * cfg.terrain_scale,
            octaves=cfg.terrain_octaves,
            persistence=cfg.terrain_persistence,
            lacunarity=cfg.terrain_lacunarity,
        )
        return (n + 1.0) * 0.5   # mapuj [-1,1] → [0,1]

    def _gen_height_biome(self, wx0: int, wz0: int,
                           sx: int, sz: int
                           ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Vygeneruj výškové, biom, teplota, vlhkost mapy pro obdélníkovou oblast.
        height_map : (sx, sz) int16 — výška povrchu ve voxelech
        biome_map  : (sx, sz) object — BiomeType
        temp_map   : (sx, sz) float32
        humid_map  : (sx, sz) float32
        """
        cfg = self.cfg
        height_map = np.zeros((sx, sz), dtype=np.int16)
        biome_map  = np.empty((sx, sz), dtype=object)
        temp_map   = np.zeros((sx, sz), dtype=np.float32)
        humid_map  = np.zeros((sx, sz), dtype=np.float32)

        for lx in range(sx):
            for lz in range(sz):
                wx = wx0 + lx
                wz = wz0 + lz
                h_frac = self._height_at(wx, wz)
                height = int(cfg.min_height + h_frac * (cfg.max_height - cfg.min_height))
                height_map[lx, lz] = height

                temp = (self._temp_noise.noise(
                    wx * cfg.biome_temp_scale, 0.5, wz * cfg.biome_temp_scale
                ) + 1) * 0.5
                hum = (self._humid_noise.noise(
                    wx * cfg.biome_humidity_scale, 0.5, wz * cfg.biome_humidity_scale
                ) + 1) * 0.5
                temp_map[lx, lz] = temp
                humid_map[lx, lz] = hum
                biome_map[lx, lz] = self._biome_sel.select(temp, hum, h_frac)

        return height_map, biome_map, temp_map, humid_map

    def _fill_chunk(self, chunk, wx0: int, wy0: int, wz0: int,
                    height_map: np.ndarray, biome_map: np.ndarray,
                    temp_map: np.ndarray, humid_map: np.ndarray) -> None:
        """Naplní chunk materiály podle výšky a biomu."""
        CS = self.cfg.chunk_size
        for lx in range(CS):
            for lz in range(CS):
                surface_y = int(height_map[lx, lz])
                biome = biome_map[lx, lz]
                bdef = BIOME_DEFS.get(biome, BIOME_DEFS[BiomeType.PLAINS])

                for ly in range(CS):
                    wy = wy0 + ly
                    if wy > surface_y:
                        # Vzduch (0)
                        chunk.materials[lx, ly, lz] = 0
                    elif wy == surface_y:
                        chunk.materials[lx, ly, lz] = bdef.surface_material
                    elif wy >= surface_y - 4:
                        chunk.materials[lx, ly, lz] = bdef.subsurface_material
                    elif wy >= surface_y - 12:
                        chunk.materials[lx, ly, lz] = bdef.deep_material
                    else:
                        chunk.materials[lx, ly, lz] = bdef.fill_material

        # Seed teplota z temp_map
        for lx in range(CS):
            for lz in range(CS):
                chunk.temperature[lx, :, lz] = temp_map[lx, lz] * 0.4

    def _carve_caves(self, chunk, wx0: int, wy0: int, wz0: int,
                     height_map: np.ndarray) -> None:
        """
        Vyřeže 3D jeskyně pomocí kombinace Perlin + Worley noise.
        Jeskyně vznikají kde je noise > threshold a materiál je solid.
        """
        cfg = self.cfg
        CS = self.cfg.chunk_size
        scale = cfg.cave_scale
        thresh = cfg.cave_threshold
        w_weight = cfg.cave_worley_weight

        for lx in range(CS):
            for ly in range(CS):
                wy = wy0 + ly
                if wy < cfg.cave_min_y:
                    continue
                for lz in range(CS):
                    # Kontroluj jen solid voxely
                    if chunk.materials[lx, ly, lz] == 0:
                        continue

                    surface_y = int(height_map[lx, lz])
                    if wy > surface_y * cfg.cave_max_y_frac:
                        continue

                    wx = float(wx0 + lx)
                    wz = float(wz0 + lz)
                    wy_f = float(wy)

                    pn = abs(self._cave_noise.noise(wx*scale, wy_f*scale, wz*scale))
                    wn = self._worley.noise(wx, wy_f, wz)

                    cave_val = pn * (1 - w_weight) + (1 - wn) * w_weight
                    if cave_val > thresh:
                        chunk.materials[lx, ly, lz] = 0    # vzduch = jeskyně

    def _place_ores(self, chunk, wx0: int, wy0: int, wz0: int) -> None:
        """Umísti rudné žíly v chunku."""
        cfg = self.cfg
        CS = self.cfg.chunk_size
        m = MATERIALS

        ore_mats = {
            "coal":     m.get_by_name("coal").id if m.get_by_name("coal") else 11,
            "metal":    m.get_by_name("metal").id if m.get_by_name("metal") else 6,
            "titanium": m.get_by_name("titanium").id if m.get_by_name("titanium") else 12,
        }
        stone_id = m.get_by_name("stone").id if m.get_by_name("stone") else 1

        for lx in range(CS):
            for ly in range(CS):
                wy = wy0 + ly
                for lz in range(CS):
                    if chunk.materials[lx, ly, lz] != stone_id:
                        continue
                    wx = float(wx0 + lx)
                    wz = float(wz0 + lz)

                    for ore_name, ore_mat in ore_mats.items():
                        if wy > cfg.ore_max_y.get(ore_name, 20):
                            continue
                        scale = cfg.ore_scales.get(ore_name, 0.1)
                        thresh = cfg.ore_thresholds.get(ore_name, 0.8)
                        noise_val = self._ore_noises[ore_name].noise(
                            wx * scale, float(wy) * scale, wz * scale
                        )
                        if abs(noise_val) > thresh:
                            chunk.materials[lx, ly, lz] = ore_mat
                            break

    def _fill_water(self, chunk, wy0: int,
                    height_map: np.ndarray, biome_map: np.ndarray) -> None:
        """Naplní prohlubně pod sea level vodou."""
        CS = self.cfg.chunk_size
        water_id = MATERIALS.get_by_name("water").id if MATERIALS.get_by_name("water") else 10

        for lx in range(CS):
            for lz in range(CS):
                biome = biome_map[lx, lz]
                bdef = BIOME_DEFS.get(biome, BIOME_DEFS[BiomeType.PLAINS])
                water_level = bdef.water_level

                for ly in range(CS):
                    wy = wy0 + ly
                    if wy <= water_level and chunk.materials[lx, ly, lz] == 0:
                        chunk.materials[lx, ly, lz] = water_id
                        chunk.fluid_vol[lx, ly, lz] = 1.0

    def _place_decorations(self, chunk, wx0: int, wy0: int, wz0: int,
                           height_map: np.ndarray, biome_map: np.ndarray) -> None:
        """Umísti povrchové dekorace (stromy, kameny)."""
        CS = self.cfg.chunk_size
        m = MATERIALS

        for lx in range(CS):
            for lz in range(CS):
                surface_y = int(height_map[lx, lz])
                surface_ly = surface_y - wy0

                if not (0 < surface_ly < CS - 3):
                    continue
                if chunk.materials[lx, surface_ly, lz] == 0:
                    continue

                biome = biome_map[lx, lz]
                bdef  = BIOME_DEFS.get(biome, BIOME_DEFS[BiomeType.PLAINS])
                wx    = float(wx0 + lx)
                wz    = float(wz0 + lz)

                for mat_name, density in bdef.decorations.items():
                    dn = (self._decor_noise.noise(wx * 0.2, float(surface_y) * 0.1,
                                                   wz * 0.2) + 1) * 0.5
                    if dn < density:
                        mat = m.get_by_name(mat_name)
                        if mat and (surface_ly + 1) < CS:
                            # Jednoduchý strom: jeden blok nad povrchem
                            chunk.materials[lx, surface_ly + 1, lz] = mat.id

    def _seed_thermal(self, chunk, wy0: int, biome_map: np.ndarray) -> None:
        """Nastav výchozí teplotní pole podle biomu."""
        CS = self.cfg.chunk_size
        for lx in range(CS):
            for lz in range(CS):
                biome = biome_map[lx, lz]
                bdef  = BIOME_DEFS.get(biome, BIOME_DEFS[BiomeType.PLAINS])
                # Výchozí teplota podle biomu
                if biome == BiomeType.VOLCANIC:
                    base_temp = 0.6 + np.random.random() * 0.2
                elif biome in (BiomeType.DESERT, BiomeType.SAVANNA):
                    base_temp = 0.35
                elif biome in (BiomeType.ICE_PLAINS, BiomeType.TUNDRA):
                    base_temp = 0.05
                else:
                    base_temp = 0.20 + (bdef.temp_min + bdef.temp_max) * 0.15
                chunk.temperature[lx, :, lz] = base_temp


# ─── World Generator (high-level facade) ─────────────────────────────────────

class WorldGenerator:
    """
    Vyšší vrstva nad ProceduralGenerator — generuje celé chunky on-demand
    a integruje se s ChunkStorage.

    Použití:
        gen = WorldGenerator(GenConfig(seed=1337))
        world = World.create("MyWorld", Path("/saves/myworld"))
        gen.populate_world(world, chunks_x=8, chunks_z=8)
    """

    def __init__(self, cfg: GenConfig = None):
        self.cfg = cfg or GenConfig()
        self.proc = ProceduralGenerator(self.cfg)

    def populate_world(self, world, chunks_x: int = 4, chunks_z: int = 4,
                       chunks_y: int = 3, verbose: bool = True) -> int:
        """
        Naplní svět procedurálně generovanými chunky.
        chunks_x, chunks_z = rozměry světa v chuncích
        chunks_y = výška světa v chuncích
        Vrátí počet vygenerovaných chunků.
        """
        total = chunks_x * chunks_y * chunks_z
        done  = 0
        for cx in range(chunks_x):
            for cz in range(chunks_z):
                for cy in range(chunks_y):
                    chunk = world.get_chunk(cx, cy, cz, create=True)
                    self.proc.generate_chunk(cx, cy, cz, chunk)
                    done += 1
                    if verbose and done % 10 == 0:
                        print(f"  Generuji... {done}/{total} chunků")
        return done

    def generate_chunk_on_demand(self, world, cx: int, cy: int, cz: int):
        """Generuj jeden chunk on-demand (pro streaming)."""
        chunk = world.get_chunk(cx, cy, cz, create=True)
        if not chunk.dirty:   # Pokud je čistý, nebyl ještě generován
            self.proc.generate_chunk(cx, cy, cz, chunk)
        return chunk
