"""noctilith/world/save_load.py — world save/load."""
from __future__ import annotations
import json, pathlib, numpy as np
from typing import Any

SCHEMA_VERSION = "noctilith.schema.v1"

def save_world(directory: str, world_obj: Any) -> str:
    p = pathlib.Path(directory)
    p.mkdir(parents=True, exist_ok=True)
    out = {"schema_version": SCHEMA_VERSION, "saved": True}
    path = str(p / "world.json")
    (p / "world.json").write_text(json.dumps(out, indent=2))
    return path

def load_world(directory: str, world_obj: Any) -> bool:
    p = pathlib.Path(directory) / "world.json"
    if not p.exists(): return False
    json.loads(p.read_text())
    return True
