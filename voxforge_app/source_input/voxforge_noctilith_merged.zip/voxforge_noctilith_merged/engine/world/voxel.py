"""
engine/world/voxel.py
=====================
Voxel typy a materiálový registr.

Blueprint §9: "Materiály nejsou jen vizuální.
               Každý materiál může mít: density, hardness, toughness,
               thermal conductivity, melting point, fluid permeability..."
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


# ── Materiál ───────────────────────────────────────────────────────────────────

@dataclass
class Material:
    """
    Fyzikální + vizuální definice materiálu.
    Každý voxel nese material_id → MaterialRegistry.get(id).
    """
    # Identita
    id: int
    name: str
    color: Tuple[int, int, int] = (128, 128, 128)   # RGB 0-255

    # Vizuální (PBR)
    roughness: float = 0.8
    metallic: float = 0.0
    emission: float = 0.0

    # Mechanické vlastnosti (normalizovány 0-1)
    density: float = 1.0          # g/cm³ normalizovaná
    hardness: float = 0.5         # odpor vůči scratching
    toughness: float = 0.5        # odpor vůči fraktuře
    brittleness: float = 0.5      # křehkost (brittle = fraktura bez deformace)

    # Termální vlastnosti
    thermal_conductivity: float = 0.5   # 0=insulator, 1=conductor
    heat_capacity: float = 0.5
    melting_point: float = 1.0          # normalizovaná teplota tání
    ignition_point: float = 1.0         # bod vznícení (1.0 = nehoří)

    # Fluidní vlastnosti
    fluid_permeability: float = 0.0     # 0=impermeable, 1=zcela permeabilní
    buoyancy: float = 0.0               # vztlak v kapalině (> 0 = plove)

    # Elektrické
    electrical_conductivity: float = 0.0

    # Chemické
    chemical_reactivity: float = 0.0    # reaktivita s jinými materiály

    # Zvukový profil
    sound_profile: str = "stone"        # "stone", "wood", "metal", "sand"

    # Flags
    is_fluid: bool = False
    is_solid: bool = True
    is_transparent: bool = False
    is_destructible: bool = True

    def can_burn(self) -> bool:
        return self.ignition_point < 1.0

    def can_melt(self) -> bool:
        return self.melting_point < 1.0

    def fracture_threshold(self) -> float:
        """Práh pro frakturu: nízká toughness = nižší práh."""
        return 0.3 + self.toughness * 0.5


# ── Materiálový registr ────────────────────────────────────────────────────────

class MaterialRegistry:
    """
    Globální registr všech materiálů platformy.
    Přístup přes singleton MATERIALS.
    """

    AIR = 0

    def __init__(self):
        self._by_id: Dict[int, Material] = {}
        self._by_name: Dict[str, Material] = {}
        self._next_id: int = 1

    def register(self, mat: Material) -> Material:
        if mat.id in self._by_id:
            raise ValueError(f"Material id={mat.id} already registered")
        self._by_id[mat.id] = mat
        self._by_name[mat.name] = mat
        return mat

    def get(self, id: int) -> Optional[Material]:
        return self._by_id.get(id)

    def get_by_name(self, name: str) -> Optional[Material]:
        return self._by_name.get(name)

    def all(self) -> List[Material]:
        return list(self._by_id.values())

    def __repr__(self) -> str:
        return f"MaterialRegistry({len(self._by_id)} materials)"


# ── Výchozí materiály platformy ────────────────────────────────────────────────

def _build_default_registry() -> MaterialRegistry:
    reg = MaterialRegistry()

    # Vzduch (id=0 je implicitně prázdný voxel, ale definujeme ho)
    # Vzduch nemá záznam — id=0 znamená "empty/air"

    reg.register(Material(
        id=1, name="stone", color=(120, 115, 110),
        roughness=0.95, density=0.85, hardness=0.75, toughness=0.55, brittleness=0.70,
        thermal_conductivity=0.30, heat_capacity=0.80, melting_point=0.95,
        fluid_permeability=0.0, sound_profile="stone",
    ))
    reg.register(Material(
        id=2, name="dirt", color=(100, 70, 50),
        roughness=0.98, density=0.45, hardness=0.20, toughness=0.30, brittleness=0.25,
        thermal_conductivity=0.15, heat_capacity=0.60, melting_point=1.0,
        fluid_permeability=0.15, sound_profile="sand",
    ))
    reg.register(Material(
        id=3, name="sand", color=(194, 178, 128),
        roughness=0.99, density=0.40, hardness=0.10, toughness=0.15, brittleness=0.10,
        thermal_conductivity=0.20, heat_capacity=0.50, melting_point=0.85,
        fluid_permeability=0.40, sound_profile="sand",
    ))
    reg.register(Material(
        id=4, name="wood", color=(139, 90, 43),
        roughness=0.80, density=0.35, hardness=0.40, toughness=0.60, brittleness=0.30,
        thermal_conductivity=0.10, heat_capacity=0.55, melting_point=1.0,
        ignition_point=0.40,   # hoří!
        fluid_permeability=0.05, sound_profile="wood",
        is_destructible=True,
    ))
    reg.register(Material(
        id=5, name="glass", color=(200, 220, 240),
        roughness=0.05, density=0.60, hardness=0.55, toughness=0.10, brittleness=0.95,
        thermal_conductivity=0.40, heat_capacity=0.45, melting_point=0.75,
        fluid_permeability=0.0, is_transparent=True, sound_profile="stone",
    ))
    reg.register(Material(
        id=6, name="metal", color=(180, 185, 195),
        roughness=0.30, metallic=0.90, density=0.90, hardness=0.85, toughness=0.80, brittleness=0.15,
        thermal_conductivity=0.90, heat_capacity=0.25, melting_point=0.80,
        electrical_conductivity=0.95, sound_profile="metal",
    ))
    reg.register(Material(
        id=7, name="concrete", color=(160, 158, 155),
        roughness=0.95, density=0.80, hardness=0.70, toughness=0.40, brittleness=0.60,
        thermal_conductivity=0.35, heat_capacity=0.70, melting_point=1.0,
        fluid_permeability=0.02, sound_profile="stone",
    ))
    reg.register(Material(
        id=8, name="ice", color=(180, 215, 240),
        roughness=0.05, density=0.50, hardness=0.30, toughness=0.20, brittleness=0.80,
        thermal_conductivity=0.70, heat_capacity=0.50, melting_point=0.15,  # taje snadno
        fluid_permeability=0.0, is_transparent=True, sound_profile="stone",
    ))
    reg.register(Material(
        id=9, name="lava", color=(220, 80, 20),
        roughness=0.60, density=1.0, emission=0.7,
        thermal_conductivity=0.50, heat_capacity=0.40, melting_point=0.0,
        ignition_point=0.0, fluid_permeability=1.0,
        is_fluid=True, is_solid=False, sound_profile="stone",
    ))
    reg.register(Material(
        id=10, name="water", color=(40, 100, 200),
        roughness=0.05, density=0.55, emission=0.0,
        thermal_conductivity=0.35, heat_capacity=0.90, melting_point=0.10,
        fluid_permeability=1.0, buoyancy=0.1,
        is_fluid=True, is_solid=False, sound_profile="sand",
    ))
    reg.register(Material(
        id=11, name="coal", color=(30, 30, 30),
        roughness=0.90, density=0.55, hardness=0.40, toughness=0.35, brittleness=0.65,
        thermal_conductivity=0.20, ignition_point=0.30, heat_capacity=0.40,
        fluid_permeability=0.0, sound_profile="stone",
    ))
    reg.register(Material(
        id=12, name="titanium", color=(200, 205, 215),
        roughness=0.20, metallic=0.95, density=0.95, hardness=0.95, toughness=0.95, brittleness=0.05,
        thermal_conductivity=0.50, heat_capacity=0.30, melting_point=0.92,
        electrical_conductivity=0.60, sound_profile="metal",
    ))

    return reg


# Globální singleton
MATERIALS = _build_default_registry()


# ── Voxel data struct ──────────────────────────────────────────────────────────

@dataclass
class VoxelData:
    """
    Kompletní data jednoho voxelu.
    Uloženo v Chunk.voxels[x, y, z].

    Blueprint §2.2: "Každý voxel může nést vlastnosti:
    materiál, hustota, pevnost, teplota, vlhkost, tlak..."
    """
    material_id: int = 0       # 0 = vzduch/prázdný

    # Field hodnoty (float 0-1, sdílené se SimGrid fieldy)
    temperature: float = 0.0
    entropy: float = 0.0
    damage: float = 0.0
    moisture: float = 0.0
    pressure: float = 0.0

    # Fluid data (blueprint §15)
    fluid_volume: float = 0.0
    fluid_velocity: Tuple[float, float, float] = field(default_factory=lambda: (0.0, 0.0, 0.0))

    # Metadata
    tags: int = 0              # bitflags pro scripting

    @property
    def is_air(self) -> bool:
        return self.material_id == 0

    @property
    def is_fluid(self) -> bool:
        mat = MATERIALS.get(self.material_id)
        return mat is not None and mat.is_fluid

    @property
    def material(self) -> Optional[Material]:
        return MATERIALS.get(self.material_id)
