"""
engine/world/world.py
=====================
World Manager — centrální správce 3D voxelového světa.

Blueprint §2.2: "chunked voxel world, LOD, regiony, zóny,
                  procedurální generování, metadata voxelů"
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterator, List, Optional, Tuple

import numpy as np

from .chunk import Chunk, ChunkStorage, CHUNK_SIZE
from .voxel import VoxelData, MATERIALS, MaterialRegistry


# ── World metadata ─────────────────────────────────────────────────────────────

@dataclass
class WorldMetadata:
    name: str = "Unnamed World"
    seed: int = 0
    chunk_size: int = CHUNK_SIZE
    world_size_chunks: Tuple[int, int, int] = (8, 4, 8)   # X, Y, Z v chuncích
    spawn_point: Tuple[float, float, float] = (64.0, 32.0, 64.0)
    enabled_modules: List[str] = None
    description: str = ""
    version: str = "1.0.0"

    def __post_init__(self):
        if self.enabled_modules is None:
            self.enabled_modules = ["thermal", "fluid", "damage"]

    def save(self, path: Path) -> None:
        path.write_text(json.dumps(asdict(self), indent=2))

    @classmethod
    def load(cls, path: Path) -> "WorldMetadata":
        d = json.loads(path.read_text())
        d["world_size_chunks"] = tuple(d["world_size_chunks"])
        d["spawn_point"] = tuple(d["spawn_point"])
        return cls(**d)


# ── World ──────────────────────────────────────────────────────────────────────

class World:
    """
    Hlavní světový manager.

    Souřadnicový systém:
        Světové souřadnice (wx, wy, wz): globální voxel pozice
        Chunk souřadnice  (cx, cy, cz): (wx // chunk_size, ...)
        Lokální souřadnice (lx, ly, lz): (wx % chunk_size, ...)

    Příklad:
        world = World.create("MyWorld", seed=42)
        world.set_voxel(10, 5, 10, material_id=MATERIALS.get_by_name("stone").id)
        world.set_voxel(10, 6, 10, material_id=MATERIALS.get_by_name("water").id)
        world.save("/path/to/save")
    """

    def __init__(self, meta: WorldMetadata, storage: ChunkStorage, bus=None):
        self.meta = meta
        self.storage = storage
        self.chunk_size = meta.chunk_size
        self.bus = bus
        self._active_chunks: Dict[Tuple[int,int,int], Chunk] = {}

    # ── Factory methods ────────────────────────────────────────────────────────

    @classmethod
    def create(cls, name: str, save_dir: Path, seed: int = 0, bus=None) -> "World":
        """Vytvoř nový prázdný svět."""
        save_dir = Path(save_dir)
        save_dir.mkdir(parents=True, exist_ok=True)
        meta = WorldMetadata(name=name, seed=seed)
        storage = ChunkStorage(save_dir / "chunks", meta.chunk_size)
        world = cls(meta, storage, bus)
        meta.save(save_dir / "metadata.json")
        return world

    @classmethod
    def load(cls, save_dir: Path, bus=None) -> "World":
        """Načti existující svět ze souboru."""
        save_dir = Path(save_dir)
        meta = WorldMetadata.load(save_dir / "metadata.json")
        storage = ChunkStorage(save_dir / "chunks", meta.chunk_size)
        return cls(meta, storage, bus)

    # ── Koordinátové konverze ──────────────────────────────────────────────────

    def world_to_chunk(self, wx: int, wy: int, wz: int) -> Tuple[Tuple[int,int,int], Tuple[int,int,int]]:
        """Vrátí (chunk_coords, local_coords)."""
        s = self.chunk_size
        cx, lx = divmod(wx, s)
        cy, ly = divmod(wy, s)
        cz, lz = divmod(wz, s)
        return (cx, cy, cz), (lx, ly, lz)

    def chunk_to_world(self, cx: int, cy: int, cz: int) -> Tuple[int, int, int]:
        s = self.chunk_size
        return cx * s, cy * s, cz * s

    # ── Voxel access ───────────────────────────────────────────────────────────

    def get_chunk(self, cx: int, cy: int, cz: int, create: bool = True) -> Optional[Chunk]:
        key = (cx, cy, cz)
        if key not in self._active_chunks:
            chunk = self.storage.get_or_create(cx, cy, cz) if create else self.storage.get(cx, cy, cz)
            if chunk is None:
                return None
            self._active_chunks[key] = chunk
        return self._active_chunks[key]

    def get_voxel(self, wx: int, wy: int, wz: int) -> VoxelData:
        (cx, cy, cz), (lx, ly, lz) = self.world_to_chunk(wx, wy, wz)
        chunk = self.get_chunk(cx, cy, cz, create=False)
        if chunk is None:
            return VoxelData()  # vzduch
        return chunk.get(lx, ly, lz)

    def get_material(self, wx: int, wy: int, wz: int) -> int:
        (cx, cy, cz), (lx, ly, lz) = self.world_to_chunk(wx, wy, wz)
        chunk = self.get_chunk(cx, cy, cz, create=False)
        if chunk is None:
            return 0
        return int(chunk.materials[lx, ly, lz])

    def set_voxel(self, wx: int, wy: int, wz: int,
                  material_id: int,
                  temperature: float = 0.0,
                  fluid_volume: float = 0.0) -> None:
        (cx, cy, cz), (lx, ly, lz) = self.world_to_chunk(wx, wy, wz)
        chunk = self.get_chunk(cx, cy, cz, create=True)
        chunk.set_material(lx, ly, lz, material_id)
        if temperature > 0:
            chunk.temperature[lx, ly, lz] = temperature
        if fluid_volume > 0:
            chunk.fluid_vol[lx, ly, lz] = fluid_volume

    def destroy_voxel(self, wx: int, wy: int, wz: int) -> int:
        """Odstraň voxel (nastavÍ na vzduch). Vrátí původní material_id."""
        old_mat = self.get_material(wx, wy, wz)
        self.set_voxel(wx, wy, wz, material_id=0)
        return old_mat

    def is_solid(self, wx: int, wy: int, wz: int) -> bool:
        mat_id = self.get_material(wx, wy, wz)
        if mat_id == 0:
            return False
        mat = MATERIALS.get(mat_id)
        return mat is not None and mat.is_solid

    def is_fluid_cell(self, wx: int, wy: int, wz: int) -> bool:
        (cx, cy, cz), (lx, ly, lz) = self.world_to_chunk(wx, wy, wz)
        chunk = self.get_chunk(cx, cy, cz, create=False)
        if chunk is None:
            return False
        return float(chunk.fluid_vol[lx, ly, lz]) > 0.001

    # ── Bulk operations ───────────────────────────────────────────────────────

    def fill_box(self,
                 wx0: int, wy0: int, wz0: int,
                 wx1: int, wy1: int, wz1: int,
                 material_id: int) -> int:
        """Vyplň kvádr materiálem. Vrátí počet nastavených voxelů."""
        count = 0
        for wx in range(wx0, wx1):
            for wy in range(wy0, wy1):
                for wz in range(wz0, wz1):
                    self.set_voxel(wx, wy, wz, material_id)
                    count += 1
        return count

    def fill_layer(self, wy: int, material_id: int,
                   wx0: int = 0, wz0: int = 0,
                   wx1: int = 64, wz1: int = 64) -> None:
        """Vyplň celou vrstvu (horizontální plát)."""
        for wx in range(wx0, wx1):
            for wz in range(wz0, wz1):
                self.set_voxel(wx, wy, wz, material_id)

    # ── Iterace ────────────────────────────────────────────────────────────────

    def iter_loaded_chunks(self) -> Iterator[Chunk]:
        yield from self._active_chunks.values()

    def loaded_chunk_count(self) -> int:
        return len(self._active_chunks)

    def total_voxel_count(self) -> int:
        return sum(c.voxel_count() for c in self._active_chunks.values())

    # ── Save / Load ────────────────────────────────────────────────────────────

    def save(self, save_dir: Optional[Path] = None) -> int:
        """Ulož všechny dirty chunky. Vrátí počet uložených."""
        return self.storage.save_dirty()

    def save_all(self) -> int:
        return self.storage.save_all()

    def __repr__(self) -> str:
        return (f"World(name='{self.meta.name}', "
                f"chunks={self.loaded_chunk_count()}, "
                f"voxels={self.total_voxel_count()})")
