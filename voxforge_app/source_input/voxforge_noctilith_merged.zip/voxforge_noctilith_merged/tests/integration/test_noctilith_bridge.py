"""Smoke + behavior tests for the imported Noctilith advanced simulation stack."""
from __future__ import annotations
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import numpy as np


def test_advanced_sim_imports():
    from engine.sim import (
        EntropyField,
        MaterialDegradationModel,
        MaterialDegradationConfig,
        FractureBridge,
        FractureBridgeConfig,
        ThermalCoupler,
        EntropyCoupler,
        WorldReactionBridge,
        DebrisWorldCoupling,
        PROFILE_CACHE,
    )
    assert EntropyField is not None
    assert MaterialDegradationModel(MaterialDegradationConfig()) is not None
    assert FractureBridge(FractureBridgeConfig()) is not None
    assert ThermalCoupler is not None
    assert EntropyCoupler is not None
    assert WorldReactionBridge is not None
    assert DebrisWorldCoupling is not None
    assert PROFILE_CACHE.get(1).voxel_name == "stone"


def test_degradation_and_fracture_pipeline_runs():
    from engine.sim.material_degradation import MaterialDegradationModel, MaterialDegradationConfig
    from engine.sim.fracture import FractureBridge, FractureBridgeConfig
    shape = (8, 8, 8)
    class TG:
        T = np.full(shape, 1500.0, dtype=np.float64)
    class EF:
        S = np.full(shape, 2.0, dtype=np.float64)
    degradation = MaterialDegradationModel(MaterialDegradationConfig(return_risk_field=True))
    d_out = degradation.evaluate(thermal_grid=TG(), entropy_field=EF(), telemetry={"phi_rms_total": 1.0})
    assert "risk_field" in d_out
    assert d_out["risk_field"].shape == shape
    fracture = FractureBridge(FractureBridgeConfig(return_fracture_risk_field=True))
    f_out = fracture.evaluate(external_failure_risk_field=d_out["risk_field"])
    assert "candidate_count" in f_out
    assert "fracture_risk_field" in f_out


def test_debris_and_world_helpers_import():
    from engine.entities import DebrisEntity, DebrisDynamicsSystem
    from engine.world import greedy_mesh, NoctilithChunkData, NoctilithTerrainGen
    from engine.tools.damage_overlay import DamageOverlayBuilder
    ent = DebrisEntity(entity_id=1, position=(0.0, 0.0, 2.0), velocity=(0.0, 0.0, 0.0))
    assert ent.active
    assert DebrisDynamicsSystem() is not None
    voxels = np.zeros((4, 4, 4), dtype=np.int16)
    voxels[1:3, 1:3, 1:3] = 1
    assert len(greedy_mesh(voxels)) > 0
    assert NoctilithChunkData(cx=0, cz=0).voxel_ids.shape == (16, 256, 16)
    assert NoctilithTerrainGen(seed=1).generate_chunk(0, 0).voxel_ids.shape == (16, 256, 16)
    assert DamageOverlayBuilder() is not None
