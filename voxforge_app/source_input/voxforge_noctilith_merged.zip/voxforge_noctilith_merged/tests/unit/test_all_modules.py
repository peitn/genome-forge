"""
tests/unit/test_all_modules.py
================================
Kompletní unit testy pro všechny moduly VoxForge platformy.

Spuštění:
    cd voxforge
    python -m pytest tests/unit/test_all_modules.py -v
    # nebo
    python tests/unit/test_all_modules.py
"""
from __future__ import annotations
import sys, time, traceback, math
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import numpy as np

# ─── Test runner ──────────────────────────────────────────────────────────────

class TestResult:
    def __init__(self):
        self.passed: list = []
        self.failed: list = []
        self.skipped: list = []
        self.total_ms: float = 0.0

    def ok(self, name: str, ms: float = 0.0):
        self.passed.append((name, ms))

    def fail(self, name: str, err: str, ms: float = 0.0):
        self.failed.append((name, err, ms))

    def skip(self, name: str, reason: str = ""):
        self.skipped.append((name, reason))

    def report(self) -> str:
        G = "\033[92m"; R = "\033[91m"; Y = "\033[93m"; W = "\033[97m"; D = "\033[0m"
        lines = [f"\n{W}{'═'*65}{D}",
                 f"{W}  VoxForge Unit Tests — {len(self.passed)+len(self.failed)+len(self.skipped)} tests{D}",
                 f"{W}{'─'*65}{D}"]
        for name, ms in self.passed:
            lines.append(f"  {G}✓{D} {name:<55} {ms:>5.1f}ms")
        for name, err, ms in self.failed:
            lines.append(f"  {R}✗{D} {name:<55} {ms:>5.1f}ms")
            lines.append(f"      {R}{err[:80]}{D}")
        for name, reason in self.skipped:
            lines.append(f"  {Y}○{D} {name} ({reason})")
        lines += [
            f"{W}{'─'*65}{D}",
            f"  {G}Passed: {len(self.passed)}{D}  "
            f"{R}Failed: {len(self.failed)}{D}  "
            f"{Y}Skipped: {len(self.skipped)}{D}",
            f"{W}{'═'*65}{D}",
        ]
        return "\n".join(lines)


def run_test(result: TestResult, name: str, fn) -> None:
    t0 = time.perf_counter()
    try:
        fn()
        ms = (time.perf_counter() - t0) * 1000
        result.ok(name, ms)
    except AssertionError as e:
        ms = (time.perf_counter() - t0) * 1000
        result.fail(name, str(e), ms)
    except Exception as e:
        ms = (time.perf_counter() - t0) * 1000
        result.fail(name, f"{type(e).__name__}: {e}", ms)


# ─── Tests: Core ─────────────────────────────────────────────────────────────

def test_eventbus():
    from engine.core.events import EventBus, EventType, Event
    bus = EventBus()
    received = []
    bus.subscribe(EventType.VOXEL_DESTROYED, lambda e: received.append(e))
    bus.publish(Event(type=EventType.VOXEL_DESTROYED, tick=1,
                      payload={"x": 5, "material": 1}))
    # EventBus doručí synchronně přes publish (bez dispatch)
    assert len(received) == 1, "Event nebyl doručen"
    assert received[0].payload["x"] == 5, "Špatný payload"


def test_ecs():
    from engine.core.ecs import World as ECSWorld
    world = ECSWorld()
    e1 = world.create()
    e2 = world.create()
    assert e1.entity_id != e2.entity_id, "Duplicate entity IDs"
    e1.components["health"] = {"hp": 100}
    e1.components["position"] = {"x": 0, "y": 0, "z": 0}
    assert "health" in e1.components, "Komponenta nenalezena"
    assert e1.components["health"]["hp"] == 100, "Špatná hodnota komponenty"
    world.destroy(e1.entity_id)
    assert world._entities.get(e1.entity_id) is None, "Entita nebyla zničena"


def test_scheduler():
    from engine.core.scheduler import Scheduler, SimModule
    from engine.core.events import EventBus
    bus = EventBus()
    sched = Scheduler(bus)
    ticks_fired = []
    sched.register(SimModule("test_mod", lambda t: ticks_fired.append(t),
                             every_n_ticks=1, priority=0))
    sched.run(10)
    assert len(ticks_fired) == 10, f"Scheduler spustil {len(ticks_fired)} místo 10"
    assert len(set(ticks_fired)) == 10, "Scheduler spustil duplicitní ticky"


def test_scheduler_every_n():
    from engine.core.scheduler import Scheduler, SimModule
    from engine.core.events import EventBus
    bus = EventBus()
    sched = Scheduler(bus)
    fired = []
    sched.register(SimModule("every3", lambda t: fired.append(t),
                             every_n_ticks=3, priority=0))
    sched.run(9)
    assert len(fired) == 3, f"Spustil {len(fired)} místo 3"


# ─── Tests: World ─────────────────────────────────────────────────────────────

def test_voxel_materials():
    from engine.world.voxel import MATERIALS
    stone = MATERIALS.get_by_name("stone")
    assert stone is not None, "Stone material nenalezen"
    assert stone.id == 1, f"Špatné ID: {stone.id}"
    assert stone.is_solid, "Stone není solid"
    water = MATERIALS.get_by_name("water")
    assert water is not None, "Water material nenalezen"
    assert not water.is_solid, "Water je solid (chyba)"


def test_chunk_create():
    from engine.world.chunk import Chunk
    chunk = Chunk(0, 0, 0, size=16)
    assert chunk.materials.shape == (16, 16, 16), "Špatný tvar chunku"
    assert chunk.materials.dtype == np.uint8, "Špatný dtype"
    chunk.materials[5, 5, 5] = 1
    assert chunk.materials[5, 5, 5] == 1, "Zápis do chunku selhal"


def test_chunk_serialize():
    from engine.world.chunk import Chunk
    chunk = Chunk(2, 0, 3, size=16)
    chunk.materials[0:4, 0, 0] = [1, 2, 3, 4]
    data = chunk.to_bytes()
    assert len(data) > 0, "Serializace vrátila prázdná data"
    chunk2 = Chunk.from_bytes(data)
    assert chunk2.cx == 2 and chunk2.cz == 3, "Špatné souřadnice po deserializaci"
    np.testing.assert_array_equal(
        chunk.materials[0:4, 0, 0],
        chunk2.materials[0:4, 0, 0],
        err_msg="Materiály se neshodují po deserializaci"
    )


def test_world_operations():
    from engine.world.world import World
    from engine.core.events import EventBus
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        world = World.create("TestWorld", Path(tmp), bus=EventBus())
        world.set_voxel(5, 1, 5, 1)
        mat = world.get_material(5, 1, 5)
        assert mat == 1, f"get_material vrátil {mat} místo 1"
        assert world.is_solid(5, 1, 5), "Voxel 1 není solid"
        assert not world.is_solid(0, 10, 0), "Vzduch je solid (chyba)"
        world.fill_box(0, 0, 0, 4, 1, 4, 1)
        for x in range(4):
            for z in range(4):
                assert world.get_material(x, 0, z) == 1, f"fill_box selhal @ {x},0,{z}"


# ─── Tests: Simulation ────────────────────────────────────────────────────────

def test_thermal_diffusion():
    from engine.sim.thermal import ThermalGrid
    grid = ThermalGrid((8, 8, 8))
    grid.T[4, 4, 4] = 500.0
    assert grid.T[4, 4, 4] >= 500.0, "Teplo nebylo nastaveno"
    grid.step(0)
    assert grid.T.max() >= 293.0, "Pole korektní"
    assert grid.mean_temp() >= 293.0, "Střední teplota ok"

def test_fluid_simulation():
    from engine.sim.fluid import FluidSimulation
    from engine.core.events import EventBus
    sim = FluidSimulation(8, 8, 8, bus=EventBus())
    sim.grid.add_fluid(4, 6, 4, 1.0)
    vol_initial = float(sim.grid.volume.sum())
    assert vol_initial > 0, "Tekutina nebyla přidána"
    for t in range(20):
        sim.step(t)
    vol_final = float(sim.grid.volume.sum())
    # Objem se zachovává (±5%)
    assert abs(vol_final - vol_initial) / vol_initial < 0.05, \
        f"Fluid volume se nezachovává: {vol_initial:.3f} → {vol_final:.3f}"


def test_chemistry_reactions():
    from engine.sim.chemistry import ChemistrySystem
    mat = np.zeros((8, 8, 8), dtype=np.uint8)
    T = np.full((8, 8, 8), 0.9, dtype=np.float32)   # horko
    S = np.zeros((8, 8, 8), dtype=np.float32)
    D = np.zeros((8, 8, 8), dtype=np.float32)
    M = np.zeros((8, 8, 8), dtype=np.float32)
    # Dřevo by mělo být zapáleno
    mat[3, 3, 3] = 4   # wood
    chem = ChemistrySystem(mat, T, S, D, M)
    assert len(chem.active_reactions) >= 10, \
        f"Málo reakcí: {len(chem.active_reactions)}"
    # Ice melt test
    mat2 = np.zeros((8, 8, 8), dtype=np.uint8)
    T2 = np.full((8, 8, 8), 0.5, dtype=np.float32)   # teplé
    mat2[2, 2, 2] = 8   # ice
    chem2 = ChemistrySystem(mat2, T2, S.copy(), D.copy(), M.copy())
    results = []
    for _ in range(30):
        results.extend(chem2.step(0))
    melt = [r for r in results if r.event_type == "material_melted"]
    assert len(melt) > 0, "Led se neroztavil při teplotě 0.5"


def test_energy_network():
    from engine.sim.energy import EnergyNetwork
    net = EnergyNetwork()
    gen = EnergyNetwork.make_generator("gen", (0,0,0), output=2.0)
    w1  = EnergyNetwork.make_wire("w1", (1,0,0))
    con = EnergyNetwork.make_consumer("load", (2,0,0), consumption=1.0)
    net.add_node(gen); net.add_node(w1); net.add_node(con)
    net.connect("gen", "w1"); net.connect("w1", "load")
    for t in range(5):
        net.step(t)
    assert con.powered, "Spotřebič není napájen"
    stats = net.stats
    assert stats["produced"] > 0, "Žádná produkce energie"
    assert stats["consumed"] > 0, "Žádná spotřeba energie"
    # Switch test
    sw = EnergyNetwork.make_switch("sw", (1,1,0))
    net.add_node(sw)
    net.set_switch("sw", False)
    net.step(10)
    # Generator-switch-consumer chain
    gen2 = EnergyNetwork.make_generator("gen2", (0,1,0), output=2.0)
    con2 = EnergyNetwork.make_consumer("load2", (2,1,0), consumption=1.0)
    net.add_node(gen2); net.add_node(con2)
    net.connect("gen2", "sw"); net.connect("sw", "load2")
    net.step(11)
    assert not con2.powered, "Spotřebič je napájen přes zavřený switch (chyba)"


def test_gas_simulation():
    from engine.sim.gas import GasGrid, GasType
    grid = GasGrid(8, 8, 8)
    grid.emit(4, 1, 4, GasType.SMOKE, 0.8)
    assert grid.concentration[4, 1, 4] > 0, "Plyn nebyl emitován"
    initial = grid.total_gas(GasType.SMOKE)
    for t in range(10):
        grid.step(t)
    # Kouř by měl stoupat (y+)
    upper = float(grid.concentration[4, 4:, 4].sum())
    lower = float(grid.concentration[4, :2, 4].sum())
    # Disperzní útlum — celkové množství klesá
    final = grid.total_gas(GasType.SMOKE)
    assert final < initial, f"Gas se nerozptyluje: {initial:.3f} → {final:.3f}"


def test_weather_simulation():
    from engine.sim.weather import WeatherSimulation, WeatherType
    weather = WeatherSimulation((16, 16, 16), seed=42)
    # Spusť 1000 ticků — alespoň 2 přechody počasí
    weather_types_seen = set()
    for t in range(1000):
        effects = weather.step(t)
        weather_types_seen.add(weather.state.type.value)
    assert len(weather_types_seen) >= 2, \
        f"Počasí se nepřechází: jen {weather_types_seen}"
    assert weather.state.temperature >= 0 and weather.state.temperature <= 1.0, \
        "Teplota mimo rozsah"


# ─── Tests: Scripting ─────────────────────────────────────────────────────────

def test_voxscript_lexer():
    from engine.scripting.voxscript import VoxLexer, TT
    source = "x = 3.14\ny = x + 1\n"
    lexer = VoxLexer(source)
    tokens = lexer.tokenize()
    types = [t.type for t in tokens if t.type != TT.NEWLINE]
    assert TT.IDENT in types, "IDENT token nenalezen"
    assert TT.NUMBER in types, "NUMBER token nenalezen"
    assert TT.ASSIGN in types, "ASSIGN token nenalezen"


def test_voxscript_compile():
    from engine.scripting.voxscript import VoxInterpreter, compile_and_check
    ok, err, ast = compile_and_check("x = 42\ny = x + 1\n")
    assert ok, f"Kompilace selhala: {err}"
    assert ast is not None, "AST je None"
    ok2, err2, _ = compile_and_check("on tick:\n    x = 1\n")
    assert ok2, f"On-handler kompilace selhala: {err2}"


def test_voxscript_run():
    from engine.scripting.voxscript import VoxInterpreter
    interp = VoxInterpreter()
    ast = VoxInterpreter.compile("x = 10\ny = x * 2\nz = y + 5\n")
    interp.run(ast)
    assert interp.get_global("x") == 10, f"x = {interp.get_global('x')}"
    assert interp.get_global("y") == 20, f"y = {interp.get_global('y')}"
    assert interp.get_global("z") == 25, f"z = {interp.get_global('z')}"


def test_voxscript_if():
    from engine.scripting.voxscript import VoxInterpreter
    interp = VoxInterpreter()
    source = "x = 5\nif x > 3:\n    result = 1\nelse:\n    result = 0\n"
    ast = VoxInterpreter.compile(source)
    interp.run(ast)
    assert interp.get_global("result") == 1, "If podmínka selhala"


def test_voxscript_functions():
    from engine.scripting.voxscript import VoxInterpreter
    interp = VoxInterpreter()
    called_args = []
    interp.register("my_func", lambda args: called_args.extend(args))
    ast = VoxInterpreter.compile("my_func(1, 2, 3)\n")
    interp.run(ast)
    assert called_args == [1, 2, 3], f"Funkce dostala {called_args}"


def test_voxscript_sandbox_limit():
    from engine.scripting.voxscript import VoxInterpreter, RuntimeError_
    interp = VoxInterpreter()
    # Nekonečná smyčka by měla být přerušena
    source = "x = 0\nwhile x < 1000000:\n    x = x + 1\n"
    ast = VoxInterpreter.compile(source)
    try:
        interp.run(ast)
        # Buď se dokončí (< MAX_OPS iterací) nebo vyhodí RuntimeError_
        # Whichever, test projde pokud nevyhodí jiný typ chyby
    except RuntimeError_ as e:
        pass  # OK — sandbox limit funguje
    except Exception as e:
        raise AssertionError(f"Neočekávaná výjimka: {e}")


def test_event_graph():
    from engine.scripting.event_graph import EventGraph, Trigger, Action
    graph = EventGraph()
    t = Trigger("t1", "on_tick", {"every": 1})
    a = Action("a1", "show_message", {"text": "hello"})
    graph.add_node("node1", trigger=t, actions=[a])
    ws = {"thermal_max": 0.2, "fluid_total": 0.0, "fluid_max": 0.0,
          "recent_events": [], "powered_nodes": set(), "buttons_pressed": set(),
          "weather": "clear", "agents_in_zones": {}, "max_damage": 0.0,
          "gas_concentration_max": 0.0, "fluid_pressure_high": False}
    fired = graph.evaluate(0, ws)
    assert len(fired) >= 1, "Event graph nespustil žádnou akci"
    assert fired[0]["action_type"] == "show_message", "Špatný typ akce"


# ─── Tests: Physics ───────────────────────────────────────────────────────────

def test_aabb_intersection():
    from engine.physics.rigid_body import AABB, vec3
    a = AABB(min=vec3(0,0,0), max=vec3(2,2,2))
    b = AABB(min=vec3(1,1,1), max=vec3(3,3,3))
    c = AABB(min=vec3(5,5,5), max=vec3(7,7,7))
    assert a.intersects(b), "AABB a,b se nepřekrývají (chyba)"
    assert not a.intersects(c), "AABB a,c se překrývají (chyba)"
    overlap = a.overlap(b)
    assert overlap is not None, "Overlap je None"
    assert abs(float(np.linalg.norm(overlap))) > 0, f"Overlap vektor má nulovou normu: {overlap}"


def test_aabb_raycast():
    from engine.physics.rigid_body import AABB, vec3, PhysicsWorld
    world = PhysicsWorld()
    body = world.create_body("box", position=vec3(5,0,0), size=vec3(1,1,1))
    result = world.raycast(vec3(0,0,0), vec3(1,0,0), max_distance=20.0)
    assert result is not None, "Raycast nenalezl těleso"
    hit_body, hit_point, dist = result
    assert hit_body.body_id == "box", f"Trefeno špatné těleso: {hit_body.body_id}"
    assert 4.0 < dist < 6.0, f"Vzdálenost mimo rozsah: {dist}"


def test_physics_gravity():
    from engine.physics.rigid_body import PhysicsWorld, BodyType, vec3
    world = PhysicsWorld()
    body = world.create_body("ball", BodyType.DYNAMIC,
                              position=vec3(0, 10, 0), mass=1.0)
    initial_y = float(body.position[1])
    dt = 0.016
    for _ in range(30):
        world.step(dt)
    final_y = float(body.position[1])
    assert final_y < initial_y, \
        f"Gravitace nefunguje: y {initial_y:.2f} → {final_y:.2f}"


def test_distance_constraint():
    from engine.physics.rigid_body import (PhysicsWorld, BodyType, DistanceConstraint,
                                             vec3)
    world = PhysicsWorld()
    a = world.create_body("a", BodyType.DYNAMIC, position=vec3(0,5,0), mass=1.0)
    b = world.create_body("b", BodyType.DYNAMIC, position=vec3(3,5,0), mass=1.0)
    rest_len = float(np.linalg.norm(b.position - a.position))
    c = DistanceConstraint(a, b, rest_length=rest_len)
    world.add_constraint(c)
    for _ in range(20):
        world.step(0.016)
    actual_dist = float(np.linalg.norm(b.position - a.position))
    assert abs(actual_dist - rest_len) < 1.0, \
        f"Distance constraint nefunguje: {actual_dist:.2f} vs {rest_len:.2f}"


# ─── Tests: AI ────────────────────────────────────────────────────────────────

def test_pathfinding():
    from engine.ai.agent import Pathfinder
    solid = np.zeros((10, 3, 10), dtype=bool)
    solid[:, 0, :] = True    # podlaha
    pf = Pathfinder()
    path = pf.find_path((1,1,1), (8,1,8), solid)
    assert path is not None, "Cesta nenalezena (volný prostor)"
    assert len(path) > 0, "Cesta je prázdná"
    assert path[-1] == (8,1,8), f"Cesta nekončí v cíli: {path[-1]}"


def test_pathfinding_blocked():
    from engine.ai.agent import Pathfinder
    solid = np.zeros((10, 3, 10), dtype=bool)
    solid[:, 0, :] = True
    # Stěna blokující cestu
    solid[5, :, :] = True
    pf = Pathfinder()
    path = pf.find_path((1,1,1), (8,1,8), solid)
    assert path is None, "Pathfinding našel cestu přes stěnu (chyba)"


def test_npc_agent_lifecycle():
    from engine.ai.agent import NPCAgent, SensoryInput
    agent = NPCAgent("test_npc", (5, 1, 5))
    assert agent.alive, "Agent není naživu při vytvoření"
    assert agent.health == 1.0, f"Špatné health: {agent.health}"
    solid = np.zeros((16, 8, 16), dtype=bool)
    sensory = SensoryInput(temperature=0.2, danger_level=0.1, fluid_nearby=False,
                           gas_toxic=False, light_level=1.0)
    for t in range(10):
        actions = agent.update(t, sensory, solid)
    # Agent by měl přežít 10 bezpečných ticků
    assert agent.alive, "Agent zemřel bez důvodu"


def test_npc_agent_heat_damage():
    from engine.ai.agent import NPCAgent, SensoryInput
    agent = NPCAgent("heat_victim", (5, 1, 5))
    solid = np.zeros((16, 8, 16), dtype=bool)
    hot_sensory = SensoryInput(temperature=0.95, danger_level=0.9)
    initial_health = agent.health
    for t in range(20):
        agent.update(t, hot_sensory, solid)
    assert agent.health < initial_health, "Teplo způsobuje poškození"


def test_swarm_boids():
    from engine.ai.swarm import Swarm, SwarmConfig
    swarm = Swarm(SwarmConfig(), grid_size=(32, 32))
    for i in range(10):
        swarm.add_boid(f"b{i}", np.random.rand(3).astype(np.float32) * 10)
    swarm.set_goal(np.array([20, 0, 20], dtype=np.float32))
    assert len(swarm.boids) == 10, "Špatný počet boidů"
    for _ in range(30):
        swarm.update(dt=0.033)
    stats = swarm.stats
    assert stats["count"] == 10, "Počet boidů se změnil"
    assert stats["avg_speed"] >= 0, "Záporná průměrná rychlost"


def test_swarm_formation():
    from engine.ai.swarm import Swarm, FormationType, compute_formation_offsets
    offsets = compute_formation_offsets(FormationType.V_SHAPE, 7, spacing=2.0)
    assert len(offsets) == 7, f"Počet offsetů: {len(offsets)}"
    assert np.allclose(offsets[0], [0,0,0]), "Leader není na pozici 0"

    offsets_circle = compute_formation_offsets(FormationType.CIRCLE, 8, spacing=2.0)
    assert len(offsets_circle) == 8, f"Circle: {len(offsets_circle)}"
    # Všechny body jsou přibližně stejně daleko od středu
    dists = [float(np.linalg.norm(o)) for o in offsets_circle]
    assert max(dists) - min(dists) < 0.5, f"Kruh není rovnoměrný: {dists}"


# ─── Tests: Assets & Project ─────────────────────────────────────────────────

def test_project_create_load():
    from engine.assets.project import VoxProject, ProjectType
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        proj = VoxProject.create(
            Path(tmp) / "test_proj",
            name="Test Project",
            project_type=ProjectType.SIMULATION,
            author="test_user"
        )
        assert proj.settings.name == "Test Project"
        assert proj.settings.project_type == ProjectType.SIMULATION
        assert (Path(tmp) / "test_proj" / "project.json").exists()

        # Reload
        proj2 = VoxProject.load(Path(tmp) / "test_proj")
        assert proj2.settings.name == proj.settings.name
        assert proj2.settings.project_type == proj.settings.project_type


def test_asset_registry():
    from engine.assets.project import AssetRegistry, AssetMeta, AssetType
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        registry = AssetRegistry(Path(tmp))
        m1 = AssetMeta("mat_001", "Custom Stone", AssetType.MATERIAL,
                        tags=["stone", "custom"])
        m2 = AssetMeta("script_001", "My Script", AssetType.SCRIPT,
                        tags=["logic"])
        registry.register(m1)
        registry.register(m2)
        assert len(registry) == 2, f"Registry má {len(registry)} assetů"
        found = registry.find_by_type(AssetType.MATERIAL)
        assert len(found) == 1, f"Nalezeno {len(found)} material assetů"
        by_tag = registry.find_by_tag("stone")
        assert len(by_tag) == 1, f"Tag search vrátil {len(by_tag)}"
        registry.save()
        registry2 = AssetRegistry(Path(tmp))
        registry2.load()
        assert len(registry2) == 2, "Reload registry selhal"


# ─── Tests: Game ─────────────────────────────────────────────────────────────

def test_health_component():
    from engine.game.rules import HealthComponent
    hp = HealthComponent(max_hp=1.0, armor=0.0)
    damage = hp.apply_damage(0.3)
    assert abs(damage - 0.3) < 0.001, f"Škoda {damage} ≠ 0.3"
    assert abs(hp.current_hp - 0.7) < 0.001, f"HP {hp.current_hp} ≠ 0.7"
    hp.heal(0.2)
    assert abs(hp.current_hp - 0.9) < 0.001, f"HP po healu {hp.current_hp} ≠ 0.9"
    # Armor test
    hp2 = HealthComponent(max_hp=1.0, armor=0.5)
    dmg2 = hp2.apply_damage(0.4)
    assert abs(dmg2 - 0.2) < 0.001, f"Armor škoda {dmg2} ≠ 0.2 (50% armor)"


def test_inventory():
    from engine.game.rules import Inventory
    inv = Inventory(max_slots=5)
    assert inv.add("stone", "Stone", 10), "Přidání selhalo"
    assert inv.add("wood", "Wood", 5), "Přidání selhalo"
    assert inv.count("stone") == 10, f"Počet: {inv.count('stone')}"
    inv.add("stone", "Stone", 3)
    assert inv.count("stone") == 13, "Stack nepracuje správně"
    removed = inv.remove("stone", 5)
    assert removed, "Odebrání selhalo"
    assert inv.count("stone") == 8, f"Po odebrání: {inv.count('stone')}"
    # Full inventory
    inv.add("iron", "Iron", 1)
    inv.add("gold", "Gold", 1)
    inv.add("diamond", "Diamond", 1)
    result = inv.add("extra", "Extra", 1)
    assert not result, "Přidání do plného inventáře mělo selhat"


def test_quest_system():
    from engine.game.rules import Quest, Objective, QuestStatus
    completed_flag = [False]
    quest = Quest("q1", "Test Quest", "A test quest")
    quest.objectives.append(
        Objective("obj1", "Complete task",
                  check_fn=lambda: completed_flag[0])
    )
    quest.start(0)
    assert quest.status == QuestStatus.ACTIVE, "Quest není aktivní"
    status = quest.update(50)
    assert status == QuestStatus.ACTIVE, "Quest dokončen předčasně"
    completed_flag[0] = True
    status = quest.update(100)
    assert status == QuestStatus.COMPLETED, f"Quest status: {status}"
    assert abs(quest.progress - 1.0) < 0.001, f"Progress: {quest.progress}"


def test_teams():
    from engine.game.rules import Team, GameRules
    team_a = Team("red", "Red Team", (255,0,0))
    team_b = Team("blue", "Blue Team", (0,0,255))
    team_a.enemy_teams.add("blue")
    team_b.enemy_teams.add("red")
    rules = GameRules()
    rules.pvp = True
    rules.add_team(team_a)
    rules.add_team(team_b)
    assert team_a.is_enemy("blue"), "Red není nepřítel blue"
    assert not team_a.is_enemy("red"), "Red je nepřítel sama sebe (chyba)"


# ─── Tests: Net/Server ────────────────────────────────────────────────────────

def test_server_join_leave():
    from engine.net.server import VoxServer
    server = VoxServer("TestWorld", max_players=5)
    server.set_owner("player_1")
    session, err = server.handle_join("player_1", "Player One")
    assert err == "", f"Join chyba: {err}"
    assert session is not None, "Session je None"
    assert session.display_name == "Player One"
    # Second player
    session2, err2 = server.handle_join("player_2", "Player Two")
    assert err2 == "", f"Join 2 chyba: {err2}"
    assert server.sessions.player_count == 2
    server.handle_leave(session.session_id)
    assert server.sessions.player_count == 1, "Player count po odchodu"


def test_server_chat():
    from engine.net.server import VoxServer
    server = VoxServer("TestWorld")
    session, _ = server.handle_join("p1", "Player")
    server.handle_chat(session.session_id, "Hello world!")
    history = server.chat.get_history("global")
    assert len(history) >= 1, "Chat history prázdná"
    assert "Hello world!" in history[-1].text


def test_server_permissions():
    from engine.net.server import VoxServer, Permission
    server = VoxServer("TestWorld")
    server.set_owner("owner")
    owner_s, _ = server.handle_join("owner", "Owner")
    player_s, _ = server.handle_join("player", "Player")
    assert owner_s.permission == Permission.OWNER
    assert player_s.permission == Permission.PLAYER
    # Viewer nemůže stavět
    viewer_s, _ = server.handle_join("viewer", "Viewer")
    server.sessions.set_permission("viewer", Permission.VIEWER, owner_s)
    assert not viewer_s.can("build"), "Viewer může stavět (chyba)"
    assert viewer_s.can("chat"), "Viewer nemůže chatovat (chyba)"


# ─── Tests: Procedural Generation ────────────────────────────────────────────

def test_perlin_noise():
    from engine.world.procedural import PerlinNoise3D
    noise = PerlinNoise3D(seed=42)
    val = noise.noise(1.5, 2.3, 0.7)
    assert -1.0 <= val <= 1.0, f"Noise mimo rozsah: {val}"
    # Deterministický
    val2 = noise.noise(1.5, 2.3, 0.7)
    assert val == val2, "Noise není deterministický"
    # fBm
    fbm_val = noise.fbm(1.0, 0.5, 2.0, octaves=4)
    assert -1.0 <= fbm_val <= 1.0, f"fBm mimo rozsah: {fbm_val}"


def test_biome_selector():
    from engine.world.procedural import BiomeSelector, BiomeType
    sel = BiomeSelector()
    ocean = sel.select(0.5, 0.5, 0.05)
    assert ocean == BiomeType.OCEAN, f"Oceán: {ocean}"
    mountain = sel.select(0.3, 0.4, 0.80)
    assert mountain == BiomeType.MOUNTAINS, f"Hory: {mountain}"
    desert = sel.select(0.90, 0.05, 0.4)
    assert desert == BiomeType.DESERT, f"Poušť: {desert}"


def test_world_generator():
    from engine.world.procedural import WorldGenerator, GenConfig
    from engine.world.world import World
    from engine.core.events import EventBus
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        gen = WorldGenerator(GenConfig(seed=123, chunk_size=8))
        world = World.create("GenTest", Path(tmp), bus=EventBus())
        count = gen.populate_world(world, chunks_x=2, chunks_z=2,
                                   chunks_y=2, verbose=False)
        assert count > 0, "Žádné chunky nebyly vygenerovány"
        # Zkontroluj že svět má materiály
        total_solid = 0
        for cx in range(2):
            for cz in range(2):
                for cy in range(2):
                    chunk = world.get_chunk(cx, cy, cz)
                    if chunk:
                        total_solid += int((chunk.materials > 0).sum())
        assert total_solid > 0, "Svět je prázdný (generátor nefunguje)"


# ─── Tests: Render ────────────────────────────────────────────────────────────

def test_naive_mesher():
    from engine.render.mesh import NaiveMesher
    mat = np.zeros((4, 4, 4), dtype=np.uint8)
    mat[1, 1, 1] = 1   # jeden stone voxel uprostřed
    mesher = NaiveMesher()
    mesh = mesher.mesh(mat)
    assert not mesh.is_empty, "Mesh je prázdný"
    # Voxel má 6 stěn, každá 4 vertexy, každá 2 trojúhelníky
    assert mesh.vertex_count == 24, f"Vertexy: {mesh.vertex_count}"
    assert mesh.triangle_count == 12, f"Trojúhelníky: {mesh.triangle_count}"


def test_greedy_mesher():
    from engine.render.mesh import GreedyMesher, NaiveMesher
    mat = np.zeros((8, 8, 8), dtype=np.uint8)
    # Plochá vrstva — greedy merge by měla dát méně polygonů
    mat[:, 0, :] = 1
    greedy = GreedyMesher()
    naive  = NaiveMesher()
    g_mesh = greedy.mesh(mat)
    n_mesh = naive.mesh(mat)
    assert not g_mesh.is_empty, "Greedy mesh je prázdný"
    assert not n_mesh.is_empty, "Naive mesh je prázdný"
    # Greedy by měl mít méně nebo stejně trojúhelníků
    assert g_mesh.triangle_count <= n_mesh.triangle_count, \
        f"Greedy ({g_mesh.triangle_count}) > Naive ({n_mesh.triangle_count})"


# ─── Tests: Plugin System ─────────────────────────────────────────────────────

def test_plugin_register():
    from engine.core.plugin_system import ModuleRegistry, VoxPlugin, PluginStatus
    class TestPlugin(VoxPlugin):
        NAME = "test_plugin"; VERSION = "1.0.0"
        DESCRIPTION = "Test"; AUTHOR = "test"

    registry = ModuleRegistry()
    record = registry.register_class(TestPlugin)
    assert record.name == "test_plugin", f"Jméno: {record.name}"
    assert record.status == PluginStatus.DISCOVERED


def test_plugin_enable():
    from engine.core.plugin_system import (ModuleRegistry, VoxPlugin,
                                           PluginContext, PluginStatus)
    load_called = []
    enable_called = []

    class TestPlugin2(VoxPlugin):
        NAME = "test_plugin2"; VERSION = "1.0.0"
        DESCRIPTION = "Test"; AUTHOR = "test"
        def on_load(self, ctx):
            super().on_load(ctx); load_called.append(True)
        def on_enable(self):
            super().on_enable(); enable_called.append(True)

    registry = ModuleRegistry()
    registry.register_class(TestPlugin2)
    ctx = PluginContext("test_plugin2", engine_ref=None)
    result = registry.enable("test_plugin2", ctx)
    assert result, "Plugin se nepodařilo aktivovat"
    assert len(load_called) == 1, "on_load nebyl zavolán"
    assert len(enable_called) == 1, "on_enable nebyl zavolán"
    assert registry.get("test_plugin2").status == PluginStatus.ACTIVE


def test_resource_manager():
    from engine.core.resource_manager import ResourceManager
    import tempfile, json
    with tempfile.TemporaryDirectory() as tmp:
        rm = ResourceManager(max_cache_mb=10.0)
        rm.add_search_path(Path(tmp))
        # Vytvoř testovací soubor
        test_file = Path(tmp) / "test.json"
        test_file.write_text(json.dumps({"key": "value", "number": 42}))
        handle = rm.load("test.json")
        assert handle is not None, "Resource nebyl načten"
        assert handle.data["key"] == "value", "Data nesouhlasí"
        assert handle.data["number"] == 42, "Číslo nesouhlasí"
        # Z cache
        handle2 = rm.load("test.json")
        assert handle2 is not None, "Cache miss"
        stats = rm.stats
        assert stats["cached_resources"] >= 1


# ─── Main ─────────────────────────────────────────────────────────────────────

TESTS = [
    # Core
    ("Core: EventBus",          test_eventbus),
    ("Core: ECS World",         test_ecs),
    ("Core: Scheduler basic",   test_scheduler),
    ("Core: Scheduler every_n", test_scheduler_every_n),
    # World
    ("World: Materials",        test_voxel_materials),
    ("World: Chunk create",     test_chunk_create),
    ("World: Chunk serialize",  test_chunk_serialize),
    ("World: World operations", test_world_operations),
    # Simulation
    ("Sim: Thermal diffusion",  test_thermal_diffusion),
    ("Sim: Fluid simulation",   test_fluid_simulation),
    ("Sim: Chemistry reactions",test_chemistry_reactions),
    ("Sim: Energy network",     test_energy_network),
    ("Sim: Gas simulation",     test_gas_simulation),
    ("Sim: Weather simulation", test_weather_simulation),
    # Scripting
    ("Script: VoxScript lexer", test_voxscript_lexer),
    ("Script: VoxScript compile",test_voxscript_compile),
    ("Script: VoxScript run",   test_voxscript_run),
    ("Script: VoxScript if",    test_voxscript_if),
    ("Script: VoxScript funcs", test_voxscript_functions),
    ("Script: VoxScript sandbox",test_voxscript_sandbox_limit),
    ("Script: Event graph",     test_event_graph),
    # Physics
    ("Phys: AABB intersection", test_aabb_intersection),
    ("Phys: AABB raycast",      test_aabb_raycast),
    ("Phys: Gravity",           test_physics_gravity),
    ("Phys: Distance constraint",test_distance_constraint),
    # AI
    ("AI: Pathfinding",         test_pathfinding),
    ("AI: Pathfinding blocked", test_pathfinding_blocked),
    ("AI: NPC lifecycle",       test_npc_agent_lifecycle),
    ("AI: NPC heat damage",     test_npc_agent_heat_damage),
    ("AI: Swarm boids",         test_swarm_boids),
    ("AI: Swarm formation",     test_swarm_formation),
    # Assets
    ("Assets: Project create",  test_project_create_load),
    ("Assets: Asset registry",  test_asset_registry),
    # Game
    ("Game: Health component",  test_health_component),
    ("Game: Inventory",         test_inventory),
    ("Game: Quest system",      test_quest_system),
    ("Game: Teams",             test_teams),
    # Net
    ("Net: Server join/leave",  test_server_join_leave),
    ("Net: Server chat",        test_server_chat),
    ("Net: Server permissions", test_server_permissions),
    # Procedural
    ("Proc: Perlin noise",      test_perlin_noise),
    ("Proc: Biome selector",    test_biome_selector),
    ("Proc: World generator",   test_world_generator),
    # Render
    ("Render: Naive mesher",    test_naive_mesher),
    ("Render: Greedy mesher",   test_greedy_mesher),
    # Plugins
    ("Plugin: Register",        test_plugin_register),
    ("Plugin: Enable",          test_plugin_enable),
    ("Plugin: ResourceManager", test_resource_manager),
]


if __name__ == "__main__":
    result = TestResult()
    t_total = time.perf_counter()
    for name, fn in TESTS:
        run_test(result, name, fn)
    result.total_ms = (time.perf_counter() - t_total) * 1000
    print(result.report())
    print(f"  Total time: {result.total_ms:.0f}ms")
    sys.exit(0 if not result.failed else 1)
